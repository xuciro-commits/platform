import { customType, integer, jsonb, pgTable, text, timestamp, varchar, index } from "drizzle-orm/pg-core";

const bytea = customType<{ data: Buffer; driverData: Buffer }>({
  dataType: () => "bytea",
  toDriver: value => value,
  fromDriver: value => value,
});

export const workshopModules = pgTable("workshop_modules", {
  id: varchar("id", { length: 64 }).primaryKey(),
  name: text("name").notNull(),
  definition: jsonb("definition").notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const workshopOntologyPatches = pgTable("workshop_ontology_patches", {
  id: varchar("id", { length: 64 }).primaryKey(),
  objectType: varchar("object_type", { length: 32 }).notNull(),
  objectId: varchar("object_id", { length: 64 }).notNull(),
  patch: jsonb("patch").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const workshopModels = pgTable("workshop_models", {
  id: varchar("id", { length: 64 }).primaryKey(),
  moduleId: varchar("module_id", { length: 64 }).notNull(),
  filename: text("filename").notNull(),
  mime: varchar("mime", { length: 80 }).notNull(),
  byteLength: integer("byte_length").notNull(),
  content: bytea("content").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
}, t => [index("models_module_created_idx").on(t.moduleId, t.createdAt)]);

export const workshopFlowRuns = pgTable("workshop_flow_runs", {
  id: varchar("id", { length: 80 }).primaryKey(),
  moduleId: varchar("module_id", { length: 64 }).notNull(),
  flowId: varchar("flow_id", { length: 80 }).notNull(),
  status: varchar("status", { length: 20 }).notNull(),
  startedAt: timestamp("started_at", { withTimezone: true }).notNull(),
  finishedAt: timestamp("finished_at", { withTimezone: true }),
  processed: integer("processed").notNull(),
  summary: jsonb("summary").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
}, t => [index("flow_runs_module_flow_started_idx").on(t.moduleId, t.flowId, t.startedAt)]);
