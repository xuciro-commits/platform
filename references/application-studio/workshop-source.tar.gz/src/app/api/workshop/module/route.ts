import { db } from "@/db";
import { workshopModules } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

const DEFAULT_ID = "mod-ops-cmd";

export async function GET() {
  try {
    const rows = await db.select().from(workshopModules).where(eq(workshopModules.id, DEFAULT_ID)).limit(1);
    if (!rows[0]) return Response.json({ ok: true, module: null });
    return Response.json({ ok: true, module: rows[0].definition });
  } catch (e) {
    return Response.json({ ok: false, error: String(e) }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  try {
    const body = await req.json() as { id?: string; name?: string; definition: unknown };
    const id = body.id ?? DEFAULT_ID;
    const name = body.name ?? "Operations Command Center";
    const existing = await db.select().from(workshopModules).where(eq(workshopModules.id, id)).limit(1);
    if (existing[0]) {
      await db.update(workshopModules).set({ name, definition: body.definition as object, updatedAt: new Date() }).where(eq(workshopModules.id, id));
    } else {
      await db.insert(workshopModules).values({ id, name, definition: body.definition as object });
    }
    return Response.json({ ok: true });
  } catch (e) {
    return Response.json({ ok: false, error: String(e) }, { status: 500 });
  }
}
