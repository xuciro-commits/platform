import { db } from "@/db";
import { workshopFlowRuns } from "@/db/schema";
import { and, desc, eq } from "drizzle-orm";
import type { FlowRun } from "@/workshop/flowTypes";

export const dynamic = "force-dynamic";
const MODULE_ID = "mod-ops-cmd";

export async function GET(request: Request) {
  try {
    const id = new URL(request.url).searchParams.get("flowId");
    const rows = await db.select().from(workshopFlowRuns)
      .where(id ? and(eq(workshopFlowRuns.moduleId, MODULE_ID), eq(workshopFlowRuns.flowId, id)) : eq(workshopFlowRuns.moduleId, MODULE_ID))
      .orderBy(desc(workshopFlowRuns.startedAt)).limit(30);
    return Response.json({ runs: rows.map(r => ({ id: r.id, flowId: r.flowId, status: r.status, startedAt: r.startedAt, finishedAt: r.finishedAt, processed: r.processed, summary: r.summary })) });
  } catch { return Response.json({ error: "Unable to load run history" }, { status: 500 }); }
}

export async function POST(request: Request) {
  try {
    const body = await request.text();
    if (body.length > 180_000) return Response.json({ error: "Audit summary exceeds 180 KB" }, { status: 413 });
    const run = JSON.parse(body) as FlowRun;
    if (!/^[\w-]{1,80}$/.test(run.id) || !/^[\w-]{1,80}$/.test(run.flowId) || !["success", "partial", "failed", "cancelled"].includes(run.status) || !Number.isFinite(run.startedAt))
      return Response.json({ error: "Invalid completed flow run" }, { status: 400 });
    // Event messages and metrics only. No telemetry rows or other raw payloads in the audit record.
    const summary = {
      error: run.error?.slice(0, 400) ?? null,
      nodeStatuses: run.nodeStatuses,
      events: run.events.slice(-180).map(e => ({ nodeId: e.nodeId, at: e.at, level: e.level, message: e.message.slice(0, 240), rowsIn: e.rowsIn, rowsOut: e.rowsOut, durationMs: e.durationMs, metrics: e.metrics })),
    };
    await db.insert(workshopFlowRuns).values({
      id: run.id, moduleId: MODULE_ID, flowId: run.flowId, status: run.status,
      startedAt: new Date(run.startedAt), finishedAt: run.finishedAt ? new Date(run.finishedAt) : null,
      processed: Math.min(2147483647, Math.max(0, run.processed)), summary,
    }).onConflictDoNothing();
    return Response.json({ ok: true, id: run.id }, { status: 201 });
  } catch { return Response.json({ error: "Run audit was not saved" }, { status: 500 }); }
}
