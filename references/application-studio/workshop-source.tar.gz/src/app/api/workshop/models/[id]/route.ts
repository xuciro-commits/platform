import { db } from "@/db";
import { workshopModels } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!/^[0-9a-f-]{36}$/i.test(id)) return new Response("Invalid model ID", { status: 400 });
  try {
    const [item] = await db.select().from(workshopModels).where(eq(workshopModels.id, id)).limit(1);
    if (!item) return new Response("Model not found", { status: 404 });
    return new Response(new Uint8Array(item.content), {
      status: 200,
      headers: {
        "Content-Type": item.mime,
        "Content-Length": String(item.byteLength),
        "Content-Disposition": `inline; filename="${item.filename.replace(/["\\]/g, "_")}"`,
        "Cache-Control": "private, max-age=60",
        "X-Content-Type-Options": "nosniff",
      },
    });
  } catch { return new Response("Model unavailable", { status: 503 }); }
}
