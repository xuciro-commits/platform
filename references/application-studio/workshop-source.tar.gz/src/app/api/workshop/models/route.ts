import { db } from "@/db";
import { workshopModels } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { randomUUID } from "node:crypto";

export const dynamic = "force-dynamic";
const MODULE_ID = "mod-ops-cmd";
const LIMIT = 15 * 1024 * 1024;

function validateGlb(bytes: Buffer): string | null {
  if (bytes.length < 32 || bytes.readUInt32LE(0) !== 0x46546c67 || bytes.readUInt32LE(4) !== 2) return "Invalid glTF 2.0 GLB header";
  if (bytes.readUInt32LE(8) !== bytes.length) return "GLB declared length does not match the file";
  if (bytes.readUInt32LE(16) !== 0x4e4f534a) return "GLB JSON chunk is missing";
  try { const data = JSON.parse(bytes.subarray(20, 20 + bytes.readUInt32LE(12)).toString("utf8")); if (data.asset?.version !== "2.0") return "Only glTF 2.0 models are supported"; }
  catch { return "GLB JSON chunk is invalid"; }
  return null;
}
function validateGltf(bytes: Buffer): string | null {
  try {
    const data = JSON.parse(bytes.toString("utf8"));
    if (data.asset?.version !== "2.0") return "Only glTF 2.0 models are supported";
    if ((data.buffers ?? []).some((b: { uri?: string }) => b.uri && !b.uri.startsWith("data:"))) return "This GLTF references external buffers. Upload a self-contained .glb instead.";
    if ((data.images ?? []).some((b: { uri?: string }) => b.uri && !b.uri.startsWith("data:"))) return "This GLTF references external images. Upload a self-contained .glb instead.";
    return null;
  } catch { return "GLTF JSON is invalid"; }
}

export async function GET() {
  try {
    const records = await db.select({ id: workshopModels.id, filename: workshopModels.filename, byteLength: workshopModels.byteLength, createdAt: workshopModels.createdAt })
      .from(workshopModels).where(eq(workshopModels.moduleId, MODULE_ID)).orderBy(desc(workshopModels.createdAt)).limit(50);
    return Response.json({ models: records.map(r => ({ ...r, url: `/api/workshop/models/${r.id}` })) });
  } catch { return Response.json({ error: "Unable to load models" }, { status: 500 }); }
}

export async function POST(request: Request) {
  try {
    const form = await request.formData();
    const file = form.get("file");
    if (!(file instanceof File)) return Response.json({ error: "Select a GLB or GLTF file" }, { status: 400 });
    if (file.size < 32 || file.size > LIMIT) return Response.json({ error: "Model must be between 32 bytes and 15 MB" }, { status: 413 });
    const extension = file.name.toLowerCase().endsWith(".glb") ? "glb" : file.name.toLowerCase().endsWith(".gltf") ? "gltf" : null;
    if (!extension) return Response.json({ error: "Only GLB and self-contained GLTF files are accepted" }, { status: 415 });
    const bytes = Buffer.from(await file.arrayBuffer());
    const issue = extension === "glb" ? validateGlb(bytes) : validateGltf(bytes);
    if (issue) return Response.json({ error: issue }, { status: 422 });
    const id = randomUUID();
    const filename = file.name.replace(/[<>\u0000-\u001f]/g, "_").slice(0, 160);
    await db.insert(workshopModels).values({ id, moduleId: MODULE_ID, filename, mime: extension === "glb" ? "model/gltf-binary" : "model/gltf+json", byteLength: bytes.length, content: bytes });
    return Response.json({ id, url: `/api/workshop/models/${id}`, filename, byteLength: bytes.length }, { status: 201 });
  } catch { return Response.json({ error: "Model upload could not be saved" }, { status: 500 }); }
}
