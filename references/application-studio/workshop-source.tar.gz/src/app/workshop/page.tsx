import { Suspense } from "react";
import { WorkshopApp } from "./WorkshopApp";

export const dynamic = "force-dynamic";

export default function WorkshopPage() {
  return (
    <Suspense fallback={<div style={{ padding: 40 }}>Loading Workshop...</div>}>
      <WorkshopApp />
    </Suspense>
  );
}
