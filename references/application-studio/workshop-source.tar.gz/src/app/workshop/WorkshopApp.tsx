"use client";
import { useEffect } from "react";
import { useSearchParams } from "next/navigation";
import { WorkshopProvider, useWorkshop } from "@/workshop/WorkshopContext";
import { BuilderShell } from "@/workshop/shell/BuilderShell";

function ModeSyncer() {
  const params = useSearchParams();
  const { setMode } = useWorkshop();
  useEffect(() => {
    const m = params.get("mode");
    if (m === "runtime" || m === "builder") setMode(m);
  }, [params, setMode]);
  return null;
}

export function WorkshopApp() {
  return (
    <WorkshopProvider initialMode="builder">
      <ModeSyncer />
      <BuilderShell />
    </WorkshopProvider>
  );
}
