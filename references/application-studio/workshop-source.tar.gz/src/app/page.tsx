import Link from "next/link";

export default function HomePage() {
  return (
    <main className="min-h-screen" style={{ background: "var(--fnd-bg)" }}>
      <div className="mx-auto" style={{ maxWidth: 1100, padding: "48px 24px" }}>
        <div className="flex items-center gap-3 mb-8">
          <div style={{ width: 32, height: 32, background: "var(--fnd-text)", color: "white", display: "inline-flex", alignItems: "center", justifyContent: "center", borderRadius: 4, fontSize: 15, fontWeight: 800 }}>F</div>
          <div>
            <div className="text-sm font-semibold">Foundry</div>
            <div className="text-xs fnd-text-muted">Workshop · Operational Application Builder</div>
          </div>
        </div>
        <h1 className="text-2xl font-bold mb-2">Workshop</h1>
        <p className="fnd-text-muted mb-6" style={{ fontSize: 14, lineHeight: 1.6, maxWidth: 760 }}>
          Build ontology-driven operational applications. Compose layouts, bind widgets to object sets,
          define variables with reactive transformations, and author events and actions — then switch to
          View mode to run the resulting application against the live Ontology.
        </p>
        <div className="flex gap-2 mb-10">
          <Link href="/workshop" className="fnd-btn fnd-btn-primary" style={{ height: 36, padding: "0 16px" }}>
            Open Workshop →
          </Link>
          <Link href="/workshop?mode=runtime" className="fnd-btn" style={{ height: 36, padding: "0 16px" }}>
            View Runtime
          </Link>
        </div>

        <div className="grid gap-4" style={{ gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))" }}>
          {[
            { t: "Layout Engine", d: "Pages, Sections (columns/rows/tabs/flow/toolbar/loop), Overlays, Header" },
            { t: "Widget System", d: "50+ widgets · Object Table, Map, Charts, Filter List, Metric, Inline Action, AIP, Embedded Module, Custom Widget" },
            { t: "Variable / Dependency Engine", d: "50+ variables, 8+ definition kinds, 10+ transformations, reactive lineage graph" },
            { t: "Event / Action Engine", d: "15+ event behaviors with chaining · Actions mutate the Ontology" },
            { t: "Ontology-oriented Data Model", d: "Asset, Sensor, Alert, Work Order, Operator, Location · 100+ demo objects" },
            { t: "Diagnostics", d: "Profiler · Changelog with snapshot diffs · Dependency graph · Validation" },
          ].map(c => (
            <div key={c.t} className="fnd-panel rounded-sm p-4">
              <div className="text-sm font-semibold mb-1">{c.t}</div>
              <div className="text-xs fnd-text-muted">{c.d}</div>
            </div>
          ))}
        </div>

        <div className="mt-10 text-xs fnd-text-dim">
          Tip: use <span className="fnd-kbd">⌘Z</span> / <span className="fnd-kbd">⌘⇧Z</span> to undo/redo. Press <span className="fnd-kbd">Esc</span> to close overlays.
        </div>
      </div>
    </main>
  );
}
