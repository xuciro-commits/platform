import { uniquifyTree } from "./moduleOps";
import { makeDemoFlow } from "./flowCatalog";
import { defaultSceneConfig } from "./scene3d/mapping";
import type { ModuleDef, SectionDef, WidgetDef, VariableDef, OverlayDef, PageDef, HeaderDef } from "./types";

// Builds the default Operations Command Center module.
// 5 pages, 4 overlays, 35+ widget instances, 50+ variables, Master-Detail wired up.

function sec(partial: Partial<SectionDef> & { id: string; name: string; layout: SectionDef["layout"] }): SectionDef {
  return {
    children: [],
    showHeader: false,
    direction: partial.layout === "columns" ? "horizontal" : "vertical",
    padding: 8,
    gap: 8,
    background: "default",
    border: false,
    scroll: false,
    collapsible: false,
    defaultCollapsed: false,
    ...partial,
  };
}

function w(id: string, type: WidgetDef["type"], name: string, config: Record<string, unknown> = {}, events: WidgetDef["events"] = []): WidgetDef {
  return { id, type, name, config, events, mountBehavior: "normal", unmountBehavior: "normal" };
}

function v(partial: Partial<VariableDef> & { id: string; name: string; type: VariableDef["type"]; definitionKind: VariableDef["definitionKind"] }): VariableDef {
  return {
    recompute: "automatic",
    dependsOn: [],
    ...partial,
  };
}

export function buildDefaultModule(): ModuleDef {
  const sections: Record<string, SectionDef> = {};
  const widgets: Record<string, WidgetDef> = {};
  const variables: VariableDef[] = [];
  const overlays: OverlayDef[] = [];
  const pages: PageDef[] = [];

  // ── Variables ─────────────────────────────────────────────────────────────
  variables.push(
    v({ id: "allAssets", name: "allAssets", type: "objectSet", definitionKind: "objectSetDefinition", sourceObjectType: "Asset", description: "All assets from Ontology" }),
    v({ id: "statusFilter", name: "statusFilter", type: "array", definitionKind: "static", staticValue: [] as string[], description: "Selected asset statuses" }),
    v({ id: "priorityFilter", name: "priorityFilter", type: "array", definitionKind: "static", staticValue: [] as string[] }),
    v({ id: "ownerFilter", name: "ownerFilter", type: "string", definitionKind: "static", staticValue: "" }),
    v({ id: "searchText", name: "searchText", type: "string", definitionKind: "static", staticValue: "" }),
    v({ id: "pressureMin", name: "pressureMin", type: "numeric", definitionKind: "static", staticValue: "" }),
    v({ id: "pressureMax", name: "pressureMax", type: "numeric", definitionKind: "static", staticValue: "" }),
    v({
      id: "filteredAssets", name: "filteredAssets", type: "objectSet", definitionKind: "objectSetDefinition",
      description: "Objects(Asset).where(status, priority, owner, search, pressure range) — OSDK-style object set",
      objectSet: {
        objectType: "Asset",
        steps: [{ op: "where", clauses: [
          { id: "f1", property: "status", op: "isOneOf", varId: "statusFilter" },
          { id: "f2", property: "priority", op: "isOneOf", varId: "priorityFilter" },
          { id: "f3", property: "owner", op: "contains", varId: "ownerFilter" },
          { id: "f4", property: "*", op: "fullTextSearch", varId: "searchText" },
          { id: "f5", property: "pressure", op: "isGreaterThanOrEqualTo", varId: "pressureMin" },
          { id: "f6", property: "pressure", op: "isLessThanOrEqualTo", varId: "pressureMax" },
        ] }],
      },
    }),
    v({ id: "selectedAssetWorkOrders", name: "selectedAssetWorkOrders", type: "objectSet", definitionKind: "objectSetDefinition", objectSet: { objectType: "Asset", steps: [{ op: "pivotTo", linkTypeApiName: "assetWorkOrders" }] }, inputVarId: "selectedAsset", description: "selectedAsset.pivotTo(\"assetWorkOrders\")" }),
    v({ id: "selectedAssetSensors", name: "selectedAssetSensors", type: "objectSet", definitionKind: "objectSetDefinition", objectSet: { objectType: "Asset", steps: [{ op: "pivotTo", linkTypeApiName: "assetSensors" }] }, inputVarId: "selectedAsset" }),
    v({ id: "filteredAssetAlerts", name: "filteredAssetAlerts", type: "objectSet", definitionKind: "objectSetDefinition", objectSet: { objectType: "Asset", steps: [{ op: "pivotTo", linkTypeApiName: "assetAlerts" }, { op: "where", clauses: [{ id: "a1", property: "acknowledged", op: "is", value: false }] }] }, inputVarId: "filteredAssets", description: "filteredAssets.pivotTo(\"assetAlerts\").where(acknowledged is false)" }),
    v({ id: "selectedAssetRisk", name: "selectedAssetRisk", type: "numeric", definitionKind: "function", functionApiName: "predictFailureRisk", inputVarId: "selectedAsset", description: "Function-backed: predictFailureRisk(selectedAsset)" }),
    v({ id: "filteredRevenueAtRisk", name: "filteredRevenueAtRisk", type: "numeric", definitionKind: "function", functionApiName: "revenueAtRisk", inputVarId: "filteredAssets" }),
    v({ id: "openWorkOrders", name: "openWorkOrders", type: "objectSet", definitionKind: "objectSetDefinition", objectSet: { objectType: "WorkOrder", steps: [{ op: "where", clauses: [{ id: "w1", property: "status", op: "isNot", value: "Done" }] }] } }),
    v({ id: "openWorkOrderCount", name: "openWorkOrderCount", type: "numeric", definitionKind: "variableTransformation", inputVarId: "openWorkOrders", transformations: [{ op: "cardinality" }] }),
    v({ id: "builderAssets", name: "builderAssets", type: "array", definitionKind: "static", staticValue: [] }),
    v({ id: "filteredCount", name: "filteredCount", type: "numeric", definitionKind: "variableTransformation", inputVarId: "filteredAssets", dependsOn: ["filteredAssets"], transformations: [{ op: "cardinality" }] }),
    v({ id: "selectedAsset", name: "selectedAsset", type: "object", definitionKind: "widgetOutput", widgetId: "wObjectTable1", widgetOutputKey: "activeObject", description: "Currently inspected asset" }),
    v({ id: "selectedAssets", name: "selectedAssets", type: "array", definitionKind: "widgetOutput", widgetId: "wObjectTable1", widgetOutputKey: "selectedObjects" }),
    v({ id: "selectedAssetId", name: "selectedAssetId", type: "string", definitionKind: "variableTransformation", inputVarId: "selectedAsset", dependsOn: ["selectedAsset"], transformations: [{ op: "objectProperty", args: { prop: "id" } }] }),
    v({ id: "showDetail", name: "showDetail", type: "boolean", definitionKind: "static", staticValue: true }),
    v({ id: "showEditDrawer", name: "showEditDrawer", type: "boolean", definitionKind: "static", staticValue: false }),
    v({ id: "showActionModal", name: "showActionModal", type: "boolean", definitionKind: "static", staticValue: false }),
    v({ id: "showCreateWO", name: "showCreateWO", type: "boolean", definitionKind: "static", staticValue: false }),
    v({ id: "showConfirmModal", name: "showConfirmModal", type: "boolean", definitionKind: "static", staticValue: false }),
    v({ id: "currentPage", name: "currentPage", type: "string", definitionKind: "static", staticValue: "pOperations" }),
    v({ id: "activeAssetTab", name: "activeAssetTab", type: "numeric", definitionKind: "static", staticValue: 0 }),
    v({ id: "dateRangeStart", name: "dateRangeStart", type: "date", definitionKind: "static", staticValue: "2026-09-01" }),
    v({ id: "dateRangeEnd", name: "dateRangeEnd", type: "date", definitionKind: "static", staticValue: "2026-09-30" }),
    v({ id: "autoRefresh", name: "autoRefresh", type: "boolean", definitionKind: "static", staticValue: false }),
    v({ id: "theme", name: "theme", type: "string", definitionKind: "static", staticValue: "light" }),
    v({ id: "mapZoom", name: "mapZoom", type: "numeric", definitionKind: "static", staticValue: 2 }),
    v({ id: "mapSelectedId", name: "mapSelectedId", type: "string", definitionKind: "widgetOutput", widgetId: "wMap1", widgetOutputKey: "selectedId" }),
    v({ id: "activeAlerts", name: "activeAlerts", type: "objectSet", definitionKind: "objectSetDefinition", sourceObjectType: "Alert" }),
    v({ id: "activeAlertsCount", name: "activeAlertsCount", type: "numeric", definitionKind: "variableTransformation", inputVarId: "activeAlerts", dependsOn: ["activeAlerts"], transformations: [{ op: "cardinality" }] }),
    v({ id: "workOrders", name: "workOrders", type: "objectSet", definitionKind: "objectSetDefinition", sourceObjectType: "WorkOrder" }),
    v({ id: "sensors", name: "sensors", type: "objectSet", definitionKind: "objectSetDefinition", sourceObjectType: "Sensor" }),
    v({ id: "operators", name: "operators", type: "objectSet", definitionKind: "objectSetDefinition", sourceObjectType: "Operator" }),
    v({ id: "locations", name: "locations", type: "objectSet", definitionKind: "objectSetDefinition", sourceObjectType: "Location" }),
    v({ id: "assetsByStatus", name: "assetsByStatus", type: "struct", definitionKind: "objectSetAggregation", inputVarId: "filteredAssets", dependsOn: ["filteredAssets"], transformations: [{ op: "aggregate", args: { by: "status" } }] }),
    v({ id: "assetsByPriority", name: "assetsByPriority", type: "struct", definitionKind: "objectSetAggregation", inputVarId: "filteredAssets", dependsOn: ["filteredAssets"], transformations: [{ op: "aggregate", args: { by: "priority" } }] }),
    v({ id: "avgAvailability", name: "avgAvailability", type: "numeric", definitionKind: "objectSetAggregation", inputVarId: "filteredAssets", dependsOn: ["filteredAssets"], transformations: [{ op: "aggregate", args: { by: "avgAvailability" } }] }),
    v({ id: "revenueAtRisk", name: "revenueAtRisk", type: "numeric", definitionKind: "objectSetAggregation", inputVarId: "filteredAssets", dependsOn: ["filteredAssets"], transformations: [{ op: "aggregate", args: { by: "sumRevenueImpact" } }] }),
    v({ id: "offlineCount", name: "offlineCount", type: "numeric", definitionKind: "objectSetAggregation", inputVarId: "allAssets", dependsOn: ["allAssets"], transformations: [{ op: "aggregate", args: { by: "countOffline" } }] }),
    v({ id: "warningCount", name: "warningCount", type: "numeric", definitionKind: "objectSetAggregation", inputVarId: "allAssets", dependsOn: ["allAssets"], transformations: [{ op: "aggregate", args: { by: "countWarning" } }] }),
    v({ id: "activeCount", name: "activeCount", type: "numeric", definitionKind: "objectSetAggregation", inputVarId: "allAssets", dependsOn: ["allAssets"], transformations: [{ op: "aggregate", args: { by: "countActive" } }] }),
    v({ id: "hasSelection", name: "hasSelection", type: "boolean", definitionKind: "variableTransformation", inputVarId: "selectedAssets", dependsOn: ["selectedAssets"], transformations: [{ op: "cardinality" }, { op: "ifElse", args: { threshold: 0 } }] }),
    v({ id: "selectedAssetName", name: "selectedAssetName", type: "string", definitionKind: "variableTransformation", inputVarId: "selectedAsset", dependsOn: ["selectedAsset"], transformations: [{ op: "objectProperty", args: { prop: "name" } }] }),
    v({ id: "selectedAssetStatus", name: "selectedAssetStatus", type: "string", definitionKind: "variableTransformation", inputVarId: "selectedAsset", dependsOn: ["selectedAsset"], transformations: [{ op: "objectProperty", args: { prop: "status" } }] }),
    v({ id: "selectedAssetOwner", name: "selectedAssetOwner", type: "string", definitionKind: "variableTransformation", inputVarId: "selectedAsset", dependsOn: ["selectedAsset"], transformations: [{ op: "objectProperty", args: { prop: "owner" } }] }),
    v({ id: "sidebarCollapsed", name: "sidebarCollapsed", type: "boolean", definitionKind: "static", staticValue: false }),
    v({ id: "mapLayer", name: "mapLayer", type: "string", definitionKind: "static", staticValue: "status" }),
    v({ id: "chartMetric", name: "chartMetric", type: "string", definitionKind: "static", staticValue: "availability" }),
    v({ id: "selectedTab", name: "selectedTab", type: "numeric", definitionKind: "static", staticValue: 0 }),
    v({ id: "chatInput", name: "chatInput", type: "string", definitionKind: "static", staticValue: "" }),
    v({ id: "chatHistory", name: "chatHistory", type: "array", definitionKind: "static", staticValue: [] }),
    v({ id: "uploadedFile", name: "uploadedFile", type: "string", definitionKind: "static", staticValue: "" }),
    v({ id: "commentDraft", name: "commentDraft", type: "string", definitionKind: "static", staticValue: "" }),
    v({ id: "commentList", name: "commentList", type: "array", definitionKind: "static", staticValue: [] }),
    v({ id: "ganttRange", name: "ganttRange", type: "string", definitionKind: "static", staticValue: "30d" }),
    v({ id: "pdfPage", name: "pdfPage", type: "numeric", definitionKind: "static", staticValue: 1 }),
    v({ id: "selectedWorkOrder", name: "selectedWorkOrder", type: "object", definitionKind: "widgetOutput", widgetId: "wWorkOrderTable", widgetOutputKey: "activeObject" }),
    v({ id: "notificationCount", name: "notificationCount", type: "numeric", definitionKind: "variableTransformation", inputVarId: "activeAlerts", dependsOn: ["activeAlerts"], transformations: [{ op: "cardinality" }] }),
    v({ id: "embeddedModuleAsset", name: "embeddedModuleAsset", type: "object", definitionKind: "static", staticValue: null, isInterface: true, externalId: "selectedAsset", interfaceDirection: "inputOutput" }),
    v({ id: "liveTelemetryStats", name: "liveTelemetryStats", type: "struct", definitionKind: "static", staticValue: null, description: "Published by the Critical vibration detection flow after WASM aggregation" }),
    v({ id: "currentTelemetryRow", name: "currentTelemetryRow", type: "struct", definitionKind: "static", staticValue: null, description: "Metadata-only selected row from the 100k × 100 telemetry table" }),
    v({ id: "selectedScenePart", name: "selectedScenePart", type: "string", definitionKind: "static", staticValue: "", description: "Named GLB part selected in the Digital Twin" }),
    v({ id: "selectedSignal", name: "selectedSignal", type: "numeric", definitionKind: "static", staticValue: 0 }),
  );

  // ── Widgets ───────────────────────────────────────────────────────────────
  // Page 1: Operations
  widgets.wKpi1 = w("wKpi1", "MetricCard", "Active Assets", { label: "Active", variableId: "activeCount", trend: "up", trendValue: "+3", variant: "card" });
  widgets.wKpi2 = w("wKpi2", "MetricCard", "Warnings", { label: "Warnings", variableId: "warningCount", trend: "flat", variant: "card", color: "warning" });
  widgets.wKpi3 = w("wKpi3", "MetricCard", "Offline", { label: "Offline", variableId: "offlineCount", trend: "down", trendValue: "-1", variant: "card", color: "danger" });
  widgets.wKpi4 = w("wKpi4", "MetricCard", "Avg Availability", { label: "Avg Availability", variableId: "avgAvailability", suffix: "%", variant: "card", color: "success" });

  widgets.wFilterList = w("wFilterList", "FilterList", "Asset Filters", {
    objectSetVarId: "allAssets",
    outputFilterVarId: "filteredAssets",
    facets: [
      { property: "status", label: "Status", type: "checkbox", varId: "statusFilter" },
      { property: "priority", label: "Priority", type: "histogram", varId: "priorityFilter" },
      { property: "owner", label: "Owner", type: "search", varId: "ownerFilter" },
    ],
    searchVarId: "searchText",
  });

  widgets.wObjectTable1 = w("wObjectTable1", "ObjectTable", "Assets", {
    objectSetVarId: "filteredAssets",
    activeVarId: "selectedAsset",
    selectedVarId: "selectedAssets",
    columns: [
      { key: "id", label: "ID", width: 90 },
      { key: "name", label: "Name", width: 170 },
      { key: "status", label: "Status", width: 100, formatter: "status" },
      { key: "priority", label: "Priority", width: 90, formatter: "priority" },
      { key: "owner", label: "Owner", width: 130 },
      { key: "pressure", label: "Pressure (bar)", width: 110, formatter: "numeric" },
      { key: "temperature", label: "Temp (°C)", width: 90, formatter: "numeric" },
      { key: "availability", label: "Avail (%)", width: 90, formatter: "numeric" },
      { key: "openAlerts", label: "Alerts", width: 70, formatter: "numeric" },
      { key: "lastInspection", label: "Last inspection", width: 130, formatter: "date" },
    ],
    density: "compact",
    enableSelection: true,
    selectionMode: "multiple",
    enableInlineEdit: true,
    showToolbar: true,
    showSearch: true,
    titleTemplate: "Assets ({count})",
  }, [
    {
      id: "ev1", trigger: "onSelect", actions: [
        { kind: "setVariable", variableId: "showDetail", valueExpr: "true" },
      ],
    },
  ]);

  widgets.wObjectView1 = w("wObjectView1", "ObjectView", "Asset Detail", {
    objectVarId: "selectedAsset",
    formFactor: "panel",
    viewMode: "configured",
    tabs: ["Overview", "Properties", "Links", "History"],
  });
  widgets.wPropList1 = w("wPropList1", "PropertyList", "Properties", {
    objectVarId: "selectedAsset",
    columns: 2,
    hideNull: true,
    properties: ["id", "name", "status", "priority", "owner", "pressure", "temperature", "availability", "model", "installedAt", "lastInspection", "nextMaintenance"],
  });
  widgets.wLinks1 = w("wLinks1", "Links", "Related", {
    objectVarId: "selectedAsset",
    linkTypes: [
      { label: "Sensors", target: "Sensor", linkField: "assetId" },
      { label: "Alerts", target: "Alert", linkField: "assetId" },
      { label: "Work Orders", target: "WorkOrder", linkField: "assetId" },
    ],
  });

  widgets.wButtonGroup1 = w("wButtonGroup1", "ButtonGroup", "Asset Actions", {
    buttons: [
      { label: "Open Detail", variant: "primary", icon: "arrow", eventActions: [{ kind: "openOverlay", overlayId: "oAssetDrawer" }] },
      { label: "Edit Status", variant: "secondary", icon: "edit", eventActions: [{ kind: "openOverlay", overlayId: "oActionModal" }] },
      { label: "Create Work Order", variant: "secondary", icon: "plus", eventActions: [{ kind: "openOverlay", overlayId: "oCreateWOModal" }] },
      { label: "Take offline…", variant: "danger", icon: "trash", eventActions: [{ kind: "openOverlay", overlayId: "oConfirmDrawer" }] },
    ],
  });

  widgets.wSearch1 = w("wSearch1", "TextInput", "Search", { variableId: "searchText", placeholder: "Search assets...", label: "Search" });

  // Page 2: Asset Overview
  widgets.wHeaderText1 = w("wHeaderText1", "HeaderText", "Overview Title", { text: "Operational Asset Overview", variant: "h2" });
  widgets.wObjectSetTitle1 = w("wObjectSetTitle1", "ObjectSetTitle", "Set Title", { objectSetVarId: "filteredAssets" });
  widgets.wObjectList1 = w("wObjectList1", "ObjectList", "Asset Gallery", { objectSetVarId: "filteredAssets", layout: "grid", activeVarId: "selectedAsset" });
  widgets.wMetric5 = w("wMetric5", "MetricCard", "Revenue at Risk", { label: "Revenue at Risk", variableId: "revenueAtRisk", prefix: "$", formatter: "currencyShort", variant: "trend" });
  widgets.wMetric6 = w("wMetric6", "MetricCard", "Open Alerts", { label: "Open Alerts", variableId: "notificationCount", variant: "simple", color: "warning" });
  widgets.wMetric7 = w("wMetric7", "MetricCard", "Filtered Count", { label: "In Filter", variableId: "filteredCount", variant: "tag" });

  // Page 3: Analytics
  widgets.wChart1 = w("wChart1", "ChartXY", "Availability by Status", { objectSetVarId: "filteredAssets", chartKind: "bar", xProperty: "status", yProperty: "availability", agg: "avg" });
  widgets.wChart2 = w("wChart2", "ChartXY", "Pressure over Assets", { objectSetVarId: "filteredAssets", chartKind: "line", xProperty: "id", yProperty: "pressure" });
  widgets.wChart3 = w("wChart3", "ChartPie", "Status Distribution", { objectSetVarId: "filteredAssets", groupBy: "status" });
  widgets.wChart4 = w("wChart4", "ChartPie", "Priority Breakdown", { objectSetVarId: "filteredAssets", groupBy: "priority", variant: "donut" });
  widgets.wPivot = w("wPivot", "PivotTable", "Status × Priority", { objectSetVarId: "filteredAssets", rows: "status", cols: "priority", measure: "count" });
  widgets.wTimeline = w("wTimeline", "Timeline", "Alert Timeline", { objectSetVarId: "activeAlerts" });
  widgets.wVega = w("wVega", "ChartVega", "Vega Status Bars", { objectSetVarId: "filteredAssets" });
  widgets.wWaterfall = w("wWaterfall", "ChartWaterfall", "Status Waterfall", { objectSetVarId: "filteredAssets" });
  widgets.wObs = w("wObs", "ObservabilityChart", "Availability SLO", { objectSetVarId: "filteredAssets" });
  widgets.wFreeForm = w("wFreeForm", "FreeFormAnalysis", "Pressure vs Temp", { objectSetVarId: "filteredAssets" });
  widgets.wTS = w("wTS", "TimeSeriesAnalysis", "Telemetry", { objectSetVarId: "filteredAssets" });
  widgets.wPills = w("wPills", "ExplorationFilter", "Status pills", { variableId: "statusFilter" });
  widgets.wTerms = w("wTerms", "ProminentTerms", "Prominent terms", { objectSetVarId: "filteredAssets", property: "status" });
  widgets.wActionTable = w("wActionTable", "ActionTable", "Bulk edit", { actionId: "updateAssetStatus", objectSetVarId: "filteredAssets" });
  widgets.wVertex = w("wVertex", "VertexGraph", "Neighborhood", { objectVarId: "selectedAsset" });
  // Maintenance board (ontology & workflow widgets)
  widgets.wKanban = w("wKanban", "KanbanBoard", "Asset status board", { objectSetVarId: "filteredAssets", groupBy: "status", actionId: "updateAssetStatus", actionParam: "status", activeVarId: "selectedAsset" });
  widgets.wApproval = w("wApproval", "ApprovalInbox", "Work order approvals", { objectSetVarId: "workOrders", approveActionId: "completeWorkOrder", rejectActionId: "cancelWorkOrder" });
  widgets.wCalendar = w("wCalendar", "Calendar", "Work order calendar", { objectSetVarId: "workOrders", dateProperty: "due", activeVarId: "selectedWorkOrder" });
  widgets.wFeed = w("wFeed", "NotificationFeed", "Action feed", {});
  widgets.wExplorer = w("wExplorer", "GraphExplorer", "Search Around", { objectVarId: "selectedAsset", outputVarId: "selectedWorkOrder" });
  widgets.wRiskGauge = w("wRiskGauge", "Gauge", "Failure risk", { variableId: "selectedAssetRisk", label: "Failure risk (selected)", max: 100, suffix: "%", warnAt: 60 });
  widgets.wOpenWoBar = w("wOpenWoBar", "ProgressBar", "Open work", { valueVarId: "openWorkOrderCount", total: 400, label: "Open work orders" });
  widgets.wOfflineBanner = w("wOfflineBanner", "AlertBanner", "Offline banner", { variableId: "offlineCount", threshold: 0, intent: "danger", message: "{value} assets are Offline — drag them to Maintenance on the board once a crew is assigned." });
  widgets.wBreadcrumb = w("wBreadcrumb", "Breadcrumbs", "Breadcrumbs", { objectVarId: "selectedAsset" });
  widgets.wSelCard = w("wSelCard", "ObjectCard", "Selected asset", { objectVarId: "selectedAsset" });
  // Analytics additions
  widgets.wHeatmap = w("wHeatmap", "Heatmap", "Status × Priority heatmap", { objectSetVarId: "filteredAssets", rows: "status", cols: "priority", rowFilterVarId: "statusFilter", colFilterVarId: "priorityFilter" });
  widgets.wTreemap = w("wTreemap", "Treemap", "Assets by owner", { objectSetVarId: "filteredAssets", groupBy: "owner", filterVarId: "ownerFilter" });
  widgets.wHistogram = w("wHistogram", "Histogram", "Pressure distribution", { objectSetVarId: "filteredAssets", property: "pressure", bins: 14 });
  widgets.wScatter = w("wScatter", "ScatterPlot", "Pressure vs temperature", { objectSetVarId: "filteredAssets", x: "pressure", y: "temperature", colorBy: "status", activeVarId: "selectedAsset" });
  widgets.wLeader = w("wLeader", "Leaderboard", "Top revenue exposure", { objectSetVarId: "filteredAssets", property: "revenueImpact", limit: 8, activeVarId: "selectedAsset" });
  widgets.wRange = w("wRange", "RangeSlider", "Pressure range", { minVarId: "pressureMin", maxVarId: "pressureMax", min: 0, max: 45, label: "Pressure", unit: "bar" });
  widgets.wCompare = w("wCompare", "ObjectComparison", "Compare selected", { objectsVarId: "selectedAssets" });
  widgets.wQuiver = w("wQuiver", "QuiverDashboard", "Quiver KPIs", { title: "Quiver · Fleet KPIs" });

  // Page 4: Map Operations
  widgets.wMap1 = w("wMap1", "Map", "Asset Map", { objectSetVarId: "filteredAssets", activeVarId: "selectedAsset", colorBy: "status", clusterEnabled: true });
  widgets.wGantt = w("wGantt", "Gantt", "Work Order Schedule", { objectSetVarId: "workOrders" });
  widgets.wStatusTracker = w("wStatusTracker", "StatusTracker", "Asset Status", { objectVarId: "selectedAsset", stages: ["Active", "Warning", "Maintenance", "Offline"], activeProp: "status" });

  // Page 5: Workflow
  widgets.wWorkOrderTable = w("wWorkOrderTable", "ObjectTable", "Work Orders", {
    objectSetVarId: "workOrders",
    activeVarId: "selectedWorkOrder",
    columns: [
      { key: "id", label: "ID", width: 110 },
      { key: "title", label: "Title", width: 220 },
      { key: "status", label: "Status", width: 110, formatter: "status" },
      { key: "assetId", label: "Asset", width: 110 },
      { key: "due", label: "Due", width: 120, formatter: "date" },
    ],
    density: "normal",
    enableSelection: true,
    selectionMode: "single",
  });
  widgets.wInlineAction = w("wInlineAction", "InlineAction", "Edit Asset", { actionId: "updateAssetStatus", objectVarId: "selectedAsset" });
  widgets.wCreateWO = w("wCreateWO", "InlineAction", "Create Work Order", { actionId: "createWorkOrder", objectVarId: "selectedAsset" });
  widgets.wConfirmCallout = w("wConfirmCallout", "Callout", "Offline warning", { title: "Take this asset offline?", text: "Offline assets stop producing revenue. The Update asset status action requires High priority when the new status is Offline.", intent: "danger" });
  widgets.wStepper = w("wStepper", "Stepper", "Workflow", { steps: ["Observe", "Investigate", "Decide", "Act"], currentVarId: "selectedTab" });
  widgets.wTabs1 = w("wTabs1", "Tabs", "Section Tabs", { tabs: ["Open", "In Progress", "Done"], variableId: "selectedTab" });
  widgets.wMarkdown = w("wMarkdown", "Markdown", "Runbook", { text: "## Standard Operating Procedure\n\n1. **Observe** telemetry trends in the selected asset.\n2. _Investigate_ anomalies via linked Sensors.\n3. Decide on a mitigation using the Action panel.\n4. Act — submit a Work Order.\n\n> Reference: [Field Manual §4.2](#)\n\n`asset.id` is the primary key." });
  widgets.wPdf = w("wPdf", "PdfViewer", "Compliance PDF", { source: "Compliance_Report_Q3.pdf", pageVarId: "pdfPage", totalPages: 24 });
  widgets.wComments = w("wComments", "Comments", "Discussion", { listVarId: "commentList", draftVarId: "commentDraft" });
  widgets.wMediaUpload = w("wMediaUpload", "MediaUploader", "Upload Reading", { outputVarId: "uploadedFile" });

  // AIP
  widgets.wAIPChat = w("wAIPChat", "AIPChatbot", "AIP Assistant", { historyVarId: "chatHistory", inputVarId: "chatInput", suggestions: ["Summarise active alerts", "Which asset has highest revenue risk?", "Explain the status filter"] });
  widgets.wAIPAnalyst = w("wAIPAnalyst", "AIPAnalyst", "AIP Analyst", { contextVarId: "selectedAsset", outputVarId: "filteredAssets" });
  widgets.wAIPGen = w("wAIPGen", "AIPGenerated", "AIP Insights", { objectVarId: "selectedAsset" });

  // Embed & Custom
  widgets.wEmbedModule = w("wEmbedModule", "EmbeddedModule", "Linked Workbook", { moduleId: "child-asset-detail", bindings: [{ parentVar: "selectedAsset", childInterface: "selectedAsset" }, { parentVar: "theme", childInterface: "theme" }] });
  widgets.wCustom = w("wCustom", "CustomWidget", "Vendor Widget", { widgetSet: "com.vendor.ops", version: "1.4.0", params: [{ name: "inputObjectSet", varId: "filteredAssets" }, { name: "selectedObject", varId: "selectedAsset" }, { name: "title", value: "Vendor Report" }], permissions: ["read.objects", "write.actions"] });
  widgets.wIframe = w("wIframe", "Iframe", "External Dashboard", { url: "https://foundry.local/embed/dashboard", height: 320 });

  // Live industrial telemetry & 3D digital twin
  widgets.wLiveStats = w("wLiveStats", "TelemetryStats", "Fleet vibration · WASM", { assetVarId: "selectedAsset", flowStatsVarId: "liveTelemetryStats", signalIndex: 0, threshold: 11.5, windowRows: 10000 });
  widgets.wDigitalTwin = w("wDigitalTwin", "Scene3D", "Robot cell · live digital twin", { ...defaultSceneConfig() });
  widgets.wLiveTable = w("wLiveTable", "TelemetryTable", "Plant telemetry · 100,000 × 100", { assetVarId: "selectedAsset", selectedSignalVarId: "selectedSignal", rowHeight: 30 });

  // Unused widgets (demo)
  widgets.wUnused1 = w("wUnused1", "ChartXY", "Chart 4 (unused)", { chartKind: "scatter" });
  widgets.wUnused2 = w("wUnused2", "ObjectTable", "Object Table 3 (unused)", {});

  // ── Sections ──────────────────────────────────────────────────────────────
  // Page 1: Operations (Master-Detail)
  sections.sKpiRow = sec({ id: "sKpiRow", name: "KPI Row", layout: "columns", showHeader: false, gap: 8, children: [
    { kind: "widget", id: "wKpi1" }, { kind: "widget", id: "wKpi2" }, { kind: "widget", id: "wKpi3" }, { kind: "widget", id: "wKpi4" },
  ] });
  sections.sMainRow = sec({ id: "sMainRow", name: "Main workspace", layout: "columns", showHeader: false, gap: 8, children: [
    { kind: "section", id: "sFiltersCol" }, { kind: "section", id: "sTableCol" }, { kind: "section", id: "sDetailCol" },
  ] });
  sections.sFiltersCol = sec({ id: "sFiltersCol", name: "Filters", layout: "rows", width: "260px", showHeader: true, title: "Filters", background: "panel", border: true, padding: 10, children: [
    { kind: "widget", id: "wSearch1" }, { kind: "widget", id: "wRange" }, { kind: "widget", id: "wFilterList" },
  ] });
  // Page 6: Maintenance board
  sections.sMbTop = sec({ id: "sMbTop", name: "Board header", layout: "columns", gap: 8, children: [
    { kind: "widget", id: "wBreadcrumb" }, { kind: "widget", id: "wOpenWoBar" },
  ] });
  sections.sMbBoard = sec({ id: "sMbBoard", name: "Board", layout: "columns", gap: 8, children: [
    { kind: "widget", id: "wKanban" }, { kind: "section", id: "sMbSide" },
  ] });
  sections.sMbSide = sec({ id: "sMbSide", name: "Context", layout: "rows", width: "320px", gap: 8, children: [
    { kind: "widget", id: "wSelCard" }, { kind: "widget", id: "wRiskGauge" }, { kind: "widget", id: "wExplorer" },
  ] });
  sections.sMbBottom = sec({ id: "sMbBottom", name: "Work", layout: "columns", gap: 8, children: [
    { kind: "widget", id: "wApproval" }, { kind: "widget", id: "wCalendar" }, { kind: "widget", id: "wFeed" },
  ] });
  sections.sMaintRoot = sec({ id: "sMaintRoot", name: "Maintenance Board", layout: "rows", gap: 10, padding: 10, scroll: true, children: [
    { kind: "widget", id: "wOfflineBanner" }, { kind: "section", id: "sMbTop" }, { kind: "section", id: "sMbBoard" }, { kind: "section", id: "sMbBottom" },
  ] });
  sections.sAnalyticsRow5 = sec({ id: "sAnalyticsRow5", name: "Row 5", layout: "columns", gap: 8, children: [
    { kind: "widget", id: "wHeatmap" }, { kind: "widget", id: "wTreemap" }, { kind: "widget", id: "wHistogram" },
  ] });
  sections.sAnalyticsRow6 = sec({ id: "sAnalyticsRow6", name: "Row 6", layout: "columns", gap: 8, children: [
    { kind: "widget", id: "wScatter" }, { kind: "widget", id: "wLeader" }, { kind: "widget", id: "wCompare" },
  ] });
  sections.sTableCol = sec({ id: "sTableCol", name: "Assets", layout: "rows", showHeader: false, children: [
    { kind: "widget", id: "wObjectTable1" },
  ] });
  sections.sDetailCol = sec({ id: "sDetailCol", name: "Detail", layout: "rows", width: "360px", showHeader: true, title: "Detail", background: "panel", border: true, padding: 10, collapsible: true, visibleVariableId: "showDetail", children: [
    { kind: "widget", id: "wObjectSetTitle1" }, { kind: "widget", id: "wStatusTracker" }, { kind: "widget", id: "wPropList1" }, { kind: "widget", id: "wLinks1" }, { kind: "widget", id: "wButtonGroup1" },
  ] });
  sections.sOperationsRoot = sec({ id: "sOperationsRoot", name: "Operations", layout: "rows", gap: 10, padding: 10, scroll: true, children: [
    { kind: "section", id: "sKpiRow" }, { kind: "section", id: "sMainRow" },
  ] });

  // Page 2: Asset Overview
  sections.sOverviewHdr = sec({ id: "sOverviewHdr", name: "Header", layout: "rows", children: [
    { kind: "widget", id: "wHeaderText1" }, { kind: "widget", id: "wObjectSetTitle1" },
  ] });
  sections.sOverviewKpi = sec({ id: "sOverviewKpi", name: "Metrics", layout: "columns", gap: 8, children: [
    { kind: "widget", id: "wMetric5" }, { kind: "widget", id: "wMetric6" }, { kind: "widget", id: "wMetric7" },
  ] });
  sections.sOverviewList = sec({ id: "sOverviewList", name: "List", layout: "rows", children: [
    { kind: "widget", id: "wObjectList1" },
  ] });
  sections.sOverviewRoot = sec({ id: "sOverviewRoot", name: "Overview Root", layout: "rows", gap: 10, padding: 12, scroll: true, children: [
    { kind: "section", id: "sOverviewHdr" }, { kind: "section", id: "sOverviewKpi" }, { kind: "section", id: "sOverviewList" },
  ] });

  // Page 3: Analytics
  sections.sAnalyticsRow1 = sec({ id: "sAnalyticsRow1", name: "Row 1", layout: "columns", gap: 8, children: [
    { kind: "widget", id: "wChart1" }, { kind: "widget", id: "wChart2" },
  ] });
  sections.sAnalyticsRow2 = sec({ id: "sAnalyticsRow2", name: "Row 2", layout: "columns", gap: 8, children: [
    { kind: "widget", id: "wChart3" }, { kind: "widget", id: "wChart4" }, { kind: "widget", id: "wPivot" },
  ] });
  sections.sAnalyticsRow3 = sec({ id: "sAnalyticsRow3", name: "Row 3", layout: "columns", gap: 8, children: [
    { kind: "widget", id: "wVega" }, { kind: "widget", id: "wWaterfall" }, { kind: "widget", id: "wObs" },
  ] });
  sections.sAnalyticsRow4 = sec({ id: "sAnalyticsRow4", name: "Row 4", layout: "columns", gap: 8, children: [
    { kind: "widget", id: "wFreeForm" }, { kind: "widget", id: "wTS" },
  ] });
  sections.sAnalyticsRoot = sec({ id: "sAnalyticsRoot", name: "Analytics", layout: "rows", gap: 10, padding: 12, scroll: true, children: [
    { kind: "widget", id: "wPills" }, { kind: "widget", id: "wTerms" },
    { kind: "section", id: "sAnalyticsRow5" }, { kind: "section", id: "sAnalyticsRow6" },
    { kind: "section", id: "sAnalyticsRow1" }, { kind: "section", id: "sAnalyticsRow2" },
    { kind: "section", id: "sAnalyticsRow3" }, { kind: "section", id: "sAnalyticsRow4" },
    { kind: "widget", id: "wTimeline" },
  ] });

  // Page 4: Map Operations
  sections.sMapRoot = sec({ id: "sMapRoot", name: "Map Operations", layout: "rows", gap: 8, padding: 10, scroll: true, children: [
    { kind: "section", id: "sKpiRow" }, { kind: "widget", id: "wMap1" }, { kind: "widget", id: "wGantt" },
  ] });

  // Page 5: Workflow
  sections.sWfTabs = sec({ id: "sWfTabs", name: "WF Tabs", layout: "tabs", tabs: [{ id: "t1", label: "Work Orders", childIndex: 0 }, { id: "t2", label: "Runbook", childIndex: 1 }, { id: "t3", label: "AIP", childIndex: 2 }, { id: "t4", label: "Comments", childIndex: 3 }], children: [
    { kind: "widget", id: "wWorkOrderTable" }, { kind: "widget", id: "wMarkdown" }, { kind: "widget", id: "wAIPChat" }, { kind: "widget", id: "wComments" },
  ] });
  sections.sWfSide = sec({ id: "sWfSide", name: "Side", layout: "rows", width: "320px", background: "panel", border: true, padding: 10, children: [
    { kind: "widget", id: "wStepper" }, { kind: "widget", id: "wInlineAction" }, { kind: "widget", id: "wMediaUpload" }, { kind: "widget", id: "wVertex" },
  ] });
  sections.sWfExtra = sec({ id: "sWfExtra", name: "Bulk + Quiver", layout: "columns", gap: 8, children: [
    { kind: "widget", id: "wActionTable" }, { kind: "widget", id: "wQuiver" },
  ] });
  sections.sWfMain = sec({ id: "sWfMain", name: "Main", layout: "columns", gap: 8, children: [
    { kind: "section", id: "sWfTabs" }, { kind: "section", id: "sWfSide" },
  ] });
  sections.sWorkflowRoot = sec({ id: "sWorkflowRoot", name: "Workflow", layout: "rows", gap: 8, padding: 10, scroll: true, children: [
    { kind: "section", id: "sWfMain" }, { kind: "section", id: "sWfExtra" },
  ] });

  // Live telemetry workspace: WASM statistics + articulated model + columnar 100K × 100 table
  sections.sTelemetryMain = sec({ id: "sTelemetryMain", name: "Live operations", layout: "columns", gap: 10, children: [
    { kind: "widget", id: "wDigitalTwin" }, { kind: "section", id: "sTelemetrySide" },
  ] });
  sections.sTelemetrySide = sec({ id: "sTelemetrySide", name: "Signal analysis", layout: "rows", width: "365px", gap: 8, children: [
    { kind: "widget", id: "wLiveStats" }, { kind: "widget", id: "wObjectView1" },
  ] });
  sections.sTelemetryRoot = sec({ id: "sTelemetryRoot", name: "Industrial stream", layout: "rows", gap: 10, padding: 12, scroll: true, children: [
    { kind: "section", id: "sTelemetryMain" }, { kind: "widget", id: "wLiveTable" },
  ] });
  widgets.wDigitalTwin.height = 490;
  widgets.wLiveTable.height = 510;
  widgets.wLiveStats.height = 220;
  widgets.wObjectView1.height = 255;

  // Overlays
  sections.sDrawerRoot = sec({ id: "sDrawerRoot", name: "Drawer Content", layout: "rows", gap: 10, padding: 14, scroll: true, children: [
    { kind: "widget", id: "wObjectSetTitle1" }, { kind: "widget", id: "wPropList1" }, { kind: "widget", id: "wLinks1" }, { kind: "widget", id: "wAIPGen" }, { kind: "widget", id: "wButtonGroup1" },
  ] });
  sections.sConfirmRoot = sec({ id: "sConfirmRoot", name: "Confirm", layout: "rows", gap: 10, padding: 14, children: [
    { kind: "widget", id: "wConfirmCallout" }, { kind: "widget", id: "wInlineAction" },
  ] });
  sections.sActionModalRoot = sec({ id: "sActionModalRoot", name: "Action Modal", layout: "rows", gap: 10, padding: 14, children: [
    { kind: "widget", id: "wInlineAction" },
  ] });
  sections.sCreateWORoot = sec({ id: "sCreateWORoot", name: "Create WO", layout: "rows", gap: 10, padding: 14, children: [
    { kind: "widget", id: "wCreateWO" },
  ] });

  overlays.push(
    { id: "oAssetDrawer", name: "Asset Detail Drawer", kind: "drawer", rootSectionId: "sDrawerRoot", side: "right", size: "medium", backdrop: true, closeOnBackdrop: true, closeOnEsc: true, openVariableId: "showEditDrawer" },
    { id: "oConfirmDrawer", name: "Confirm Offline", kind: "drawer", rootSectionId: "sConfirmRoot", side: "right", size: "small", backdrop: true, closeOnBackdrop: true, closeOnEsc: true, openVariableId: "showConfirmModal" },
    { id: "oActionModal", name: "Edit Status Modal", kind: "modal", rootSectionId: "sActionModalRoot", title: "Edit Asset Status", backdrop: true, closeOnBackdrop: false, closeOnEsc: true, openVariableId: "showActionModal" },
    { id: "oCreateWOModal", name: "Create Work Order Modal", kind: "modal", rootSectionId: "sCreateWORoot", title: "Create Work Order", backdrop: true, closeOnBackdrop: true, closeOnEsc: true, openVariableId: "showCreateWO" },
  );

  // Pages
  pages.push(
    { id: "pOperations", name: "Operations", rootSectionId: "sOperationsRoot" },
    { id: "pOverview", name: "Asset Overview", rootSectionId: "sOverviewRoot" },
    { id: "pAnalytics", name: "Analytics", rootSectionId: "sAnalyticsRoot" },
    { id: "pMap", name: "Map Operations", rootSectionId: "sMapRoot" },
    { id: "pWorkflow", name: "Workflow", rootSectionId: "sWorkflowRoot" },
    { id: "pMaintenance", name: "Maintenance Board", rootSectionId: "sMaintRoot" },
    { id: "pTelemetry", name: "Digital Twin & Telemetry", rootSectionId: "sTelemetryRoot" },
  );

  const header: HeaderDef = {
    variant: "horizontal",
    title: "Operations Command Center",
    items: [
      { kind: "logo" }, { kind: "title" },
      { kind: "tabs", pageIds: pages.map(p => p.id) },
      { kind: "spacer" },
      { kind: "button", label: "Refresh", eventActions: [{ kind: "refreshData" }] },
      { kind: "button", label: "Theme", eventActions: [{ kind: "toggleTheme" }] },
    ],
  };

  return uniquifyTree({
    id: "mod-ops-cmd",
    name: "Operations Command Center",
    description: "Monitor assets, triage alerts, and dispatch work orders across the global fleet.",
    header,
    pages,
    sections,
    widgets,
    overlays,
    variables,
    flows: [makeDemoFlow()],
    unusedWidgetIds: ["wUnused1", "wUnused2"],
    usedObjectTypes: ["Asset", "Sensor", "Alert", "WorkOrder", "Operator", "Location"],
    usedActions: ["updateAssetStatus", "createWorkOrder", "acknowledgeAlert"],
    usedFunctions: ["aggregateByStatus", "revenueAtRisk"],
    moduleInterface: [
      { variableId: "selectedAsset", externalId: "selectedAsset", direction: "inputOutput", description: "The currently inspected asset" },
      { variableId: "currentPage", externalId: "currentPage", direction: "inputOutput" },
      { variableId: "showDetail", externalId: "showDetail", direction: "input" },
    ],
    savedState: "saved",
  });
}
