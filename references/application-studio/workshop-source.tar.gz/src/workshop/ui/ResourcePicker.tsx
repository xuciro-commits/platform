"use client";
import React, { useEffect, useMemo, useRef, useState } from "react";
import { useWorkshop } from "../WorkshopContext";
import { Icon } from "../widgets/icons";

export function ResourcePicker({
  value, onChange, kinds = ["variable"], placeholder = "Search resources…",
}: {
  value?: string;
  onChange: (id: string) => void;
  kinds?: Array<"variable" | "action" | "objectType" | "function" | "page" | "overlay" | "widget">;
  placeholder?: string;
}) {
  const { module, ontologyMeta } = useWorkshop();
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const [idx, setIdx] = useState(0);
  const ref = useRef<HTMLDivElement>(null);

  const results = useMemo(() => {
    const out: Array<{ id: string; label: string; meta: string; group: string }> = [];
    if (kinds.includes("variable")) {
      for (const v of module.variables) out.push({ id: v.id, label: `@${v.name}`, meta: v.type, group: "Variables" });
    }
    if (kinds.includes("action")) {
      for (const a of ontologyMeta.actionTypes) out.push({ id: a.apiName, label: a.displayName, meta: a.apiName, group: "Action types" });
    }
    if (kinds.includes("objectType")) {
      for (const t of ontologyMeta.objectTypes) out.push({ id: t.apiName, label: t.displayName, meta: "object type", group: "Object types" });
    }
    if (kinds.includes("function")) {
      for (const f of ontologyMeta.functions) out.push({ id: f.apiName, label: f.displayName, meta: f.output, group: "Functions" });
    }
    if (kinds.includes("page")) {
      for (const p of module.pages) out.push({ id: p.id, label: p.name, meta: p.id, group: "Pages" });
    }
    if (kinds.includes("overlay")) {
      for (const o of module.overlays) out.push({ id: o.id, label: o.name, meta: o.kind, group: "Overlays" });
    }
    if (kinds.includes("widget")) {
      for (const w of Object.values(module.widgets)) out.push({ id: w.id, label: w.name, meta: w.type, group: "Widgets" });
    }
    const qq = q.toLowerCase();
    return qq ? out.filter(r => r.label.toLowerCase().includes(qq) || r.id.toLowerCase().includes(qq) || r.meta.toLowerCase().includes(qq)) : out;
  }, [module, ontologyMeta, kinds, q]);

  useEffect(() => { setIdx(0); }, [q, open]);

  const current = results.find(r => r.id === value);

  return (
    <div ref={ref} className="relative">
      <button type="button" className="fnd-input text-left flex items-center gap-1" onClick={() => setOpen(o => !o)}>
        <span className="flex-1 truncate">{current ? current.label : (value ? value : "—")}</span>
        <Icon.Chevron size={12}/>
      </button>
      {open && (
        <div className="fnd-panel" style={{ position: "absolute", zIndex: 40, left: 0, right: 0, top: 30, maxHeight: 260, overflow: "hidden", display: "flex", flexDirection: "column", boxShadow: "0 8px 20px rgba(0,0,0,0.14)" }}>
          <div className="p-1 border-b fnd-border">
            <input autoFocus className="fnd-input" placeholder={placeholder} value={q} onChange={e => setQ(e.target.value)}
              onKeyDown={e => {
                if (e.key === "ArrowDown") { setIdx(i => Math.min(results.length - 1, i + 1)); e.preventDefault(); }
                else if (e.key === "ArrowUp") { setIdx(i => Math.max(0, i - 1)); e.preventDefault(); }
                else if (e.key === "Enter" && results[idx]) { onChange(results[idx].id); setOpen(false); }
                else if (e.key === "Escape") setOpen(false);
              }}/>
          </div>
          <div className="flex-1 overflow-auto">
            {results.length === 0 && <div className="p-2 text-xs fnd-text-dim">No matching resources.</div>}
            {results.map((r, i) => (
              <button key={r.group + r.id} className="w-full text-left px-2 py-1 flex items-center gap-2"
                style={{ background: i === idx ? "var(--fnd-selection)" : "transparent", fontSize: 12 }}
                onMouseEnter={() => setIdx(i)}
                onClick={() => { onChange(r.id); setOpen(false); }}>
                <span className="flex-1 truncate">{r.label}</span>
                <span className="fnd-tag">{r.meta}</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
