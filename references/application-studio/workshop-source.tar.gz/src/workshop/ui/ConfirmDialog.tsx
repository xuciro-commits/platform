"use client";
import React from "react";
import { Icon } from "../widgets/icons";

export function ConfirmDialog({
  title, message, impact, confirmLabel, onConfirm, onCancel,
}: {
  title: string; message: string; impact: string[]; confirmLabel?: string;
  onConfirm: () => void; onCancel: () => void;
}) {
  return (
    <div className="fnd-overlay-backdrop" onClick={onCancel}>
      <div className="fnd-panel fnd-fade-in" onClick={e => e.stopPropagation()} style={{
        position: "fixed", top: "22%", left: "50%", transform: "translateX(-50%)",
        width: "min(460px, 92vw)", zIndex: 70, borderRadius: 4, boxShadow: "0 10px 40px rgba(0,0,0,0.2)",
      }}>
        <div className="flex items-center gap-2 px-3 py-2 border-b fnd-border">
          <Icon.Warning size={14}/>
          <div className="text-sm font-semibold">{title}</div>
        </div>
        <div className="p-3 text-xs space-y-2">
          <div>{message}</div>
          {impact.length > 0 && (
            <div className="rounded-sm p-2" style={{ background: "#fdf1dc", border: "1px solid #f0d49a" }}>
              <div className="font-semibold mb-1" style={{ color: "#8a5a16" }}>Impact</div>
              {impact.map((l, i) => <div key={i} style={{ color: "#5c4a20" }}>· {l}</div>)}
            </div>
          )}
        </div>
        <div className="flex justify-end gap-2 px-3 py-2 border-t fnd-border">
          <button className="fnd-btn" onClick={onCancel}>Cancel</button>
          <button className="fnd-btn fnd-btn-danger" onClick={onConfirm}>{confirmLabel ?? "Delete"}</button>
        </div>
      </div>
    </div>
  );
}
