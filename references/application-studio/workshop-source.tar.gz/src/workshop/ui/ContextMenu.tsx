"use client";
import React, { useEffect } from "react";

export interface MenuItem {
  label: string;
  shortcut?: string;
  danger?: boolean;
  disabled?: boolean;
  separator?: boolean;
  onClick?: () => void;
}

export function ContextMenu({ x, y, items, onClose }: { x: number; y: number; items: MenuItem[]; onClose: () => void }) {
  useEffect(() => {
    const h = (e: MouseEvent) => { if (!(e.target as HTMLElement).closest?.("[data-fnd-menu]")) onClose(); };
    const k = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("mousedown", h);
    window.addEventListener("keydown", k);
    return () => { window.removeEventListener("mousedown", h); window.removeEventListener("keydown", k); };
  }, [onClose]);
  const left = Math.min(x, (typeof window !== "undefined" ? window.innerWidth : 800) - 220);
  const top = Math.min(y, (typeof window !== "undefined" ? window.innerHeight : 600) - 8 - items.length * 26);
  return (
    <div data-fnd-menu className="fnd-panel fnd-fade-in" style={{
      position: "fixed", left, top, zIndex: 80, minWidth: 200, padding: "4px 0",
      boxShadow: "0 6px 18px rgba(0,0,0,0.16)", borderRadius: 3,
    }}>
      {items.map((it, i) => it.separator ? (
        <div key={i} style={{ height: 1, background: "var(--fnd-border)", margin: "4px 0" }}/>
      ) : (
        <button key={i} disabled={it.disabled} onClick={() => { if (!it.disabled) { it.onClick?.(); onClose(); } }}
          className="w-full text-left flex items-center px-3"
          style={{
            height: 26, fontSize: 12, background: "transparent", border: 0, cursor: it.disabled ? "not-allowed" : "pointer",
            color: it.danger ? "var(--fnd-danger)" : it.disabled ? "var(--fnd-text-dim)" : "var(--fnd-text)",
            opacity: it.disabled ? 0.5 : 1,
          }}
          onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = "var(--fnd-hover)"; }}
          onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = "transparent"; }}
        >
          <span className="flex-1">{it.label}</span>
          {it.shortcut && <span className="fnd-text-dim text-[10px]">{it.shortcut}</span>}
        </button>
      ))}
    </div>
  );
}
