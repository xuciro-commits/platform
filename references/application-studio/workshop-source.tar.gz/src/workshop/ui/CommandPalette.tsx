"use client";
import React, { useEffect, useMemo, useState } from "react";
import { useWorkshop } from "../WorkshopContext";

export function CommandPalette({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { module, select, setCurrentPageId, setMode, undo, redo, snapshot, setLeftPanel, toggleTheme, openOverlay } = useWorkshop();
  const [q, setQ] = useState("");
  const [idx, setIdx] = useState(0);

  const commands = useMemo(() => {
    const cmds: Array<{ id: string; label: string; group: string; run: () => void }> = [
      { id: "mode-edit", label: "Switch to Edit mode", group: "Mode", run: () => setMode("builder") },
      { id: "mode-view", label: "Switch to View mode", group: "Mode", run: () => setMode("runtime") },
      { id: "undo", label: "Undo", group: "Edit", run: undo },
      { id: "redo", label: "Redo", group: "Edit", run: redo },
      { id: "snap", label: "Take snapshot", group: "Edit", run: () => snapshot(`v${Date.now().toString().slice(-4)}`) },
      { id: "theme", label: "Toggle theme", group: "View", run: toggleTheme },
      { id: "p-layout", label: "Open Layout panel", group: "Navigate", run: () => setLeftPanel("layout") },
      { id: "p-vars", label: "Open Variables panel", group: "Navigate", run: () => setLeftPanel("variables") },
      { id: "p-ov", label: "Open Overview panel", group: "Navigate", run: () => setLeftPanel("overview") },
      { id: "p-prof", label: "Open Profiler", group: "Navigate", run: () => setLeftPanel("profiler") },
      { id: "p-log", label: "Open Changelog", group: "Navigate", run: () => setLeftPanel("changelog") },
      { id: "p-set", label: "Open Settings", group: "Navigate", run: () => setLeftPanel("settings") },
    ];
    for (const p of module.pages) cmds.push({ id: `page-${p.id}`, label: `Go to page: ${p.name}`, group: "Pages", run: () => { setCurrentPageId(p.id); select({ kind: "page", id: p.id }); } });
    for (const o of module.overlays) cmds.push({ id: `ov-${o.id}`, label: `Open overlay: ${o.name}`, group: "Overlays", run: () => { openOverlay(o.id); select({ kind: "overlay", id: o.id }); } });
    for (const w of Object.values(module.widgets).slice(0, 40)) cmds.push({ id: `w-${w.id}`, label: `Select widget: ${w.name}`, group: "Widgets", run: () => select({ kind: "widget", id: w.id }) });
    const qq = q.toLowerCase();
    return qq ? cmds.filter(c => c.label.toLowerCase().includes(qq)) : cmds;
  }, [module, q, select, setCurrentPageId, setMode, undo, redo, snapshot, setLeftPanel, toggleTheme, openOverlay]);

  useEffect(() => { setIdx(0); }, [q, open]);
  useEffect(() => { if (open) setQ(""); }, [open]);

  if (!open) return null;
  return (
    <div className="fnd-overlay-backdrop" onClick={onClose}>
      <div className="fnd-panel fnd-fade-in" onClick={e => e.stopPropagation()} style={{
        position: "fixed", top: "14%", left: "50%", transform: "translateX(-50%)",
        width: "min(560px, 92vw)", zIndex: 80, borderRadius: 4, boxShadow: "0 12px 40px rgba(0,0,0,0.22)",
        display: "flex", flexDirection: "column", maxHeight: "70vh",
      }}>
        <div className="p-2 border-b fnd-border">
          <input autoFocus className="fnd-input" style={{ height: 32 }} placeholder="Type a command…" value={q} onChange={e => setQ(e.target.value)}
            onKeyDown={e => {
              if (e.key === "ArrowDown") { setIdx(i => Math.min(commands.length - 1, i + 1)); e.preventDefault(); }
              else if (e.key === "ArrowUp") { setIdx(i => Math.max(0, i - 1)); e.preventDefault(); }
              else if (e.key === "Enter" && commands[idx]) { commands[idx].run(); onClose(); }
              else if (e.key === "Escape") onClose();
            }}/>
        </div>
        <div className="flex-1 overflow-auto py-1">
          {commands.length === 0 && <div className="p-3 text-xs fnd-text-dim">No commands match.</div>}
          {commands.slice(0, 40).map((c, i) => (
            <button key={c.id} className="w-full text-left px-3 py-1.5 flex items-center gap-2"
              style={{ background: i === idx ? "var(--fnd-selection)" : "transparent", fontSize: 12 }}
              onMouseEnter={() => setIdx(i)}
              onClick={() => { c.run(); onClose(); }}>
              <span className="flex-1">{c.label}</span>
              <span className="fnd-tag">{c.group}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
