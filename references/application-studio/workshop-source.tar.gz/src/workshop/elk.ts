"use client";
import type { ElkNode, ElkExtendedEdge, LayoutOptions } from "elkjs/lib/elk-api";

// elkjs is large; load it lazily the first time a layout is requested.
type ElkInstance = { layout: (g: ElkNode) => Promise<ElkNode> };
let elkPromise: Promise<ElkInstance> | null = null;
export function getElk(): Promise<ElkInstance> {
  if (!elkPromise) elkPromise = import("elkjs/lib/elk.bundled.js").then(m => new m.default() as unknown as ElkInstance);
  return elkPromise;
}

export interface PackItem { id: string; w: number; h: number }

/** ELK `rectpacking`: returns rows of items (ordered left→right, top→bottom) with their packed widths. */
export async function packRows(items: PackItem[], targetWidth: number): Promise<Array<Array<{ id: string; w: number }>>> {
  const elk = await getElk();
  const res = await elk.layout({
    id: "root",
    layoutOptions: {
      "elk.algorithm": "rectpacking",
      "elk.rectpacking.widthApproximation.strategy": "TARGET_WIDTH",
      "elk.rectpacking.widthApproximation.targetWidth": String(Math.max(320, targetWidth)),
      "elk.rectpacking.packing.strategy": "COMPACTION",
      "elk.spacing.nodeNode": "16",
      "elk.padding": "[top=0,left=0,bottom=0,right=0]",
    },
    children: items.map(i => ({ id: i.id, width: i.w, height: i.h })),
  });
  const placed = (res.children ?? []).map(c => ({ id: c.id, x: c.x ?? 0, y: c.y ?? 0, w: c.width ?? 0, h: c.height ?? 0 }));
  placed.sort((a, b) => a.y - b.y || a.x - b.x);
  const rows: Array<Array<(typeof placed)[number]>> = [];
  for (const p of placed) {
    const row = rows[rows.length - 1];
    if (row && Math.abs(row[0].y - p.y) < Math.min(row[0].h, p.h) / 2) row.push(p); else rows.push([p]);
  }
  return rows.map(r => r.sort((a, b) => a.x - b.x).map(p => ({ id: p.id, w: p.w })));
}

export interface GNode { id: string; w: number; h: number }
export interface GEdge { id: string; from: string; to: string }
export interface LaidOut {
  nodes: Record<string, { x: number; y: number; w: number; h: number }>;
  edges: Record<string, Array<{ x: number; y: number }>>;
  width: number; height: number;
}

export type GraphAlgorithm = "layered-right" | "layered-down" | "stress";

/** Layered (Sugiyama) or stress layout through ELK, returning node boxes and routed edge polylines. */
export async function layoutGraph(nodes: GNode[], edges: GEdge[], algorithm: GraphAlgorithm = "layered-right"): Promise<LaidOut> {
  const elk = await getElk();
  const layered = algorithm !== "stress";
  const options: LayoutOptions = layered ? {
    "elk.algorithm": "layered",
    "elk.direction": algorithm === "layered-right" ? "RIGHT" : "DOWN",
    "elk.edgeRouting": "ORTHOGONAL",
    "elk.layered.spacing.nodeNodeBetweenLayers": "64",
    "elk.spacing.nodeNode": "14",
    "elk.spacing.edgeNode": "10",
    "elk.layered.crossingMinimization.strategy": "LAYER_SWEEP",
    "elk.layered.nodePlacement.strategy": "BRANDES_KOEPF",
    "elk.layered.considerModelOrder.strategy": "NODES_AND_EDGES",
    "elk.padding": "[top=24,left=24,bottom=24,right=24]",
  } : {
    "elk.algorithm": "stress",
    "elk.stress.desiredEdgeLength": "230",
    "elk.padding": "[top=40,left=40,bottom=40,right=40]",
  };
  const known = new Set(nodes.map(n => n.id));
  const extEdges: ElkExtendedEdge[] = edges.filter(e => known.has(e.from) && known.has(e.to) && e.from !== e.to).map(e => ({ id: e.id, sources: [e.from], targets: [e.to] }));
  const res = await elk.layout({ id: "root", layoutOptions: options, children: nodes.map(n => ({ id: n.id, width: n.w, height: n.h })), edges: extEdges });
  const out: LaidOut = { nodes: {}, edges: {}, width: res.width ?? 800, height: res.height ?? 600 };
  for (const c of res.children ?? []) out.nodes[c.id] = { x: c.x ?? 0, y: c.y ?? 0, w: c.width ?? 0, h: c.height ?? 0 };
  for (const e of (res.edges ?? []) as ElkExtendedEdge[]) {
    const pts: Array<{ x: number; y: number }> = [];
    for (const s of e.sections ?? []) { pts.push(s.startPoint, ...(s.bendPoints ?? []), s.endPoint); }
    if (pts.length < 2) {
      const a = out.nodes[e.sources[0]], b = out.nodes[e.targets[0]];
      if (a && b) pts.push({ x: a.x + a.w, y: a.y + a.h / 2 }, { x: b.x, y: b.y + b.h / 2 });
    }
    out.edges[e.id] = pts;
  }
  return out;
}

/** Rounded orthogonal polyline for an ELK route. */
export function routePath(pts: Array<{ x: number; y: number }>, radius = 6): string {
  if (pts.length < 2) return "";
  let d = `M${pts[0].x} ${pts[0].y}`;
  for (let i = 1; i < pts.length - 1; i++) {
    const p0 = pts[i - 1], p1 = pts[i], p2 = pts[i + 1];
    const l1 = Math.hypot(p1.x - p0.x, p1.y - p0.y), l2 = Math.hypot(p2.x - p1.x, p2.y - p1.y);
    const r = Math.min(radius, l1 / 2, l2 / 2);
    if (r < 1) { d += `L${p1.x} ${p1.y}`; continue; }
    const a = { x: p1.x - ((p1.x - p0.x) / l1) * r, y: p1.y - ((p1.y - p0.y) / l1) * r };
    const b = { x: p1.x + ((p2.x - p1.x) / l2) * r, y: p1.y + ((p2.y - p1.y) / l2) * r };
    d += `L${a.x} ${a.y}Q${p1.x} ${p1.y} ${b.x} ${b.y}`;
  }
  const last = pts[pts.length - 1];
  return d + `L${last.x} ${last.y}`;
}
