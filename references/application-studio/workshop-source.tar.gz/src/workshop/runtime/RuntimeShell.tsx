"use client";
import React, { useEffect, useLayoutEffect, useRef, useState } from "react";
import { useWorkshop, useWS } from "../WorkshopContext";
import { SectionView } from "../widgets/SectionRenderer";
import { Icon } from "../widgets/icons";
import { OverlayHost } from "./OverlayHost";
import { Toasts } from "../shell/Toasts";

const CONTENT_MAX = 1680;

function useWidth(ref: React.RefObject<HTMLElement | null>) {
  const [w, setW] = useState(1200);
  useLayoutEffect(() => {
    const el = ref.current; if (!el) return;
    setW(el.clientWidth);
    const ro = new ResizeObserver(e => setW(e[0].contentRect.width));
    ro.observe(el);
    return () => ro.disconnect();
  }, [ref]);
  return w;
}

export function RuntimeShell() {
  const pageRoot = useWS(s => (s.core.module.pages.find(p => p.id === s.core.currentPageId) ?? s.core.module.pages[0])?.rootSectionId ?? "");
  const vertical = useWS(s => s.core.module.header.variant === "vertical");
  return (
    <div className="h-full flex overflow-hidden" style={{ background: "var(--fnd-bg)" }}>
      {vertical && <VerticalNav/>}
      <div className="flex-1 flex flex-col min-w-0">
        {!vertical && <RuntimeHeader/>}
        <main className="flex-1 overflow-auto p-4" id="runtime-main">
          <div className="fnd-panel rounded-sm overflow-hidden mx-auto" style={{ maxWidth: CONTENT_MAX, minHeight: 480, display: "flex", flexDirection: "column", padding: 12 }}>
            {pageRoot ? <SectionView sectionId={pageRoot} isBuilder={false}/> : null}
          </div>
        </main>
      </div>
      <OverlayHost isBuilder={false}/>
      <Toasts/>
    </div>
  );
}

function NotificationsMenu() {
  const { actionLog } = useWorkshop();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const h = (e: MouseEvent) => { if (!ref.current?.contains(e.target as Node)) setOpen(false); };
    const k = (e: KeyboardEvent) => { if (e.key === "Escape") setOpen(false); };
    window.addEventListener("mousedown", h); window.addEventListener("keydown", k);
    return () => { window.removeEventListener("mousedown", h); window.removeEventListener("keydown", k); };
  }, [open]);
  return (
    <div ref={ref} className="relative">
      <button className="fnd-btn fnd-btn-minimal" title="Recent actions" aria-haspopup="true" aria-expanded={open} onClick={() => setOpen(o => !o)} style={{ position: "relative" }}>
        <Icon.Event size={13}/>
        {actionLog.length > 0 && <span style={{ position: "absolute", top: 1, right: 1, minWidth: 14, height: 14, borderRadius: 7, background: "var(--fnd-accent)", color: "#fff", fontSize: 9, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center" }}>{Math.min(99, actionLog.length)}</span>}
      </button>
      {open && (
        <div className="fnd-panel fnd-fade-in" role="menu" style={{ position: "absolute", right: 0, top: 32, width: 320, maxHeight: 360, overflow: "auto", zIndex: 70, boxShadow: "0 8px 24px rgba(0,0,0,.18)" }}>
          <div className="px-3 py-2 border-b fnd-border text-xs font-semibold">Recent actions</div>
          {actionLog.length === 0 && <div className="p-4 text-xs fnd-text-dim text-center">No actions yet. Edit an object to see writeback events here.</div>}
          {actionLog.slice(0, 12).map(l => (
            <div key={l.id} className="px-3 py-2 border-b fnd-border text-xs">
              <div className="flex items-center gap-2"><span className="font-semibold truncate">{l.displayName}</span><span className="ml-auto fnd-text-dim tabular-nums">{new Date(l.ts).toLocaleTimeString()}</span></div>
              {l.edits.map((e, i) => <div key={i} className="text-[11px] fnd-text-muted truncate">{e.kind} {e.objectType} <span className="font-mono">{e.objectId}</span></div>)}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function VerticalNav() {
  const { module, currentPageId, setCurrentPageId, headerCollapsed, setHeaderCollapsed, fireEvents, theme, toggleTheme } = useWorkshop();
  const w = headerCollapsed ? 52 : 208;
  return (
    <nav aria-label="Pages" className="flex flex-col border-r fnd-border" style={{ width: w, background: "var(--fnd-panel)", flexShrink: 0, transition: "width 160ms" }}>
      <div className="flex items-center gap-2 px-2.5 border-b fnd-border" style={{ height: 52 }}>
        <div style={{ width: 24, height: 24, background: "var(--fnd-accent)", color: "white", display: "inline-flex", alignItems: "center", justifyContent: "center", borderRadius: 3, fontSize: 12, fontWeight: 800, flexShrink: 0 }}>F</div>
        {!headerCollapsed && <div className="text-xs font-semibold truncate" title={module.header.title}>{module.header.title}</div>}
      </div>
      <div className="flex-1 overflow-auto py-2">
        {module.pages.map(p => {
          const active = currentPageId === p.id;
          return (
            <button key={p.id} onClick={() => setCurrentPageId(p.id)} title={p.name} aria-current={active ? "page" : undefined} className="w-full flex items-center gap-2 px-3 text-xs"
              style={{ height: 36, background: active ? "var(--fnd-selection)" : "transparent", color: active ? "var(--fnd-accent)" : "var(--fnd-text-muted)", borderLeft: active ? "2px solid var(--fnd-accent)" : "2px solid transparent", fontWeight: active ? 600 : 500 }}>
              <Icon.Section size={14}/>{!headerCollapsed && <span className="truncate">{p.name}</span>}
            </button>
          );
        })}
      </div>
      <div className="border-t fnd-border p-2 space-y-1">
        {module.header.items.map((it, i) => it.kind === "button" && (
          <button key={i} className="fnd-btn w-full justify-center" title={it.label} onClick={() => fireEvents(it.eventActions)}>{headerCollapsed ? it.label.slice(0, 1) : it.label}</button>
        ))}
        <button className="fnd-btn w-full justify-center" title={headerCollapsed ? "Expand navigation" : "Collapse navigation"} aria-expanded={!headerCollapsed} onClick={() => setHeaderCollapsed(!headerCollapsed)}>
          <Icon.Chevron size={12} dir={headerCollapsed ? "right" : "left"}/>{!headerCollapsed && <span>Collapse</span>}
        </button>
        <button className="fnd-btn w-full justify-center" title="Toggle theme" onClick={toggleTheme}>{theme === "light" ? "☾" : "☀"}</button>
      </div>
    </nav>
  );
}

/** Horizontal header. Collapses page tabs into a menu when the container is narrow. */
export function RuntimeHeader() {
  const { module, currentPageId, setCurrentPageId, toggleTheme, theme, fireEvents } = useWorkshop();
  const ref = useRef<HTMLDivElement>(null);
  const width = useWidth(ref);
  const compact = width < 880;
  const h = module.header;
  return (
    <header ref={ref} className="flex items-center gap-3 px-4 border-b fnd-border" style={{ height: 52, background: "var(--fnd-panel)", flexShrink: 0 }}>
      <div className="flex items-center gap-2 min-w-0">
        <div style={{ width: 24, height: 24, background: "var(--fnd-accent)", color: "white", display: "inline-flex", alignItems: "center", justifyContent: "center", borderRadius: 3, fontSize: 12, fontWeight: 800, flexShrink: 0 }}>F</div>
        <div className="text-sm font-semibold truncate" title={h.title}>{h.title}</div>
      </div>
      {compact ? (
        <select className="fnd-input fnd-select" style={{ width: 160, marginLeft: 8 }} value={currentPageId} onChange={e => setCurrentPageId(e.target.value)} aria-label="Page">
          {module.pages.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
      ) : (
        <nav className="flex items-center ml-6 gap-1 overflow-x-auto min-w-0" aria-label="Pages">
          {module.pages.map(p => (
            <button key={p.id} onClick={() => setCurrentPageId(p.id)} aria-current={currentPageId === p.id ? "page" : undefined} className="px-3 py-1.5 text-xs font-medium rounded-sm whitespace-nowrap"
              style={{ background: currentPageId === p.id ? "var(--fnd-selection)" : "transparent", color: currentPageId === p.id ? "var(--fnd-accent)" : "var(--fnd-text-muted)", borderBottom: currentPageId === p.id ? "2px solid var(--fnd-accent)" : "2px solid transparent" }}>{p.name}</button>
          ))}
        </nav>
      )}
      <div className="flex-1"/>
      {!compact && h.items.map((it, i) => it.kind === "button" && <button key={i} className="fnd-btn" onClick={() => fireEvents(it.eventActions)}>{it.label}</button>)}
      <button className="fnd-btn fnd-btn-minimal" title="Toggle theme" aria-label="Toggle theme" onClick={toggleTheme}>{theme === "light" ? "☾" : "☀"}</button>
      <NotificationsMenu/>
      <div title="Jane Smith" style={{ width: 28, height: 28, borderRadius: "50%", background: "var(--fnd-accent)", color: "white", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 700, flexShrink: 0 }}>JS</div>
    </header>
  );
}
