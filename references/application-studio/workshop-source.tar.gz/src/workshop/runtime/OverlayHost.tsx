"use client";
import React from "react";
import { useWorkshop } from "../WorkshopContext";
import { SectionRenderer } from "../widgets/SectionRenderer";
import { Icon } from "../widgets/icons";

export function OverlayHost({ isBuilder }: { isBuilder: boolean }) {
  const { openOverlayIds, closeOverlay, module } = useWorkshop();
  return (
    <>
      {openOverlayIds.map(id => {
        const o = module.overlays.find(x => x.id === id);
        if (!o) return null;
        if (o.kind === "drawer") {
          const w = o.size === "small" ? 320 : o.size === "large" ? 560 : o.size === "custom" ? (o.customWidth ?? 400) : 420;
          return (
            <div key={id}>
              {o.backdrop !== false && <div className="fnd-overlay-backdrop" onClick={() => o.closeOnBackdrop !== false && closeOverlay(id)}/>}
              <div className="fnd-slide-right fnd-panel" style={{ position: "fixed", top: 0, bottom: 0, [o.side ?? "right"]: 0, width: w, zIndex: 60, display: "flex", flexDirection: "column", boxShadow: o.side === "left" ? "2px 0 10px rgba(0,0,0,0.1)" : "-2px 0 10px rgba(0,0,0,0.1)" }}>
                <div className="flex items-center gap-2 px-3 py-2 border-b fnd-border">
                  <Icon.Overlay size={14}/>
                  <div className="text-sm font-semibold">{o.name}</div>
                  <div className="flex-1"/>
                  <button className="fnd-btn fnd-btn-minimal" onClick={() => closeOverlay(id)}><Icon.Close size={14}/></button>
                </div>
                <div className="flex-1 overflow-auto">
                  <SectionRenderer sectionId={o.rootSectionId} isBuilder={isBuilder}/>
                </div>
              </div>
            </div>
          );
        }
        return (
          <div key={id}>
            {o.backdrop !== false && <div className="fnd-overlay-backdrop" onClick={() => o.closeOnBackdrop !== false && closeOverlay(id)}/>}
            <div className="fnd-fade-in fnd-panel" style={{
              position: "fixed", top: "15%", left: "50%", transform: "translateX(-50%)",
              width: "min(560px, 90vw)", maxHeight: "70vh", zIndex: 60,
              display: "flex", flexDirection: "column", borderRadius: 4,
              boxShadow: "0 10px 40px rgba(0,0,0,0.2)",
            }}>
              <div className="flex items-center gap-2 px-3 py-2 border-b fnd-border">
                <div className="text-sm font-semibold">{o.title ?? o.name}</div>
                <div className="flex-1"/>
                <button className="fnd-btn fnd-btn-minimal" onClick={() => closeOverlay(id)}><Icon.Close size={14}/></button>
              </div>
              <div className="flex-1 overflow-auto">
                <SectionRenderer sectionId={o.rootSectionId} isBuilder={isBuilder}/>
              </div>
            </div>
          </div>
        );
      })}
    </>
  );
}
