// Mock Ontology — industrial operations
// Object Types: Asset, Sensor, Alert, WorkOrder, Operator, Location

export type ObjectType = "Asset" | "Sensor" | "Alert" | "WorkOrder" | "Operator" | "Location";

export interface AssetObj {
  __type: "Asset";
  id: string;
  name: string;
  status: "Active" | "Warning" | "Offline" | "Maintenance";
  priority: "High" | "Medium" | "Low";
  owner: string;
  ownerId: string;
  locationId: string;
  pressure: number;
  temperature: number;
  availability: number;
  lastInspection: string; // ISO
  nextMaintenance: string;
  model: string;
  installedAt: string;
  lat: number;
  lng: number;
  revenueImpact: number;
  openAlerts: number;
}

export interface SensorObj {
  __type: "Sensor";
  id: string;
  name: string;
  assetId: string;
  kind: "Pressure" | "Temperature" | "Vibration" | "Flow";
  unit: string;
  current: number;
  threshold: number;
  status: "Nominal" | "Degraded" | "Fault";
}

export interface AlertObj {
  __type: "Alert";
  id: string;
  assetId: string;
  severity: "Critical" | "High" | "Medium" | "Low";
  title: string;
  description: string;
  createdAt: string;
  acknowledged: boolean;
}

export interface WorkOrderObj {
  __type: "WorkOrder";
  id: string;
  assetId: string;
  operatorId: string;
  title: string;
  status: "Open" | "In Progress" | "Blocked" | "Done";
  due: string;
  createdAt: string;
}

export interface OperatorObj {
  __type: "Operator";
  id: string;
  name: string;
  shift: "Day" | "Night" | "Swing";
  certifications: string[];
}

export interface LocationObj {
  __type: "Location";
  id: string;
  name: string;
  region: string;
  lat: number;
  lng: number;
}

export type AnyObj = AssetObj | SensorObj | AlertObj | WorkOrderObj | OperatorObj | LocationObj;

// ─── Seed data ───────────────────────────────────────────────────────────────

const OPERATORS: OperatorObj[] = [
  { __type: "Operator", id: "op-1", name: "Jane Smith", shift: "Day", certifications: ["Compressor", "Pump"] },
  { __type: "Operator", id: "op-2", name: "Marcus Chen", shift: "Night", certifications: ["Electrical"] },
  { __type: "Operator", id: "op-3", name: "Priya Patel", shift: "Day", certifications: ["Mechanical", "Compressor"] },
  { __type: "Operator", id: "op-4", name: "Diego Alvarez", shift: "Swing", certifications: ["Pump", "Hydraulic"] },
  { __type: "Operator", id: "op-5", name: "Yuki Tanaka", shift: "Day", certifications: ["Instrumentation"] },
  { __type: "Operator", id: "op-6", name: "Sarah Okafor", shift: "Night", certifications: ["Mechanical"] },
  { __type: "Operator", id: "op-7", name: "Lars Nielsen", shift: "Day", certifications: ["Compressor", "Welding"] },
  { __type: "Operator", id: "op-8", name: "Amina Hassan", shift: "Swing", certifications: ["Electrical", "Controls"] },
  { __type: "Operator", id: "op-9", name: "Tom Reilly", shift: "Day", certifications: ["Mechanical", "Pump"] },
  { __type: "Operator", id: "op-10", name: "Zara Khan", shift: "Night", certifications: ["Instrumentation", "Controls"] },
];

const LOCATIONS: LocationObj[] = [
  { __type: "Location", id: "loc-1", name: "Houston Facility A", region: "US-Gulf", lat: 29.76, lng: -95.37 },
  { __type: "Location", id: "loc-2", name: "Rotterdam Terminal", region: "EU-North", lat: 51.92, lng: 4.48 },
  { __type: "Location", id: "loc-3", name: "Singapore Hub", region: "APAC-SE", lat: 1.29, lng: 103.85 },
  { __type: "Location", id: "loc-4", name: "Calgary Site 7", region: "CA-West", lat: 51.05, lng: -114.07 },
  { __type: "Location", id: "loc-5", name: "Perth Offshore", region: "APAC-OC", lat: -31.95, lng: 115.86 },
];

const ASSET_NAMES = [
  "Compressor", "Pump", "Turbine", "Separator", "Heat Exchanger", "Reactor", "Valve Array",
];

function statusFor(i: number): AssetObj["status"] {
  const r = i % 13;
  if (r < 7) return "Active";
  if (r < 10) return "Warning";
  if (r < 12) return "Maintenance";
  return "Offline";
}

function priorityFor(i: number): AssetObj["priority"] {
  const r = i % 7;
  if (r < 2) return "High";
  if (r < 5) return "Medium";
  return "Low";
}

export function generateAssets(count = 120): AssetObj[] {
  const assets: AssetObj[] = [];
  for (let i = 0; i < count; i++) {
    const loc = LOCATIONS[i % LOCATIONS.length];
    const op = OPERATORS[i % OPERATORS.length];
    const nameBase = ASSET_NAMES[i % ASSET_NAMES.length];
    const status = statusFor(i);
    const priority = priorityFor(i);
    const latJ = (Math.sin(i * 1.1) * 0.8);
    const lngJ = (Math.cos(i * 1.3) * 0.8);
    assets.push({
      __type: "Asset",
      id: `AST-${String(1000 + i).padStart(4, "0")}`,
      name: `${nameBase} ${String.fromCharCode(65 + (i % 26))}-${100 + i}`,
      status,
      priority,
      owner: op.name,
      ownerId: op.id,
      locationId: loc.id,
      pressure: Math.round((20 + Math.sin(i) * 8 + (i % 10)) * 10) / 10,
      temperature: Math.round((60 + Math.cos(i) * 15 + (i % 7) * 2) * 10) / 10,
      availability: Math.round((88 + Math.sin(i * 0.7) * 10) * 10) / 10,
      lastInspection: new Date(2026, 7, 1 + (i % 28)).toISOString(),
      nextMaintenance: new Date(2026, 9, 1 + (i % 28)).toISOString(),
      model: `MDL-${1000 + (i % 20)}`,
      installedAt: new Date(2020 + (i % 6), i % 12, 1 + (i % 27)).toISOString(),
      lat: loc.lat + latJ,
      lng: loc.lng + lngJ,
      revenueImpact: Math.round((50 + (i % 50)) * 10000),
      openAlerts: status === "Warning" ? 1 + (i % 3) : status === "Offline" ? 2 + (i % 2) : (i % 5 === 0 ? 1 : 0),
    });
  }
  return assets;
}

export function generateAlerts(assets: AssetObj[]): AlertObj[] {
  const out: AlertObj[] = [];
  const sevs: AlertObj["severity"][] = ["Critical", "High", "Medium", "Low"];
  let n = 0;
  for (const a of assets) {
    for (let j = 0; j < a.openAlerts; j++) {
      out.push({
        __type: "Alert",
        id: `ALT-${String(5000 + n).padStart(5, "0")}`,
        assetId: a.id,
        severity: sevs[(n + j) % 4],
        title: j === 0 ? `${a.name} — abnormal reading` : `Threshold breach on ${a.name}`,
        description: `Sensor telemetry outside expected envelope. Investigate within 24h.`,
        createdAt: new Date(2026, 8, 1 + (n % 28), (n % 24)).toISOString(),
        acknowledged: n % 5 === 0,
      });
      n++;
    }
  }
  return out;
}

export function generateWorkOrders(assets: AssetObj[]): WorkOrderObj[] {
  const out: WorkOrderObj[] = [];
  const statuses: WorkOrderObj["status"][] = ["Open", "In Progress", "Blocked", "Done"];
  let n = 0;
  for (const a of assets) {
    const nOrders = a.status === "Maintenance" ? 2 : a.openAlerts;
    for (let j = 0; j < nOrders; j++) {
      out.push({
        __type: "WorkOrder",
        id: `WO-${String(2000 + n).padStart(5, "0")}`,
        assetId: a.id,
        operatorId: OPERATORS[n % OPERATORS.length].id,
        title: `${["Inspect", "Replace", "Calibrate", "Clean"][j % 4]} ${a.name}`,
        status: statuses[(n + j) % 4],
        due: new Date(2026, 9, 1 + ((n + 5) % 28)).toISOString(),
        createdAt: new Date(2026, 8, 1 + (n % 20)).toISOString(),
      });
      n++;
    }
  }
  return out;
}

export function generateSensors(assets: AssetObj[]): SensorObj[] {
  const out: SensorObj[] = [];
  const kinds: SensorObj["kind"][] = ["Pressure", "Temperature", "Vibration", "Flow"];
  const units = { Pressure: "bar", Temperature: "°C", Vibration: "mm/s", Flow: "L/min" };
  let n = 0;
  for (const a of assets) {
    for (let k = 0; k < 3; k++) {
      const kind = kinds[(n + k) % 4];
      const current = Math.round((20 + Math.sin(n + k) * 15 + k * 10) * 10) / 10;
      const threshold = Math.round((current * (1.1 + k * 0.05)) * 10) / 10;
      out.push({
        __type: "Sensor",
        id: `SNS-${String(9000 + n).padStart(5, "0")}`,
        name: `${a.name} ${kind}`,
        assetId: a.id,
        kind,
        unit: units[kind],
        current,
        threshold,
        status: current > threshold ? "Fault" : current > threshold * 0.9 ? "Degraded" : "Nominal",
      });
      n++;
    }
  }
  return out;
}

export function buildOntology() {
  const assets = generateAssets(120);
  const alerts = generateAlerts(assets);
  const workOrders = generateWorkOrders(assets);
  const sensors = generateSensors(assets);
  return {
    assets,
    alerts,
    workOrders,
    sensors,
    operators: OPERATORS,
    locations: LOCATIONS,
    // objects of object types created at runtime in the Ontology Manager
    extra: {} as Record<string, Array<Record<string, unknown>>>,
  };
}

export type Ontology = ReturnType<typeof buildOntology>;
