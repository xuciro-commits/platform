// Workshop Module definition types (schema shared by Builder + Runtime)
import type { ObjectSetDef } from "./ontologyMeta";
import type { FlowDef } from "./flowTypes";

export type VarType =
  | "string" | "numeric" | "boolean" | "date" | "timestamp"
  | "array" | "objectSet" | "objectSetFilter" | "objectProperty"
  | "struct" | "geoPoint" | "geoShape" | "timeSeriesSet" | "object";

export type VarDefinitionKind =
  | "static"
  | "function"
  | "objectSetAggregation"
  | "objectProperty"
  | "objectSetDefinition"
  | "variableTransformation"
  | "sqlQuery"
  | "widgetOutput";

export type RecomputeMode = "automatic" | "triggered" | "onLoadAndTriggered";

export interface TransformationStep {
  op:
    | "concat" | "ifElse" | "cast" | "isEmpty" | "isNotEmpty"
    | "objectProperty" | "cardinality" | "aggregate"
    | "add" | "subtract" | "multiply" | "divide"
    | "filterStatus" | "filterPriority" | "filterOwner" | "filterSearch";
  args?: Record<string, unknown>;
}

export interface VariableDef {
  id: string;
  name: string;
  type: VarType;
  description?: string;
  definitionKind: VarDefinitionKind;
  recompute: RecomputeMode;
  // config varies by definitionKind
  staticValue?: unknown;
  sourceObjectType?: "Asset" | "Sensor" | "Alert" | "WorkOrder" | "Operator" | "Location";
  transformations?: TransformationStep[];
  // dependencies: list of variable IDs this depends on
  dependsOn?: string[];
  // widget output source
  widgetId?: string;
  widgetOutputKey?: string;
  // module interface
  isInterface?: boolean;
  externalId?: string;
  interfaceDirection?: "input" | "output" | "inputOutput";
  // transformation input var
  inputVarId?: string;
  // Ontology-native object set definition — an OSDK-shaped `Objects(type).where(...).pivotTo(...)` chain.
  // See `ObjectSetDef` / `ObjectSetStep` in ontologyMeta.ts (re-exported below for convenience).
  objectSet?: ObjectSetDef;
  // Function-backed variable (Ontology-backed Function / Query)
  functionApiName?: string;
}

export type { ObjectSetDef, ObjectSetStep, WhereClause, FilterOp } from "./ontologyMeta";

export type WidgetType =
  | "ObjectTable" | "ObjectList" | "ObjectView" | "PropertyList" | "Links"
  | "HeaderText" | "ObjectSetTitle"
  | "FilterList" | "ObjectDropdown" | "StringSelector" | "Checkbox"
  | "DateInput" | "TextInput" | "NumericInput" | "UserSelect"
  | "MetricCard" | "ChartXY" | "ChartPie" | "ChartVega" | "ChartWaterfall"
  | "Map" | "Gantt" | "Timeline" | "PivotTable" | "Markdown" | "PdfViewer"
  | "MediaPreview" | "StatusTracker" | "Stepper" | "ActionLogTimeline"
  | "ButtonGroup" | "Tabs" | "Comments" | "MediaUploader" | "InlineAction" | "ActionTable"
  | "AIPAnalyst" | "AIPChatbot" | "AIPGenerated"
  | "Iframe" | "EmbeddedModule" | "CustomWidget"
  | "DerivedSeries" | "QuiverDashboard" | "VertexGraph" | "NotepadEmbed" | "MapTemplate"
  | "FreeFormAnalysis" | "TimeSeriesAnalysis" | "ImageAnnotation"
  | "ObservabilityChart" | "ResourceList" | "LinkedCompass"
  | "ExplorationFilter" | "ExplorationSearch" | "ProminentTerms"
  | "ObjectSelector" | "DateTimePicker" | "MultiSelector"
  | "KanbanBoard" | "ObjectCard" | "ObjectComparison" | "Histogram" | "ScatterPlot" | "Heatmap"
  | "Gauge" | "SparklineKpi" | "ProgressBar" | "Treemap" | "Calendar" | "RangeSlider"
  | "ToggleSwitch" | "RadioGroup" | "SegmentedControl" | "Breadcrumbs" | "AlertBanner" | "Callout"
  | "Divider" | "Spacer" | "ImageWidget" | "SingleButton" | "NotificationFeed" | "ApprovalInbox"
  | "GraphExplorer" | "SummaryStats" | "TagList" | "AvatarStack" | "Leaderboard" | "ObjectSetBuilder"
  | "TelemetryTable" | "TelemetryStats" | "Scene3D";

export interface WidgetEvent {
  id: string;
  trigger: string; // e.g. "onSelect", "onClick", "onSubmit"
  actions: EventAction[];
}

export type EventAction =
  | { kind: "setVariable"; variableId: string; valueExpr: string }
  | { kind: "resetVariable"; variableId: string }
  | { kind: "recomputeVariable"; variableId: string }
  | { kind: "openOverlay"; overlayId: string }
  | { kind: "closeOverlay"; overlayId: string }
  | { kind: "expandSection"; sectionId: string }
  | { kind: "collapseSection"; sectionId: string }
  | { kind: "toggleSection"; sectionId: string }
  | { kind: "switchPage"; pageId: string }
  | { kind: "switchTab"; sectionId: string; tabIndex: number }
  | { kind: "openModule"; moduleId: string }
  | { kind: "openObjectView"; variableId: string }
  | { kind: "openUrl"; url: string }
  | { kind: "refreshData" }
  | { kind: "enableAutoRefresh" }
  | { kind: "disableAutoRefresh" }
  | { kind: "toggleTheme" }
  | { kind: "runAction"; actionId: string }
  | { kind: "exportData"; widgetId: string };

export interface WidgetDef {
  id: string;
  type: WidgetType;
  name: string;
  // bindings: config varies per widget type
  config: Record<string, unknown>;
  events?: WidgetEvent[];
  // display optimization
  height?: number;
  /** Flex weight within a horizontal parent (columns). Default 1. */
  flex?: number;
  /** Real display settings applied by the section/widget host. */
  style?: { background?: "default" | "panel" | "muted" | "none"; border?: boolean; elevation?: 0 | 1 | 2; padding?: number };
  emptyMessage?: string;
  /** Interaction is disabled (rendered inert) — models "Read only" visibility state. */
  readOnly?: boolean;
  /** Hidden at runtime (shown as dashed placeholder in the builder). */
  hidden?: boolean;
  mountBehavior?: "normal" | "delayUntilOnScreen" | "eager";
  unmountBehavior?: "normal" | "neverUnmount" | "unmountOffScreen";
}

export type SectionLayoutKind = "columns" | "rows" | "tabs" | "flow" | "toolbar" | "loop";

export interface SectionDef {
  id: string;
  name: string;
  layout: SectionLayoutKind;
  // children can be sections or widgets
  children: Array<{ kind: "section"; id: string } | { kind: "widget"; id: string }>;
  // header
  showHeader?: boolean;
  title?: string;
  description?: string;
  // layout
  direction?: "horizontal" | "vertical";
  width?: string;
  height?: string;
  minWidth?: string;
  maxWidth?: string;
  padding?: number;
  gap?: number;
  // appearance
  background?: "default" | "panel" | "muted" | "none";
  border?: boolean;
  elevation?: 0 | 1 | 2;
  divider?: boolean;
  // behavior
  scroll?: boolean;
  collapsible?: boolean;
  defaultCollapsed?: boolean;
  visibleVariableId?: string;
  // tabs config
  tabs?: Array<{ id: string; label: string; childIndex: number }>;
  // for loop
  loopVariableId?: string;
  /** Variable that resolves to the current item inside a loop body. */
  loopItemVarId?: string;
  /** Flex weight within a horizontal parent. Default 1. */
  flex?: number;
  /** Created by drag/drop wrapping; auto-removed when it degenerates (≤1 child). */
  auto?: boolean;
  align?: "stretch" | "start" | "center" | "end";
  justify?: "start" | "center" | "end" | "between";
  wrap?: boolean;
  /** Columns stack vertically when the section is narrower than this (px). Default 640. */
  stackBelow?: number;
  noStack?: boolean;
}

export interface PageDef {
  id: string;
  name: string;
  rootSectionId: string;
}

export type OverlayKind = "drawer" | "modal";

export interface OverlayDef {
  id: string;
  name: string;
  kind: OverlayKind;
  rootSectionId: string;
  // drawer
  side?: "left" | "right";
  size?: "small" | "medium" | "large" | "custom";
  customWidth?: number;
  backdrop?: boolean;
  closeOnBackdrop?: boolean;
  closeOnEsc?: boolean;
  // state var
  openVariableId?: string;
  /** Event chain fired whenever the overlay closes (X, backdrop, Esc or variable reset). */
  onCloseActions?: EventAction[];
  // modal
  title?: string;
}

export interface HeaderDef {
  variant: "horizontal" | "vertical";
  title: string;
  logo?: string;
  collapsed?: boolean;
  items: Array<
    | { kind: "logo" }
    | { kind: "title" }
    | { kind: "tabs"; pageIds: string[] }
    | { kind: "spacer" }
    | { kind: "button"; label: string; eventActions: EventAction[] }
    | { kind: "text"; text: string }
  >;
}

export interface ModuleInterfaceVar {
  variableId: string;
  externalId: string;
  description?: string;
  direction: "input" | "output" | "inputOutput";
}

export interface ModuleDef {
  id: string;
  name: string;
  description: string;
  header: HeaderDef;
  pages: PageDef[];
  sections: Record<string, SectionDef>;
  widgets: Record<string, WidgetDef>;
  overlays: OverlayDef[];
  variables: VariableDef[];
  /** Native operational stream / dataflow definitions, versioned with the module. */
  flows: FlowDef[];
  unusedWidgetIds: string[];
  // ontology references for Overview
  usedObjectTypes: string[];
  usedActions: string[];
  usedFunctions: string[];
  moduleInterface: ModuleInterfaceVar[];
  savedState: "saved" | "saving" | "unsaved" | "failed" | "published";
}
