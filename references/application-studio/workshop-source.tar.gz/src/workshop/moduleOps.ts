import type { ModuleDef, SectionDef, WidgetDef, WidgetType, OverlayDef } from "./types";
import { defaultSceneConfig } from "./scene3d/mapping";

export function newId(prefix: string) {
  return `${prefix}${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
}

export function emptySection(id: string, name: string, layout: SectionDef["layout"] = "rows"): SectionDef {
  return {
    id, name, layout, children: [],
    showHeader: false, direction: layout === "columns" ? "horizontal" : "vertical",
    padding: 8, gap: 8, background: "default", border: false, scroll: false,
    collapsible: false, defaultCollapsed: false,
  };
}

export function defaultConfig(type: WidgetType): Record<string, unknown> {
  switch (type) {
    case "TelemetryTable": return { assetVarId: "selectedAsset", selectedSignalVarId: "selectedSignal", rowHeight: 30 };
    case "TelemetryStats": return { assetVarId: "selectedAsset", flowStatsVarId: "liveTelemetryStats", signalIndex: 0, threshold: 11.5, windowRows: 10000 };
    case "Scene3D": return { ...defaultSceneConfig() };
    case "ObjectTable": return { objectSetVarId: "filteredAssets", activeVarId: "selectedAsset", selectedVarId: "selectedAssets", columns: [{ key: "id", label: "ID", width: 100 }, { key: "name", label: "Name", width: 180 }, { key: "status", label: "Status", width: 100, formatter: "status" }], density: "compact", enableSelection: true, selectionMode: "single", showToolbar: true, enableInlineEdit: true, titleTemplate: "Objects ({count})" };
    case "ObjectList": return { objectSetVarId: "filteredAssets", layout: "list", activeVarId: "selectedAsset" };
    case "ObjectView": return { objectVarId: "selectedAsset", formFactor: "panel", viewMode: "configured", tabs: ["Overview", "Properties", "Links", "History"] };
    case "PropertyList": return { objectVarId: "selectedAsset", columns: 2, hideNull: true, properties: ["id", "name", "status", "owner", "pressure"] };
    case "Links": return { objectVarId: "selectedAsset", linkTypes: [{ label: "Sensors", target: "Sensor", linkField: "assetId" }, { label: "Alerts", target: "Alert", linkField: "assetId" }] };
    case "MetricCard": return { label: "Metric", variableId: "filteredCount", variant: "card" };
    case "ChartXY": return { objectSetVarId: "filteredAssets", chartKind: "bar", xProperty: "status", yProperty: "pressure" };
    case "ChartPie": return { objectSetVarId: "filteredAssets", groupBy: "status" };
    case "ChartVega": return { objectSetVarId: "filteredAssets", spec: "bar" };
    case "ChartWaterfall": return { objectSetVarId: "filteredAssets" };
    case "FilterList": return { objectSetVarId: "allAssets", facets: [{ property: "status", label: "Status", type: "checkbox", varId: "statusFilter" }], searchVarId: "searchText" };
    case "HeaderText": return { text: "Heading", variant: "h2" };
    case "Markdown": return { text: "## Edit me\n\nAdd markdown content here." };
    case "ButtonGroup": return { buttons: [{ label: "Click me", variant: "primary", eventActions: [] }] };
    case "Tabs": return { tabs: ["Tab 1", "Tab 2"], variableId: "selectedTab" };
    case "TextInput": return { variableId: "searchText", label: "Text", placeholder: "Type..." };
    case "NumericInput": return { variableId: "mapZoom", label: "Number" };
    case "DateInput": return { variableId: "dateRangeStart", label: "Date" };
    case "DateTimePicker": return { variableId: "dateRangeStart", label: "Date & time" };
    case "Checkbox": return { variableId: "showDetail", label: "Enabled" };
    case "StringSelector": return { variableId: "mapLayer", options: ["status", "priority", "owner"], label: "Select" };
    case "ObjectDropdown": return { variableId: "ownerFilter", options: [], label: "Object" };
    case "ObjectSelector": return { objectSetVarId: "filteredAssets", activeVarId: "selectedAsset", label: "Pick object" };
    case "UserSelect": return { variableId: "ownerFilter", label: "User" };
    case "MultiSelector": return { variableId: "statusFilter", options: ["Active", "Warning", "Offline", "Maintenance"], label: "Multi" };
    case "Map": return { objectSetVarId: "filteredAssets", activeVarId: "selectedAsset", colorBy: "status", clusterEnabled: true };
    case "Gantt": return { objectSetVarId: "workOrders" };
    case "Timeline": return { objectSetVarId: "activeAlerts" };
    case "PivotTable": return { objectSetVarId: "filteredAssets", rows: "status", cols: "priority", measure: "count" };
    case "PdfViewer": return { source: "Compliance_Report_Q3.pdf", pageVarId: "pdfPage", totalPages: 24 };
    case "InlineAction": return { actionId: "updateAssetStatus", objectVarId: "selectedAsset", mode: "form" };
    case "ActionTable": return { actionId: "updateAssetStatus", objectSetVarId: "filteredAssets" };
    case "AIPChatbot": return { historyVarId: "chatHistory", inputVarId: "chatInput", suggestions: ["Summarise active alerts"] };
    case "AIPAnalyst": return { contextVarId: "selectedAsset", outputVarId: "filteredAssets" };
    case "AIPGenerated": return { objectVarId: "selectedAsset" };
    case "Comments": return { listVarId: "commentList", draftVarId: "commentDraft" };
    case "MediaUploader": return { outputVarId: "uploadedFile" };
    case "MediaPreview": return { outputVarId: "uploadedFile" };
    case "StatusTracker": return { objectVarId: "selectedAsset", stages: ["Active", "Warning", "Maintenance", "Offline"], activeProp: "status" };
    case "Stepper": return { steps: ["Observe", "Investigate", "Decide", "Act"], currentVarId: "selectedTab" };
    case "ObjectSetTitle": return { objectSetVarId: "filteredAssets" };
    case "EmbeddedModule": return { moduleId: "child-asset-detail", bindings: [{ parentVar: "selectedAsset", childInterface: "selectedAsset" }] };
    case "CustomWidget": return { widgetSet: "com.vendor.ops", version: "1.0.0", params: [{ name: "inputObjectSet", varId: "filteredAssets" }], permissions: ["read.objects"] };
    case "Iframe": return { url: "https://foundry.local/embed", height: 240 };
    case "ExplorationFilter": return { variableId: "statusFilter" };
    case "ExplorationSearch": return { variableId: "searchText" };
    case "ProminentTerms": return { objectSetVarId: "filteredAssets", property: "status" };
    case "FreeFormAnalysis": return { objectSetVarId: "filteredAssets" };
    case "TimeSeriesAnalysis": return { objectSetVarId: "filteredAssets" };
    case "ImageAnnotation": return { objectVarId: "selectedAsset" };
    case "ObservabilityChart": return { objectSetVarId: "filteredAssets" };
    case "ResourceList": return { objectSetVarId: "filteredAssets" };
    case "LinkedCompass": return { title: "Compass resource" };
    case "DerivedSeries": return { objectSetVarId: "filteredAssets" };
    case "QuiverDashboard": return { title: "Quiver · Fleet KPIs" };
    case "VertexGraph": return { objectVarId: "selectedAsset" };
    case "NotepadEmbed": return { title: "Field notes" };
    case "MapTemplate": return { objectSetVarId: "filteredAssets", activeVarId: "selectedAsset" };
    case "ActionLogTimeline": return { objectSetVarId: "activeAlerts" };
    case "KanbanBoard": return { objectSetVarId: "filteredAssets", groupBy: "status", actionId: "updateAssetStatus", actionParam: "status", activeVarId: "selectedAsset" };
    case "ApprovalInbox": return { objectSetVarId: "workOrders", approveActionId: "completeWorkOrder", rejectActionId: "cancelWorkOrder" };
    case "GraphExplorer": return { objectVarId: "selectedAsset", outputVarId: "selectedWorkOrder" };
    case "ObjectCard": return { objectVarId: "selectedAsset" };
    case "ObjectComparison": return { objectsVarId: "selectedAssets" };
    case "ObjectSetBuilder": return { objectSetVarId: "allAssets", outputVarId: "builderAssets" };
    case "NotificationFeed": return {};
    case "Histogram": return { objectSetVarId: "filteredAssets", property: "pressure", bins: 12 };
    case "ScatterPlot": return { objectSetVarId: "filteredAssets", x: "pressure", y: "temperature", colorBy: "status", activeVarId: "selectedAsset" };
    case "Heatmap": return { objectSetVarId: "filteredAssets", rows: "status", cols: "priority", rowFilterVarId: "statusFilter", colFilterVarId: "priorityFilter" };
    case "Treemap": return { objectSetVarId: "filteredAssets", groupBy: "owner", filterVarId: "ownerFilter" };
    case "Gauge": return { variableId: "avgAvailability", label: "Fleet availability", max: 100, suffix: "%" };
    case "SparklineKpi": return { variableId: "filteredCount", label: "Assets in view", seriesSetVarId: "filteredAssets", seriesProperty: "availability" };
    case "ProgressBar": return { valueVarId: "activeCount", totalVarId: "filteredCount", label: "Active share" };
    case "SummaryStats": return { objectSetVarId: "filteredAssets", property: "pressure" };
    case "Leaderboard": return { objectSetVarId: "filteredAssets", property: "revenueImpact", limit: 8, activeVarId: "selectedAsset" };
    case "Calendar": return { objectSetVarId: "workOrders", dateProperty: "due", activeVarId: "selectedWorkOrder" };
    case "TagList": return { objectSetVarId: "filteredAssets", property: "model" };
    case "RangeSlider": return { minVarId: "pressureMin", maxVarId: "pressureMax", min: 0, max: 45, label: "Pressure", unit: "bar" };
    case "ToggleSwitch": return { variableId: "showDetail", label: "Show detail panel" };
    case "RadioGroup": return { variableId: "mapLayer", options: ["status", "priority", "owner"], label: "Color by" };
    case "SegmentedControl": return { variableId: "mapLayer", options: ["status", "priority", "owner"], label: "Layer" };
    case "Breadcrumbs": return { objectVarId: "selectedAsset" };
    case "AlertBanner": return { variableId: "offlineCount", threshold: 0, intent: "danger", message: "{value} assets are offline — triage required." };
    case "Callout": return { title: "Note", text: "Describe this section for operators.", intent: "primary" };
    case "Divider": return { label: "" };
    case "Spacer": return { size: 16 };
    case "ImageWidget": return { url: "", caption: "" };
    case "SingleButton": return { label: "Run", variant: "primary", eventActions: [] };
    case "AvatarStack": return { objectVarId: "selectedAsset" };
    default: return {};
  }
}

export function createWidget(type: WidgetType, name: string): WidgetDef {
  return { id: newId("w"), type, name, config: defaultConfig(type), events: [], mountBehavior: "normal", unmountBehavior: "normal" };
}

export function findParent(module: ModuleDef, childId: string): { sectionId: string; index: number; kind: "widget" | "section" } | null {
  for (const [sid, s] of Object.entries(module.sections)) {
    const idx = s.children.findIndex(c => c.id === childId);
    if (idx >= 0) return { sectionId: sid, index: idx, kind: s.children[idx].kind };
  }
  return null;
}

export function addWidgetToSection(module: ModuleDef, sectionId: string, widget: WidgetDef, index?: number): ModuleDef {
  const s = module.sections[sectionId];
  if (!s) return module;
  const children = [...s.children];
  const item = { kind: "widget" as const, id: widget.id };
  if (index === undefined || index < 0 || index > children.length) children.push(item);
  else children.splice(index, 0, item);
  return { ...module, widgets: { ...module.widgets, [widget.id]: widget }, sections: { ...module.sections, [sectionId]: { ...s, children } } };
}

export function duplicateWidget(module: ModuleDef, widgetId: string): { module: ModuleDef; newId: string } | null {
  const w = module.widgets[widgetId];
  if (!w) return null;
  const nw: WidgetDef = { ...w, id: newId("w"), name: `${w.name} copy`, config: structuredClone(w.config), events: structuredClone(w.events ?? []) };
  const parent = findParent(module, widgetId);
  let next = { ...module, widgets: { ...module.widgets, [nw.id]: nw } };
  if (parent) {
    const s = next.sections[parent.sectionId];
    const children = [...s.children];
    children.splice(parent.index + 1, 0, { kind: "widget", id: nw.id });
    next = { ...next, sections: { ...next.sections, [parent.sectionId]: { ...s, children } } };
  } else {
    next = { ...next, unusedWidgetIds: [...next.unusedWidgetIds, nw.id] };
  }
  return { module: next, newId: nw.id };
}

export function makeUnused(module: ModuleDef, widgetId: string): ModuleDef {
  const parent = findParent(module, widgetId);
  let next = module;
  if (parent) {
    const s = next.sections[parent.sectionId];
    next = { ...next, sections: { ...next.sections, [parent.sectionId]: { ...s, children: s.children.filter(c => c.id !== widgetId) } } };
  }
  if (!next.unusedWidgetIds.includes(widgetId)) next = { ...next, unusedWidgetIds: [...next.unusedWidgetIds, widgetId] };
  return next;
}

export function restoreUnused(module: ModuleDef, widgetId: string, targetSectionId: string): ModuleDef {
  const s = module.sections[targetSectionId];
  if (!s) return module;
  return {
    ...module,
    unusedWidgetIds: module.unusedWidgetIds.filter(id => id !== widgetId),
    sections: { ...module.sections, [targetSectionId]: { ...s, children: [...s.children, { kind: "widget", id: widgetId }] } },
  };
}

export function deleteWidget(module: ModuleDef, widgetId: string): ModuleDef {
  const parent = findParent(module, widgetId);
  const widgets = { ...module.widgets };
  delete widgets[widgetId];
  let sections = module.sections;
  if (parent) {
    const s = sections[parent.sectionId];
    sections = { ...sections, [parent.sectionId]: { ...s, children: s.children.filter(c => c.id !== widgetId) } };
  }
  return { ...module, widgets, sections, unusedWidgetIds: module.unusedWidgetIds.filter(id => id !== widgetId) };
}

export function moveChild(module: ModuleDef, childId: string, dir: "up" | "down"): ModuleDef {
  const parent = findParent(module, childId);
  if (!parent) return module;
  const s = module.sections[parent.sectionId];
  const children = [...s.children];
  const i = parent.index;
  const j = dir === "up" ? i - 1 : i + 1;
  if (j < 0 || j >= children.length) return module;
  [children[i], children[j]] = [children[j], children[i]];
  return { ...module, sections: { ...module.sections, [parent.sectionId]: { ...s, children } } };
}

/** Move a widget/section into targetSectionId at index (drag & drop). */
export function moveChildTo(module: ModuleDef, childId: string, childKind: "widget" | "section", targetSectionId: string, index: number, fromSectionId?: string): ModuleDef {
  if (!module.sections[targetSectionId]) return module;
  if (childKind === "section") {
    if (childId === targetSectionId) return module;
    const { sectionIds } = collectSectionSubtree(module, childId);
    if (sectionIds.includes(targetSectionId)) return module; // cannot drop into own subtree
    if (module.pages.some(p => p.rootSectionId === childId)) return module;
  }
  const sections = { ...module.sections };
  let idx = index;
  const srcId = fromSectionId && sections[fromSectionId]?.children.some(c => c.id === childId) ? fromSectionId : findParent(module, childId)?.sectionId;
  if (srcId) {
    const s = sections[srcId];
    const oldIdx = s.children.findIndex(c => c.id === childId);
    sections[srcId] = { ...s, children: s.children.filter((_, i) => i !== oldIdx) };
    if (srcId === targetSectionId && oldIdx >= 0 && oldIdx < index) idx -= 1;
  }
  const t = sections[targetSectionId];
  const children = [...t.children];
  children.splice(Math.max(0, Math.min(idx, children.length)), 0, { kind: childKind, id: childId });
  sections[targetSectionId] = { ...t, children };
  return { ...module, sections, unusedWidgetIds: module.unusedWidgetIds.filter(id => id !== childId) };
}

export function addSectionRelative(module: ModuleDef, sectionId: string, where: "above" | "below" | "left" | "right"): ModuleDef {
  const parent = findParent(module, sectionId);
  const nid = newId("s");
  const layout: SectionDef["layout"] = where === "left" || where === "right" ? "columns" : "rows";
  const ns = emptySection(nid, "New section", "rows");
  if (!parent) {
    // wrap current as sibling under a new parent? fallback: add as unused-ish child of itself
    return { ...module, sections: { ...module.sections, [nid]: ns } };
  }
  const s = module.sections[parent.sectionId];
  const children = [...s.children];
  const insertAt = where === "above" || where === "left" ? parent.index : parent.index + 1;
  children.splice(insertAt, 0, { kind: "section", id: nid });
  let nextLayout = s.layout;
  if ((where === "left" || where === "right") && s.layout !== "columns") nextLayout = "columns";
  if ((where === "above" || where === "below") && s.layout === "columns") nextLayout = s.layout;
  void layout;
  return { ...module, sections: { ...module.sections, [nid]: ns, [parent.sectionId]: { ...s, children, layout: nextLayout } } };
}

export function duplicateSection(module: ModuleDef, sectionId: string): { module: ModuleDef; newId: string } | null {
  const src = module.sections[sectionId];
  if (!src) return null;
  const mapping: Record<string, string> = {};
  const widgets = { ...module.widgets };
  const sections = { ...module.sections };

  const cloneSection = (id: string): string => {
    const s = module.sections[id];
    const nid = newId("s");
    mapping[id] = nid;
    const children = s.children.map(c => {
      if (c.kind === "section") return { kind: "section" as const, id: cloneSection(c.id) };
      const w = module.widgets[c.id];
      const wid = newId("w");
      widgets[wid] = { ...w, id: wid, name: `${w.name} copy`, config: structuredClone(w.config), events: structuredClone(w.events ?? []) };
      return { kind: "widget" as const, id: wid };
    });
    sections[nid] = { ...s, id: nid, name: `${s.name} copy`, children };
    return nid;
  };
  const nid = cloneSection(sectionId);
  const parent = findParent(module, sectionId);
  let next: ModuleDef = { ...module, widgets, sections };
  if (parent) {
    const s = next.sections[parent.sectionId];
    const children = [...s.children];
    children.splice(parent.index + 1, 0, { kind: "section", id: nid });
    next = { ...next, sections: { ...next.sections, [parent.sectionId]: { ...s, children } } };
  }
  return { module: next, newId: nid };
}

export function collectSectionSubtree(module: ModuleDef, sectionId: string): { sectionIds: string[]; widgetIds: string[] } {
  const sectionIds: string[] = [];
  const widgetIds: string[] = [];
  const walk = (id: string) => {
    const s = module.sections[id];
    if (!s) return;
    sectionIds.push(id);
    for (const c of s.children) {
      if (c.kind === "section") walk(c.id);
      else widgetIds.push(c.id);
    }
  };
  walk(sectionId);
  return { sectionIds, widgetIds };
}

export function deleteSection(module: ModuleDef, sectionId: string): ModuleDef {
  const { sectionIds, widgetIds } = collectSectionSubtree(module, sectionId);
  const parent = findParent(module, sectionId);
  const sections = { ...module.sections };
  const widgets = { ...module.widgets };
  if (parent) {
    const s = sections[parent.sectionId];
    sections[parent.sectionId] = { ...s, children: s.children.filter(c => c.id !== sectionId) };
  }
  for (const id of sectionIds) delete sections[id];
  for (const id of widgetIds) delete widgets[id];
  return { ...module, sections, widgets, unusedWidgetIds: module.unusedWidgetIds.filter(id => !widgetIds.includes(id)), pages: module.pages.filter(p => p.rootSectionId !== sectionId) };
}

export function deletePage(module: ModuleDef, pageId: string): ModuleDef {
  const page = module.pages.find(p => p.id === pageId);
  if (!page) return module;
  let next = deleteSection(module, page.rootSectionId);
  next = { ...next, pages: next.pages.filter(p => p.id !== pageId) };
  return next;
}

export function addPage(module: ModuleDef): { module: ModuleDef; pageId: string } {
  const pid = newId("p");
  const sid = newId("s");
  return {
    pageId: pid,
    module: {
      ...module,
      pages: [...module.pages, { id: pid, name: `New Page ${module.pages.length + 1}`, rootSectionId: sid }],
      sections: { ...module.sections, [sid]: emptySection(sid, "Root", "rows") },
    },
  };
}

export function addOverlay(module: ModuleDef, kind: OverlayDef["kind"]): { module: ModuleDef; overlayId: string } {
  const oid = newId("o");
  const sid = newId("s");
  const overlay: OverlayDef = {
    id: oid, name: kind === "drawer" ? "New Drawer" : "New Modal", kind, rootSectionId: sid,
    side: "right", size: "medium", backdrop: true, closeOnBackdrop: true, closeOnEsc: true, title: kind === "modal" ? "Modal" : undefined,
  };
  return {
    overlayId: oid,
    module: { ...module, overlays: [...module.overlays, overlay], sections: { ...module.sections, [sid]: emptySection(sid, overlay.name, "rows") } },
  };
}

export function widgetsUsingVariable(module: ModuleDef, varId: string): string[] {
  const out: string[] = [];
  for (const [id, w] of Object.entries(module.widgets)) {
    const s = JSON.stringify(w.config) + JSON.stringify(w.events ?? []);
    if (s.includes(varId)) out.push(id);
  }
  return out;
}

export function variablesDependingOn(module: ModuleDef, varId: string): string[] {
  return module.variables.filter(v => (v.dependsOn ?? []).includes(varId) || v.inputVarId === varId).map(v => v.id);
}

export function deleteVariable(module: ModuleDef, varId: string): ModuleDef {
  return { ...module, variables: module.variables.filter(v => v.id !== varId), moduleInterface: module.moduleInterface.filter(m => m.variableId !== varId) };
}

export function describeImpact(module: ModuleDef, kind: "widget" | "section" | "page" | "overlay" | "variable", id: string): string[] {
  if (kind === "widget") {
    const w = module.widgets[id];
    const downs = module.variables.filter(v => v.widgetId === id).map(v => `Variable @${v.name} is a widget output of this widget`);
    return [`Widget "${w?.name ?? id}" (${w?.type}) will be removed`, ...downs];
  }
  if (kind === "section") {
    const { sectionIds, widgetIds } = collectSectionSubtree(module, id);
    return [
      `Section "${module.sections[id]?.name}" and ${sectionIds.length - 1} nested section(s) will be removed`,
      `${widgetIds.length} widget(s) will be deleted: ${widgetIds.slice(0, 6).map(i => module.widgets[i]?.name).filter(Boolean).join(", ")}${widgetIds.length > 6 ? "…" : ""}`,
    ];
  }
  if (kind === "page") {
    const p = module.pages.find(x => x.id === id);
    return [`Page "${p?.name}" will be deleted`, `Its root layout and all nested widgets will be removed`];
  }
  if (kind === "overlay") {
    const o = module.overlays.find(x => x.id === id);
    return [`Overlay "${o?.name}" (${o?.kind}) will be deleted`, `Widgets inside the overlay body will be removed`];
  }
  const v = module.variables.find(x => x.id === id);
  const users = widgetsUsingVariable(module, id);
  const deps = variablesDependingOn(module, id);
  return [
    `Variable @${v?.name} (${v?.type}) will be deleted`,
    users.length ? `${users.length} widget(s) currently bind this variable` : "No widgets bind this variable",
    deps.length ? `${deps.length} downstream variable(s) depend on it: ${deps.join(", ")}` : "No downstream variables",
  ];
}

export type ClipboardPayload =
  | { kind: "widget"; widget: WidgetDef }
  | { kind: "section"; moduleSlice: { sections: Record<string, SectionDef>; widgets: Record<string, WidgetDef>; rootId: string } };

export function copySelection(module: ModuleDef, kind: "widget" | "section", id: string): ClipboardPayload | null {
  if (kind === "widget") {
    const w = module.widgets[id];
    if (!w) return null;
    return { kind: "widget", widget: structuredClone(w) };
  }
  const src = module.sections[id];
  if (!src) return null;
  const { sectionIds, widgetIds } = collectSectionSubtree(module, id);
  const sections: Record<string, SectionDef> = {};
  const widgets: Record<string, WidgetDef> = {};
  for (const sid of sectionIds) sections[sid] = structuredClone(module.sections[sid]);
  for (const wid of widgetIds) widgets[wid] = structuredClone(module.widgets[wid]);
  return { kind: "section", moduleSlice: { sections, widgets, rootId: id } };
}

export function pasteClipboard(module: ModuleDef, clip: ClipboardPayload, targetSectionId: string): { module: ModuleDef; select: { kind: "widget" | "section"; id: string } } | null {
  const target = module.sections[targetSectionId];
  if (!target) return null;
  if (clip.kind === "widget") {
    const nw: WidgetDef = { ...structuredClone(clip.widget), id: newId("w"), name: `${clip.widget.name} copy` };
    const next = addWidgetToSection(module, targetSectionId, nw);
    return { module: next, select: { kind: "widget", id: nw.id } };
  }
  const idMap: Record<string, string> = {};
  const sections = { ...module.sections };
  const widgets = { ...module.widgets };
  for (const oldId of Object.keys(clip.moduleSlice.sections)) idMap[oldId] = newId("s");
  for (const [oldId, s] of Object.entries(clip.moduleSlice.sections)) {
    const nid = idMap[oldId];
    sections[nid] = {
      ...s, id: nid, name: `${s.name} copy`,
      children: s.children.map(c => {
        if (c.kind === "section") return { kind: "section" as const, id: idMap[c.id] };
        const wid = newId("w");
        const w = clip.moduleSlice.widgets[c.id];
        widgets[wid] = { ...w, id: wid, name: `${w.name} copy` };
        return { kind: "widget" as const, id: wid };
      }),
    };
  }
  const newRoot = idMap[clip.moduleSlice.rootId];
  const t = sections[targetSectionId];
  sections[targetSectionId] = { ...t, children: [...t.children, { kind: "section", id: newRoot }] };
  return { module: { ...module, sections, widgets }, select: { kind: "section", id: newRoot } };
}

/**
 * Guarantee every widget/section appears exactly once in the layout tree. A node referenced from several
 * parents is cloned for each extra placement (deterministic ids), so selection, drag & drop and
 * `findParent` are unambiguous.
 */
export function uniquifyTree(m: ModuleDef): ModuleDef {
  const sections = { ...m.sections };
  const widgets = { ...m.widgets };
  const seen = new Set<string>();
  let n = 0;
  const cloneWidget = (id: string): string => {
    const w = widgets[id]; const nid = `${id}~${++n}`;
    widgets[nid] = { ...w, id: nid, config: structuredClone(w.config), events: structuredClone(w.events ?? []) };
    seen.add(nid);
    return nid;
  };
  const cloneSection = (id: string): string => {
    const s = sections[id]; const nid = `${id}~${++n}`;
    seen.add(nid);
    sections[nid] = { ...s, id: nid, children: s.children.map(c => (c.kind === "section" ? { kind: "section" as const, id: cloneSection(c.id) } : { kind: "widget" as const, id: cloneWidget(c.id) })) };
    return nid;
  };
  const visit = (id: string) => {
    const s = sections[id];
    if (!s) return;
    seen.add(id);
    const children = s.children.map(c => {
      if (c.kind === "widget") { if (seen.has(c.id)) return { kind: "widget" as const, id: cloneWidget(c.id) }; seen.add(c.id); return c; }
      if (seen.has(c.id)) return { kind: "section" as const, id: cloneSection(c.id) };
      visit(c.id);
      return c;
    });
    sections[id] = { ...sections[id], children };
  };
  [...m.pages.map(p => p.rootSectionId), ...m.overlays.map(o => o.rootSectionId)].forEach(visit);
  return { ...m, sections, widgets };
}
