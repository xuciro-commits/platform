"use client";
import React from "react";
import type { FlowNodeDef, FlowPortDef } from "../flowTypes";
import { FLOW_NODES, PORT_COLORS } from "../flowCatalog";

export function FlowNodeCard({
  node, status, selected, onRename, onPointerDown, onOutput, onSelect, onContext, onInputUp,
}: {
  node: FlowNodeDef;
  status?: string;
  selected: boolean;
  onRename: (name: string) => void;
  onPointerDown: (e: React.PointerEvent) => void;
  onOutput: (p: FlowPortDef, x: number, y: number) => void;
  onInputUp: (p: FlowPortDef) => void;
  onSelect: () => void;
  onContext: (e: React.MouseEvent) => void;
}) {
  const spec = FLOW_NODES.find(s => s.type === node.type)!;
  const statusColor = status === "success" ? "var(--fnd-success)" : status === "running" ? "var(--fnd-info)" : status === "error" ? "var(--fnd-danger)" : status === "warning" ? "var(--fnd-warning)" : "var(--fnd-border-strong)";
  const summary = Object.entries(node.config).filter(([, v]) => typeof v !== "object").slice(0, 2).map(([k, v]) => `${k}: ${String(v)}`).join(" · ");
  const portRows = Math.max(spec.inputs.length, spec.outputs.length);
  const h = Math.max(142, 84 + portRows * 20);
  return (
    <div data-flow-node={node.id} onPointerDown={onPointerDown} onClick={e => { e.stopPropagation(); onSelect(); }} onContextMenu={onContext}
      style={{ position: "absolute", left: node.x, top: node.y, width: 252, height: h, border: `1px solid ${selected ? "var(--fnd-accent)" : "var(--fnd-border-strong)"}`, borderTop: `3px solid ${spec.color}`, borderRadius: 5, background: "var(--fnd-panel)", boxShadow: selected ? "0 0 0 2px rgba(43,108,176,.2), 0 4px 16px rgba(0,0,0,.12)" : "0 2px 8px rgba(0,0,0,.10)", zIndex: selected ? 4 : 2, opacity: node.disabled ? .5 : 1, cursor: "grab", userSelect: "none" }}>
      <div className="flex items-center gap-1.5 px-2" style={{ height: 34, background: "var(--fnd-panel-2)", borderBottom: "1px solid var(--fnd-border)" }}>
        <span style={{ width: 8, height: 8, borderRadius: 5, background: statusColor, flexShrink: 0 }}/>
        <input className="fnd-input" value={node.name} aria-label="Node name" onPointerDown={e => e.stopPropagation()} onClick={e => e.stopPropagation()} onChange={e => onRename(e.target.value)} style={{ height: 23, fontSize: 11, fontWeight: 600 }}/>
        <span className="fnd-tag" style={{ height: 17, fontSize: 8 }}>{status ?? "idle"}</span>
      </div>
      <div className="px-2 py-1.5" style={{ height: 44 }}>
        <div className="text-[9px] fnd-text-muted leading-snug" style={{ maxHeight: 25, overflow: "hidden" }}>{spec.description}</div>
        {summary && <div className="text-[8px] fnd-text-dim mt-1 truncate" title={summary}>{summary}</div>}
      </div>
      {Array.from({ length: portRows }, (_, i) => {
        const input = spec.inputs[i];
        const output = spec.outputs[i];
        return (
          <div key={i} className="flex items-center justify-between" style={{ height: 20 }}>
            <div style={{ width: "50%" }}>
              {input && <div data-flow-port="input" data-flow-node={node.id} data-port-id={input.id} onPointerUp={e => { e.stopPropagation(); onInputUp(input); }} onClick={e => e.stopPropagation()} className="flex items-center gap-1.5 text-[9px] fnd-text-muted" style={{ position: "relative", padding: "0 6px", height: 20, cursor: "crosshair" }}>
                <PortDot port={input} side="left"/><span className="truncate">{input.label}</span>
              </div>}
            </div>
            <div style={{ width: "50%" }}>
              {output && <div data-flow-port="output" data-flow-node={node.id} data-port-id={output.id} onPointerDown={e => { e.stopPropagation(); onOutput(output, e.clientX, e.clientY); }} onClick={e => e.stopPropagation()} className="flex items-center gap-1.5 justify-end text-[9px] fnd-text-muted" style={{ position: "relative", padding: "0 6px", height: 20, cursor: "crosshair" }}>
                <span className="truncate">{output.label}</span><PortDot port={output} side="right"/>
              </div>}
            </div>
          </div>
        );
      })}
      <div className="absolute left-2 bottom-1 text-[8px] fnd-text-dim">{spec.category} · {spec.cost} cost</div>
    </div>
  );
}

function PortDot({ port, side }: { port: FlowPortDef; side: "left" | "right" }) {
  return <span aria-label={`${port.type} ${port.direction} port`} style={{ position: "absolute", [side]: -6, width: 11, height: 11, borderRadius: 8, border: `2px solid ${PORT_COLORS[port.type]}`, background: "var(--fnd-panel)" }}/>;
}
