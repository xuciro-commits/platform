"use client";
import React, { useEffect, useMemo, useRef, useState } from "react";
import { useWorkshop } from "../WorkshopContext";
import { layoutGraph, routePath, type GEdge, type GNode, type GraphAlgorithm, type LaidOut } from "../elk";
import { variableDeps } from "../engine";
import { widgetDeps } from "../widgets/SectionRenderer";

// ═══ Generic pan/zoom graph canvas on top of ELK ═══════════════════════════
export interface GraphNodeIn<T> extends GNode { data: T }
export interface NodeState { selected: boolean; dim: boolean; hl: boolean }
interface Props<T> {
  nodes: Array<GraphNodeIn<T>>; edges: GEdge[]; algorithm?: GraphAlgorithm;
  renderNode: (n: GraphNodeIn<T>, s: NodeState) => React.ReactNode;
  selectedId?: string | null; onSelect?: (id: string) => void; highlight?: Set<string> | null; dimmed?: Set<string> | null;
  edgeLabel?: (edgeId: string) => string | undefined; onEdgeClick?: (edgeId: string) => void; emptyText?: string; toolbar?: React.ReactNode;
}
interface T3 { k: number; x: number; y: number }

export function GraphCanvas<T>({ nodes, edges, algorithm = "layered-right", renderNode, selectedId, onSelect, highlight, dimmed, edgeLabel, onEdgeClick, emptyText, toolbar }: Props<T>) {
  const [laid, setLaid] = useState<LaidOut | null>(null);
  const [status, setStatus] = useState<"layout" | "ready" | "error">("layout");
  const [err, setErr] = useState("");
  const [t, setT] = useState<T3>({ k: 1, x: 0, y: 0 });
  const [size, setSize] = useState({ w: 600, h: 400 });
  const wrap = useRef<HTMLDivElement>(null);
  const tRef = useRef(t); tRef.current = t;
  const sizeRef = useRef(size); sizeRef.current = size;
  const moved = useRef(false);

  const fitTo = (l: LaidOut | null, s = sizeRef.current) => {
    if (!l) return;
    const k = Math.min(1.25, Math.max(0.1, Math.min((s.w - 32) / l.width, (s.h - 32) / l.height)));
    setT({ k, x: (s.w - l.width * k) / 2, y: (s.h - l.height * k) / 2 });
  };

  const sig = useMemo(() => `${algorithm}|${nodes.map(n => `${n.id}:${n.w}x${n.h}`).join(",")}|${edges.map(e => e.id).join(",")}`, [algorithm, nodes, edges]);
  useEffect(() => {
    if (nodes.length === 0) { setLaid(null); setStatus("ready"); return; }
    let cancel = false;
    setStatus("layout");
    layoutGraph(nodes, edges, algorithm)
      .then(l => { if (!cancel) { setLaid(l); setStatus("ready"); fitTo(l); } })
      .catch(e => { if (!cancel) { setErr((e as Error).message ?? String(e)); setStatus("error"); } });
    return () => { cancel = true; };
    // layout depends only on structure signature
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sig]);

  useEffect(() => {
    const el = wrap.current; if (!el) return;
    const apply = () => setSize({ w: el.clientWidth, h: el.clientHeight });
    apply();
    const ro = new ResizeObserver(apply); ro.observe(el);
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const r = el.getBoundingClientRect(), px = e.clientX - r.left, py = e.clientY - r.top, cur = tRef.current;
      const k = Math.min(3, Math.max(0.08, cur.k * Math.exp(-e.deltaY * 0.0016)));
      setT({ k, x: px - ((px - cur.x) / cur.k) * k, y: py - ((py - cur.y) / cur.k) * k });
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => { ro.disconnect(); el.removeEventListener("wheel", onWheel); };
  }, []);

  // keep the selected node visible
  useEffect(() => {
    if (!selectedId || !laid?.nodes[selectedId]) return;
    const n = laid.nodes[selectedId], cur = tRef.current, s = sizeRef.current;
    const sx = n.x * cur.k + cur.x, sy = n.y * cur.k + cur.y;
    if (sx < 20 || sy < 20 || sx + n.w * cur.k > s.w - 20 || sy + n.h * cur.k > s.h - 20) setT({ k: cur.k, x: s.w / 2 - (n.x + n.w / 2) * cur.k, y: s.h / 2 - (n.y + n.h / 2) * cur.k });
  }, [selectedId, laid]);

  const onPointerDown = (e: React.PointerEvent) => {
    if (e.button !== 0) return;
    moved.current = false;
    const sx = e.clientX, sy = e.clientY, o = tRef.current;
    const move = (ev: PointerEvent) => { const dx = ev.clientX - sx, dy = ev.clientY - sy; if (Math.hypot(dx, dy) > 3) moved.current = true; setT({ k: o.k, x: o.x + dx, y: o.y + dy }); };
    const up = () => { window.removeEventListener("pointermove", move); window.removeEventListener("pointerup", up); };
    window.addEventListener("pointermove", move); window.addEventListener("pointerup", up);
  };
  const zoomBy = (f: number) => { const cur = tRef.current, s = sizeRef.current; const k = Math.min(3, Math.max(0.08, cur.k * f)); setT({ k, x: s.w / 2 - ((s.w / 2 - cur.x) / cur.k) * k, y: s.h / 2 - ((s.h / 2 - cur.y) / cur.k) * k }); };

  const byId = useMemo(() => new Map(nodes.map(n => [n.id, n])), [nodes]);

  return (
    <div className="h-full flex flex-col min-h-0">
      <div className="flex items-center gap-1 px-2 border-b fnd-border" style={{ height: 34, flexShrink: 0, background: "var(--fnd-panel)" }}>
        {toolbar}
        <div className="flex-1"/>
        <button className="fnd-btn fnd-btn-minimal" title="Zoom out" aria-label="Zoom out" onClick={() => zoomBy(1 / 1.3)}>−</button>
        <span className="text-[11px] tabular-nums fnd-text-muted" style={{ width: 40, textAlign: "center" }}>{Math.round(t.k * 100)}%</span>
        <button className="fnd-btn fnd-btn-minimal" title="Zoom in" aria-label="Zoom in" onClick={() => zoomBy(1.3)}>+</button>
        <button className="fnd-btn fnd-btn-minimal" title="Fit view" onClick={() => fitTo(laid)}>Fit</button>
        <button className="fnd-btn fnd-btn-minimal" title="Actual size" onClick={() => setT(c => ({ ...c, k: 1 }))}>100%</button>
      </div>
      <div ref={wrap} className="flex-1 relative min-h-0 fnd-canvas-bg" style={{ overflow: "hidden" }}>
        {status === "layout" && <div className="absolute inset-0 flex items-center justify-center text-xs fnd-text-muted" style={{ zIndex: 2 }}><span className="fnd-pulse">Computing layout with ELK…</span></div>}
        {status === "error" && <div className="absolute inset-0 flex items-center justify-center text-xs p-6 text-center" style={{ color: "var(--fnd-danger)" }}>Layout failed: {err}</div>}
        {status === "ready" && nodes.length === 0 && <div className="absolute inset-0 flex items-center justify-center text-xs fnd-text-dim">{emptyText ?? "Nothing to show."}</div>}
        <svg width="100%" height="100%" onPointerDown={onPointerDown} style={{ touchAction: "none", cursor: "grab", display: "block" }} role="img" aria-label="Dependency graph">
          <defs>
            <marker id="g-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0 0L10 5L0 10z" fill="var(--fnd-border-strong)"/></marker>
            <marker id="g-arrow-hl" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0 0L10 5L0 10z" fill="var(--fnd-accent)"/></marker>
          </defs>
          {laid && (
            <g transform={`translate(${t.x} ${t.y}) scale(${t.k})`} style={{ opacity: status === "ready" ? 1 : 0.4 }}>
              {edges.map(e => {
                const pts = laid.edges[e.id]; if (!pts) return null;
                const on = !highlight || (highlight.has(e.from) && highlight.has(e.to));
                const hl = !!highlight && on;
                const lbl = edgeLabel?.(e.id);
                const mid = pts[Math.floor(pts.length / 2)];
                return (
                  <g key={e.id} style={{ cursor: onEdgeClick ? "pointer" : undefined }} onClick={() => { if (!moved.current) onEdgeClick?.(e.id); }}>
                    <path d={routePath(pts)} fill="none" stroke={hl ? "var(--fnd-accent)" : "var(--fnd-border-strong)"} strokeWidth={hl ? 2 : 1.2} opacity={on ? 1 : 0.15} markerEnd={hl ? "url(#g-arrow-hl)" : "url(#g-arrow)"}/>
                    {onEdgeClick && <path d={routePath(pts)} fill="none" stroke="transparent" strokeWidth={12}/>}
                    {lbl && mid && <g transform={`translate(${mid.x} ${mid.y})`} opacity={on ? 1 : 0.2}><rect x={-56} y={-9} width={112} height={18} rx={3} fill="var(--fnd-panel)" stroke="var(--fnd-border)"/><text textAnchor="middle" y={4} fontSize={10} fill="var(--fnd-text-muted)">{lbl}</text></g>}
                  </g>
                );
              })}
              {Object.entries(laid.nodes).map(([id, p]) => {
                const n = byId.get(id); if (!n) return null;
                const isHl = !!highlight?.has(id);
                const dim = (!!highlight && !isHl) || (!!dimmed && dimmed.has(id));
                return (
                  <g key={id} transform={`translate(${p.x} ${p.y})`} opacity={dim ? 0.22 : 1} style={{ cursor: onSelect ? "pointer" : "default" }}
                    onClick={() => { if (!moved.current) onSelect?.(id); }}>
                    {renderNode(n, { selected: id === selectedId, dim, hl: isHl })}
                  </g>
                );
              })}
            </g>
          )}
        </svg>
      </div>
    </div>
  );
}

// ═══ Variable lineage ══════════════════════════════════════════════════════
type LNode = { kind: "var" | "widget"; label: string; sub: string };

export function LineageView() {
  const { module, select, selection, setLeftPanel } = useWorkshop();
  const [withWidgets, setWithWidgets] = useState(true);
  const [q, setQ] = useState("");
  const [algo, setAlgo] = useState<GraphAlgorithm>("layered-right");

  const graph = useMemo(() => {
    const nodes: Array<GraphNodeIn<LNode>> = [];
    const edges: GEdge[] = [];
    const varIds = new Set(module.variables.map(v => v.id));
    for (const v of module.variables) nodes.push({ id: `v:${v.id}`, w: 156, h: 28, data: { kind: "var", label: v.name, sub: `${v.type} · ${v.definitionKind}` } });
    for (const v of module.variables) for (const d of variableDeps(v)) if (varIds.has(d)) edges.push({ id: `e:${d}>${v.id}`, from: `v:${d}`, to: `v:${v.id}` });
    if (withWidgets) {
      for (const w of Object.values(module.widgets)) {
        if (module.unusedWidgetIds.includes(w.id)) continue;
        const deps = widgetDeps(w, module.variables);
        const outputs = module.variables.filter(v => v.widgetId === w.id);
        if (deps.length === 0 && outputs.length === 0) continue;
        nodes.push({ id: `w:${w.id}`, w: 156, h: 28, data: { kind: "widget", label: w.name, sub: w.type } });
        for (const d of deps) if (!outputs.some(o => o.id === d)) edges.push({ id: `e:${d}>w${w.id}`, from: `v:${d}`, to: `w:${w.id}` });
        for (const o of outputs) edges.push({ id: `e:w${w.id}>${o.id}`, from: `w:${w.id}`, to: `v:${o.id}` });
      }
    }
    return { nodes, edges };
  }, [module, withWidgets]);

  const selId = selection.kind === "variable" && selection.id ? `v:${selection.id}` : selection.kind === "widget" && selection.id ? `w:${selection.id}` : null;
  const { highlight, up, down } = useMemo(() => {
    if (!selId || !graph.nodes.some(n => n.id === selId)) return { highlight: null as Set<string> | null, up: 0, down: 0 };
    const out = new Map<string, string[]>(), inc = new Map<string, string[]>();
    for (const e of graph.edges) { (out.get(e.from) ?? out.set(e.from, []).get(e.from)!).push(e.to); (inc.get(e.to) ?? inc.set(e.to, []).get(e.to)!).push(e.from); }
    const bfs = (adj: Map<string, string[]>) => { const seen = new Set<string>(); const stack = [selId]; while (stack.length) { const c = stack.pop()!; for (const n of adj.get(c) ?? []) if (!seen.has(n)) { seen.add(n); stack.push(n); } } return seen; };
    const u = bfs(inc), d = bfs(out);
    return { highlight: new Set([selId, ...u, ...d]), up: u.size, down: d.size };
  }, [graph, selId]);

  const dimmed = useMemo(() => {
    if (!q.trim()) return null;
    const needle = q.toLowerCase();
    return new Set(graph.nodes.filter(n => !n.data.label.toLowerCase().includes(needle) && !n.id.toLowerCase().includes(needle)).map(n => n.id));
  }, [q, graph]);

  return (
    <div className="h-full flex flex-col" style={{ background: "var(--fnd-bg)" }}>
      <div className="flex items-center gap-2 px-3 border-b fnd-border" style={{ height: 36, background: "var(--fnd-panel)", flexShrink: 0 }}>
        <span className="text-xs font-semibold">Variable lineage</span>
        <span className="fnd-text-dim text-[11px]">{graph.nodes.length} nodes · {graph.edges.length} edges{highlight ? ` · ▲ ${up} upstream · ▼ ${down} downstream` : ""}</span>
        <div className="flex-1"/>
        <button className="fnd-btn fnd-btn-minimal" onClick={() => setLeftPanel("variables")}>Back to list</button>
      </div>
      <div className="flex-1 min-h-0">
        <GraphCanvas
          nodes={graph.nodes} edges={graph.edges} algorithm={algo} highlight={highlight} dimmed={dimmed} selectedId={selId}
          onSelect={id => select(id.startsWith("v:") ? { kind: "variable", id: id.slice(2) } : { kind: "widget", id: id.slice(2) })}
          emptyText="No variables yet."
          toolbar={
            <>
              <input className="fnd-input" style={{ width: 170, height: 24 }} placeholder="Search nodes…" value={q} onChange={e => setQ(e.target.value)} aria-label="Search lineage nodes"/>
              <label className="flex items-center gap-1 text-[11px] fnd-text-muted"><input type="checkbox" checked={withWidgets} onChange={e => setWithWidgets(e.target.checked)}/> widgets</label>
              <select className="fnd-input fnd-select" style={{ width: 108, height: 24 }} value={algo} onChange={e => setAlgo(e.target.value as GraphAlgorithm)} aria-label="Layout direction"><option value="layered-right">Layered →</option><option value="layered-down">Layered ↓</option><option value="stress">Force</option></select>
              <span className="flex items-center gap-2 text-[10px] fnd-text-dim ml-2"><i style={{ width: 10, height: 10, background: "var(--fnd-panel)", border: "1px solid var(--fnd-border-strong)", display: "inline-block" }}/> variable <i style={{ width: 10, height: 10, background: "#f5e8d2", border: "1px solid #d9822b", display: "inline-block" }}/> widget</span>
            </>
          }
          renderNode={(n, s) => (
            <>
              <rect width={n.w} height={n.h} rx={3} fill={n.data.kind === "widget" ? "#f5e8d2" : s.selected ? "var(--fnd-selection)" : "var(--fnd-panel)"} stroke={s.selected ? "var(--fnd-accent)" : s.hl ? "var(--fnd-accent)" : n.data.kind === "widget" ? "#d9822b" : "var(--fnd-border-strong)"} strokeWidth={s.selected ? 2.2 : 1}/>
              <text x={8} y={18} fontSize={11} fontWeight={600} fill={n.data.kind === "widget" ? "#5c3a0a" : "var(--fnd-text)"}>{n.data.label.length > 21 ? n.data.label.slice(0, 20) + "…" : n.data.label}</text>
              <title>{`${n.data.label} — ${n.data.sub}`}</title>
            </>
          )}
        />
      </div>
    </div>
  );
}
