"use client";
import React, { useMemo, useState } from "react";
import { useWorkshop } from "../WorkshopContext";
import { Icon } from "../widgets/icons";
import { formatValue } from "../widgets/WidgetRenderer";
import { widgetDeps } from "../widgets/SectionRenderer";
import { describeImpact, deleteVariable } from "../moduleOps";
import { lineageStore, useStore } from "../runtimeStores";
import type { VariableDef } from "../types";

const TYPES = ["string", "numeric", "boolean", "date", "timestamp", "array", "object", "objectSet", "objectSetFilter", "objectProperty", "struct", "geoPoint", "geoShape", "timeSeriesSet"];
const TYPE_ABBR: Record<string, string> = { string: "Aa", numeric: "#", boolean: "✓", date: "📅", timestamp: "⏱", array: "[ ]", object: "◆", objectSet: "◆◆", struct: "{ }", geoPoint: "⌖", geoShape: "⬡", timeSeriesSet: "〰", objectSetFilter: "⛃", objectProperty: "·" };

export function VariablesPanel() {
  const { module, select, selection, values, updateModule, requestConfirm, openContextMenu } = useWorkshop();
  const lineageOpen = useStore(lineageStore, s => s);
  const [q, setQ] = useState("");
  const [type, setType] = useState("");
  const [kind, setKind] = useState("");

  const matches = (v: VariableDef) => (!q || v.name.toLowerCase().includes(q.toLowerCase()) || v.id.toLowerCase().includes(q.toLowerCase())) && (!type || v.type === type) && (!kind || v.definitionKind === kind);
  const filtered = useMemo(() => module.variables.filter(matches), [module.variables, q, type, kind]); // eslint-disable-line react-hooks/exhaustive-deps

  const usedBySelection = useMemo(() => {
    if (selection.kind !== "widget" || !selection.id) return [];
    const w = module.widgets[selection.id];
    if (!w) return [];
    const ids = new Set(widgetDeps(w, module.variables));
    return module.variables.filter(v => ids.has(v.id) && matches(v));
  }, [selection, module, q, type, kind]); // eslint-disable-line react-hooks/exhaustive-deps

  const addVariable = () => {
    const id = `var${Date.now().toString(36)}`;
    updateModule(m => ({ ...m, variables: [...m.variables, { id, name: `newVariable${m.variables.length + 1}`, type: "string", definitionKind: "static", recompute: "automatic", staticValue: "" }] }), "add variable");
    select({ kind: "variable", id });
  };
  const remove = (v: VariableDef) => requestConfirm({
    title: "Delete variable", message: `Delete @${v.name}. Widgets and variables that read it will report an unresolved reference.`,
    impact: describeImpact(module, "variable", v.id),
    onConfirm: () => { updateModule(m => deleteVariable(m, v.id), "delete variable"); select({ kind: null, id: null }); },
  });

  const Row = (v: VariableDef) => {
    const sel = selection.kind === "variable" && selection.id === v.id;
    return (
      <div key={v.id} role="button" tabIndex={0} onClick={() => select({ kind: "variable", id: v.id })} onKeyDown={e => { if (e.key === "Enter") select({ kind: "variable", id: v.id }); }}
        onContextMenu={e => { e.preventDefault(); select({ kind: "variable", id: v.id }); openContextMenu(e.clientX, e.clientY, [{ label: "Show in lineage", onClick: () => lineageStore.set(true) }, { separator: true, label: "" }, { label: "Delete", danger: true, onClick: () => remove(v) }]); }}
        className={`fnd-tree-row ${sel ? "selected" : ""}`} style={{ height: 34, flexDirection: "column", alignItems: "flex-start", justifyContent: "center", padding: "2px 8px" }}>
        <div className="flex items-center gap-1.5 w-full min-w-0">
          <span className="fnd-tag" style={{ height: 16, minWidth: 24, justifyContent: "center", fontSize: 9 }} title={v.type}>{TYPE_ABBR[v.type] ?? "?"}</span>
          <span className="font-semibold truncate" title={v.id}>{v.name}</span>
          <span className="ml-auto text-[9px] fnd-text-dim whitespace-nowrap">{v.definitionKind}</span>
        </div>
        <div className="truncate w-full text-[10px] fnd-text-dim pl-[30px]">= {formatValue(values[v.id])}</div>
      </div>
    );
  };

  return (
    <div className="h-full flex flex-col text-xs">
      <div className="px-2.5 py-2 border-b fnd-border flex items-center gap-2">
        <div className="fnd-label">Variables</div>
        <span className="fnd-tag">{module.variables.length}</span>
        <div className="flex-1"/>
        <button className={`fnd-btn ${lineageOpen ? "fnd-btn-primary" : ""}`} title="Open the dependency lineage graph (ELK layout)" aria-pressed={lineageOpen} onClick={() => lineageStore.set(!lineageOpen)}><Icon.Diagram size={11}/> Lineage</button>
        <button className="fnd-btn fnd-btn-primary" onClick={addVariable}><Icon.Plus size={11}/> New</button>
      </div>
      <div className="px-2 py-2 border-b fnd-border space-y-1.5">
        <input className="fnd-input" placeholder="Search by name or ID" value={q} onChange={e => setQ(e.target.value)} aria-label="Search variables"/>
        <div className="flex gap-1">
          <select className="fnd-input fnd-select" value={type} onChange={e => setType(e.target.value)} aria-label="Filter by type"><option value="">All types</option>{TYPES.map(t => <option key={t}>{t}</option>)}</select>
          <select className="fnd-input fnd-select" value={kind} onChange={e => setKind(e.target.value)} aria-label="Filter by definition"><option value="">All definitions</option>{["static", "function", "objectSetAggregation", "objectProperty", "objectSetDefinition", "variableTransformation", "sqlQuery", "widgetOutput"].map(t => <option key={t}>{t}</option>)}</select>
        </div>
      </div>
      <div className="flex-1 overflow-auto">
        {usedBySelection.length > 0 && (
          <>
            <div className="px-2 pt-2 pb-1 fnd-label">Used by {module.widgets[selection.id ?? ""]?.name} ({usedBySelection.length})</div>
            {usedBySelection.map(Row)}
          </>
        )}
        <div className="px-2 pt-2 pb-1 fnd-label">All variables ({filtered.length})</div>
        {filtered.map(Row)}
        {filtered.length === 0 && <div className="p-4 text-center fnd-text-dim">No variables match.</div>}
      </div>
    </div>
  );
}
