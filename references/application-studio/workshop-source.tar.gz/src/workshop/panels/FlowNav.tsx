"use client";
import React, { useState } from "react";
import { useWorkshop } from "../WorkshopContext";
import { Icon } from "../widgets/icons";
import { FLOW_NODES, makeDemoFlow } from "../flowCatalog";
import { getFlowRuntime, validateFlow } from "../flowEngine";
import { newId } from "../moduleOps";
import type { FlowDef } from "../flowTypes";

export function FlowNav() {
  const { module, activeFlowId, setActiveFlowId, select, updateModule, requestConfirm, openContextMenu } = useWorkshop();
  const [search, setSearch] = useState("");
  const totalNodes = module.flows.reduce((s, f) => s + f.nodes.length, 0);
  const totalEdges = module.flows.reduce((s, f) => s + f.edges.length, 0);
  const flows = module.flows.filter(f => `${f.name} ${f.description}`.toLowerCase().includes(search.toLowerCase()));
  const add = () => {
    const id = newId("flow-");
    const f: FlowDef = { id, name: `New pipeline ${module.flows.length + 1}`, description: "Drag nodes and connect typed ports", enabled: true, version: 1, nodes: [], edges: [], execution: { mode: "onDemand", maxConcurrency: 4, checkpointEvery: 100, errorPolicy: "deadLetter", scheduleMs: 1000 } };
    updateModule(m => ({ ...m, flows: [...m.flows, f] }), "add flow"); setActiveFlowId(id); select({ kind: "flow", id });
  };
  const clone = (f: FlowDef, template = false) => {
    const copy = structuredClone(f);
    const ids = new Map(copy.nodes.map(n => [n.id, newId("fn")]));
    copy.id = newId("flow-"); copy.name = template ? `Operations stream ${module.flows.length + 1}` : `${f.name} copy`;
    copy.version = 1; copy.nodes.forEach(n => { n.id = ids.get(n.id)!; });
    copy.edges.forEach(e => { e.id = newId("fe"); e.source = ids.get(e.source)!; e.target = ids.get(e.target)!; });
    updateModule(m => ({ ...m, flows: [...m.flows, copy] }), "duplicate flow"); setActiveFlowId(copy.id); select({ kind: "flow", id: copy.id });
  };
  const remove = (f: FlowDef) => requestConfirm({
    title: "Delete pipeline", message: `Remove “${f.name}” and its graph?`,
    impact: [`${f.nodes.length} nodes and ${f.edges.length} connections will be removed`, "Previous audited runs remain in the database"],
    onConfirm: () => {
      updateModule(m => ({ ...m, flows: m.flows.filter(item => item.id !== f.id) }), "delete flow");
      getFlowRuntime(f.id).reset();
      const next = module.flows.find(item => item.id !== f.id);
      if (next) { setActiveFlowId(next.id); select({ kind: "flow", id: next.id }); }
      else select({ kind: null, id: null });
    },
  });
  return (
    <div className="h-full flex flex-col text-xs">
      <div className="flex items-center px-2.5 py-2 border-b fnd-border"><span className="fnd-label flex-1">Data flows</span><button className="fnd-btn fnd-btn-primary" onClick={add}><Icon.Plus size={10}/> New</button></div>
      <div className="grid grid-cols-2 gap-1 p-2 border-b fnd-border">
        <div className="fnd-panel rounded-sm p-2"><div className="fnd-text-dim text-[9px] uppercase">Pipelines</div><div className="font-bold text-base">{module.flows.length}</div></div>
        <div className="fnd-panel rounded-sm p-2"><div className="fnd-text-dim text-[9px] uppercase">Nodes / wires</div><div className="font-bold text-base">{totalNodes} / {totalEdges}</div></div>
      </div>
      <div className="p-2 border-b fnd-border space-y-1">
        <input className="fnd-input" placeholder="Search pipelines…" value={search} onChange={e => setSearch(e.target.value)}/>
        <button className="fnd-btn w-full justify-center" onClick={() => clone(makeDemoFlow(), true)}><Icon.Plus size={11}/> Operations stream template</button>
      </div>
      <div className="flex-1 overflow-auto p-1.5">
        {flows.map(f => {
          const issues = validateFlow(f);
          return <button key={f.id} className={`w-full text-left p-2 rounded-sm mb-1 ${activeFlowId === f.id ? "fnd-selected" : "fnd-row-hover"}`}
            onClick={() => { setActiveFlowId(f.id); select({ kind: "flow", id: f.id }); }}
            onContextMenu={e => { e.preventDefault(); openContextMenu(e.clientX, e.clientY, [
              { label: "Open settings", onClick: () => { setActiveFlowId(f.id); select({ kind: "flow", id: f.id }); } },
              { label: "Duplicate", onClick: () => clone(f) },
              { label: f.enabled ? "Disable" : "Enable", onClick: () => updateModule(m => ({ ...m, flows: m.flows.map(x => x.id === f.id ? { ...x, enabled: !x.enabled } : x) }), "toggle flow") },
              { label: "Reset runtime window & cursors", onClick: () => getFlowRuntime(f.id).reset() },
              { separator: true, label: "" }, { label: "Delete", danger: true, onClick: () => remove(f) },
            ]); }}
            style={{ border: `1px solid ${activeFlowId === f.id ? "var(--fnd-accent)" : "var(--fnd-border)"}` }}>
            <div className="flex items-center gap-1"><Icon.Flow size={12}/><span className="font-semibold truncate flex-1">{f.name}</span><span title={f.enabled ? "Enabled" : "Disabled"} style={{ width: 7, height: 7, borderRadius: 4, background: f.enabled ? "var(--fnd-success)" : "var(--fnd-text-dim)" }}/></div>
            <div className="text-[10px] fnd-text-muted mt-1">{f.nodes.length} nodes · {f.edges.length} wires · {f.execution.mode}</div>
            <div className="text-[9px] fnd-text-dim truncate mt-0.5">{issues.length ? `⚠ ${issues.length} validation issue(s)` : f.description}</div>
          </button>;
        })}
        {flows.length === 0 && <div className="p-4 fnd-text-dim text-center">No pipelines match your search.</div>}
      </div>
      <div className="p-2 border-t fnd-border"><div className="fnd-label mb-1">Node library</div><div className="text-[10px] fnd-text-muted">{FLOW_NODES.length} typed processors · bounded windows · WebAssembly aggregation · Ontology Actions</div></div>
    </div>
  );
}
