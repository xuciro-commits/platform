"use client";
import React, { useMemo, useState, useSyncExternalStore } from "react";
import { useWorkshop } from "../WorkshopContext";
import { GraphCanvas } from "./GraphViews";
import { Icon } from "../widgets/icons";
import {
  AGGREGATIONS, BASE_TYPES, CONDITION_OPERATORS, formatPropertyValue, getObjects, linkTypesFor, pivotTo, primaryKeyOf, rid, runFunction, validateAction,
  type ActionParameterDef, type ActionRuleDef, type ActionTypeDef, type BaseType, type ConditionOperator, type LinkCardinality,
  type LinkTypeDef, type ObjectTypeDef, type OntologyMeta, type PropertyTypeDef,
} from "../ontologyMeta";

// ─── tiny shared selection store (nav ⇄ main view) ─────────────────────────
type OSel = { kind: "graph" | "objectType" | "linkType" | "actionType" | "function" | "interface" | "sharedProperty"; id: string };
let current: OSel = { kind: "graph", id: "" };
const listeners = new Set<() => void>();
const store = {
  get: () => current,
  set: (s: OSel) => { current = s; listeners.forEach(l => l()); },
  sub: (l: () => void) => { listeners.add(l); return () => { listeners.delete(l); }; },
};
function useOSel(): [OSel, (s: OSel) => void] {
  const s = useSyncExternalStore(store.sub, store.get, store.get);
  return [s, store.set];
}

const STATUS_COLORS: Record<string, { bg: string; fg: string }> = {
  ACTIVE: { bg: "#e4f1e5", fg: "#296936" },
  EXPERIMENTAL: { bg: "#fdf1dc", fg: "#8a5a16" },
  DEPRECATED: { bg: "#fde0e0", fg: "#8a1f1f" },
};
function StatusTag({ s }: { s: string }) {
  const c = STATUS_COLORS[s] ?? { bg: "#e9ecef", fg: "#555" };
  return <span className="fnd-tag" style={{ background: c.bg, color: c.fg, borderColor: "transparent", fontWeight: 600 }}>{s.toLowerCase()}</span>;
}
function TypeBadge({ ot, size = 22 }: { ot?: ObjectTypeDef; size?: number }) {
  return (
    <span style={{ width: size, height: size, borderRadius: 3, background: ot?.color ?? "#8a9ba8", color: "white", display: "inline-flex", alignItems: "center", justifyContent: "center", fontSize: size * 0.5, fontWeight: 800, flexShrink: 0 }}>
      {ot?.icon ?? "?"}
    </span>
  );
}
const BT_ICON: Record<string, string> = { String: "Aa", Integer: "#", Long: "#", Short: "#", Byte: "#", Double: "1.0", Decimal: "1.0", Float: "1.0", Boolean: "✓", Date: "📅", Timestamp: "⏱", GeoPoint: "⌖", GeoShape: "⬡", Array: "[ ]", Struct: "{ }", Attachment: "📎", MediaReference: "▶", TimeSeries: "〰", Marking: "🔒", Vector: "→", CipherText: "***" };
export function BaseTypeIcon({ t }: { t: string }) {
  return <span className="fnd-tag" style={{ height: 18, minWidth: 34, justifyContent: "center", fontFamily: "ui-monospace, Menlo, monospace", fontSize: 10 }}>{BT_ICON[t] ?? "?"}</span>;
}
const CARD_LABEL: Record<LinkCardinality, string> = { ONE_TO_ONE: "1 : 1", ONE_TO_MANY: "1 : N", MANY_TO_ONE: "N : 1", MANY_TO_MANY: "N : N" };

function linkOrientedProps(l: LinkTypeDef) {
  // "from"/"to" oriented accessors used throughout the UI; objectTypeA is always "from".
  return { from: l.objectTypeA, to: l.objectTypeB };
}

// ─── Left nav ──────────────────────────────────────────────────────────────
export function OntologyNav() {
  const { ontologyMeta: meta, updateOntologyMeta, ontology, resetOntologyMeta, requestConfirm } = useWorkshop();
  const [sel, setSel] = useOSel();
  const [q, setQ] = useState("");
  const match = (s: string) => !q || s.toLowerCase().includes(q.toLowerCase());

  const addObjectType = () => {
    const n = meta.objectTypes.length + 1;
    const apiName = `CustomType${n}`;
    updateOntologyMeta(m => ({
      ...m,
      objectTypes: [...m.objectTypes, {
        apiName, rid: rid("object-type"), apiNamespace: m.apiNamespace, displayName: `Custom Type ${n}`, pluralDisplayName: `Custom Types ${n}`, description: "New object type", icon: "C", color: "#8f398f",
        primaryKeyPropertyApiNames: ["id"], titlePropertyApiName: "name", status: "EXPERIMENTAL",
        datasource: { rid: rid("dataset"), type: "dataset", path: `/ontology/datasets/custom_${n}`, syncMode: "snapshot" }, groups: [], implementsInterfaces: [],
        properties: [
          { apiName: "id", rid: rid("property-type"), displayName: "ID", baseType: "String", visibility: "PROMINENT" },
          { apiName: "name", rid: rid("property-type"), displayName: "Name", baseType: "String", visibility: "PROMINENT", searchable: true },
        ],
      }],
    }));
    setSel({ kind: "objectType", id: apiName });
  };
  const addLinkType = () => {
    const apiName = `newLink${meta.linkTypes.length + 1}`;
    const a = meta.objectTypes[0]?.apiName ?? "", b = meta.objectTypes[1]?.apiName ?? a;
    updateOntologyMeta(m => ({ ...m, linkTypes: [...m.linkTypes, { apiName, rid: rid("link-type"), displayName: "Related", reverseDisplayName: "Related from", objectTypeA: a, objectTypeB: b, cardinality: "ONE_TO_MANY", definition: { type: "foreignKey", foreignKeyObjectType: b, foreignKeyProperty: "id", primaryKeyObjectType: a }, status: "EXPERIMENTAL" }] }));
    setSel({ kind: "linkType", id: apiName });
  };
  const addActionType = () => {
    const apiName = `newAction${meta.actionTypes.length + 1}`;
    const a = meta.objectTypes[0]?.apiName ?? "";
    updateOntologyMeta(m => ({ ...m, actionTypes: [...m.actionTypes, {
      apiName, rid: rid("action-type"), displayName: "New action", description: "", status: "EXPERIMENTAL", submissionGroups: [], notifications: [],
      parameters: [{ apiName: "object", displayName: "Object", type: "ObjectReference", validation: { required: true, objectTypeApiName: a } }],
      rules: [{ kind: "modifyObjectRule", objectParameterApiName: "object", propertyMappings: {} }], submissionCriteria: [],
    }] }));
    setSel({ kind: "actionType", id: apiName });
  };

  const Row = ({ s, label, right, icon }: { s: OSel; label: string; right?: React.ReactNode; icon?: React.ReactNode }) => (
    <div className={`fnd-tree-row ${sel.kind === s.kind && sel.id === s.id ? "selected" : ""}`} onClick={() => setSel(s)} style={{ height: 26 }}>
      {icon}<span className="ml-1.5 truncate flex-1">{label}</span>{right}
    </div>
  );
  const Group = ({ title, count, onAdd, children }: { title: string; count: number; onAdd?: () => void; children: React.ReactNode }) => (
    <div className="mb-2">
      <div className="flex items-center px-1.5 py-1">
        <span className="fnd-label flex-1">{title}</span>
        <span className="fnd-tag mr-1" style={{ height: 16 }}>{count}</span>
        {onAdd && <button className="fnd-btn fnd-btn-minimal" style={{ height: 20, padding: "0 4px" }} title={`New ${title.toLowerCase()}`} onClick={onAdd}><Icon.Plus size={10}/></button>}
      </div>
      {children}
    </div>
  );

  return (
    <div className="h-full flex flex-col text-xs">
      <div className="px-2.5 py-2 border-b fnd-border flex items-center gap-2">
        <div className="fnd-label">Ontology Manager</div>
        <div className="flex-1"/>
        <button className="fnd-btn fnd-btn-minimal" title="Reset ontology metadata" onClick={() => requestConfirm({ title: "Reset ontology", message: "Restore the default ontology metadata.", impact: ["All object type, link type and action type edits will be lost"], onConfirm: resetOntologyMeta })}>Reset</button>
      </div>
      <div className="px-2.5 py-1 text-[10px] fnd-text-dim font-mono truncate border-b fnd-border">{meta.apiNamespace}</div>
      <div className="p-2 border-b fnd-border"><input className="fnd-input" placeholder="Search ontology…" value={q} onChange={e => setQ(e.target.value)}/></div>
      <div className="flex-1 overflow-auto p-1">
        <Row s={{ kind: "graph", id: "" }} label="Ontology graph" icon={<Icon.Diagram size={12}/>}/>
        <div className="h-2"/>
        <Group title="Object types" count={meta.objectTypes.length} onAdd={addObjectType}>
          {meta.objectTypes.filter(o => match(o.displayName + o.apiName)).map(o => (
            <Row key={o.apiName} s={{ kind: "objectType", id: o.apiName }} label={o.displayName} icon={<TypeBadge ot={o} size={16}/>}
              right={<span className="fnd-text-dim tabular-nums">{getObjects(ontology, o.apiName).length}</span>}/>
          ))}
        </Group>
        <Group title="Link types" count={meta.linkTypes.length} onAdd={addLinkType}>
          {meta.linkTypes.filter(l => match(l.apiName + l.displayName)).map(l => (
            <Row key={l.apiName} s={{ kind: "linkType", id: l.apiName }} label={`${l.objectTypeA} → ${l.objectTypeB}`} icon={<Icon.Flow size={11}/>}
              right={<span className="fnd-tag" style={{ height: 16 }}>{CARD_LABEL[l.cardinality]}</span>}/>
          ))}
        </Group>
        <Group title="Action types" count={meta.actionTypes.length} onAdd={addActionType}>
          {meta.actionTypes.filter(a => match(a.apiName + a.displayName)).map(a => (
            <Row key={a.apiName} s={{ kind: "actionType", id: a.apiName }} label={a.displayName} icon={<Icon.Action size={11}/>}/>
          ))}
        </Group>
        <Group title="Functions / Queries" count={meta.functions.length}>
          {meta.functions.filter(f => match(f.apiName)).map(f => (
            <Row key={f.apiName} s={{ kind: "function", id: f.apiName }} label={f.apiName} icon={<Icon.Code size={11}/>} right={<span className="fnd-text-dim">{f.language === "Python" ? "py" : f.language === "Java" ? "jv" : "ts"}</span>}/>
          ))}
        </Group>
        <Group title="Interfaces" count={meta.interfaces.length}>
          {meta.interfaces.filter(i => match(i.apiName)).map(i => (
            <Row key={i.apiName} s={{ kind: "interface", id: i.apiName }} label={i.displayName} icon={<Icon.Overlay size={11}/>}/>
          ))}
        </Group>
        <Group title="Shared property types" count={meta.sharedProperties.length}>
          {meta.sharedProperties.filter(s => match(s.apiName)).map(s => (
            <Row key={s.apiName} s={{ kind: "sharedProperty", id: s.apiName }} label={s.displayName} icon={<BaseTypeIcon t={s.baseType}/>}/>
          ))}
        </Group>
      </div>
    </div>
  );
}

// ─── Main view ─────────────────────────────────────────────────────────────
export function OntologyManager() {
  const { ontologyMeta: meta } = useWorkshop();
  const [sel] = useOSel();
  let body: React.ReactNode = null;
  if (sel.kind === "graph") body = <OntologyGraph/>;
  else if (sel.kind === "objectType") { const o = meta.objectTypes.find(x => x.apiName === sel.id); body = o ? <ObjectTypeDetail ot={o}/> : <Missing/>; }
  else if (sel.kind === "linkType") { const l = meta.linkTypes.find(x => x.apiName === sel.id); body = l ? <LinkTypeDetail lt={l}/> : <Missing/>; }
  else if (sel.kind === "actionType") { const a = meta.actionTypes.find(x => x.apiName === sel.id); body = a ? <ActionTypeDetail at={a}/> : <Missing/>; }
  else if (sel.kind === "function") body = <FunctionDetail id={sel.id}/>;
  else if (sel.kind === "interface") body = <InterfaceDetail id={sel.id}/>;
  else if (sel.kind === "sharedProperty") body = <SharedPropertyDetail id={sel.id}/>;
  return (
    <div className="h-full flex flex-col overflow-hidden" style={{ background: "var(--fnd-bg)" }}>
      <div className="flex items-center gap-2 px-4 border-b fnd-border" style={{ height: 36, background: "var(--fnd-panel)", flexShrink: 0 }}>
        <Icon.Diagram size={13}/>
        <span className="text-xs font-semibold">{meta.apiNamespace}</span>
        <span className="fnd-text-dim text-[11px]">· {meta.objectTypes.length} object types · {meta.linkTypes.length} link types · {meta.actionTypes.length} action types · {meta.functions.length} functions</span>
      </div>
      <div className="flex-1 overflow-auto p-4">{body}</div>
    </div>
  );
}

function Missing() { return <div className="text-xs fnd-text-dim">This entity no longer exists.</div>; }

function Card({ title, right, children }: { title: string; right?: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="fnd-panel rounded-sm mb-3">
      <div className="flex items-center gap-2 px-3 border-b fnd-border" style={{ height: 34 }}>
        <span className="text-xs font-semibold">{title}</span><div className="flex-1"/>{right}
      </div>
      <div className="p-3">{children}</div>
    </div>
  );
}
function KV({ k, children }: { k: string; children: React.ReactNode }) {
  return <div className="flex items-start gap-3 py-1 text-xs"><span className="fnd-text-muted" style={{ width: 150, flexShrink: 0 }}>{k}</span><span className="flex-1 min-w-0">{children}</span></div>;
}

function useMetaUpdate() {
  const { updateOntologyMeta } = useWorkshop();
  return {
    updObj: (api: string, patch: Partial<ObjectTypeDef>) => updateOntologyMeta(m => ({ ...m, objectTypes: m.objectTypes.map(o => o.apiName === api ? { ...o, ...patch } : o) })),
    updLink: (api: string, patch: Partial<LinkTypeDef>) => updateOntologyMeta(m => ({ ...m, linkTypes: m.linkTypes.map(o => o.apiName === api ? { ...o, ...patch } : o) })),
    updAction: (api: string, patch: Partial<ActionTypeDef>) => updateOntologyMeta(m => ({ ...m, actionTypes: m.actionTypes.map(o => o.apiName === api ? { ...o, ...patch } : o) })),
    raw: updateOntologyMeta,
  };
}

// ─── Object type ───────────────────────────────────────────────────────────
function ObjectTypeDetail({ ot }: { ot: ObjectTypeDef }) {
  const { ontology, ontologyMeta: meta, requestConfirm, module } = useWorkshop();
  const { updObj, raw } = useMetaUpdate();
  const [, setSel] = useOSel();
  const [tab, setTab] = useState<"overview" | "properties" | "links" | "actions" | "data" | "usage">("overview");
  const objs = getObjects(ontology, ot.apiName);
  const links = linkTypesFor(meta, ot.apiName);
  const actions = meta.actionTypes.filter(a => a.parameters.some(p => p.validation.objectTypeApiName === ot.apiName) || a.rules.some(r => r.kind === "addObjectRule" && r.objectTypeApiName === ot.apiName));
  const usedBy = module.variables.filter(v => v.objectSet?.objectType === ot.apiName);

  const updProp = (i: number, patch: Partial<PropertyTypeDef>) => updObj(ot.apiName, { properties: ot.properties.map((p, j) => j === i ? { ...p, ...patch } : p) });

  return (
    <div style={{ maxWidth: 1180 }}>
      <div className="flex items-center gap-3 mb-3">
        <TypeBadge ot={ot} size={36}/>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <input className="text-lg font-semibold bg-transparent" style={{ border: 0, outline: "none", color: "var(--fnd-text)", width: "auto", minWidth: 120 }} value={ot.displayName} onChange={e => updObj(ot.apiName, { displayName: e.target.value })}/>
            <StatusTag s={ot.status}/>
          </div>
          <div className="text-xs fnd-text-muted font-mono">{ot.apiNamespace}.{ot.apiName} · {ot.rid} · {objs.length.toLocaleString()} objects · {ot.properties.length} properties</div>
        </div>
        <button className="fnd-btn fnd-btn-danger" onClick={() => requestConfirm({
          title: "Delete object type", message: `Delete object type ${ot.apiName} from the ontology.`,
          impact: [`${links.length} link type(s) reference this type`, `${actions.length} action type(s) reference this type`, `${usedBy.length} module variable(s) use it as an object set source`],
          onConfirm: () => { raw(m => ({ ...m, objectTypes: m.objectTypes.filter(o => o.apiName !== ot.apiName), linkTypes: m.linkTypes.filter(l => l.objectTypeA !== ot.apiName && l.objectTypeB !== ot.apiName) })); setSel({ kind: "graph", id: "" }); },
        })}><Icon.Trash size={11}/> Delete</button>
      </div>
      <div className="flex border-b fnd-border mb-3">
        {(["overview", "properties", "links", "actions", "data", "usage"] as const).map(t => (
          <button key={t} onClick={() => setTab(t)} className="px-3 py-1.5 text-xs font-medium capitalize"
            style={{ borderBottom: tab === t ? "2px solid var(--fnd-accent)" : "2px solid transparent", color: tab === t ? "var(--fnd-text)" : "var(--fnd-text-muted)" }}>
            {t}{t === "properties" ? ` (${ot.properties.length})` : t === "links" ? ` (${links.length})` : t === "actions" ? ` (${actions.length})` : ""}
          </button>
        ))}
      </div>

      {tab === "overview" && (
        <div className="grid gap-3" style={{ gridTemplateColumns: "1fr 1fr" }}>
          <Card title="Metadata">
            <KV k="Display name"><input className="fnd-input" value={ot.displayName} onChange={e => updObj(ot.apiName, { displayName: e.target.value })}/></KV>
            <KV k="Plural display name"><input className="fnd-input" value={ot.pluralDisplayName} onChange={e => updObj(ot.apiName, { pluralDisplayName: e.target.value })}/></KV>
            <KV k="Description"><textarea className="fnd-input" style={{ height: 52, paddingTop: 4 }} value={ot.description} onChange={e => updObj(ot.apiName, { description: e.target.value })}/></KV>
            <KV k="Icon / color">
              <div className="flex gap-2">
                <input className="fnd-input" style={{ width: 50 }} maxLength={2} value={ot.icon} onChange={e => updObj(ot.apiName, { icon: e.target.value })}/>
                <input type="color" value={ot.color} onChange={e => updObj(ot.apiName, { color: e.target.value })} style={{ width: 40, height: 28, border: "1px solid var(--fnd-border-strong)", borderRadius: 3 }}/>
              </div>
            </KV>
            <KV k="Status">
              <select className="fnd-input fnd-select" value={ot.status} onChange={e => updObj(ot.apiName, { status: e.target.value as ObjectTypeDef["status"] })}>
                <option value="ACTIVE">Active</option><option value="EXPERIMENTAL">Experimental</option><option value="DEPRECATED">Deprecated</option>
              </select>
            </KV>
          </Card>
          <Card title="Keys & backing datasource">
            <KV k="Primary key">
              <select className="fnd-input fnd-select" value={primaryKeyOf(ot)} onChange={e => updObj(ot.apiName, { primaryKeyPropertyApiNames: [e.target.value] })}>
                {ot.properties.map(p => <option key={p.apiName} value={p.apiName}>{p.displayName} ({p.apiName})</option>)}
              </select>
            </KV>
            <KV k="Title property">
              <select className="fnd-input fnd-select" value={ot.titlePropertyApiName} onChange={e => updObj(ot.apiName, { titlePropertyApiName: e.target.value })}>
                {ot.properties.map(p => <option key={p.apiName} value={p.apiName}>{p.displayName} ({p.apiName})</option>)}
              </select>
            </KV>
            <KV k="Datasource type">
              <select className="fnd-input fnd-select" value={ot.datasource.type} onChange={e => updObj(ot.apiName, { datasource: { ...ot.datasource, type: e.target.value as "dataset" | "stream" | "media-set" } })}>
                <option value="dataset">Dataset</option><option value="stream">Stream</option><option value="media-set">Media set</option>
              </select>
            </KV>
            <KV k="Path"><span className="font-mono text-[11px]">{ot.datasource.path}</span></KV>
            <KV k="Sync mode">
              <select className="fnd-input fnd-select" value={ot.datasource.syncMode} onChange={e => updObj(ot.apiName, { datasource: { ...ot.datasource, syncMode: e.target.value as "snapshot" | "incremental" } })}>
                <option value="snapshot">Snapshot</option><option value="incremental">Incremental</option>
              </select>
            </KV>
            <KV k="Objects indexed"><strong className="tabular-nums">{objs.length.toLocaleString()}</strong></KV>
            <KV k="Groups"><div className="flex gap-1 flex-wrap">{ot.groups.map(g => <span key={g} className="fnd-tag">{g}</span>)}{ot.groups.length === 0 && <span className="fnd-text-dim">—</span>}</div></KV>
            <KV k="Implements interfaces">
              <div className="flex gap-1 flex-wrap">
                {meta.interfaces.map(i => {
                  const impl = ot.implementsInterfaces.find(x => x.interfaceApiName === i.apiName);
                  return (
                    <button key={i.apiName} className="fnd-tag" style={{ cursor: "pointer", background: impl ? "var(--fnd-selection)" : undefined, borderColor: impl ? "var(--fnd-accent)" : undefined, color: impl ? "var(--fnd-accent)" : undefined }}
                      onClick={() => updObj(ot.apiName, { implementsInterfaces: impl ? ot.implementsInterfaces.filter(x => x.interfaceApiName !== i.apiName) : [...ot.implementsInterfaces, { interfaceApiName: i.apiName, propertyMapping: {} }] })}>
                      {impl ? "✓ " : ""}{i.displayName}
                    </button>
                  );
                })}
              </div>
            </KV>
            {ot.implementsInterfaces.map(impl => {
              const iface = meta.interfaces.find(i => i.apiName === impl.interfaceApiName);
              if (!iface) return null;
              return (
                <KV key={impl.interfaceApiName} k={`↳ ${iface.displayName} mapping`}>
                  <div className="space-y-1">
                    {iface.sharedPropertyApiNames.map(sp => {
                      const spDef = meta.sharedProperties.find(s => s.apiName === sp);
                      return (
                        <div key={sp} className="flex items-center gap-1 text-[11px]">
                          <span style={{ width: 90 }}>{spDef?.displayName ?? sp}</span><span className="fnd-text-dim">←</span>
                          <select className="fnd-input fnd-select" style={{ height: 22 }} value={impl.propertyMapping[sp] ?? ""} onChange={e => updObj(ot.apiName, { implementsInterfaces: ot.implementsInterfaces.map(x => x.interfaceApiName === impl.interfaceApiName ? { ...x, propertyMapping: { ...x.propertyMapping, [sp]: e.target.value } } : x) })}>
                            <option value="">—</option>
                            {ot.properties.map(p => <option key={p.apiName} value={p.apiName}>{p.apiName}</option>)}
                          </select>
                        </div>
                      );
                    })}
                  </div>
                </KV>
              );
            })}
          </Card>
        </div>
      )}

      {tab === "properties" && (
        <Card title="Property types" right={
          <button className="fnd-btn" onClick={() => updObj(ot.apiName, { properties: [...ot.properties, { apiName: `property${ot.properties.length + 1}`, rid: rid("property-type"), displayName: `Property ${ot.properties.length + 1}`, baseType: "String", visibility: "NORMAL", searchable: true, sortable: true }] })}>
            <Icon.Plus size={11}/> Add property type
          </button>
        }>
          <table className="w-full text-xs" style={{ borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ background: "var(--fnd-panel-2)" }}>
                {["", "Display name", "API name", "Base type", "Visibility", "Format / unit", "Shared prop.", "Derived", "Req.", ""].map((h, i) => (
                  <th key={i} style={{ textAlign: "left", padding: "6px", fontSize: 10, textTransform: "uppercase", color: "var(--fnd-text-muted)", borderBottom: "1px solid var(--fnd-border)" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {ot.properties.map((p, i) => (
                <tr key={i} style={{ borderBottom: "1px solid var(--fnd-border)" }}>
                  <td style={{ padding: 4 }}><BaseTypeIcon t={p.baseType}/></td>
                  <td style={{ padding: 4 }}>
                    <div className="flex items-center gap-1">
                      <input className="fnd-input" value={p.displayName} onChange={e => updProp(i, { displayName: e.target.value })}/>
                      {primaryKeyOf(ot) === p.apiName && <span className="fnd-tag" title="Primary key">PK</span>}
                      {ot.titlePropertyApiName === p.apiName && <span className="fnd-tag" title="Title property">T</span>}
                    </div>
                  </td>
                  <td style={{ padding: 4 }}><input className="fnd-input font-mono" style={{ fontSize: 11 }} value={p.apiName} onChange={e => updProp(i, { apiName: e.target.value.replace(/[^a-zA-Z0-9_]/g, "") })}/></td>
                  <td style={{ padding: 4 }}>
                    <select className="fnd-input fnd-select" value={p.baseType} onChange={e => updProp(i, { baseType: e.target.value as BaseType })}>
                      {BASE_TYPES.map(t => <option key={t}>{t}</option>)}
                    </select>
                  </td>
                  <td style={{ padding: 4 }}>
                    <select className="fnd-input fnd-select" value={p.visibility} onChange={e => updProp(i, { visibility: e.target.value as PropertyTypeDef["visibility"] })}>
                      <option value="PROMINENT">Prominent</option><option value="NORMAL">Normal</option><option value="HIDDEN">Hidden</option>
                    </select>
                  </td>
                  <td style={{ padding: 4 }}>
                    <div className="flex gap-1">
                      <select className="fnd-input fnd-select" style={{ width: 92 }} value={p.valueFormatting ?? "none"} onChange={e => updProp(i, { valueFormatting: e.target.value as PropertyTypeDef["valueFormatting"] })}>
                        {["none", "number", "percent", "currency", "date", "datetime", "unit"].map(f => <option key={f}>{f}</option>)}
                      </select>
                      <input className="fnd-input" style={{ width: 50 }} placeholder="unit" value={p.unit ?? ""} onChange={e => updProp(i, { unit: e.target.value })}/>
                    </div>
                  </td>
                  <td style={{ padding: 4 }}>
                    <select className="fnd-input fnd-select" style={{ width: 110 }} value={p.sharedPropertyType ?? ""} onChange={e => updProp(i, { sharedPropertyType: e.target.value || undefined })}>
                      <option value="">—</option>
                      {meta.sharedProperties.map(s => <option key={s.apiName} value={s.apiName}>{s.displayName}</option>)}
                    </select>
                  </td>
                  <td style={{ padding: 4, textAlign: "center" }}>{p.derivation ? <span className="fnd-tag" title={`${p.derivation.linkTypeApiNames.join(" → ")} · ${p.derivation.aggregation}`}>Σ</span> : <span className="fnd-text-dim">—</span>}</td>
                  <td style={{ padding: 4, textAlign: "center" }}><input type="checkbox" checked={primaryKeyOf(ot) === p.apiName || !!p.derivation ? false : !p.nullable} disabled={!!p.derivation} onChange={e => updProp(i, { nullable: !e.target.checked })}/></td>
                  <td style={{ padding: 4 }}>
                    <button className="fnd-btn fnd-btn-minimal" title="Delete property" disabled={primaryKeyOf(ot) === p.apiName}
                      onClick={() => updObj(ot.apiName, { properties: ot.properties.filter((_, j) => j !== i) })}><Icon.Trash size={11}/></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="text-[10px] fnd-text-dim mt-2">Base types drive formatting, filter operators and widget compatibility across Workshop. Hidden properties are excluded from Object Views and Property Lists. Σ marks a property computed via Object & Link Types → derived properties.</div>
        </Card>
      )}

      {tab === "links" && (
        <Card title="Link types">
          {links.length === 0 && <div className="text-xs fnd-text-dim">This object type has no link types.</div>}
          {links.map(({ link, target, label, many }) => {
            const sample = objs[0] ? pivotTo(ontology, meta, link.apiName, [objs[0]]).length : 0;
            const tot = meta.objectTypes.find(o => o.apiName === target);
            return (
              <div key={link.apiName + target} className="flex items-center gap-3 py-2 border-b fnd-border text-xs cursor-pointer fnd-row-hover" onClick={() => setSel({ kind: "linkType", id: link.apiName })}>
                <TypeBadge ot={ot} size={18}/>
                <span className="fnd-text-dim">—{many ? "<" : "—"}</span>
                <TypeBadge ot={tot} size={18}/>
                <span className="font-semibold">{label}</span>
                <span className="fnd-tag">{CARD_LABEL[link.cardinality]}</span>
                <span className="fnd-text-dim font-mono">{link.apiName}</span>
                <div className="flex-1"/>
                <span className="fnd-text-dim">{link.definition.type === "foreignKey" ? `FK ${link.definition.foreignKeyObjectType}.${link.definition.foreignKeyProperty}` : `join table ${link.definition.datasetRid}`}</span>
                <span className="fnd-text-muted">e.g. {sample} linked from {String(objs[0]?.id ?? "—")}</span>
              </div>
            );
          })}
        </Card>
      )}

      {tab === "actions" && (
        <Card title="Action types operating on this object type">
          {actions.length === 0 && <div className="text-xs fnd-text-dim">No action types reference this object type.</div>}
          {actions.map(a => (
            <div key={a.apiName} className="flex items-center gap-2 py-2 border-b fnd-border text-xs cursor-pointer fnd-row-hover" onClick={() => setSel({ kind: "actionType", id: a.apiName })}>
              <Icon.Action size={12}/><span className="font-semibold">{a.displayName}</span><StatusTag s={a.status}/>
              <span className="fnd-text-dim">{a.parameters.length} params · {a.rules.length} rules · {a.submissionCriteria.length} criteria</span>
              <div className="flex-1"/>
              {a.rules.map((r, i) => <span key={i} className="fnd-tag">{r.kind}</span>)}
            </div>
          ))}
        </Card>
      )}

      {tab === "data" && <ObjectDataPreview ot={ot}/>}

      {tab === "usage" && (
        <Card title="Usage in this Workshop module">
          {usedBy.length === 0 && <div className="text-xs fnd-text-dim">No module variables are backed by this object type.</div>}
          {usedBy.map(v => (
            <div key={v.id} className="flex items-center gap-2 py-1.5 border-b fnd-border text-xs">
              <Icon.Variable size={11}/><span className="font-semibold">@{v.name}</span>
              <span className="fnd-tag">{v.definitionKind}</span>
              <span className="fnd-text-dim">{(v.objectSet?.steps ?? []).length} pipeline step(s)</span>
            </div>
          ))}
        </Card>
      )}
    </div>
  );
}

function ObjectDataPreview({ ot }: { ot: ObjectTypeDef }) {
  const { ontology, ontologyMeta: meta } = useWorkshop();
  const [q, setQ] = useState("");
  const objs = getObjects(ontology, ot.apiName);
  const props = ot.properties.filter(p => p.visibility !== "HIDDEN").slice(0, 9);
  const rows = objs.filter(o => !q || Object.values(o).some(v => typeof v === "string" && v.toLowerCase().includes(q.toLowerCase())));
  return (
    <Card title={`Data preview · ${rows.length.toLocaleString()} of ${objs.length.toLocaleString()} objects`} right={<input className="fnd-input" style={{ width: 200 }} placeholder="Search objects…" value={q} onChange={e => setQ(e.target.value)}/>}>
      <div className="overflow-auto" style={{ maxHeight: 460 }}>
        <table className="w-full text-xs" style={{ borderCollapse: "collapse" }}>
          <thead className="sticky top-0" style={{ background: "var(--fnd-panel-2)" }}>
            <tr>{props.map(p => <th key={p.apiName} style={{ textAlign: "left", padding: "6px 8px", borderBottom: "1px solid var(--fnd-border)", whiteSpace: "nowrap" }}><span className="mr-1"><BaseTypeIcon t={p.baseType}/></span>{p.displayName}</th>)}</tr>
          </thead>
          <tbody>
            {rows.slice(0, 100).map((o, i) => (
              <tr key={String(o[primaryKeyOf(ot)] ?? i)} style={{ borderBottom: "1px solid var(--fnd-border)" }} className="fnd-row-hover">
                {props.map(p => <td key={p.apiName} style={{ padding: "5px 8px", whiteSpace: "nowrap" }}>{formatPropertyValue(p, p.derivation ? "derived" : o[p.apiName])}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
        {rows.length === 0 && <div className="p-4 text-center text-xs fnd-text-dim">No {ot.pluralDisplayName.toLowerCase()} match.</div>}
      </div>
      <div className="text-[10px] fnd-text-dim mt-2">Derived property values are shown per-object in Workshop widgets (Property List, Object View) and computed live via link traversal + aggregation.</div>
    </Card>
  );
}

// ─── Link type ─────────────────────────────────────────────────────────────
function LinkTypeDetail({ lt }: { lt: LinkTypeDef }) {
  const { ontologyMeta: meta, ontology, requestConfirm } = useWorkshop();
  const { updLink, raw } = useMetaUpdate();
  const [, setSel] = useOSel();
  const { from, to } = linkOrientedProps(lt);
  const fromOt = meta.objectTypes.find(o => o.apiName === from);
  const toOt = meta.objectTypes.find(o => o.apiName === to);
  const fkHolderType = lt.definition.type === "foreignKey" ? lt.definition.foreignKeyObjectType : undefined;
  const fkOwnerOt = meta.objectTypes.find(o => o.apiName === fkHolderType);
  const sources = getObjects(ontology, from).slice(0, 5);
  return (
    <div style={{ maxWidth: 980 }}>
      <div className="flex items-center gap-3 mb-3">
        <Icon.Flow size={20}/>
        <div className="flex-1">
          <div className="text-lg font-semibold">{from} → {to}</div>
          <div className="text-xs fnd-text-muted font-mono">{lt.apiName} · {lt.rid}</div>
        </div>
        <StatusTag s={lt.status}/>
        <button className="fnd-btn fnd-btn-danger" onClick={() => requestConfirm({ title: "Delete link type", message: `Delete ${lt.apiName}.`, impact: ["pivotTo()/Search Around steps and Links widgets using this link will resolve to empty sets"], onConfirm: () => { raw(m => ({ ...m, linkTypes: m.linkTypes.filter(l => l.apiName !== lt.apiName) })); setSel({ kind: "graph", id: "" }); } })}><Icon.Trash size={11}/> Delete</button>
      </div>
      <Card title="Relationship type">
        <div className="flex items-center justify-center gap-6 py-4">
          <div className="flex flex-col items-center gap-1"><TypeBadge ot={fromOt} size={40}/><span className="text-xs font-semibold">{fromOt?.displayName ?? from}</span></div>
          <div className="flex flex-col items-center" style={{ minWidth: 220 }}>
            <span className="text-[11px] fnd-text-muted">{lt.displayName} →</span>
            <div style={{ height: 2, width: "100%", background: "var(--fnd-accent)", position: "relative", margin: "6px 0" }}>
              <span className="fnd-tag" style={{ position: "absolute", left: "50%", top: -11, transform: "translateX(-50%)", background: "var(--fnd-panel)" }}>{CARD_LABEL[lt.cardinality]}</span>
            </div>
            <span className="text-[11px] fnd-text-muted">← {lt.reverseDisplayName}</span>
          </div>
          <div className="flex flex-col items-center gap-1"><TypeBadge ot={toOt} size={40}/><span className="text-xs font-semibold">{toOt?.displayName ?? to}</span></div>
        </div>
      </Card>
      <div className="grid gap-3" style={{ gridTemplateColumns: "1fr 1fr" }}>
        <Card title="Definition">
          <KV k="Source object type"><select className="fnd-input fnd-select" value={lt.objectTypeA} onChange={e => updLink(lt.apiName, { objectTypeA: e.target.value })}>{meta.objectTypes.map(o => <option key={o.apiName}>{o.apiName}</option>)}</select></KV>
          <KV k="Target object type"><select className="fnd-input fnd-select" value={lt.objectTypeB} onChange={e => updLink(lt.apiName, { objectTypeB: e.target.value })}>{meta.objectTypes.map(o => <option key={o.apiName}>{o.apiName}</option>)}</select></KV>
          <KV k="Cardinality"><select className="fnd-input fnd-select" value={lt.cardinality} onChange={e => updLink(lt.apiName, { cardinality: e.target.value as LinkCardinality })}>{(Object.keys(CARD_LABEL) as LinkCardinality[]).map(c => <option key={c} value={c}>{c} ({CARD_LABEL[c]})</option>)}</select></KV>
          <KV k="Forward label"><input className="fnd-input" value={lt.displayName} onChange={e => updLink(lt.apiName, { displayName: e.target.value })}/></KV>
          <KV k="Reverse label"><input className="fnd-input" value={lt.reverseDisplayName} onChange={e => updLink(lt.apiName, { reverseDisplayName: e.target.value })}/></KV>
          <KV k="Status"><select className="fnd-input fnd-select" value={lt.status} onChange={e => updLink(lt.apiName, { status: e.target.value as LinkTypeDef["status"] })}><option value="ACTIVE">Active</option><option value="EXPERIMENTAL">Experimental</option><option value="DEPRECATED">Deprecated</option></select></KV>
        </Card>
        <Card title="Link resources (backing)">
          <KV k="Relationship backing">
            <select className="fnd-input fnd-select" value={lt.definition.type} onChange={e => updLink(lt.apiName, { definition: e.target.value === "foreignKey" ? { type: "foreignKey", foreignKeyObjectType: lt.objectTypeB, foreignKeyProperty: "id", primaryKeyObjectType: lt.objectTypeA } : { type: "joinTable", datasetRid: rid("dataset"), objectTypeAProperty: "id", objectTypeBProperty: "id" } })}>
              <option value="foreignKey">Object type foreign keys</option>
              <option value="joinTable">Join table dataset</option>
            </select>
          </KV>
          {lt.definition.type === "foreignKey" ? (
            <>
              <KV k="Foreign key held by"><select className="fnd-input fnd-select" value={lt.definition.foreignKeyObjectType} onChange={e => { const d = lt.definition; if (d.type === "foreignKey") updLink(lt.apiName, { definition: { ...d, foreignKeyObjectType: e.target.value } }); }}><option value={lt.objectTypeA}>{lt.objectTypeA} (source)</option><option value={lt.objectTypeB}>{lt.objectTypeB} (target)</option></select></KV>
              <KV k="Foreign key property"><select className="fnd-input fnd-select" value={lt.definition.foreignKeyProperty} onChange={e => { const d = lt.definition; if (d.type === "foreignKey") updLink(lt.apiName, { definition: { ...d, foreignKeyProperty: e.target.value } }); }}>{(fkOwnerOt?.properties ?? []).map(p => <option key={p.apiName} value={p.apiName}>{p.displayName} ({p.apiName})</option>)}</select></KV>
              <KV k="References primary key">
                <span className="font-mono text-[11px]">{(lt.definition.foreignKeyObjectType === lt.objectTypeA ? toOt : fromOt)?.apiName}.{primaryKeyOf(lt.definition.foreignKeyObjectType === lt.objectTypeA ? toOt : fromOt)}</span>
              </KV>
            </>
          ) : (
            <>
              <KV k="Join table dataset"><input className="fnd-input font-mono" value={lt.definition.datasetRid} onChange={e => { const d = lt.definition; if (d.type === "joinTable") updLink(lt.apiName, { definition: { ...d, datasetRid: e.target.value } }); }}/></KV>
              <KV k={`${lt.objectTypeA} key column`}><input className="fnd-input" value={lt.definition.objectTypeAProperty} onChange={e => { const d = lt.definition; if (d.type === "joinTable") updLink(lt.apiName, { definition: { ...d, objectTypeAProperty: e.target.value } }); }}/></KV>
              <KV k={`${lt.objectTypeB} key column`}><input className="fnd-input" value={lt.definition.objectTypeBProperty} onChange={e => { const d = lt.definition; if (d.type === "joinTable") updLink(lt.apiName, { definition: { ...d, objectTypeBProperty: e.target.value } }); }}/></KV>
              <div className="text-[10px] fnd-text-dim">Many-to-many cardinality requires a join table dataset to support writeback.</div>
            </>
          )}
        </Card>
      </div>
      <Card title="pivotTo() preview (first 5 source objects)">
        {sources.map(s => {
          const linked = pivotTo(ontology, meta, lt.apiName, [s]);
          return (
            <div key={String(s.id)} className="flex items-center gap-2 py-1 border-b fnd-border text-xs">
              <span className="font-mono" style={{ width: 90 }}>{String(s.id)}</span>
              <span className="truncate" style={{ width: 180 }}>{String(s[fromOt?.titlePropertyApiName ?? "name"] ?? "")}</span>
              <span>.pivotTo(&quot;{lt.apiName}&quot;) →</span><span className="fnd-tag">{linked.length} {toOt?.pluralDisplayName ?? to}</span>
              <span className="truncate fnd-text-dim flex-1">{linked.slice(0, 3).map(o => String(o[toOt?.titlePropertyApiName ?? "name"] ?? o.id)).join(", ")}</span>
            </div>
          );
        })}
        {sources.length === 0 && <div className="text-xs fnd-text-dim">Source object type has no objects.</div>}
      </Card>
    </div>
  );
}

// ─── Action type ───────────────────────────────────────────────────────────
function ActionTypeDetail({ at }: { at: ActionTypeDef }) {
  const { ontologyMeta: meta, requestConfirm } = useWorkshop();
  const { updAction, raw } = useMetaUpdate();
  const [, setSel] = useOSel();
  const [tab, setTab] = useState<"parameters" | "rules" | "criteria" | "test" | "security">("parameters");
  const updParam = (i: number, patch: Partial<ActionParameterDef>) => updAction(at.apiName, { parameters: at.parameters.map((p, j) => j === i ? { ...p, ...patch } : p) });
  const updParamValidation = (i: number, patch: Partial<ActionParameterDef["validation"]>) => updParam(i, { validation: { ...at.parameters[i].validation, ...patch } });
  const updRule = (i: number, r: ActionRuleDef) => updAction(at.apiName, { rules: at.rules.map((x, j) => j === i ? r : x) });
  const updCrit = (i: number, patch: Partial<ActionTypeDef["submissionCriteria"][number]>) => updAction(at.apiName, { submissionCriteria: at.submissionCriteria.map((c, j) => j === i ? { ...c, ...patch } : c) });
  const objParams = at.parameters.filter(p => p.type === "ObjectReference");

  return (
    <div style={{ maxWidth: 1100 }}>
      <div className="flex items-center gap-3 mb-3">
        <span style={{ width: 36, height: 36, borderRadius: 3, background: "#e3ecfa", color: "#1e4a85", display: "flex", alignItems: "center", justifyContent: "center" }}><Icon.Action size={20}/></span>
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <input className="text-lg font-semibold bg-transparent" style={{ border: 0, outline: "none", color: "var(--fnd-text)" }} value={at.displayName} onChange={e => updAction(at.apiName, { displayName: e.target.value })}/>
            <StatusTag s={at.status}/>
          </div>
          <div className="text-xs fnd-text-muted font-mono">{at.apiName} · {at.rid} · edits {[...new Set(at.rules.map(r => r.kind === "addObjectRule" ? r.objectTypeApiName : at.parameters.find(p => "objectParameterApiName" in r && p.apiName === r.objectParameterApiName)?.validation.objectTypeApiName))].filter(Boolean).join(", ")}</div>
        </div>
        <button className="fnd-btn fnd-btn-danger" onClick={() => requestConfirm({ title: "Delete action type", message: `Delete ${at.apiName}.`, impact: ["Inline Action widgets and Kanban/Approval widgets referencing it will show a configuration error"], onConfirm: () => { raw(m => ({ ...m, actionTypes: m.actionTypes.filter(a => a.apiName !== at.apiName) })); setSel({ kind: "graph", id: "" }); } })}><Icon.Trash size={11}/> Delete</button>
      </div>
      <div className="flex border-b fnd-border mb-3">
        {(["parameters", "rules", "criteria", "test", "security"] as const).map(t => (
          <button key={t} onClick={() => setTab(t)} className="px-3 py-1.5 text-xs font-medium capitalize"
            style={{ borderBottom: tab === t ? "2px solid var(--fnd-accent)" : "2px solid transparent", color: tab === t ? "var(--fnd-text)" : "var(--fnd-text-muted)" }}>
            {t === "criteria" ? `Submission criteria (${at.submissionCriteria.length})` : t === "parameters" ? `Parameters (${at.parameters.length})` : t === "rules" ? `Logic / Rules (${at.rules.length})` : t === "test" ? "Test run" : "Security & notifications"}
          </button>
        ))}
      </div>

      {tab === "parameters" && (
        <Card title="Parameters" right={<button className="fnd-btn" onClick={() => updAction(at.apiName, { parameters: [...at.parameters, { apiName: `param${at.parameters.length + 1}`, displayName: `Parameter ${at.parameters.length + 1}`, type: "String", validation: { required: false } }] })}><Icon.Plus size={11}/> Add parameter</button>}>
          <table className="w-full text-xs" style={{ borderCollapse: "collapse" }}>
            <thead><tr style={{ background: "var(--fnd-panel-2)" }}>{["Display name", "API name", "Type", "Object type", "Required", "Default from", "Validation", ""].map(h => <th key={h} style={{ textAlign: "left", padding: 6, fontSize: 10, textTransform: "uppercase", color: "var(--fnd-text-muted)" }}>{h}</th>)}</tr></thead>
            <tbody>
              {at.parameters.map((p, i) => (
                <tr key={i} style={{ borderBottom: "1px solid var(--fnd-border)" }}>
                  <td style={{ padding: 3 }}><input className="fnd-input" value={p.displayName} onChange={e => updParam(i, { displayName: e.target.value })}/></td>
                  <td style={{ padding: 3 }}><input className="fnd-input font-mono" style={{ fontSize: 11 }} value={p.apiName} onChange={e => updParam(i, { apiName: e.target.value.replace(/[^a-zA-Z0-9_]/g, "") })}/></td>
                  <td style={{ padding: 3 }}>
                    <select className="fnd-input fnd-select" value={p.type} onChange={e => updParam(i, { type: e.target.value as ActionParameterDef["type"] })}>
                      {["String", "Integer", "Double", "Boolean", "Date", "Timestamp", "ObjectReference", "ObjectSetReference", "InterfaceReference", "Attachment"].map(t => <option key={t}>{t}</option>)}
                    </select>
                  </td>
                  <td style={{ padding: 3 }}>
                    {p.type === "ObjectReference" || p.type === "ObjectSetReference" ? (
                      <select className="fnd-input fnd-select" value={p.validation.objectTypeApiName ?? ""} onChange={e => updParamValidation(i, { objectTypeApiName: e.target.value })}>
                        <option value="">—</option>{meta.objectTypes.map(o => <option key={o.apiName}>{o.apiName}</option>)}
                      </select>
                    ) : p.type === "InterfaceReference" ? (
                      <select className="fnd-input fnd-select" value={p.validation.interfaceApiName ?? ""} onChange={e => updParamValidation(i, { interfaceApiName: e.target.value })}>
                        <option value="">—</option>{meta.interfaces.map(o => <option key={o.apiName}>{o.apiName}</option>)}
                      </select>
                    ) : <span className="fnd-text-dim">—</span>}
                  </td>
                  <td style={{ padding: 3, textAlign: "center" }}><input type="checkbox" checked={p.validation.required} onChange={e => updParamValidation(i, { required: e.target.checked })}/></td>
                  <td style={{ padding: 3 }}><input className="fnd-input font-mono" style={{ fontSize: 11 }} placeholder="object.status" value={p.defaultFrom ?? ""} onChange={e => updParam(i, { defaultFrom: e.target.value || undefined })}/></td>
                  <td style={{ padding: 3 }}>
                    {p.type === "String" && (
                      <div className="flex gap-1">
                        <input className="fnd-input" placeholder="Allowed values (comma sep.)" value={(p.validation.allowedValues ?? []).join(", ")} onChange={e => updParamValidation(i, { allowedValues: e.target.value ? e.target.value.split(",").map(s => s.trim()).filter(Boolean) : undefined })}/>
                        <input className="fnd-input" style={{ width: 60 }} placeholder="min len" value={p.validation.minLength ?? ""} onChange={e => updParamValidation(i, { minLength: e.target.value === "" ? undefined : Number(e.target.value) })}/>
                      </div>
                    )}
                    {(p.type === "Integer" || p.type === "Double") && (
                      <div className="flex gap-1">
                        <input className="fnd-input" style={{ width: 70 }} placeholder="min" value={p.validation.range?.min ?? ""} onChange={e => updParamValidation(i, { range: { ...p.validation.range, min: e.target.value === "" ? undefined : Number(e.target.value) } })}/>
                        <input className="fnd-input" style={{ width: 70 }} placeholder="max" value={p.validation.range?.max ?? ""} onChange={e => updParamValidation(i, { range: { ...p.validation.range, max: e.target.value === "" ? undefined : Number(e.target.value) } })}/>
                      </div>
                    )}
                  </td>
                  <td style={{ padding: 3 }}><button className="fnd-btn fnd-btn-minimal" title="Remove" onClick={() => updAction(at.apiName, { parameters: at.parameters.filter((_, j) => j !== i) })}><Icon.Trash size={11}/></button></td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="text-[10px] fnd-text-dim mt-2">&quot;Allowed values&quot; is the Validation constraint that renders a dropdown — Palantir does not model a separate Enum parameter type.</div>
        </Card>
      )}

      {tab === "rules" && (
        <Card title="Logic — Rules describing how parameters translate into Ontology edits" right={
          <div className="flex gap-1 flex-wrap">
            <button className="fnd-btn" onClick={() => updAction(at.apiName, { rules: [...at.rules, { kind: "addObjectRule", objectTypeApiName: meta.objectTypes[0]?.apiName ?? "", propertyMappings: {} }] })}>+ Add object</button>
            <button className="fnd-btn" onClick={() => updAction(at.apiName, { rules: [...at.rules, { kind: "modifyObjectRule", objectParameterApiName: objParams[0]?.apiName ?? "", propertyMappings: {} }] })}>+ Modify object</button>
            <button className="fnd-btn" onClick={() => updAction(at.apiName, { rules: [...at.rules, { kind: "deleteObjectRule", objectParameterApiName: objParams[0]?.apiName ?? "" }] })}>+ Delete object</button>
            <button className="fnd-btn" onClick={() => updAction(at.apiName, { rules: [...at.rules, { kind: "addLinkRule", linkTypeApiName: meta.linkTypes[0]?.apiName ?? "", objectAParameterApiName: objParams[0]?.apiName ?? "", objectBParameterApiName: objParams[1]?.apiName ?? objParams[0]?.apiName ?? "" }] })}>+ Add link</button>
          </div>
        }>
          {at.rules.length === 0 && <div className="text-xs fnd-text-dim">No rules — submitting this action will not change the ontology.</div>}
          {at.rules.map((r, i) => {
            const targetType = r.kind === "addObjectRule" ? r.objectTypeApiName : "objectParameterApiName" in r ? at.parameters.find(p => p.apiName === r.objectParameterApiName)?.validation.objectTypeApiName : undefined;
            const tot = meta.objectTypes.find(o => o.apiName === targetType);
            const ruleLabel = r.kind === "addObjectRule" ? "Add object" : r.kind === "modifyObjectRule" ? "Modify object" : r.kind === "deleteObjectRule" ? "Delete object" : r.kind === "addLinkRule" ? "Add link" : "Remove link";
            return (
              <div key={i} className="rounded-sm mb-2" style={{ border: "1px solid var(--fnd-border)" }}>
                <div className="flex items-center gap-2 px-2 py-1.5 border-b fnd-border" style={{ background: "var(--fnd-panel-2)" }}>
                  <span className="fnd-tag" style={{ fontWeight: 700 }}>{i + 1}</span>
                  <span className="text-xs font-semibold">{ruleLabel}</span>
                  {r.kind === "addObjectRule" && (
                    <select className="fnd-input fnd-select" style={{ width: 160 }} value={r.objectTypeApiName} onChange={e => updRule(i, { ...r, objectTypeApiName: e.target.value })}>{meta.objectTypes.map(o => <option key={o.apiName}>{o.apiName}</option>)}</select>
                  )}
                  {(r.kind === "modifyObjectRule" || r.kind === "deleteObjectRule") && (
                    <select className="fnd-input fnd-select" style={{ width: 200 }} value={r.objectParameterApiName} onChange={e => updRule(i, { ...r, objectParameterApiName: e.target.value })}>
                      {objParams.map(p => <option key={p.apiName} value={p.apiName}>param.{p.apiName} ({p.validation.objectTypeApiName})</option>)}
                    </select>
                  )}
                  {(r.kind === "addLinkRule" || r.kind === "removeLinkRule") && (
                    <>
                      <select className="fnd-input fnd-select" style={{ width: 160 }} value={r.linkTypeApiName} onChange={e => updRule(i, { ...r, linkTypeApiName: e.target.value })}>{meta.linkTypes.map(l => <option key={l.apiName} value={l.apiName}>{l.apiName}</option>)}</select>
                      <select className="fnd-input fnd-select" style={{ width: 140 }} value={r.objectAParameterApiName} onChange={e => updRule(i, { ...r, objectAParameterApiName: e.target.value })}>{objParams.map(p => <option key={p.apiName} value={p.apiName}>A: param.{p.apiName}</option>)}</select>
                      <select className="fnd-input fnd-select" style={{ width: 140 }} value={r.objectBParameterApiName} onChange={e => updRule(i, { ...r, objectBParameterApiName: e.target.value })}>{objParams.map(p => <option key={p.apiName} value={p.apiName}>B: param.{p.apiName}</option>)}</select>
                    </>
                  )}
                  <div className="flex-1"/>
                  <button className="fnd-btn fnd-btn-minimal" onClick={() => updAction(at.apiName, { rules: at.rules.filter((_, j) => j !== i) })}><Icon.Trash size={11}/></button>
                </div>
                {(r.kind === "addObjectRule" || r.kind === "modifyObjectRule") && (
                  <div className="p-2 space-y-1">
                    {Object.entries(r.propertyMappings).map(([prop, expr]) => (
                      <div key={prop} className="flex items-center gap-2 text-xs">
                        <span className="font-mono" style={{ width: 160 }}>{targetType}.{prop}</span>
                        <span className="fnd-text-dim">←</span>
                        <input className="fnd-input font-mono" style={{ fontSize: 11 }} value={expr} onChange={e => updRule(i, { ...r, propertyMappings: { ...r.propertyMappings, [prop]: e.target.value } })}/>
                        <button className="fnd-btn fnd-btn-minimal" onClick={() => { const m = { ...r.propertyMappings }; delete m[prop]; updRule(i, { ...r, propertyMappings: m }); }}><Icon.Close size={10}/></button>
                      </div>
                    ))}
                    <select className="fnd-input fnd-select" style={{ width: 240 }} value="" onChange={e => { if (e.target.value) updRule(i, { ...r, propertyMappings: { ...r.propertyMappings, [e.target.value]: at.parameters.find(p => p.apiName === e.target.value) ? `param.${e.target.value}` : "''" } }); }}>
                      <option value="">+ Map a property…</option>
                      {(tot?.properties ?? []).filter(p => !(p.apiName in r.propertyMappings) && primaryKeyOf(tot) !== p.apiName).map(p => <option key={p.apiName} value={p.apiName}>{p.displayName} ({p.baseType})</option>)}
                    </select>
                    <div className="text-[10px] fnd-text-dim">Expressions: <code>param.x</code>, <code>object.x</code>, <code>&apos;literal&apos;</code>, <code>now()</code>, <code>currentUser()</code>, numbers, true/false. Primary key properties cannot be modified by any action type.</div>
                  </div>
                )}
              </div>
            );
          })}
        </Card>
      )}

      {tab === "criteria" && (
        <Card title="Security & Submission Criteria — validated before any edit is applied" right={<button className="fnd-btn" onClick={() => updAction(at.apiName, { submissionCriteria: [...at.submissionCriteria, { id: `c${Date.now()}`, conditionType: "parameter", condition: { left: "param." + (at.parameters[0]?.apiName ?? "x"), op: "isNotEmpty" }, failureMessage: "Condition not met" }] })}><Icon.Plus size={11}/> Add condition</button>}>
          {at.submissionCriteria.length === 0 && <div className="text-xs fnd-text-dim">No submission criteria.</div>}
          {at.submissionCriteria.map((c, i) => (
            <div key={c.id} className="rounded-sm mb-2 p-2 space-y-1.5" style={{ border: "1px solid var(--fnd-border)" }}>
              <div className="flex items-center gap-2 text-xs">
                <span className="fnd-label" style={{ width: 50 }}>When</span>
                {c.when ? (
                  <>
                    <input className="fnd-input font-mono" style={{ width: 160, fontSize: 11 }} value={c.when.left} onChange={e => updCrit(i, { when: { ...c.when!, left: e.target.value } })}/>
                    <select className="fnd-input fnd-select" style={{ width: 150 }} value={c.when.op} onChange={e => updCrit(i, { when: { ...c.when!, op: e.target.value as ConditionOperator } })}>{CONDITION_OPERATORS.map(o => <option key={o.v} value={o.v}>{o.label}</option>)}</select>
                    <input className="fnd-input" style={{ width: 160 }} value={Array.isArray(c.when.right) ? (c.when.right as unknown[]).join(", ") : String(c.when.right ?? "")} onChange={e => updCrit(i, { when: { ...c.when!, right: e.target.value } })}/>
                    <button className="fnd-btn fnd-btn-minimal" onClick={() => updCrit(i, { when: undefined })}>always</button>
                  </>
                ) : <button className="fnd-btn fnd-btn-minimal" onClick={() => updCrit(i, { when: { left: "param.", op: "is", right: "" } })}>always · add guard condition</button>}
              </div>
              <div className="flex items-center gap-2 text-xs">
                <span className="fnd-label" style={{ width: 50 }}>Require</span>
                <input className="fnd-input font-mono" style={{ width: 160, fontSize: 11 }} value={c.condition.left} onChange={e => updCrit(i, { condition: { ...c.condition, left: e.target.value } })}/>
                <select className="fnd-input fnd-select" style={{ width: 150 }} value={c.condition.op} onChange={e => updCrit(i, { condition: { ...c.condition, op: e.target.value as ConditionOperator } })}>{CONDITION_OPERATORS.map(o => <option key={o.v} value={o.v}>{o.label}</option>)}</select>
                <input className="fnd-input" style={{ width: 160 }} value={Array.isArray(c.condition.right) ? (c.condition.right as unknown[]).join(", ") : String(c.condition.right ?? "")}
                  onChange={e => updCrit(i, { condition: { ...c.condition, right: c.condition.op === "isOneOf" || c.condition.op === "isNotOneOf" ? e.target.value.split(",").map(s => s.trim()) : e.target.value } })}/>
                <div className="flex-1"/>
                <button className="fnd-btn fnd-btn-minimal" onClick={() => updAction(at.apiName, { submissionCriteria: at.submissionCriteria.filter((_, j) => j !== i) })}><Icon.Trash size={11}/></button>
              </div>
              <div className="flex items-center gap-2 text-xs">
                <span className="fnd-label" style={{ width: 50 }}>Failure message</span>
                <input className="fnd-input" value={c.failureMessage} onChange={e => updCrit(i, { failureMessage: e.target.value })}/>
              </div>
            </div>
          ))}
        </Card>
      )}

      {tab === "test" && <ActionTestRun at={at}/>}

      {tab === "security" && (
        <Card title="Security & Notifications">
          <KV k="Description"><textarea className="fnd-input" style={{ height: 52, paddingTop: 4 }} value={at.description} onChange={e => updAction(at.apiName, { description: e.target.value })}/></KV>
          <KV k="Status"><select className="fnd-input fnd-select" value={at.status} onChange={e => updAction(at.apiName, { status: e.target.value as ActionTypeDef["status"] })}><option value="ACTIVE">Active</option><option value="EXPERIMENTAL">Experimental</option><option value="DEPRECATED">Deprecated</option></select></KV>
          <KV k="Who can submit (groups)"><input className="fnd-input" value={at.submissionGroups.join(", ")} onChange={e => updAction(at.apiName, { submissionGroups: e.target.value.split(",").map(s => s.trim()).filter(Boolean) })}/></KV>
          <KV k="Notifications / webhooks"><input className="fnd-input" value={at.notifications.join(", ")} onChange={e => updAction(at.apiName, { notifications: e.target.value.split(",").map(s => s.trim()).filter(Boolean) })}/></KV>
        </Card>
      )}
    </div>
  );
}

function ActionTestRun({ at }: { at: ActionTypeDef }) {
  const { ontology, ontologyMeta: meta, executeAction, actionLog } = useWorkshop();
  const [params, setParams] = useState<Record<string, unknown>>({});
  const [result, setResult] = useState<{ ok: boolean; errors: string[] } | null>(null);
  const v = useMemo(() => validateAction(at, ontology, meta, params), [at, ontology, meta, params]);
  const log = actionLog.filter(l => l.actionType === at.apiName).slice(0, 8);
  return (
    <div className="grid gap-3" style={{ gridTemplateColumns: "1fr 1fr" }}>
      <Card title="Run against live ontology">
        <div className="space-y-2">
          {at.parameters.map(p => {
            const err = v.fieldErrors[p.apiName];
            const ot = meta.objectTypes.find(o => o.apiName === p.validation.objectTypeApiName);
            const opts = p.type === "ObjectReference" ? getObjects(ontology, p.validation.objectTypeApiName).slice(0, 200) : [];
            return (
              <div key={p.apiName}>
                <label className="fnd-field-label">{p.displayName}{p.validation.required && <span style={{ color: "var(--fnd-danger)" }}> *</span>} <span className="fnd-text-dim font-mono" style={{ fontSize: 10 }}>{p.type}{p.validation.objectTypeApiName ? `<${p.validation.objectTypeApiName}>` : ""}</span></label>
                {p.type === "ObjectReference" ? (
                  <select className="fnd-input fnd-select" style={{ borderColor: err ? "var(--fnd-danger)" : undefined }} value={String(params[p.apiName] ?? "")} onChange={e => setParams(s => ({ ...s, [p.apiName]: e.target.value }))}>
                    <option value="">Select {ot?.displayName ?? "object"}…</option>
                    {opts.map(o => <option key={String(o[primaryKeyOf(ot)])} value={String(o[primaryKeyOf(ot)])}>{String(o[ot?.titlePropertyApiName ?? "name"] ?? o.id)} · {String(o.status ?? "")}</option>)}
                  </select>
                ) : p.validation.allowedValues ? (
                  <select className="fnd-input fnd-select" style={{ borderColor: err ? "var(--fnd-danger)" : undefined }} value={String(params[p.apiName] ?? "")} onChange={e => setParams(s => ({ ...s, [p.apiName]: e.target.value }))}>
                    <option value="">—</option>{p.validation.allowedValues.map(o => <option key={o}>{o}</option>)}
                  </select>
                ) : p.type === "Boolean" ? (
                  <input type="checkbox" checked={!!params[p.apiName]} onChange={e => setParams(s => ({ ...s, [p.apiName]: e.target.checked }))}/>
                ) : (
                  <input className="fnd-input" style={{ borderColor: err ? "var(--fnd-danger)" : undefined }} type={p.type === "Date" || p.type === "Timestamp" ? "date" : p.type === "Integer" || p.type === "Double" ? "number" : "text"} value={String(params[p.apiName] ?? "")}
                    onChange={e => setParams(s => ({ ...s, [p.apiName]: p.type === "Integer" || p.type === "Double" ? (e.target.value === "" ? "" : Number(e.target.value)) : e.target.value }))}/>
                )}
                {err && <div className="text-[11px]" style={{ color: "var(--fnd-danger)" }}>{err}</div>}
              </div>
            );
          })}
          {v.criteriaErrors.length > 0 && (
            <div className="rounded-sm p-2 text-[11px]" style={{ background: "#fde9e9", border: "1px solid #e8a9a9", color: "#8a1f1f" }}>
              {v.criteriaErrors.map((m, i) => <div key={i}>⚠ {m}</div>)}
            </div>
          )}
          <div className="flex justify-end gap-2 pt-1">
            <button className="fnd-btn" onClick={() => { setParams({}); setResult(null); }}>Reset</button>
            <button className="fnd-btn fnd-btn-primary" onClick={() => setResult(executeAction(at.apiName, params))}>Submit</button>
          </div>
          {result && (
            <div className="text-[11px] rounded-sm p-2" style={{ background: result.ok ? "#e4f1e5" : "#fde9e9", color: result.ok ? "#296936" : "#8a1f1f" }}>
              {result.ok ? "✓ Action applied — the ontology has been updated and all bound Workshop widgets refreshed." : result.errors.map((e, i) => <div key={i}>✕ {e}</div>)}
            </div>
          )}
        </div>
      </Card>
      <Card title="Recent executions">
        {log.length === 0 && <div className="text-xs fnd-text-dim">No executions of this action yet.</div>}
        {log.map(l => (
          <div key={l.id} className="py-1.5 border-b fnd-border text-xs">
            <div className="flex items-center gap-2"><span className="fnd-text-dim tabular-nums">{new Date(l.ts).toLocaleTimeString()}</span><span className="font-semibold">{l.user}</span></div>
            {l.edits.map((e, i) => (
              <div key={i} className="pl-2 text-[11px]">
                <span className="fnd-tag" style={{ height: 16 }}>{e.kind}</span> {e.objectType} <span className="font-mono">{e.objectId}</span>
                {e.kind === "modify" && e.before && e.after && (
                  <span className="fnd-text-muted"> {Object.keys(e.after).filter(k => String(e.after![k]) !== String(e.before![k])).map(k => `${k}: ${String(e.before![k])} → ${String(e.after![k])}`).join("; ")}</span>
                )}
              </div>
            ))}
          </div>
        ))}
      </Card>
    </div>
  );
}

// ─── Functions / interfaces / shared properties ────────────────────────────
function FunctionDetail({ id }: { id: string }) {
  const { ontologyMeta: meta, ontology, values } = useWorkshop();
  const f = meta.functions.find(x => x.apiName === id);
  const [out, setOut] = useState<string>("");
  if (!f) return <Missing/>;
  const sampleInput = f.inputs[0]?.type.startsWith("ObjectSet") ? values.filteredAssets : values.selectedAsset;
  return (
    <div style={{ maxWidth: 900 }}>
      <div className="flex items-center gap-3 mb-3">
        <Icon.Code size={22}/>
        <div className="flex-1"><div className="text-lg font-semibold">{f.displayName}</div><div className="text-xs fnd-text-muted font-mono">{f.apiName} · {f.rid} @ {f.version} · {f.language}</div></div>
      </div>
      <Card title="Signature">
        <div className="font-mono text-xs">{f.apiName}({f.inputs.map(i => `${i.name}: ${i.type}`).join(", ")}) → {f.output}</div>
        <div className="text-xs fnd-text-muted mt-1">{f.description}</div>
      </Card>
      <Card title="Source">
        <pre className="text-[11px] p-3 rounded-sm overflow-auto" style={{ background: "var(--fnd-panel-2)", fontFamily: "ui-monospace, Menlo, monospace" }}>{f.source}</pre>
      </Card>
      <Card title="Execute" right={<button className="fnd-btn fnd-btn-primary" onClick={() => setOut(JSON.stringify(runFunction(f.apiName, sampleInput, ontology), null, 2))}><Icon.Play size={11}/> Run</button>}>
        <div className="text-xs fnd-text-muted mb-1">Input: {f.inputs[0]?.type.startsWith("ObjectSet") ? `@filteredAssets (${Array.isArray(values.filteredAssets) ? (values.filteredAssets as unknown[]).length : 0} objects)` : `@selectedAsset (${String((values.selectedAsset as Record<string, unknown> | null)?.name ?? "none")})`}</div>
        <pre className="text-[11px] p-2 rounded-sm" style={{ background: "var(--fnd-panel-2)", minHeight: 40 }}>{out || "Click Run to execute against current Workshop state."}</pre>
      </Card>
      <div className="text-[10px] fnd-text-dim">{AGGREGATIONS.length} aggregation kinds are available to Object Type derived properties and Variable transformations (Count, Average, Sum, Minimum, Maximum, Approximate/Exact cardinality, Collect list).</div>
    </div>
  );
}

function InterfaceDetail({ id }: { id: string }) {
  const { ontologyMeta: meta } = useWorkshop();
  const [, setSel] = useOSel();
  const i = meta.interfaces.find(x => x.apiName === id);
  if (!i) return <Missing/>;
  const impl = meta.objectTypes.filter(o => o.implementsInterfaces.some(x => x.interfaceApiName === i.apiName));
  return (
    <div style={{ maxWidth: 820 }}>
      <div className="text-lg font-semibold mb-1">{i.displayName} <span className="fnd-tag">interface</span></div>
      <div className="text-xs fnd-text-muted mb-1">{i.description}</div>
      <div className="text-[10px] fnd-text-dim font-mono mb-3">{i.apiName} · {i.rid}</div>
      <Card title="Shared property types">
        {i.sharedPropertyApiNames.map(sp => {
          const d = meta.sharedProperties.find(s => s.apiName === sp);
          return <div key={sp} className="flex items-center gap-2 py-1 text-xs"><BaseTypeIcon t={d?.baseType ?? "String"}/><span className="font-semibold">{d?.displayName ?? sp}</span><span className="font-mono fnd-text-dim">{sp}</span></div>;
        })}
      </Card>
      <Card title={`Implemented by (${impl.length})`}>
        {impl.map(o => {
          const mapping = o.implementsInterfaces.find(x => x.interfaceApiName === i.apiName)?.propertyMapping ?? {};
          return (
            <div key={o.apiName} className="flex items-center gap-2 py-1.5 border-b fnd-border text-xs cursor-pointer fnd-row-hover" onClick={() => setSel({ kind: "objectType", id: o.apiName })}>
              <TypeBadge ot={o} size={18}/><span className="font-semibold">{o.displayName}</span>
              <span className="fnd-text-dim">maps {i.sharedPropertyApiNames.map(sp => mapping[sp] ?? "✕ unmapped").join(", ")}</span>
            </div>
          );
        })}
      </Card>
    </div>
  );
}

function SharedPropertyDetail({ id }: { id: string }) {
  const { ontologyMeta: meta, updateOntologyMeta } = useWorkshop();
  const s = meta.sharedProperties.find(x => x.apiName === id);
  if (!s) return <Missing/>;
  const users = meta.objectTypes.flatMap(o => o.properties.filter(p => p.sharedPropertyType === id).map(p => ({ o, p })));
  return (
    <div style={{ maxWidth: 820 }}>
      <div className="flex items-center gap-2 mb-1"><BaseTypeIcon t={s.baseType}/><span className="text-lg font-semibold">{s.displayName}</span><span className="fnd-tag">shared property type</span></div>
      <div className="text-[10px] fnd-text-dim font-mono mb-3">{s.apiName} · {s.rid}</div>
      <Card title="Definition">
        <KV k="Display name"><input className="fnd-input" value={s.displayName} onChange={e => updateOntologyMeta(m => ({ ...m, sharedProperties: m.sharedProperties.map(x => x.apiName === id ? { ...x, displayName: e.target.value } : x) }))}/></KV>
        <KV k="Base type"><span className="font-mono">{s.baseType}</span></KV>
        <KV k="Description">{s.description}</KV>
      </Card>
      <Card title={`Used by ${users.length} property type(s)`}>
        {users.map(({ o, p }) => <div key={o.apiName + p.apiName} className="flex items-center gap-2 py-1 text-xs"><TypeBadge ot={o} size={16}/><span>{o.displayName}.{p.apiName}</span><BaseTypeIcon t={p.baseType}/>{p.baseType !== s.baseType && <span style={{ color: "var(--fnd-danger)" }}>⚠ type mismatch</span>}</div>)}
      </Card>
    </div>
  );
}

// ─── Graph ─────────────────────────────────────────────────────────────────
function OntologyGraph() {
  const { ontologyMeta: meta, ontology } = useWorkshop();
  const [, setSel] = useOSel();
  const nodes = useMemo(() => meta.objectTypes.map(o => ({ id: o.apiName, w: 176, h: 54, data: o })), [meta.objectTypes]);
  const edges = useMemo(() => meta.linkTypes.map(l => ({ id: l.apiName, from: l.objectTypeA, to: l.objectTypeB })), [meta.linkTypes]);
  const [hover, setHover] = useState<string | null>(null);
  const hl = useMemo(() => hover ? new Set([hover, ...meta.linkTypes.filter(l => l.objectTypeA === hover || l.objectTypeB === hover).flatMap(l => [l.objectTypeA, l.objectTypeB])]) : null, [hover, meta.linkTypes]);
  return (
    <div className="flex flex-col" style={{ height: "calc(100vh - 150px)", minHeight: 420 }}>
      <OntologyStats meta={meta}/>
      <div className="fnd-panel rounded-sm flex-1 min-h-0 overflow-hidden">
        <GraphCanvas
          nodes={nodes} edges={edges} algorithm="stress" highlight={hl}
          onSelect={id => setSel({ kind: "objectType", id })} onEdgeClick={id => setSel({ kind: "linkType", id })}
          edgeLabel={id => { const l = meta.linkTypes.find(x => x.apiName === id); return l ? `${l.displayName} · ${CARD_LABEL[l.cardinality]}` : undefined; }}
          emptyText="No object types defined."
          toolbar={<span className="text-[11px] fnd-text-muted">Laid out with ELK (stress) · click a type or link to open it · scroll to zoom, drag to pan</span>}
          renderNode={(n, s) => {
            const o = n.data; const count = getObjects(ontology, o.apiName).length;
            return (
              <g onPointerEnter={() => setHover(o.apiName)} onPointerLeave={() => setHover(null)}>
                <rect width={n.w} height={n.h} rx={4} fill="var(--fnd-panel)" stroke={s.hl || s.selected ? o.color : "var(--fnd-border-strong)"} strokeWidth={s.hl ? 2 : 1}/>
                <rect width={4} height={n.h} rx={2} fill={o.color}/>
                <rect x={12} y={14} width={26} height={26} rx={3} fill={o.color}/>
                <text x={25} y={32} textAnchor="middle" fontSize={13} fontWeight={800} fill="white">{o.icon}</text>
                <text x={46} y={24} fontSize={12} fontWeight={600} fill="var(--fnd-text)">{o.displayName}</text>
                <text x={46} y={40} fontSize={10} fill="var(--fnd-text-muted)">{count.toLocaleString()} obj · {o.properties.length} props</text>
              </g>
            );
          }}
        />
      </div>
    </div>
  );
}

function OntologyStats({ meta }: { meta: OntologyMeta }) {
  const { ontology } = useWorkshop();
  const total = meta.objectTypes.reduce((s, o) => s + getObjects(ontology, o.apiName).length, 0);
  const props = meta.objectTypes.reduce((s, o) => s + o.properties.length, 0);
  const stats = [
    ["Object types", meta.objectTypes.length], ["Objects", total], ["Properties", props], ["Link types", meta.linkTypes.length],
    ["Action types", meta.actionTypes.length], ["Functions", meta.functions.length], ["Interfaces", meta.interfaces.length], ["Shared props", meta.sharedProperties.length],
  ] as const;
  return (
    <div className="grid gap-2 mb-3" style={{ gridTemplateColumns: "repeat(8, 1fr)" }}>
      {stats.map(([k, v]) => (
        <div key={k} className="fnd-panel rounded-sm px-3 py-2">
          <div className="text-[10px] uppercase tracking-wide fnd-text-muted">{k}</div>
          <div className="text-lg font-bold tabular-nums">{v.toLocaleString()}</div>
        </div>
      ))}
    </div>
  );
}
