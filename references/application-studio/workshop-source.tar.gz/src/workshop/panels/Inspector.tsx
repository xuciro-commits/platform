"use client";
import React, { useState } from "react";
import { useWorkshop } from "../WorkshopContext";
import type { WidgetDef, SectionDef, EventAction, VariableDef, FilterOp, ObjectSetStep } from "../types";
import { FILTER_OPS } from "../ontologyMeta";
import { Icon } from "../widgets/icons";
import { formatValue } from "../widgets/WidgetRenderer";
import { ResourcePicker } from "../ui/ResourcePicker";
import { FlowNodeInspector } from "./FlowNodeInspector";
import { FlowSettingsInspector, FlowEdgeInspector } from "./FlowSettingsInspector";

export function Inspector() {
  const { selection, module } = useWorkshop();
  if (!selection.kind || !selection.id) return <EmptyInspector />;

  if (selection.kind === "widget") {
    const w = module.widgets[selection.id];
    if (!w) return <EmptyInspector />;
    return <WidgetInspector widget={w} />;
  }
  if (selection.kind === "section") {
    const s = module.sections[selection.id];
    if (!s) return <EmptyInspector />;
    return <SectionInspector section={s} />;
  }
  if (selection.kind === "page") {
    const p = module.pages.find(x => x.id === selection.id);
    if (!p) return <EmptyInspector />;
    return <PageInspector page={p} />;
  }
  if (selection.kind === "overlay") {
    const o = module.overlays.find(x => x.id === selection.id);
    if (!o) return <EmptyInspector />;
    return <OverlayInspector overlay={o} />;
  }
  if (selection.kind === "variable") {
    const v = module.variables.find(x => x.id === selection.id);
    if (!v) return <EmptyInspector />;
    return <VariableInspector variable={v} />;
  }
  if (selection.kind === "flow") return <FlowSettingsInspector flowId={selection.id}/>;
  if (selection.kind === "flowNode") return <FlowNodeInspector nodeId={selection.id} />;
  if (selection.kind === "flowEdge") return <FlowEdgeInspector edgeId={selection.id}/>;
  if (selection.kind === "header") {
    return <HeaderInspector />;
  }
  return <EmptyInspector />;
}

function EmptyInspector() {
  return (
    <div className="p-4 text-xs fnd-text-dim">
      <div className="font-semibold mb-1">No selection</div>
      <div>Select a widget, section, page, overlay, or variable in the canvas or tree to configure it here.</div>
    </div>
  );
}

function Section({ title, children, defaultOpen = true }: { title: string; children: React.ReactNode; defaultOpen?: boolean }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="border-b fnd-border">
      <button onClick={() => setOpen(!open)} className="w-full flex items-center gap-1 px-3 py-2 text-left">
        <Icon.Chevron size={10} dir={open ? "down" : "right"}/>
        <span className="fnd-label">{title}</span>
      </button>
      {open && <div className="px-3 pb-3 space-y-2.5">{children}</div>}
    </div>
  );
}

function Field({ label, children, hint }: { label: string; children: React.ReactNode; hint?: string }) {
  return (
    <div>
      <label className="fnd-field-label">{label}</label>
      {children}
      {hint && <div className="text-[10px] fnd-text-dim mt-0.5">{hint}</div>}
    </div>
  );
}

function VariablePicker({ value, onChange }: { value: string | undefined; onChange: (v: string) => void; filterType?: string }) {
  return <ResourcePicker value={value} onChange={onChange} kinds={["variable"]} placeholder="Search variables…"/>;
}

// ─── Widget Inspector ──────────────────────────────────────────────
function WidgetInspector({ widget }: { widget: WidgetDef }) {
  const { updateModule, module, values, openContextMenu, duplicateSel, copySel, deleteSel, makeUnusedSel } = useWorkshop();
  const [tab, setTab] = useState<"setup" | "data" | "props" | "events" | "display" | "advanced">("setup");

  const update = (patch: Partial<WidgetDef>) => {
    updateModule(m => ({ ...m, widgets: { ...m.widgets, [widget.id]: { ...m.widgets[widget.id], ...patch } } }), "edit widget");
  };

  const updateConfig = (patch: Record<string, unknown>) => update({ config: { ...widget.config, ...patch } });

  return (
    <div className="h-full flex flex-col">
      <div className="px-3 py-2 border-b fnd-border">
        <div className="flex items-center gap-2">
          <Icon.Object size={14}/>
          <input className="fnd-input" value={widget.name} onChange={e => update({ name: e.target.value })} style={{ fontWeight: 600 }}/>
          <button className="fnd-btn fnd-btn-minimal" title="More" onClick={e => {
            const r = (e.currentTarget as HTMLButtonElement).getBoundingClientRect();
            openContextMenu(r.left, r.bottom, [
              { label: "Duplicate", onClick: duplicateSel },
              { label: "Copy", onClick: copySel },
              { label: "Make unused", onClick: makeUnusedSel },
              { separator: true, label: "" },
              { label: "Delete", danger: true, onClick: deleteSel },
            ]);
          }}><Icon.More size={14}/></button>
        </div>
        <div className="text-[10px] fnd-text-dim mt-1">{widget.type} · {widget.id}</div>
      </div>
      <div className="flex items-center border-b fnd-border px-1" style={{ overflowX: "auto" }}>
        {(["setup", "data", "props", "events", "display", "advanced"] as const).map(t => (
          <button key={t} onClick={() => setTab(t)}
            className="px-2 py-1.5 text-[11px] font-medium"
            style={{ borderBottom: tab === t ? "2px solid var(--fnd-accent)" : "2px solid transparent", color: tab === t ? "var(--fnd-text)" : "var(--fnd-text-muted)", whiteSpace: "nowrap" }}>
            {t}
          </button>
        ))}
      </div>
      <div className="flex-1 overflow-auto">
        {tab === "setup" && (
          <Section title="Widget setup">
            <Field label="Widget type"><div className="fnd-input" style={{ display: "flex", alignItems: "center" }}>{widget.type}</div></Field>
            <Field label="Widget name"><input className="fnd-input" value={widget.name} onChange={e => update({ name: e.target.value })}/></Field>
            <Field label="Widget ID"><div className="fnd-input" style={{ display: "flex", alignItems: "center", color: "var(--fnd-text-dim)" }}>{widget.id}</div></Field>
          </Section>
        )}
        {tab === "data" && <DataInspector widget={widget} updateConfig={updateConfig} values={values}/>}
        {tab === "props" && <PropsInspector widget={widget} updateConfig={updateConfig}/>}
        {tab === "events" && <EventsInspector widget={widget} update={update}/>}
        {tab === "display" && (
          <>
            <Section title="Display & formatting">
              <Field label="Density">
                <select className="fnd-input fnd-select" value={(widget.config.density as string) ?? "normal"} onChange={e => updateConfig({ density: e.target.value })}>
                  <option value="compact">Compact</option><option value="normal">Normal</option>
                </select>
              </Field>
              <Field label="Background">
                <select className="fnd-input fnd-select" value={widget.style?.background ?? "default"} onChange={e => update({ style: { ...widget.style, background: e.target.value as NonNullable<WidgetDef["style"]>["background"] } })}>
                  <option value="default">Default</option><option value="panel">Panel</option><option value="muted">Muted</option><option value="none">Transparent</option>
                </select>
              </Field>
              <Field label="Border">
                <select className="fnd-input fnd-select" value={widget.style?.border === undefined ? "inherit" : widget.style.border ? "on" : "off"} onChange={e => update({ style: { ...widget.style, border: e.target.value === "inherit" ? undefined : e.target.value === "on" } })}>
                  <option value="inherit">Widget default</option><option value="on">Always</option><option value="off">None</option>
                </select>
              </Field>
              <Field label="Elevation">
                <select className="fnd-input fnd-select" value={String(widget.style?.elevation ?? 0)} onChange={e => update({ style: { ...widget.style, elevation: Number(e.target.value) as 0 | 1 | 2 } })}>
                  <option value="0">Flat</option><option value="1">Low</option><option value="2">Raised</option>
                </select>
              </Field>
              <Field label="Padding (px)"><input type="number" className="fnd-input" min={0} max={48} value={widget.style?.padding ?? 0} onChange={e => update({ style: { ...widget.style, padding: Number(e.target.value) } })}/></Field>
              <Field label="Height (px)" hint="Empty = auto. You can also drag the bottom handle on the canvas.">
                <input type="number" className="fnd-input" min={40} placeholder="auto" value={widget.height ?? ""} onChange={e => update({ height: e.target.value === "" ? undefined : Math.max(40, Number(e.target.value)) })}/>
              </Field>
              <Field label="Width weight" hint="Share of a row (columns) this widget takes. Drag the side handle on canvas to change.">
                <input type="number" className="fnd-input" min={0.1} step={0.1} value={widget.flex ?? 1} onChange={e => update({ flex: Math.max(0.1, Number(e.target.value)) })}/>
              </Field>
            </Section>
            <Section title="Empty / error behavior">
              <Field label="Empty message" hint="Shown instead of the widget when its bound object set has no objects.">
                <input className="fnd-input" placeholder="e.g. No assets match the current filters" value={widget.emptyMessage ?? ""} onChange={e => update({ emptyMessage: e.target.value || undefined })}/>
              </Field>
            </Section>
          </>
        )}
        {tab === "advanced" && (
          <>
            <Section title="Display optimization">
              <Field label="Mount behavior" hint="How the widget initializes">
                <select className="fnd-input fnd-select" value={widget.mountBehavior ?? "normal"} onChange={e => update({ mountBehavior: e.target.value as WidgetDef["mountBehavior"] })}>
                  <option value="normal">Normal</option>
                  <option value="delayUntilOnScreen">Delay until on-screen</option>
                  <option value="eager">Eager</option>
                </select>
              </Field>
              <Field label="Unmount behavior" hint="What happens when hidden">
                <select className="fnd-input fnd-select" value={widget.unmountBehavior ?? "normal"} onChange={e => update({ unmountBehavior: e.target.value as WidgetDef["unmountBehavior"] })}>
                  <option value="normal">Normal</option>
                  <option value="neverUnmount">Never unmount</option>
                  <option value="unmountOffScreen">Unmount off-screen</option>
                </select>
              </Field>
            </Section>
            <Section title="Visibility state">
              <Field label="Read-only" hint="Renders the widget inert: no clicks, typing or actions.">
                <label className="flex items-center gap-2 text-xs"><input type="checkbox" checked={!!widget.readOnly} onChange={e => update({ readOnly: e.target.checked || undefined })}/> Disable interaction</label>
              </Field>
              <Field label="Hidden" hint="Not rendered at runtime; shown dimmed with a dashed outline in the builder.">
                <label className="flex items-center gap-2 text-xs"><input type="checkbox" checked={!!widget.hidden} onChange={e => update({ hidden: e.target.checked || undefined })}/> Hide at runtime</label>
              </Field>
            </Section>
          </>
        )}
        {/* Validation */}
        {tab === "data" && <ValidationHint widget={widget} values={values} module={module}/>}
      </div>
    </div>
  );
}

function ValidationHint({ widget, values, module }: { widget: WidgetDef; values: Record<string, unknown>; module: ReturnType<typeof useWorkshop>["module"] }) {
  const warnings: string[] = [];
  const cfg = widget.config as Record<string, unknown>;
  for (const key of ["objectSetVarId", "objectVarId", "activeVarId", "variableId"]) {
    const v = cfg[key] as string | undefined;
    if (v && !module.variables.find(x => x.id === v)) warnings.push(`Cannot resolve variable "${v}" (${key})`);
  }
  if (warnings.length === 0) return null;
  return (
    <div className="m-3 p-2 rounded-sm" style={{ background: "#fde9e9", border: "1px solid #e8a9a9", color: "#8a1f1f", fontSize: 11 }}>
      <div className="flex items-center gap-1 font-semibold mb-1"><Icon.Warning size={11}/> Configuration warnings</div>
      {warnings.map(w => <div key={w}>· {w}</div>)}
      <div className="mt-1 text-[10px]">Preview value: {formatValue(values[String(cfg.objectSetVarId ?? cfg.objectVarId ?? cfg.variableId)])}</div>
    </div>
  );
}

function DataInspector({ widget, updateConfig, values }: { widget: WidgetDef; updateConfig: (p: Record<string, unknown>) => void; values: Record<string, unknown> }) {
  const cfg = widget.config as Record<string, unknown>;
  const bindings: Array<{ key: string; label: string; filter?: string }> = [];
  // deduce based on config keys present
  if ("objectSetVarId" in cfg) bindings.push({ key: "objectSetVarId", label: "Object set", filter: "objectSet" });
  if ("objectVarId" in cfg) bindings.push({ key: "objectVarId", label: "Object", filter: "object" });
  if ("activeVarId" in cfg) bindings.push({ key: "activeVarId", label: "Active object (output)", filter: "object" });
  if ("selectedVarId" in cfg) bindings.push({ key: "selectedVarId", label: "Selected objects (output)", filter: "array" });
  if ("variableId" in cfg) bindings.push({ key: "variableId", label: "Value variable", filter: "any" });
  if ("historyVarId" in cfg) bindings.push({ key: "historyVarId", label: "History variable", filter: "array" });
  if ("inputVarId" in cfg) bindings.push({ key: "inputVarId", label: "Input variable", filter: "string" });
  if ("outputVarId" in cfg) bindings.push({ key: "outputVarId", label: "Output variable", filter: "any" });
  if ("listVarId" in cfg) bindings.push({ key: "listVarId", label: "List variable", filter: "array" });
  if ("draftVarId" in cfg) bindings.push({ key: "draftVarId", label: "Draft variable", filter: "string" });
  if ("pageVarId" in cfg) bindings.push({ key: "pageVarId", label: "Page variable", filter: "numeric" });
  if ("contextVarId" in cfg) bindings.push({ key: "contextVarId", label: "Context", filter: "any" });

  return (
    <>
      <Section title="Input data">
        {bindings.length === 0 && <div className="fnd-text-dim text-xs">This widget has no data bindings.</div>}
        {bindings.map(b => (
          <Field key={b.key} label={b.label}>
            <VariablePicker value={cfg[b.key] as string | undefined} onChange={v => updateConfig({ [b.key]: v })} filterType="any"/>
            {Boolean(cfg[b.key]) && <div className="text-[10px] fnd-text-dim mt-1">Value: {formatValue(values[cfg[b.key] as string])}</div>}
          </Field>
        ))}
      </Section>
    </>
  );
}

function PropsInspector({ widget, updateConfig }: { widget: WidgetDef; updateConfig: (p: Record<string, unknown>) => void }) {
  const cfg = widget.config as Record<string, unknown>;
  if (widget.type === "ObjectTable") {
    const columns = (cfg.columns as Array<{ key: string; label: string; width: number }>) ?? [];
    return (
      <>
        <Section title="Columns">
          {columns.map((c, i) => (
            <div key={c.key} className="flex items-center gap-2">
              <input className="fnd-input" value={c.label} onChange={e => {
                const next = [...columns]; next[i] = { ...next[i], label: e.target.value }; updateConfig({ columns: next });
              }} style={{ flex: 1 }}/>
              <input className="fnd-input" type="number" value={c.width} onChange={e => {
                const next = [...columns]; next[i] = { ...next[i], width: Number(e.target.value) }; updateConfig({ columns: next });
              }} style={{ width: 70 }}/>
              <button className="fnd-btn fnd-btn-minimal" onClick={() => {
                const next = columns.filter((_, j) => j !== i); updateConfig({ columns: next });
              }}><Icon.Trash size={11}/></button>
            </div>
          ))}
          <OntologyColumnPicker widget={widget} columns={columns} onAdd={col => updateConfig({ columns: [...columns, col] })}/>
        </Section>
        <Section title="Interaction">
          <Field label="Enable selection"><input type="checkbox" checked={!!cfg.enableSelection} onChange={e => updateConfig({ enableSelection: e.target.checked })}/></Field>
          <Field label="Selection mode">
            <select className="fnd-input fnd-select" value={(cfg.selectionMode as string) ?? "single"} onChange={e => updateConfig({ selectionMode: e.target.value })}>
              <option value="single">Single</option><option value="multiple">Multiple</option>
            </select>
          </Field>
          <Field label="Inline edit"><input type="checkbox" checked={!!cfg.enableInlineEdit} onChange={e => updateConfig({ enableInlineEdit: e.target.checked })}/></Field>
          <Field label="Show toolbar"><input type="checkbox" checked={cfg.showToolbar !== false} onChange={e => updateConfig({ showToolbar: e.target.checked })}/></Field>
          <Field label="Title template"><input className="fnd-input" value={(cfg.titleTemplate as string) ?? ""} onChange={e => updateConfig({ titleTemplate: e.target.value })}/></Field>
        </Section>
      </>
    );
  }
  if (widget.type === "MetricCard") {
    return (
      <Section title="Metric">
        <Field label="Label"><input className="fnd-input" value={(cfg.label as string) ?? ""} onChange={e => updateConfig({ label: e.target.value })}/></Field>
        <Field label="Prefix"><input className="fnd-input" value={(cfg.prefix as string) ?? ""} onChange={e => updateConfig({ prefix: e.target.value })}/></Field>
        <Field label="Suffix"><input className="fnd-input" value={(cfg.suffix as string) ?? ""} onChange={e => updateConfig({ suffix: e.target.value })}/></Field>
        <Field label="Variant">
          <select className="fnd-input fnd-select" value={(cfg.variant as string) ?? "card"} onChange={e => updateConfig({ variant: e.target.value })}>
            <option>simple</option><option>card</option><option>tag</option><option>trend</option><option>interactive</option>
          </select>
        </Field>
        <Field label="Color">
          <select className="fnd-input fnd-select" value={(cfg.color as string) ?? "default"} onChange={e => updateConfig({ color: e.target.value })}>
            <option value="default">Default</option><option>success</option><option>warning</option><option>danger</option>
          </select>
        </Field>
        <Field label="Trend">
          <select className="fnd-input fnd-select" value={(cfg.trend as string) ?? "flat"} onChange={e => updateConfig({ trend: e.target.value })}>
            <option>up</option><option>flat</option><option>down</option>
          </select>
        </Field>
      </Section>
    );
  }
  if (widget.type === "ChartXY") {
    return (
      <Section title="Chart">
        <Field label="Chart kind">
          <select className="fnd-input fnd-select" value={(cfg.chartKind as string) ?? "bar"} onChange={e => updateConfig({ chartKind: e.target.value })}>
            <option>line</option><option>bar</option><option>scatter</option><option>area</option>
          </select>
        </Field>
        <Field label="X property"><input className="fnd-input" value={(cfg.xProperty as string) ?? ""} onChange={e => updateConfig({ xProperty: e.target.value })}/></Field>
        <Field label="Y property"><input className="fnd-input" value={(cfg.yProperty as string) ?? ""} onChange={e => updateConfig({ yProperty: e.target.value })}/></Field>
        <Field label="Aggregation">
          <select className="fnd-input fnd-select" value={(cfg.agg as string) ?? "none"} onChange={e => updateConfig({ agg: e.target.value })}>
            <option>none</option><option>avg</option><option>sum</option><option>count</option>
          </select>
        </Field>
      </Section>
    );
  }
  if (widget.type === "Markdown") {
    return (
      <Section title="Content">
        <Field label="Markdown">
          <textarea className="fnd-input" style={{ height: 180, resize: "vertical" }} value={(cfg.text as string) ?? ""} onChange={e => updateConfig({ text: e.target.value })}/>
        </Field>
      </Section>
    );
  }
  if (widget.type === "ButtonGroup") {
    const btns = (cfg.buttons as Array<{ label: string; variant?: string }>) ?? [];
    return (
      <Section title="Buttons">
        {btns.map((b, i) => (
          <div key={i} className="flex items-center gap-2">
            <input className="fnd-input" value={b.label} onChange={e => { const n = [...btns]; n[i] = { ...n[i], label: e.target.value }; updateConfig({ buttons: n }); }}/>
            <select className="fnd-input fnd-select" style={{ width: 100 }} value={b.variant ?? "secondary"} onChange={e => { const n = [...btns]; n[i] = { ...n[i], variant: e.target.value }; updateConfig({ buttons: n }); }}>
              <option>primary</option><option>secondary</option><option>minimal</option><option>danger</option>
            </select>
          </div>
        ))}
        <button className="fnd-btn fnd-btn-minimal w-full justify-start" onClick={() => updateConfig({ buttons: [...btns, { label: `Button ${btns.length + 1}`, variant: "secondary", eventActions: [] }] })}><Icon.Plus size={11}/> Add button</button>
      </Section>
    );
  }
  if (widget.type === "HeaderText") {
    return <Section title="Text"><Field label="Content"><input className="fnd-input" value={(cfg.text as string) ?? ""} onChange={e => updateConfig({ text: e.target.value })}/></Field></Section>;
  }
  return (
    <div className="p-3 text-xs fnd-text-dim">
      {Object.entries(cfg).map(([k, v]) => (
        <div key={k} className="flex justify-between py-1 border-b fnd-border">
          <span className="fnd-text-muted">{k}</span>
          <span className="truncate" style={{ maxWidth: 140 }}>{typeof v === "object" ? JSON.stringify(v).slice(0, 40) : String(v)}</span>
        </div>
      ))}
    </div>
  );
}

function OntologyColumnPicker({ widget, columns, onAdd }: { widget: WidgetDef; columns: Array<{ key: string }>; onAdd: (c: { key: string; label: string; width: number }) => void }) {
  const { values, ontologyMeta, module } = useWorkshop();
  const varId = (widget.config as { objectSetVarId?: string }).objectSetVarId ?? "";
  const set = values[varId];
  const vdef = module.variables.find(v => v.id === varId);
  const type = (Array.isArray(set) && set[0] ? String((set[0] as Record<string, unknown>).__type) : undefined) ?? vdef?.sourceObjectType;
  const ot = ontologyMeta.objectTypes.find(o => o.apiName === type);
  if (!ot) return <div className="text-[11px] fnd-text-dim">Bind an object set to pick columns from its object type.</div>;
  const avail = ot.properties.filter(p => !columns.some(c => c.key === p.apiName));
  return (
    <div>
      <select className="fnd-input fnd-select" value="" onChange={e => {
        const p = ot.properties.find(x => x.apiName === e.target.value);
        if (p) onAdd({ key: p.apiName, label: p.displayName, width: p.baseType === "String" ? 140 : 100 });
      }}>
        <option value="">+ Add column from {ot.displayName}…</option>
        {avail.map(p => <option key={p.apiName} value={p.apiName}>{p.displayName} · {p.baseType}{p.visibility === "HIDDEN" ? " (hidden)" : ""}{p.derivation ? " · derived" : ""}</option>)}
      </select>
      <div className="text-[10px] fnd-text-dim mt-1">Columns format automatically from property base types defined in the Ontology.</div>
    </div>
  );
}

/** Resolve the Object Type an ObjectSetStep pipeline is operating on at a given step index. */
function typeAtStep(meta: ReturnType<typeof useWorkshop>["ontologyMeta"], base: string, steps: ObjectSetStep[], uptoIndex: number): string {
  let t = base;
  for (let i = 0; i < uptoIndex; i++) {
    const s = steps[i];
    if (s.op === "pivotTo") {
      const l = meta.linkTypes.find(x => x.apiName === s.linkTypeApiName);
      if (l) t = l.objectTypeA === t ? l.objectTypeB : l.objectTypeA;
    }
  }
  return t;
}

/** `Objects(Type).where(...).pivotTo(...)` pipeline builder — mirrors the OSDK Object Set fluent chain exactly. */
function ObjectSetDefinitionEditor({ variable, update }: { variable: VariableDef; update: (p: Partial<VariableDef>) => void }) {
  const { ontologyMeta: meta } = useWorkshop();
  const os: NonNullable<VariableDef["objectSet"]> = variable.objectSet ?? { objectType: meta.objectTypes[0]?.apiName ?? "", steps: [] };
  const setOs = (next: NonNullable<VariableDef["objectSet"]>) => update({ objectSet: next });
  const finalType = typeAtStep(meta, os.objectType, os.steps, os.steps.length);
  const finalOt = meta.objectTypes.find(o => o.apiName === finalType);

  return (
    <>
      <Field label="Base object type" hint={`Objects(${os.objectType || "…"})`}>
        <select className="fnd-input fnd-select" value={os.objectType} onChange={e => setOs({ objectType: e.target.value, steps: [] })}>
          <option value="">—</option>
          {meta.objectTypes.map(o => <option key={o.apiName} value={o.apiName}>{o.displayName} ({o.apiName})</option>)}
        </select>
      </Field>
      <Field label="Pipeline">
        <div className="space-y-1.5">
          {os.steps.map((step, i) => {
            const typeBefore = typeAtStep(meta, os.objectType, os.steps, i);
            const otBefore = meta.objectTypes.find(o => o.apiName === typeBefore);
            return (
              <div key={i} className="rounded-sm p-1.5" style={{ border: "1px solid var(--fnd-border)", background: "var(--fnd-panel-2)" }}>
                <div className="flex items-center gap-1 mb-1">
                  <span className="fnd-tag" style={{ fontFamily: "ui-monospace, Menlo, monospace" }}>.{step.op}(</span>
                  <div className="flex-1"/>
                  <button className="fnd-btn fnd-btn-minimal" title="Remove step" onClick={() => setOs({ ...os, steps: os.steps.filter((_, j) => j !== i) })}><Icon.Trash size={10}/></button>
                </div>
                {step.op === "where" && <WhereClauseEditor ot={otBefore} clauses={step.clauses} onChange={clauses => setOs({ ...os, steps: os.steps.map((s, j) => j === i ? { ...s, clauses } : s) })}/>}
                {step.op === "pivotTo" && (
                  <select className="fnd-input fnd-select" value={step.linkTypeApiName} onChange={e => setOs({ ...os, steps: os.steps.map((s, j) => j === i ? { ...s, linkTypeApiName: e.target.value } : s) })}>
                    {meta.linkTypes.filter(l => l.objectTypeA === typeBefore || l.objectTypeB === typeBefore).map(l => (
                      <option key={l.apiName} value={l.apiName}>{l.objectTypeA === typeBefore ? `${l.displayName} → ${l.objectTypeB}` : `${l.reverseDisplayName} → ${l.objectTypeA}`}</option>
                    ))}
                  </select>
                )}
                {(step.op === "union" || step.op === "intersect" || step.op === "subtract") && (
                  <VariablePicker value={step.otherVarId} onChange={v => setOs({ ...os, steps: os.steps.map((s, j) => j === i ? { ...s, otherVarId: v } : s) })}/>
                )}
                <span className="fnd-tag" style={{ fontFamily: "ui-monospace, Menlo, monospace" }}>)</span>
              </div>
            );
          })}
          <div className="flex flex-wrap gap-1">
            <button className="fnd-btn fnd-btn-minimal" onClick={() => setOs({ ...os, steps: [...os.steps, { op: "where", clauses: [] }] })}><Icon.Plus size={10}/> .where()</button>
            <button className="fnd-btn fnd-btn-minimal" onClick={() => setOs({ ...os, steps: [...os.steps, { op: "pivotTo", linkTypeApiName: meta.linkTypes[0]?.apiName ?? "" }] })}><Icon.Plus size={10}/> .pivotTo()</button>
            <button className="fnd-btn fnd-btn-minimal" onClick={() => setOs({ ...os, steps: [...os.steps, { op: "union", otherVarId: "" }] })}><Icon.Plus size={10}/> .union()</button>
            <button className="fnd-btn fnd-btn-minimal" onClick={() => setOs({ ...os, steps: [...os.steps, { op: "intersect", otherVarId: "" }] })}><Icon.Plus size={10}/> .intersect()</button>
            <button className="fnd-btn fnd-btn-minimal" onClick={() => setOs({ ...os, steps: [...os.steps, { op: "subtract", otherVarId: "" }] })}><Icon.Plus size={10}/> .subtract()</button>
          </div>
        </div>
        <div className="text-[10px] fnd-text-dim mt-1 font-mono">Objects({os.objectType}){os.steps.map(s => s.op === "where" ? ".where(…)" : s.op === "pivotTo" ? `.pivotTo("${s.linkTypeApiName}")` : `.${s.op}(@${s.otherVarId})`).join("")} <span className="fnd-tag">→ {finalOt?.displayName ?? finalType}</span></div>
      </Field>
    </>
  );
}

function WhereClauseEditor({ ot, clauses, onChange }: { ot: ReturnType<typeof useWorkshop>["ontologyMeta"]["objectTypes"][number] | undefined; clauses: Array<{ id: string; property: string; op: FilterOp; value?: unknown; varId?: string }>; onChange: (c: typeof clauses) => void }) {
  return (
    <div className="space-y-1">
      {clauses.map((f, i) => {
        const def = ot?.properties.find(p => p.apiName === f.property);
        const numeric = def && ["Double", "Integer", "Long", "Decimal", "Float", "Short", "Byte"].includes(def.baseType);
        const ops: FilterOp[] = f.property === "*" ? ["fullTextSearch"] : numeric ? ["is", "isNot", "isGreaterThanOrEqualTo", "isLessThanOrEqualTo", "isEmpty", "isNotEmpty"] : ["isOneOf", "is", "isNot", "contains", "isEmpty", "isNotEmpty"];
        const set = (patch: Partial<typeof f>) => onChange(clauses.map((x, j) => j === i ? { ...x, ...patch } : x));
        return (
          <div key={f.id} className="rounded-sm p-1.5 space-y-1" style={{ border: "1px solid var(--fnd-border)" }}>
            <div className="flex gap-1">
              <select className="fnd-input fnd-select" value={f.property} onChange={e => set({ property: e.target.value, op: e.target.value === "*" ? "fullTextSearch" : f.op })}>
                <option value="*">Full-text search</option>
                {(ot?.properties ?? []).map(p => <option key={p.apiName} value={p.apiName}>{p.displayName}</option>)}
              </select>
              <select className="fnd-input fnd-select" style={{ width: 150 }} value={f.op} onChange={e => set({ op: e.target.value as FilterOp })}>
                {ops.map(o => <option key={o} value={o}>{FILTER_OPS.find(x => x.v === o)?.label ?? o}</option>)}
              </select>
              <button className="fnd-btn fnd-btn-minimal" title="Remove clause" onClick={() => onChange(clauses.filter((_, j) => j !== i))}><Icon.Trash size={10}/></button>
            </div>
            {f.op !== "isEmpty" && f.op !== "isNotEmpty" && (
              <div className="flex gap-1 items-center">
                <select className="fnd-input fnd-select" style={{ width: 86 }} value={f.varId !== undefined ? "var" : "static"} onChange={e => set(e.target.value === "var" ? { varId: "", value: undefined } : { varId: undefined, value: "" })}>
                  <option value="static">Value</option><option value="var">Variable</option>
                </select>
                {f.varId !== undefined ? (
                  <div className="flex-1"><VariablePicker value={f.varId} onChange={v => set({ varId: v })}/></div>
                ) : null}
                {f.varId === undefined && (
                  <input className="fnd-input" value={String(f.value ?? "")} onChange={e => set({ value: numeric ? Number(e.target.value) : e.target.value })}/>
                )}
              </div>
            )}
          </div>
        );
      })}
      <button className="fnd-btn fnd-btn-minimal w-full justify-start" onClick={() => onChange([...clauses, { id: `f${Date.now()}`, property: ot?.properties[2]?.apiName ?? "*", op: "is", value: "" }])}><Icon.Plus size={10}/> Add clause</button>
    </div>
  );
}

// Events inspector
const EVENT_TRIGGERS = ["onClick", "onSelect", "onSubmit", "onLoad", "onTabChange", "onOverlayClose", "onFormSubmitSuccess", "onFormSubmitError"];
const EVENT_KINDS: Array<{ kind: EventAction["kind"]; label: string }> = [
  { kind: "setVariable", label: "Set variable value" },
  { kind: "resetVariable", label: "Reset variable" },
  { kind: "recomputeVariable", label: "Recompute variable" },
  { kind: "openOverlay", label: "Open overlay" },
  { kind: "closeOverlay", label: "Close overlay" },
  { kind: "expandSection", label: "Expand section" },
  { kind: "collapseSection", label: "Collapse section" },
  { kind: "toggleSection", label: "Toggle section" },
  { kind: "switchPage", label: "Switch page" },
  { kind: "switchTab", label: "Switch tab" },
  { kind: "openModule", label: "Open Workshop module" },
  { kind: "openObjectView", label: "Open Object View" },
  { kind: "openUrl", label: "Open URL" },
  { kind: "refreshData", label: "Refresh module data" },
  { kind: "enableAutoRefresh", label: "Enable auto-refresh" },
  { kind: "disableAutoRefresh", label: "Disable auto-refresh" },
  { kind: "toggleTheme", label: "Toggle light/dark" },
  { kind: "runAction", label: "Run action" },
];

function EventsInspector({ widget, update }: { widget: WidgetDef; update: (p: Partial<WidgetDef>) => void }) {
  const events = widget.events ?? [];
  return (
    <Section title="Events">
      {events.map((ev, ei) => (
        <div key={ev.id} className="rounded-sm" style={{ border: "1px solid var(--fnd-border)" }}>
          <div className="flex items-center gap-2 px-2 py-1.5 border-b fnd-border" style={{ background: "var(--fnd-panel-2)" }}>
            <Icon.Event size={11}/>
            <select className="fnd-input" style={{ flex: 1 }} value={ev.trigger} onChange={e => {
              const next = [...events]; next[ei] = { ...ev, trigger: e.target.value }; update({ events: next });
            }}>
              {EVENT_TRIGGERS.map(t => <option key={t}>{t}</option>)}
            </select>
            <button className="fnd-btn fnd-btn-minimal" onClick={() => update({ events: events.filter((_, i) => i !== ei) })}><Icon.Trash size={11}/></button>
          </div>
          <div className="p-2 space-y-1.5">
            {ev.actions.map((a, ai) => (
              <ActionRow key={ai} action={a} onChange={na => {
                const next = [...events]; next[ei] = { ...ev, actions: ev.actions.map((x, j) => j === ai ? na : x) }; update({ events: next });
              }} onDelete={() => {
                const next = [...events]; next[ei] = { ...ev, actions: ev.actions.filter((_, j) => j !== ai) }; update({ events: next });
              }}/>
            ))}
            <button className="fnd-btn fnd-btn-minimal w-full justify-start" onClick={() => {
              const next = [...events]; next[ei] = { ...ev, actions: [...ev.actions, { kind: "refreshData" } as EventAction] }; update({ events: next });
            }}><Icon.Plus size={11}/> Add action</button>
          </div>
        </div>
      ))}
      <button className="fnd-btn w-full justify-center" onClick={() => update({ events: [...events, { id: `ev${Date.now()}`, trigger: "onClick", actions: [] }] })}>
        <Icon.Plus size={11}/> Add event
      </button>
    </Section>
  );
}

function ActionRow({ action, onChange, onDelete }: { action: EventAction; onChange: (a: EventAction) => void; onDelete: () => void }) {
  const { module, ontologyMeta } = useWorkshop();
  return (
    <div className="flex items-start gap-1.5">
      <select className="fnd-input" style={{ flex: 1 }} value={action.kind} onChange={e => onChange({ ...action, kind: e.target.value } as EventAction)}>
        {EVENT_KINDS.map(k => <option key={k.kind} value={k.kind}>{k.label}</option>)}
      </select>
      {(action.kind === "setVariable" || action.kind === "resetVariable" || action.kind === "recomputeVariable") && (
        <select className="fnd-input" style={{ flex: 1 }} value={("variableId" in action ? action.variableId : "") as string} onChange={e => onChange({ ...action, variableId: e.target.value } as EventAction)}>
          <option value="">Variable...</option>
          {module.variables.map(v => <option key={v.id} value={v.id}>@{v.name}</option>)}
        </select>
      )}
      {action.kind === "setVariable" && (
        <input className="fnd-input" style={{ width: 80 }} value={(action as { valueExpr?: string }).valueExpr ?? ""} onChange={e => onChange({ ...action, valueExpr: e.target.value } as EventAction)} placeholder="value"/>
      )}
      {(action.kind === "openOverlay" || action.kind === "closeOverlay") && (
        <select className="fnd-input" style={{ flex: 1 }} value={("overlayId" in action ? action.overlayId : "") as string} onChange={e => onChange({ ...action, overlayId: e.target.value } as EventAction)}>
          <option value="">Overlay...</option>
          {module.overlays.map(o => <option key={o.id} value={o.id}>{o.name}</option>)}
        </select>
      )}
      {action.kind === "switchPage" && (
        <select className="fnd-input" style={{ flex: 1 }} value={("pageId" in action ? action.pageId : "") as string} onChange={e => onChange({ ...action, pageId: e.target.value } as EventAction)}>
          <option value="">Page...</option>
          {module.pages.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
      )}
      {action.kind === "runAction" && (
        <select className="fnd-input" style={{ flex: 1 }} value={("actionId" in action ? action.actionId : "") as string} onChange={e => onChange({ ...action, actionId: e.target.value } as EventAction)}>
          <option value="">Action...</option>
          {ontologyMeta.actionTypes.map(a => <option key={a.apiName} value={a.apiName}>{a.displayName}</option>)}
        </select>
      )}
      <button className="fnd-btn fnd-btn-minimal" onClick={onDelete}><Icon.Trash size={11}/></button>
    </div>
  );
}

// ─── Section Inspector ───
function SectionInspector({ section }: { section: SectionDef }) {
  const { updateModule } = useWorkshop();
  const update = (patch: Partial<SectionDef>) => {
    updateModule(m => ({ ...m, sections: { ...m.sections, [section.id]: { ...m.sections[section.id], ...patch } } }), "edit section");
  };
  return (
    <div className="h-full flex flex-col">
      <div className="px-3 py-2 border-b fnd-border">
        <div className="flex items-center gap-2"><Icon.Section size={14}/><input className="fnd-input" value={section.name} onChange={e => update({ name: e.target.value })}/></div>
        <div className="text-[10px] fnd-text-dim mt-1">section · {section.id}</div>
      </div>
      <div className="flex-1 overflow-auto">
        <Section title="Identity">
          <Field label="Name"><input className="fnd-input" value={section.name} onChange={e => update({ name: e.target.value })}/></Field>
          <Field label="Description"><input className="fnd-input" value={section.description ?? ""} onChange={e => update({ description: e.target.value })}/></Field>
        </Section>
        <Section title="Header">
          <Field label="Show header"><input type="checkbox" checked={!!section.showHeader} onChange={e => update({ showHeader: e.target.checked })}/></Field>
          <Field label="Title"><input className="fnd-input" value={section.title ?? ""} onChange={e => update({ title: e.target.value })}/></Field>
        </Section>
        <Section title="Layout">
          <Field label="Direction">
            <select className="fnd-input fnd-select" value={section.layout} onChange={e => update({ layout: e.target.value as SectionDef["layout"] })}>
              <option value="columns">Columns</option>
              <option value="rows">Rows</option>
              <option value="tabs">Tabs</option>
              <option value="flow">Flow</option>
              <option value="toolbar">Toolbar</option>
              <option value="loop">Loop</option>
            </select>
          </Field>
          <Field label="Width"><input className="fnd-input" value={section.width ?? ""} onChange={e => update({ width: e.target.value })} placeholder="auto / 260px"/></Field>
          <Field label="Height"><input className="fnd-input" value={section.height ?? ""} onChange={e => update({ height: e.target.value })} placeholder="auto"/></Field>
          <Field label="Width weight" hint="Share of the row this section takes when its parent is Columns. Drag the side handle on canvas for the same effect."><input type="number" className="fnd-input" min={0.1} step={0.1} value={section.flex ?? 1} onChange={e => update({ flex: Math.max(0.1, Number(e.target.value)) })}/></Field>
          <Field label="Align items"><select className="fnd-input fnd-select" value={section.align ?? "stretch"} onChange={e => update({ align: e.target.value as SectionDef["align"] })}><option value="stretch">Stretch</option><option value="start">Start</option><option value="center">Center</option><option value="end">End</option></select></Field>
          <Field label="Justify"><select className="fnd-input fnd-select" value={section.justify ?? "start"} onChange={e => update({ justify: e.target.value as SectionDef["justify"] })}><option value="start">Start</option><option value="center">Center</option><option value="end">End</option><option value="between">Space between</option></select></Field>
          <Field label="Wrap children"><label className="flex items-center gap-2 text-xs"><input type="checkbox" checked={!!section.wrap} onChange={e => update({ wrap: e.target.checked })}/> Allow wrapping</label></Field>
          <Field label="Stack below (px)" hint="Columns become a vertical stack when this section is narrower than this. Test with the device picker."><input type="number" className="fnd-input" min={0} value={section.stackBelow ?? 640} disabled={section.noStack} onChange={e => update({ stackBelow: Number(e.target.value) })}/></Field>
          <Field label="Never stack"><label className="flex items-center gap-2 text-xs"><input type="checkbox" checked={!!section.noStack} onChange={e => update({ noStack: e.target.checked })}/> Keep columns on small screens</label></Field>
          {section.layout === "loop" && (<>
            <Field label="Loop over (object set)"><VariablePicker value={section.loopVariableId} onChange={v => update({ loopVariableId: v })}/></Field>
            <Field label="Current item variable" hint="Inside the loop body, this variable resolves to the current object."><VariablePicker value={section.loopItemVarId} onChange={v => update({ loopItemVarId: v })}/></Field>
          </>)}
          <Field label="Padding"><input type="number" className="fnd-input" value={section.padding ?? 0} onChange={e => update({ padding: Number(e.target.value) })}/></Field>
          <Field label="Gap"><input type="number" className="fnd-input" value={section.gap ?? 0} onChange={e => update({ gap: Number(e.target.value) })}/></Field>
        </Section>
        <Section title="Appearance">
          <Field label="Background">
            <select className="fnd-input fnd-select" value={section.background ?? "default"} onChange={e => update({ background: e.target.value as SectionDef["background"] })}>
              <option>default</option><option>panel</option><option>muted</option><option>none</option>
            </select>
          </Field>
          <Field label="Border"><input type="checkbox" checked={!!section.border} onChange={e => update({ border: e.target.checked })}/></Field>
          <Field label="Divider"><input type="checkbox" checked={!!section.divider} onChange={e => update({ divider: e.target.checked })}/></Field>
        </Section>
        <Section title="Behavior">
          <Field label="Scroll"><input type="checkbox" checked={!!section.scroll} onChange={e => update({ scroll: e.target.checked })}/></Field>
          <Field label="Collapsible"><input type="checkbox" checked={!!section.collapsible} onChange={e => update({ collapsible: e.target.checked })}/></Field>
          <Field label="Default collapsed"><input type="checkbox" checked={!!section.defaultCollapsed} onChange={e => update({ defaultCollapsed: e.target.checked })}/></Field>
          <Field label="Visible when variable">
            <VariablePicker value={section.visibleVariableId} onChange={v => update({ visibleVariableId: v })} filterType="boolean"/>
          </Field>
        </Section>
      </div>
    </div>
  );
}

function PageInspector({ page }: { page: { id: string; name: string } }) {
  const { updateModule } = useWorkshop();
  return (
    <div>
      <div className="px-3 py-2 border-b fnd-border">
        <div className="flex items-center gap-2"><Icon.Section size={14}/><input className="fnd-input" value={page.name} onChange={e => updateModule(m => ({ ...m, pages: m.pages.map(p => p.id === page.id ? { ...p, name: e.target.value } : p) }))}/></div>
      </div>
      <Section title="Page">
        <Field label="Name"><input className="fnd-input" value={page.name} onChange={e => updateModule(m => ({ ...m, pages: m.pages.map(p => p.id === page.id ? { ...p, name: e.target.value } : p) }))}/></Field>
        <Field label="Page ID"><div className="fnd-input" style={{ display: "flex", alignItems: "center", color: "var(--fnd-text-dim)" }}>{page.id}</div></Field>
      </Section>
    </div>
  );
}

function OverlayInspector({ overlay }: { overlay: import("../types").OverlayDef }) {
  const { updateModule } = useWorkshop();
  const update = (patch: Partial<import("../types").OverlayDef>) => updateModule(m => ({ ...m, overlays: m.overlays.map(o => o.id === overlay.id ? { ...o, ...patch } : o) }));
  return (
    <div>
      <div className="px-3 py-2 border-b fnd-border"><div className="flex items-center gap-2"><Icon.Overlay size={14}/><input className="fnd-input" value={overlay.name} onChange={e => update({ name: e.target.value })}/></div></div>
      <Section title="Overlay">
        <Field label="Kind">
          <select className="fnd-input fnd-select" value={overlay.kind} onChange={e => update({ kind: e.target.value as import("../types").OverlayKind })}>
            <option value="drawer">Drawer</option><option value="modal">Modal</option>
          </select>
        </Field>
        {overlay.kind === "drawer" && (
          <>
            <Field label="Side">
              <select className="fnd-input fnd-select" value={overlay.side ?? "right"} onChange={e => update({ side: e.target.value as "left" | "right" })}><option>left</option><option>right</option></select>
            </Field>
            <Field label="Size">
              <select className="fnd-input fnd-select" value={overlay.size ?? "medium"} onChange={e => update({ size: e.target.value as "small" | "medium" | "large" | "custom" })}>
                <option>small</option><option>medium</option><option>large</option><option>custom</option>
              </select>
            </Field>
          </>
        )}
        {overlay.kind === "modal" && (
          <Field label="Title"><input className="fnd-input" value={overlay.title ?? ""} onChange={e => update({ title: e.target.value })}/></Field>
        )}
        <Field label="Backdrop"><input type="checkbox" checked={overlay.backdrop !== false} onChange={e => update({ backdrop: e.target.checked })}/></Field>
        <Field label="Close on backdrop click"><input type="checkbox" checked={overlay.closeOnBackdrop !== false} onChange={e => update({ closeOnBackdrop: e.target.checked })}/></Field>
        <Field label="Close on Esc"><input type="checkbox" checked={overlay.closeOnEsc !== false} onChange={e => update({ closeOnEsc: e.target.checked })}/></Field>
        <Field label="Open state variable">
          <VariablePicker value={overlay.openVariableId} onChange={v => update({ openVariableId: v })} filterType="boolean"/>
        </Field>
      </Section>
    </div>
  );
}

function HeaderInspector() {
  const { module, updateModule } = useWorkshop();
  const h = module.header;
  return (
    <div>
      <div className="px-3 py-2 border-b fnd-border"><div className="flex items-center gap-2"><Icon.Flow size={14}/><span className="font-semibold">Header</span></div></div>
      <Section title="Header">
        <Field label="Title"><input className="fnd-input" value={h.title} onChange={e => updateModule(m => ({ ...m, header: { ...m.header, title: e.target.value } }))}/></Field>
        <Field label="Variant">
          <select className="fnd-input fnd-select" value={h.variant} onChange={e => updateModule(m => ({ ...m, header: { ...m.header, variant: e.target.value as "horizontal" | "vertical" } }))}>
            <option value="horizontal">Horizontal</option><option value="vertical">Vertical</option>
          </select>
        </Field>
      </Section>
      <Section title="Items">
        {h.items.map((it, i) => (
          <div key={i} className="flex items-center gap-2 py-1 border-b fnd-border">
            <span className="fnd-tag">{it.kind}</span>
            <span className="text-xs truncate">{it.kind === "button" ? it.label : it.kind === "text" ? it.text : ""}</span>
          </div>
        ))}
      </Section>
    </div>
  );
}

function VariableInspector({ variable }: { variable: VariableDef }) {
  const { updateModule, values, ontologyMeta } = useWorkshop();
  const update = (patch: Partial<VariableDef>) => updateModule(m => ({ ...m, variables: m.variables.map(v => v.id === variable.id ? { ...v, ...patch } : v) }));
  const current = values[variable.id];
  return (
    <div>
      <div className="px-3 py-2 border-b fnd-border"><div className="flex items-center gap-2"><Icon.Variable size={14}/><input className="fnd-input" value={variable.name} onChange={e => update({ name: e.target.value })}/></div></div>
      <Section title="Identity">
        <Field label="Name"><input className="fnd-input" value={variable.name} onChange={e => update({ name: e.target.value })}/></Field>
        <Field label="Description"><input className="fnd-input" value={variable.description ?? ""} onChange={e => update({ description: e.target.value })}/></Field>
        <Field label="Type">
          <select className="fnd-input fnd-select" value={variable.type} onChange={e => update({ type: e.target.value as VariableDef["type"] })}>
            {["string", "numeric", "boolean", "date", "timestamp", "array", "objectSet", "objectSetFilter", "objectProperty", "struct", "geoPoint", "geoShape", "timeSeriesSet", "object"].map(t => <option key={t}>{t}</option>)}
          </select>
        </Field>
      </Section>
      <Section title="Definition">
        <Field label="Definition kind">
          <select className="fnd-input fnd-select" value={variable.definitionKind} onChange={e => update({ definitionKind: e.target.value as VariableDef["definitionKind"] })}>
            {["static", "function", "objectSetAggregation", "objectProperty", "objectSetDefinition", "variableTransformation", "sqlQuery", "widgetOutput"].map(t => <option key={t}>{t}</option>)}
          </select>
        </Field>
        {variable.definitionKind === "static" && (
          <Field label="Static value"><input className="fnd-input" value={String(variable.staticValue ?? "")} onChange={e => update({ staticValue: e.target.value })}/></Field>
        )}
        {variable.definitionKind === "objectSetDefinition" && <ObjectSetDefinitionEditor variable={variable} update={update}/>}
        {variable.definitionKind === "function" && (
          <>
            <Field label="Function">
              <select className="fnd-input fnd-select" value={variable.functionApiName ?? ""} onChange={e => update({ functionApiName: e.target.value })}>
                <option value="">—</option>
                {ontologyMeta.functions.map(f => <option key={f.apiName} value={f.apiName}>{f.apiName}({f.inputs.map(i => i.type).join(", ")}) → {f.output}</option>)}
              </select>
            </Field>
            <Field label="Input variable"><VariablePicker value={variable.inputVarId} onChange={v => update({ inputVarId: v })}/></Field>
          </>
        )}
        {variable.definitionKind === "widgetOutput" && (
          <>
            <Field label="Source widget ID"><input className="fnd-input" value={variable.widgetId ?? ""} onChange={e => update({ widgetId: e.target.value })}/></Field>
            <Field label="Output key"><input className="fnd-input" value={variable.widgetOutputKey ?? ""} onChange={e => update({ widgetOutputKey: e.target.value })}/></Field>
          </>
        )}
        <Field label="Recompute">
          <select className="fnd-input fnd-select" value={variable.recompute} onChange={e => update({ recompute: e.target.value as VariableDef["recompute"] })}>
            <option value="automatic">Automatic</option>
            <option value="triggered">Only when triggered by event</option>
            <option value="onLoadAndTriggered">On module load + triggered</option>
          </select>
        </Field>
      </Section>
      <Section title="Value preview">
        <div className="fnd-panel-2 rounded-sm p-2 text-xs font-mono">{formatValue(current)}</div>
      </Section>
      <Section title="Module interface">
        <Field label="Expose on interface"><input type="checkbox" checked={!!variable.isInterface} onChange={e => update({ isInterface: e.target.checked })}/></Field>
        <Field label="External ID"><input className="fnd-input" value={variable.externalId ?? ""} onChange={e => update({ externalId: e.target.value })}/></Field>
        <Field label="Direction">
          <select className="fnd-input fnd-select" value={variable.interfaceDirection ?? "inputOutput"} onChange={e => update({ interfaceDirection: e.target.value as VariableDef["interfaceDirection"] })}>
            <option value="input">Input</option><option value="output">Output</option><option value="inputOutput">Input/Output</option>
          </select>
        </Field>
      </Section>
    </div>
  );
}
