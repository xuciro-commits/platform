"use client";
import React, { useState } from "react";
import { useWorkshop } from "../WorkshopContext";
import type { SectionDef } from "../types";
import { Icon } from "../widgets/icons";
import { beginDrag } from "../dnd";
import type { MenuItem } from "../ui/ContextMenu";
import { deletePage, deleteSection, deleteWidget, describeImpact, duplicateSection, duplicateWidget, makeUnused, moveChild } from "../moduleOps";

export function LayoutTree() {
  const {
    module, currentPageId, setCurrentPageId, selection, select, openOverlay,
    openContextMenu, addNewPage, addNewOverlay, copySel, pasteSel,
    restoreWidget, addSectionAt, updateModule, requestConfirm,
  } = useWorkshop();
  const [expanded, setExpanded] = useState<Record<string, boolean>>({ _header: true, _pages: true, _overlays: true, _unused: false });
  const toggle = (k: string) => setExpanded(e => ({ ...e, [k]: !e[k] }));

  const widgetMenu = (id: string): MenuItem[] => [
    { label: "Rename", onClick: () => {
      const w = module.widgets[id];
      const n = prompt("Widget name", w?.name);
      if (n) updateModule(m => ({ ...m, widgets: { ...m.widgets, [id]: { ...m.widgets[id], name: n } } }), "rename widget");
    }},
    { label: "Duplicate", shortcut: "⌘D", onClick: () => {
      const res = duplicateWidget(module, id);
      if (res) { updateModule(() => res.module, "duplicate widget"); select({ kind: "widget", id: res.newId }); }
    }},
    { label: "Copy", shortcut: "⌘C", onClick: () => { select({ kind: "widget", id }); copySel(); } },
    { label: "Move up", onClick: () => updateModule(m => moveChild(m, id, "up"), "move up") },
    { label: "Move down", onClick: () => updateModule(m => moveChild(m, id, "down"), "move down") },
    { label: "Make unused", onClick: () => { updateModule(m => makeUnused(m, id), "make unused"); select({ kind: null, id: null }); } },
    { separator: true, label: "" },
    { label: "Delete", danger: true, shortcut: "⌫", onClick: () => {
      requestConfirm({
        title: "Delete widget",
        message: "This widget and its downstream widget-output variables will be affected.",
        impact: describeImpact(module, "widget", id),
        onConfirm: () => { updateModule(m => deleteWidget(m, id), "delete widget"); select({ kind: null, id: null }); },
      });
    }},
  ];

  const sectionMenu = (id: string): MenuItem[] => [
    { label: "Rename", onClick: () => {
      const n = prompt("Section name", module.sections[id]?.name);
      if (n) updateModule(m => ({ ...m, sections: { ...m.sections, [id]: { ...m.sections[id], name: n } } }), "rename section");
    }},
    { label: "Add above", onClick: () => addSectionAt(id, "above") },
    { label: "Add below", onClick: () => addSectionAt(id, "below") },
    { label: "Add left", onClick: () => addSectionAt(id, "left") },
    { label: "Add right", onClick: () => addSectionAt(id, "right") },
    { label: "Duplicate", onClick: () => {
      const res = duplicateSection(module, id);
      if (res) { updateModule(() => res.module, "duplicate section"); select({ kind: "section", id: res.newId }); }
    }},
    { label: "Copy", onClick: () => { select({ kind: "section", id }); setTimeout(copySel, 0); } },
    { label: "Paste into", onClick: () => pasteSel(id) },
    { separator: true, label: "" },
    { label: "Delete", danger: true, onClick: () => {
      requestConfirm({
        title: "Delete section",
        message: "Nested sections and widgets will be removed.",
        impact: describeImpact(module, "section", id),
        onConfirm: () => { updateModule(m => deleteSection(m, id), "delete section"); select({ kind: null, id: null }); },
      });
    }},
  ];

  return (
    <div className="h-full flex flex-col text-xs">
      <div className="px-2.5 py-2 border-b fnd-border flex items-center gap-2">
        <div className="fnd-label">Layout</div>
        <div className="flex-1"/>
        <button className="fnd-btn fnd-btn-minimal" title="Add page" onClick={() => addNewPage()}><Icon.Plus size={12}/></button>
      </div>
      <div className="flex-1 overflow-auto p-1">
        <div className={`fnd-tree-row ${selection.kind === "header" ? "selected" : ""}`} onClick={() => select({ kind: "header", id: "header" })}>
          <button onClick={e => { e.stopPropagation(); toggle("_header"); }} style={{ padding: 0, background: "none", border: 0, cursor: "pointer" }}>
            <Icon.Chevron size={10} dir={expanded._header ? "down" : "right"}/>
          </button>
          <span style={{ color: "var(--fnd-text-muted)" }}><Icon.Flow size={12}/></span>
          <span className="ml-1 font-semibold">Header</span>
        </div>
        {expanded._header && (
          <div style={{ paddingLeft: 20 }}>
            {module.header.items.map((it, i) => (
              <div key={i} className="fnd-tree-row">
                <span className="fnd-text-dim">·</span>
                <span className="ml-1">{it.kind === "button" ? `Button · ${it.label}` : it.kind === "tabs" ? `Tabs (${it.pageIds.length})` : it.kind}</span>
              </div>
            ))}
          </div>
        )}

        <div className="fnd-tree-row" onClick={() => toggle("_pages")} onContextMenu={e => {
          e.preventDefault();
          openContextMenu(e.clientX, e.clientY, [
            { label: "Add page", onClick: () => addNewPage() },
          ]);
        }}>
          <Icon.Chevron size={10} dir={expanded._pages ? "down" : "right"}/>
          <span className="ml-1 font-semibold">Pages</span>
          <span className="ml-auto fnd-tag">{module.pages.length}</span>
        </div>
        {expanded._pages && module.pages.map(page => {
          const isCurrent = page.id === currentPageId;
          const sel = selection.kind === "page" && selection.id === page.id;
          return (
            <div key={page.id} style={{ paddingLeft: 16 }}>
              <div className={`fnd-tree-row ${sel ? "selected" : ""}`}
                onClick={() => { select({ kind: "page", id: page.id }); setCurrentPageId(page.id); }}
                onContextMenu={e => {
                  e.preventDefault();
                  openContextMenu(e.clientX, e.clientY, [
                    { label: "Rename", onClick: () => {
                      const n = prompt("Page name", page.name);
                      if (n) updateModule(m => ({ ...m, pages: m.pages.map(p => p.id === page.id ? { ...p, name: n } : p) }), "rename page");
                    }},
                    { label: "Add page", onClick: () => addNewPage() },
                    { separator: true, label: "" },
                    { label: "Delete page", danger: true, onClick: () => {
                      requestConfirm({
                        title: "Delete page",
                        message: "The page and its entire layout tree will be removed.",
                        impact: describeImpact(module, "page", page.id),
                        onConfirm: () => { updateModule(m => deletePage(m, page.id), "delete page"); },
                      });
                    }},
                  ]);
                }}>
                <button onClick={e => { e.stopPropagation(); toggle(page.id); }} style={{ padding: 0, background: "none", border: 0, cursor: "pointer" }}>
                  <Icon.Chevron size={10} dir={expanded[page.id] ? "down" : "right"}/>
                </button>
                <Icon.Section size={12}/>
                <span className="ml-1">{page.name}</span>
                {isCurrent && <span className="ml-auto fnd-tag" style={{ background: "var(--fnd-selection)", color: "var(--fnd-accent)", borderColor: "var(--fnd-selection-border)" }}>current</span>}
              </div>
              {expanded[page.id] && (
                <div style={{ paddingLeft: 16 }}>
                  <SectionNode sectionId={page.rootSectionId} sectionMenu={sectionMenu} widgetMenu={widgetMenu}/>
                </div>
              )}
            </div>
          );
        })}

        <div className="fnd-tree-row" onClick={() => toggle("_overlays")} onContextMenu={e => {
          e.preventDefault();
          openContextMenu(e.clientX, e.clientY, [
            { label: "Add drawer", onClick: () => addNewOverlay("drawer") },
            { label: "Add modal", onClick: () => addNewOverlay("modal") },
          ]);
        }}>
          <Icon.Chevron size={10} dir={expanded._overlays ? "down" : "right"}/>
          <span className="ml-1 font-semibold">Overlays</span>
          <span className="ml-auto fnd-tag">{module.overlays.length}</span>
        </div>
        {expanded._overlays && module.overlays.map(o => (
          <div key={o.id} style={{ paddingLeft: 16 }}>
            <div className={`fnd-tree-row ${selection.kind === "overlay" && selection.id === o.id ? "selected" : ""}`}
              onClick={() => { select({ kind: "overlay", id: o.id }); openOverlay(o.id); }}
              onContextMenu={e => {
                e.preventDefault();
                openContextMenu(e.clientX, e.clientY, [
                  { label: "Open", onClick: () => openOverlay(o.id) },
                  { label: "Delete", danger: true, onClick: () => {
                    requestConfirm({
                      title: "Delete overlay",
                      message: "The overlay and its contents will be removed.",
                      impact: describeImpact(module, "overlay", o.id),
                      onConfirm: () => updateModule(m => ({ ...m, overlays: m.overlays.filter(x => x.id !== o.id) }), "delete overlay"),
                    });
                  }},
                ]);
              }}>
              <Icon.Overlay size={12}/>
              <span className="ml-1">{o.name}</span>
              <span className="ml-auto fnd-tag">{o.kind}</span>
            </div>
          </div>
        ))}

        <div className="fnd-tree-row" onClick={() => toggle("_unused")}>
          <Icon.Chevron size={10} dir={expanded._unused ? "down" : "right"}/>
          <span className="ml-1 font-semibold">Unused widgets</span>
          <span className="ml-auto fnd-tag">{module.unusedWidgetIds.length}</span>
        </div>
        {expanded._unused && module.unusedWidgetIds.map(id => {
          const w = module.widgets[id];
          return (
            <div key={id} style={{ paddingLeft: 32 }}
              className={`fnd-tree-row ${selection.kind === "widget" && selection.id === id ? "selected" : ""}`}
              onClick={() => select({ kind: "widget", id })}
              onContextMenu={e => {
                e.preventDefault();
                openContextMenu(e.clientX, e.clientY, [
                  { label: "Restore to current page", onClick: () => restoreWidget(id) },
                  { label: "Delete", danger: true, onClick: () => {
                    requestConfirm({
                      title: "Delete unused widget",
                      message: "This unused widget will be permanently removed.",
                      impact: describeImpact(module, "widget", id),
                      onConfirm: () => updateModule(m => deleteWidget(m, id), "delete widget"),
                    });
                  }},
                ]);
              }}>
              <Icon.Object size={12}/>
              <span className="ml-1 fnd-text-dim">{w?.name}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function SectionNode({ sectionId, depth = 0, sectionMenu, widgetMenu, parentId, parentIndex }: {
  sectionId: string; depth?: number; parentIndex?: number;
  sectionMenu: (id: string) => MenuItem[];
  widgetMenu: (id: string) => MenuItem[];
  parentId?: string;
}) {
  const { module, selection, select, openContextMenu } = useWorkshop();
  const [open, setOpen] = useState(true);
  const section: SectionDef | undefined = module.sections[sectionId];
  if (!section) return null;
  const sel = selection.kind === "section" && selection.id === sectionId;
  const isRoot = module.pages.some(p => p.rootSectionId === sectionId) || module.overlays.some(o => o.rootSectionId === sectionId);

  return (
    <div>
      <div className={`fnd-tree-row ${sel ? "selected" : ""}`} onClick={() => select({ kind: "section", id: sectionId })}
        data-tree-node="section" data-tree-id={sectionId} data-tree-parent={parentId} data-tree-index={parentIndex}
        onPointerDown={e => { if (!isRoot) beginDrag({ kind: "move", childKind: "section", id: sectionId, name: section.name }, e.nativeEvent); }}
        title={isRoot ? undefined : "Drag to move · drop on a row to insert"}
        onContextMenu={e => { e.preventDefault(); e.stopPropagation(); openContextMenu(e.clientX, e.clientY, sectionMenu(sectionId)); }}
        style={{ paddingLeft: depth * 8, touchAction: "none" }}>
        <button onClick={e => { e.stopPropagation(); setOpen(!open); }} style={{ padding: 0, background: "none", border: 0, cursor: "pointer" }}>
          <Icon.Chevron size={10} dir={open ? "down" : "right"}/>
        </button>
        <Icon.Section size={11}/>
        <span className="ml-1">{section.name}</span>
        <span className="ml-auto text-[10px] fnd-text-dim">{section.layout}</span>
      </div>
      {open && section.children.map((c, i) => {
        if (c.kind === "section") return <SectionNode key={i} sectionId={c.id} depth={depth + 1} sectionMenu={sectionMenu} widgetMenu={widgetMenu} parentId={sectionId} parentIndex={i}/>;
        const w = module.widgets[c.id];
        const widgetSel = selection.kind === "widget" && selection.id === c.id;
        return (
          <div key={i} className={`fnd-tree-row ${widgetSel ? "selected" : ""}`}
            style={{ paddingLeft: (depth + 1) * 8 + 14, cursor: "grab", touchAction: "none" }}
            data-tree-node="widget" data-tree-id={c.id} data-tree-parent={sectionId} data-tree-index={i}
            title="Drag to move · drop on a row to insert"
            onPointerDown={e => beginDrag({ kind: "move", childKind: "widget", id: c.id, name: w?.name ?? c.id }, e.nativeEvent)}
            onClick={() => select({ kind: "widget", id: c.id })}
            onContextMenu={e => { e.preventDefault(); e.stopPropagation(); openContextMenu(e.clientX, e.clientY, widgetMenu(c.id)); }}>
            <WidgetIcon type={w?.type ?? ""}/>
            <span className="ml-1">{w?.name}</span>
          </div>
        );
      })}
      {open && section.children.length === 0 && (
        <div className="fnd-text-dim" style={{ paddingLeft: (depth + 1) * 8 + 22, fontSize: 11, height: 22, display: "flex", alignItems: "center" }}>empty section</div>
      )}
    </div>
  );
}

export function WidgetIcon({ type }: { type: string }) {
  if (type === "ObjectTable") return <Icon.Table size={11}/>;
  if (type === "ObjectList") return <Icon.List size={11}/>;
  if (type === "ObjectView") return <Icon.Object size={11}/>;
  if (type.startsWith("Chart")) return <Icon.Chart size={11}/>;
  if (type === "Map") return <Icon.Map size={11}/>;
  if (type === "FilterList") return <Icon.Filter size={11}/>;
  if (type === "MetricCard") return <Icon.Metric size={11}/>;
  if (type === "ButtonGroup") return <Icon.Button size={11}/>;
  if (type === "Tabs") return <Icon.Tabs size={11}/>;
  if (type === "TextInput" || type === "NumericInput" || type === "DateInput") return <Icon.Input size={11}/>;
  if (type === "StringSelector" || type === "UserSelect" || type === "ObjectDropdown") return <Icon.Dropdown size={11}/>;
  if (type === "Markdown") return <Icon.Markdown size={11}/>;
  if (type === "PdfViewer") return <Icon.Pdf size={11}/>;
  if (type === "Comments") return <Icon.Comment size={11}/>;
  if (type === "MediaUploader") return <Icon.Upload size={11}/>;
  if (type === "Gantt") return <Icon.Gantt size={11}/>;
  if (type === "Timeline") return <Icon.Timeline size={11}/>;
  if (type.startsWith("AIP")) return <Icon.AI size={11}/>;
  if (type === "EmbeddedModule" || type === "Iframe") return <Icon.Embed size={11}/>;
  if (type === "CustomWidget") return <Icon.Code size={11}/>;
  if (type === "InlineAction" || type === "ActionTable") return <Icon.Action size={11}/>;
  return <Icon.Object size={11}/>;
}
