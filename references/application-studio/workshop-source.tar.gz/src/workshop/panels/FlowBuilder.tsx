"use client";
import React, { useEffect, useMemo, useRef, useState } from "react";
import { useWorkshop } from "../WorkshopContext";
import type { FlowDef, FlowEdgeDef, FlowNodeType, FlowRun } from "../flowTypes";
import { FLOW_NODES, getSpec, makeNode } from "../flowCatalog";
import { executeFlow, getFlowRuntime, validateFlow } from "../flowEngine";
import { FlowCanvas, type FlowTransform } from "./FlowCanvas";
import { Icon } from "../widgets/icons";
import { newId } from "../moduleOps";

interface StoredRun { id: string; flowId: string; status: string; startedAt: string; processed: number; summary?: { error?: string | null; events?: Array<{ nodeId: string; at: number; level: string; message: string; durationMs?: number; rowsIn?: number; rowsOut?: number }> } }

export function FlowBuilder() {
  const w = useWorkshop();
  const { module, activeFlowId, setActiveFlowId, select, selection, updateModule, pushToast, values, setValues, ontology, ontologyMeta, executeAction, openContextMenu } = w;
  const flow = module.flows.find(f => f.id === activeFlowId) ?? module.flows[0];
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All nodes");
  const [paletteOpen, setPaletteOpen] = useState(true);
  const [transform, setTransform] = useState<FlowTransform>({ x: 28, y: 34, k: 1 });
  const [running, setRunning] = useState(false);
  const [continuous, setContinuous] = useState(false);
  const [logOpen, setLogOpen] = useState(true);
  const [logTab, setLogTab] = useState<"events" | "history" | "deadLetters">("events");
  const [events, setEvents] = useState<FlowRun["events"]>([]);
  const [statuses, setStatuses] = useState<FlowRun["nodeStatuses"]>({});
  const [status, setStatus] = useState("idle");
  const [error, setError] = useState("");
  const [audit, setAudit] = useState<"idle" | "saving" | "saved" | "failed">("idle");
  const [history, setHistory] = useState<StoredRun[]>([]);
  const [selectedRun, setSelectedRun] = useState<string | null>(null);
  const [deadLetterVersion, setDeadLetterVersion] = useState(0);
  const [ghost, setGhost] = useState<{ label: string; x: number; y: number } | null>(null);
  const canvasRef = useRef<HTMLDivElement>(null);
  const lock = useRef(false);
  const abortRef = useRef<AbortController | null>(null);
  const lastRun = useRef<FlowRun | null>(null);
  const runRef = useRef<() => Promise<void>>(async () => {});
  const valuesRef = useRef(values); valuesRef.current = values;
  const transformRef = useRef(transform); transformRef.current = transform;
  const paletteMoved = useRef(false);
  const problemList = useMemo(() => flow ? validateFlow(flow, { module, ontologyMeta }) : [], [flow, module, ontologyMeta]);
  const categories = useMemo(() => [...new Set(FLOW_NODES.map(s => s.category))], []);
  const types = FLOW_NODES.filter(s => (category === "All" || category === s.category) && `${s.label} ${s.description} ${s.category}`.toLowerCase().includes(query.toLowerCase()));
  const runtime = flow ? getFlowRuntime(flow.id) : null;
  void deadLetterVersion;
  const deadLetters = runtime?.getDeadLetters() ?? [];

  const editFlow = (flowId: string, change: (f: FlowDef) => FlowDef, label: string) => {
    updateModule(m => ({ ...m, flows: m.flows.map(f => f.id === flowId ? change(f) : f) }), label);
  };
  const addFlow = () => {
    const id = newId("flow-");
    const created: FlowDef = { id, name: `New pipeline ${module.flows.length + 1}`, description: "New operational pipeline", enabled: true, version: 1, nodes: [], edges: [], execution: { mode: "onDemand", maxConcurrency: 4, checkpointEvery: 100, errorPolicy: "deadLetter", scheduleMs: 1000 } };
    updateModule(m => ({ ...m, flows: [...m.flows, created] }), "add flow");
    setActiveFlowId(id); select({ kind: "flow", id });
  };
  const addNode = (type: FlowNodeType, x?: number, y?: number) => {
    if (!flow) return;
    const p = transformRef.current;
    const n = makeNode(type, x ?? Math.max(0, ((canvasRef.current?.clientWidth ?? 900) / 2 - p.x) / p.k - 125), y ?? Math.max(0, ((canvasRef.current?.clientHeight ?? 600) / 2 - p.y) / p.k - 90));
    editFlow(flow.id, f => ({ ...f, nodes: [...f.nodes, n], version: f.version + 1 }), "add flow node");
    select({ kind: "flowNode", id: n.id });
  };
  const connect = (edge: Omit<FlowEdgeDef, "id">) => {
    if (!flow) return;
    const created: FlowEdgeDef = { ...edge, id: newId("fe") };
    editFlow(flow.id, f => ({ ...f, edges: [...f.edges.filter(e => !(e.target === edge.target && e.targetPort === edge.targetPort)), created], version: f.version + 1 }), "connect flow nodes");
    select({ kind: "flowEdge", id: created.id });
  };
  const saveAudit = async (run: FlowRun) => {
    setAudit("saving");
    try {
      const res = await fetch("/api/workshop/flow-runs", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(run) });
      if (!res.ok) throw new Error(`Audit HTTP ${res.status}`);
      setAudit("saved");
      setHistory(prev => [{ id: run.id, flowId: run.flowId, startedAt: new Date(run.startedAt).toISOString(), status: run.status, processed: run.processed, summary: { events: run.events.map(e => ({ nodeId: e.nodeId, at: e.at, level: e.level, message: e.message, durationMs: e.durationMs, rowsIn: e.rowsIn, rowsOut: e.rowsOut })) } }, ...prev].slice(0, 30));
    } catch { setAudit("failed"); }
  };
  useEffect(() => {
    if (!flow?.id) return;
    let cancelled = false;
    fetch(`/api/workshop/flow-runs?flowId=${encodeURIComponent(flow.id)}`).then(r => r.json()).then((data: { runs?: StoredRun[] }) => { if (!cancelled) setHistory(data.runs ?? []); }).catch(() => { if (!cancelled) setHistory([]); });
    return () => { cancelled = true; };
  }, [flow?.id]);

  const runOnce = async () => {
    if (!flow || lock.current || flow.nodes.length === 0) return;
    lock.current = true; abortRef.current = new AbortController();
    setRunning(true); setStatus("running"); setError(""); setEvents([]); setStatuses({}); setAudit("idle"); setSelectedRun(null);
    try {
      const run = await executeFlow(flow, {
        module, ontology, ontologyMeta, executeAction,
        setVariable: (id, value) => setValues(prev => ({ ...prev, [id]: value })),
        getVariable: id => valuesRef.current[id],
        signal: abortRef.current.signal,
        onRun: snapshot => { setEvents(snapshot.events); setStatuses(snapshot.nodeStatuses); setStatus(snapshot.status); },
      });
      lastRun.current = run; setStatus(run.status); setError(run.error ?? ""); setDeadLetterVersion(x => x + 1);
      void saveAudit(run);
    } catch (cause) { setStatus("failed"); setError((cause as Error).message); }
    finally { setRunning(false); lock.current = false; abortRef.current = null; }
  };
  runRef.current = runOnce;
  useEffect(() => {
    if (!continuous || !flow?.enabled) return;
    const interval = setInterval(() => { void runRef.current(); }, Math.max(500, Number(flow.execution.scheduleMs ?? 1000)));
    void runRef.current();
    return () => clearInterval(interval);
  }, [continuous, flow?.id, flow?.enabled, flow?.execution.scheduleMs]);
  useEffect(() => () => { abortRef.current?.abort(); }, []);

  const arrange = async () => {
    if (!flow?.nodes.length || running) return;
    try {
      const { layoutGraph } = await import("../elk");
      const result = await layoutGraph(flow.nodes.map(n => ({ id: n.id, w: 252, h: Math.max(150, 82 + Math.max(getSpec(n.type).inputs.length, getSpec(n.type).outputs.length) * 20) })), flow.edges.filter(e => e.enabled !== false).map(e => ({ id: e.id, from: e.source, to: e.target })), "layered-right");
      editFlow(flow.id, f => ({ ...f, nodes: f.nodes.map(n => ({ ...n, x: Math.round(result.nodes[n.id]?.x ?? n.x), y: Math.round(result.nodes[n.id]?.y ?? n.y) })), version: f.version + 1 }), "auto layout flow");
      setTransform({ x: 35, y: 40, k: 1 });
    } catch (cause) { pushToast({ kind: "error", message: `ELK failed: ${(cause as Error).message}` }); }
  };
  const paletteDown = (e: React.PointerEvent<HTMLButtonElement>, type: FlowNodeType, name: string) => {
    if (e.button !== 0) return;
    const sx = e.clientX, sy = e.clientY;
    paletteMoved.current = false;
    const move = (event: PointerEvent) => {
      if (!paletteMoved.current && Math.hypot(event.clientX - sx, event.clientY - sy) < 5) return;
      paletteMoved.current = true; setGhost({ label: name, x: event.clientX, y: event.clientY });
    };
    const up = (event: PointerEvent) => {
      window.removeEventListener("pointermove", move); window.removeEventListener("pointerup", up);
      setGhost(null);
      if (!paletteMoved.current) return; // native click adds at centre
      const rect = canvasRef.current?.getBoundingClientRect();
      if (rect && event.clientX >= rect.left && event.clientX <= rect.right && event.clientY >= rect.top && event.clientY <= rect.bottom) {
        const t = transformRef.current;
        addNode(type, Math.max(0, (event.clientX - rect.left - t.x) / t.k), Math.max(0, (event.clientY - rect.top - t.y) / t.k));
      }
      setTimeout(() => { paletteMoved.current = false; }, 100);
    };
    window.addEventListener("pointermove", move); window.addEventListener("pointerup", up);
  };

  if (!flow) return <div className="h-full flex items-center justify-center"><button className="fnd-btn fnd-btn-primary" onClick={addFlow}>＋ Create a pipeline</button></div>;
  const eventView = selectedRun ? (history.find(r => r.id === selectedRun)?.summary?.events ?? []) : events;
  return (
    <div className="h-full flex flex-col overflow-hidden" style={{ background: "var(--fnd-bg)" }}>
      <div className="flex items-center gap-2 px-2.5 border-b fnd-border" style={{ height: 40, flexShrink: 0, background: "var(--fnd-panel)" }}>
        <Icon.Flow size={15}/>
        <select aria-label="Select flow" className="fnd-input fnd-select" style={{ width: 190 }} value={flow.id} onChange={e => { setContinuous(false); setActiveFlowId(e.target.value); select({ kind: "flow", id: e.target.value }); setStatus("idle"); setEvents([]); }}>
          {module.flows.map(f => <option key={f.id} value={f.id}>{f.name}</option>)}
        </select>
        <input aria-label="Flow name" className="fnd-input" style={{ width: 215, fontWeight: 600 }} value={flow.name} onChange={e => editFlow(flow.id, f => ({ ...f, name: e.target.value, version: f.version + 1 }), "rename flow")}/>
        <span className="fnd-tag">v{flow.version}</span><span className="fnd-tag">{flow.execution.mode}</span>
        <div className="flex-1"/>
        <span className="text-[11px] fnd-text-muted">{flow.nodes.length} nodes · {flow.edges.length} wires</span>
        <button className="fnd-btn" disabled={!flow.nodes.length || running} onClick={() => void arrange()}>ELK arrange</button>
        <button className={`fnd-btn ${continuous ? "fnd-btn-primary" : ""}`} aria-pressed={continuous} title="Execute continuously with backpressure (skips overlapping runs)" onClick={() => { setContinuous(!continuous); if (continuous) abortRef.current?.abort(); }}>{continuous ? "Ⅱ Stop stream" : "● Stream"}</button>
        <button className="fnd-btn fnd-btn-primary" disabled={!flow.nodes.length || running} onClick={() => void runOnce()}>{running ? "Running…" : "▶ Run once"}</button>
        {running && <button className="fnd-btn fnd-btn-danger" onClick={() => { abortRef.current?.abort(); setContinuous(false); }}>Cancel</button>}
        <button className="fnd-btn" onClick={addFlow} title="Create an empty pipeline"><Icon.Plus size={11}/> Flow</button>
      </div>
      {problemList.length > 0 && <div role="alert" className="px-3 py-1.5 text-[11px] border-b" style={{ background: "#fde9e9", color: "#8a1f1f", borderColor: "#e8a9a9" }}><Icon.Warning size={12}/> {problemList[0]}{problemList.length > 1 ? ` · +${problemList.length - 1} more` : ""}</div>}
      {error && status !== "running" && <div role="alert" className="px-3 py-1.5 text-[11px] border-b" style={{ background: "#fde9e9", color: "#8a1f1f", borderColor: "#e8a9a9" }}>{error}</div>}
      <div className="flex flex-1 min-h-0">
        {paletteOpen && <aside className="flex flex-col border-r fnd-border" style={{ width: 202, flexShrink: 0, background: "var(--fnd-panel)" }}>
          <div className="flex items-center px-2 py-2 border-b fnd-border"><span className="fnd-label flex-1">Processors · {FLOW_NODES.length}</span><button className="fnd-btn fnd-btn-minimal" title="Hide node library" onClick={() => setPaletteOpen(false)}>×</button></div>
          <div className="p-2 space-y-1 border-b fnd-border"><input className="fnd-input" placeholder="Find processors…" value={query} onChange={e => setQuery(e.target.value)}/><select aria-label="Node category" className="fnd-input fnd-select" value={category} onChange={e => setCategory(e.target.value)}><option>All</option>{categories.map(c => <option key={c}>{c}</option>)}</select></div>
          <div className="flex-1 overflow-auto p-1.5">
            {types.map(spec => <button key={spec.type} className="w-full text-left px-2 py-1.5 mb-1 rounded-sm fnd-row-hover" title={`${spec.description} · drag onto canvas or click to add`} onPointerDown={e => paletteDown(e, spec.type, spec.label)} onClick={() => { if (!paletteMoved.current) addNode(spec.type); }} style={{ border: "1px solid var(--fnd-border)", borderLeft: `3px solid ${spec.color}`, cursor: "grab", background: "var(--fnd-panel)", touchAction: "none" }}>
              <div className="text-[11px] font-semibold">{spec.label}</div><div className="text-[9px] fnd-text-dim leading-snug">{spec.description}</div><div className="text-[9px] fnd-text-dim mt-0.5">{spec.inputs.length} in · {spec.outputs.length} out</div>
            </button>)}
          </div>
        </aside>}
        {!paletteOpen && <div style={{ width: 32, flexShrink: 0, background: "var(--fnd-panel)", borderRight: "1px solid var(--fnd-border)" }}><button title="Show node library" className="fnd-btn fnd-btn-minimal" onClick={() => setPaletteOpen(true)}>＋</button></div>}
        <FlowCanvas flow={flow} transform={transform} setTransform={setTransform} canvasRef={canvasRef} selection={selection} statuses={statuses} onSelect={(kind, id) => select({ kind, id })} onAdd={addNode}
          onMove={(id, x, y) => editFlow(flow.id, f => ({ ...f, nodes: f.nodes.map(n => n.id === id ? { ...n, x: Math.round(x), y: Math.round(y) } : n), version: f.version + 1 }), "move flow node")}
          onConnect={connect} onDeleteNode={id => editFlow(flow.id, f => ({ ...f, nodes: f.nodes.filter(n => n.id !== id), edges: f.edges.filter(e => e.source !== id && e.target !== id), version: f.version + 1 }), "delete flow node")}
          onDuplicateNode={id => editFlow(flow.id, f => { const n = f.nodes.find(x => x.id === id); return n ? { ...f, nodes: [...f.nodes, { ...structuredClone(n), id: newId("fn"), name: `${n.name} copy`, x: n.x + 40, y: n.y + 40 }], version: f.version + 1 } : f; }, "duplicate flow node")}
          onToggleNode={id => editFlow(flow.id, f => ({ ...f, nodes: f.nodes.map(n => n.id === id ? { ...n, disabled: !n.disabled } : n), version: f.version + 1 }), "toggle flow node")}
          onDeleteEdge={id => editFlow(flow.id, f => ({ ...f, edges: f.edges.filter(e => e.id !== id), version: f.version + 1 }), "delete flow edge")}
          onToggleEdge={id => editFlow(flow.id, f => ({ ...f, edges: f.edges.map(e => e.id === id ? { ...e, enabled: e.enabled === false } : e), version: f.version + 1 }), "toggle flow edge")}
          onRename={(id, name) => editFlow(flow.id, f => ({ ...f, nodes: f.nodes.map(n => n.id === id ? { ...n, name } : n), version: f.version + 1 }), "rename flow node")}
          onMenu={(x, y, items) => openContextMenu(x, y, items)} onError= {message => pushToast({ kind: "warning", message })}/>
      </div>
      {ghost && <div className="fixed pointer-events-none fnd-panel px-2 py-1.5" style={{ zIndex: 110, left: ghost.x + 12, top: ghost.y + 12, boxShadow: "0 5px 15px rgba(0,0,0,.2)", fontSize: 11 }}>⠿ {ghost.label} · drop on canvas</div>}
      <div className="px-3 py-1 border-t fnd-border flex items-center gap-3 text-[10px] fnd-text-muted" style={{ height: 24, flexShrink: 0, background: "var(--fnd-panel)" }}>
        <span>Run: <b style={{ color: status === "failed" ? "var(--fnd-danger)" : status === "success" ? "var(--fnd-success)" : undefined }}>{status}</b></span>
        <span>{audit === "saved" ? "✓ Audit stored" : audit === "saving" ? "Saving audit…" : audit === "failed" ? "⚠ Audit save failed" : ""}</span>
        {audit === "failed" && <button className="fnd-btn fnd-btn-minimal" style={{ height: 18 }} onClick={() => { if (lastRun.current) void saveAudit(lastRun.current); }}>Retry</button>}
        <span>DLQ: {deadLetters.reduce((n, b) => n + b.records.length, 0)} records</span>
        <div className="flex-1"/>
        <span>Typed ports · bounded queues · executable DAG · simulated source</span>
      </div>
      <div style={{ height: logOpen ? 179 : 27, flexShrink: 0, background: "var(--fnd-panel)", borderTop: "1px solid var(--fnd-border)" }} className="flex flex-col">
        <div className="flex items-center gap-1 px-2 border-b fnd-border" style={{ height: 28, flexShrink: 0 }}>
          {(["events", "history", "deadLetters"] as const).map(tab => <button key={tab} className={`fnd-btn fnd-btn-minimal ${logTab === tab ? "fnd-selected" : ""}`} style={{ height: 24 }} onClick={() => { setLogTab(tab); setLogOpen(true); }}>{tab === "events" ? `Events (${eventView.length})` : tab === "history" ? `Audit history (${history.length})` : `Dead letters (${deadLetters.length})`}</button>)}
          <div className="flex-1"/>
          {logTab === "deadLetters" && deadLetters.length > 0 && <button className="fnd-btn fnd-btn-minimal" style={{ height: 21 }} onClick={() => { runtime?.clearDeadLetters(); setDeadLetterVersion(v => v + 1); }}>Clear DLQ</button>}
          <button className="fnd-btn fnd-btn-minimal" title={logOpen ? "Collapse log" : "Expand log"} style={{ height: 22 }} onClick={() => setLogOpen(!logOpen)}>{logOpen ? "⌄" : "⌃"}</button>
        </div>
        {logOpen && <div className="flex-1 overflow-auto px-2 py-1 font-mono text-[10px]">
          {logTab === "events" && (eventView.length ? eventView.slice().reverse().map((e, i) => <div key={`${e.nodeId}-${e.at}-${i}`} className="flex gap-2 py-0.5 border-b fnd-border">
            <span className="fnd-text-dim tabular-nums" style={{ width: 70 }}>{new Date(e.at).toLocaleTimeString()}</span>
            <span style={{ width: 50, color: e.level === "error" ? "var(--fnd-danger)" : e.level === "warning" ? "var(--fnd-warning)" : "var(--fnd-success)" }}>{e.level.toUpperCase()}</span>
            <span style={{ width: 180 }} className="font-semibold truncate">{flow.nodes.find(n => n.id === e.nodeId)?.name ?? e.nodeId}</span><span className="flex-1">{e.message}</span>
            {e.durationMs !== undefined && <span className="fnd-text-dim tabular-nums">{e.durationMs.toFixed(1)}ms</span>}
          </div>) : <div className="fnd-text-dim p-2">Run the graph to see per-node throughput, WASM timings and validation errors.</div>)}
          {logTab === "history" && (history.length ? history.map(run => <button key={run.id} className="w-full text-left py-1 border-b fnd-border fnd-row-hover flex gap-3" onClick={() => { setSelectedRun(run.id); setLogTab("events"); }}>
            <span className="tabular-nums fnd-text-dim">{new Date(run.startedAt).toLocaleString()}</span><strong style={{ color: run.status === "failed" ? "var(--fnd-danger)" : "var(--fnd-success)" }}>{run.status}</strong><span>{run.processed.toLocaleString()} processed</span><span className="fnd-text-dim ml-auto">{run.id}</span>
          </button>) : <div className="fnd-text-dim p-2">No audited flow runs yet.</div>)}
          {logTab === "deadLetters" && (deadLetters.length ? deadLetters.slice().reverse().map((batch, i) => <div key={`${batch.node}-${i}`} className="py-1 border-b fnd-border"><div><strong>{flow.nodes.find(n => n.id === batch.node)?.name ?? batch.node}</strong> · {new Date(batch.at).toLocaleTimeString()} · {batch.records.length} records</div><div style={{ color: "var(--fnd-danger)" }}>{batch.reason}</div></div>) : <div className="fnd-text-dim p-2">Dead-letter queue is empty. Validation failures and explicitly routed late/overflow events appear here.</div>)}
        </div>}
      </div>
    </div>
  );
}
