"use client";
import React, { useEffect, useRef, useState } from "react";
import type { FlowDef, FlowEdgeDef, FlowNodeDef, FlowNodeType, FlowPortDef, FlowValueType } from "../flowTypes";
import { FLOW_NODES, PORT_COLORS, getSpec, makeNode } from "../flowCatalog";
import { validateFlow } from "../flowEngine";
import { Icon } from "../widgets/icons";
import { FlowNodeCard } from "./FlowNodeCard";

const NODE_W = 252, NODE_H = 178;
export interface FlowTransform { x: number; y: number; k: number }
interface ConnectionDraft { source: string; port: string; x: number; y: number }
interface Props {
  flow: FlowDef;
  transform: FlowTransform;
  setTransform: (t: FlowTransform) => void;
  canvasRef: React.RefObject<HTMLDivElement | null>;
  selection: { kind: string | null; id: string | null };
  onSelect: (kind: "flow" | "flowNode" | "flowEdge", id: string) => void;
  onAdd: (type: FlowNodeType, x?: number, y?: number) => void;
  onMove: (id: string, x: number, y: number) => void;
  onConnect: (edge: Omit<FlowEdgeDef, "id">) => void;
  onDeleteNode: (id: string) => void;
  onDuplicateNode: (id: string) => void;
  onToggleNode: (id: string) => void;
  onDeleteEdge: (id: string) => void;
  onToggleEdge: (id: string) => void;
  onRename: (id: string, name: string) => void;
  onMenu: (x: number, y: number, items: Array<{ label: string; onClick?: () => void; danger?: boolean; separator?: boolean }>) => void;
  onError: (msg: string) => void;
  statuses: Record<string, string>;
}
const accepts = (a: FlowValueType, b: FlowValueType) => a === b || a === "Any" || b === "Any" || a === "Scalar" && b === "Alert";
const portY = (n: FlowNodeDef, p: FlowPortDef) => 88 + (p.direction === "input" ? getSpec(n.type).inputs.findIndex(x => x.id === p.id) : getSpec(n.type).outputs.findIndex(x => x.id === p.id)) * 20;

export function FlowCanvas({ flow, transform, setTransform, canvasRef, selection, onSelect, onAdd, onMove, onConnect, onDeleteNode, onDuplicateNode, onToggleNode, onDeleteEdge, onToggleEdge, onRename, onMenu, onError, statuses }: Props) {
  const [size, setSize] = useState({ w: 1000, h: 650 });
  const [draft, setDraft] = useState<ConnectionDraft | null>(null);
  const draftRef = useRef<ConnectionDraft | null>(null);
  const [pointer, setPointer] = useState({ x: 0, y: 0 });
  const [preview, setPreview] = useState<Record<string, { x: number; y: number }>>({});
  const [hoverInput, setHoverInput] = useState<string | null>(null);
  const raf = useRef(0);
  const transformRef = useRef(transform); transformRef.current = transform;
  const stageW = Math.max(1600, size.w * 2, ...flow.nodes.map(n => n.x + 480));
  const stageH = Math.max(900, size.h * 2, ...flow.nodes.map(n => n.y + 300));

  const world = (cx: number, cy: number) => {
    const r = canvasRef.current?.getBoundingClientRect();
    const t = transformRef.current;
    return { x: (cx - (r?.left ?? 0) - t.x) / t.k, y: (cy - (r?.top ?? 0) - t.y) / t.k };
  };
  const pos = (n: FlowNodeDef) => preview[n.id] ?? n;
  const edgePoints = (edge: FlowEdgeDef) => {
    const a = flow.nodes.find(n => n.id === edge.source), b = flow.nodes.find(n => n.id === edge.target);
    if (!a || !b) return null;
    const op = getSpec(a.type).outputs.find(p => p.id === edge.sourcePort), ip = getSpec(b.type).inputs.find(p => p.id === edge.targetPort);
    if (!op || !ip) return null;
    const pa = pos(a), pb = pos(b);
    return { x1: pa.x + NODE_W, y1: pa.y + portY(a, op), x2: pb.x, y2: pb.y + portY(b, ip), color: PORT_COLORS[op.type] };
  };
  const path = (x1: number, y1: number, x2: number, y2: number) => {
    const bend = Math.max(44, Math.abs(x2 - x1) * .42);
    return `M${x1},${y1} C${x1 + bend},${y1} ${x2 - bend},${y2} ${x2},${y2}`;
  };
  const setDraftBoth = (c: ConnectionDraft | null) => { draftRef.current = c; setDraft(c); };

  useEffect(() => {
    const el = canvasRef.current; if (!el) return;
    const ro = new ResizeObserver(e => setSize({ w: e[0].contentRect.width, h: e[0].contentRect.height }));
    ro.observe(el); setSize({ w: el.clientWidth, h: el.clientHeight });
    return () => ro.disconnect();
  }, [canvasRef]);
  useEffect(() => {
    const key = (e: KeyboardEvent) => { if (e.key === "Escape") { setDraftBoth(null); setHoverInput(null); } };
    window.addEventListener("keydown", key);
    return () => { window.removeEventListener("keydown", key); if (raf.current) cancelAnimationFrame(raf.current); };
  }, []);

  const commitConnection = (targetNode: string, targetPort: string) => {
    const current = draftRef.current; if (!current) return;
    const from = flow.nodes.find(n => n.id === current.source), to = flow.nodes.find(n => n.id === targetNode);
    const output = from && getSpec(from.type).outputs.find(p => p.id === current.port);
    const input = to && getSpec(to.type).inputs.find(p => p.id === targetPort);
    if (!from || !to || !output || !input) { setDraftBoth(null); return; }
    if (from.id === to.id) { onError("Connect distinct nodes; self loops need an explicit Delay node."); setDraftBoth(null); return; }
    if (!accepts(output.type, input.type)) { onError(`${output.type} cannot connect to ${input.type}.`); setDraftBoth(null); return; }
    const candidate: Omit<FlowEdgeDef, "id"> = { source: current.source, sourcePort: current.port, target: targetNode, targetPort, enabled: true };
    const next = { ...flow, edges: [...flow.edges.filter(e => !(e.target === targetNode && e.targetPort === targetPort)), { ...candidate, id: "candidate" }] };
    if (validateFlow(next).some(problem => problem.startsWith("Cycle without"))) { onError("This connection creates a cycle without a Delay node."); setDraftBoth(null); return; }
    onConnect(candidate);
    setDraftBoth(null); setHoverInput(null);
  };
  const onNodeDown = (e: React.PointerEvent, n: FlowNodeDef) => {
    if (e.button !== 0 || (e.target as HTMLElement).closest("[data-flow-port],input,button,select")) return;
    e.stopPropagation(); onSelect("flowNode", n.id);
    const original = { x: n.x, y: n.y }, sx = e.clientX, sy = e.clientY;
    let dx = 0, dy = 0;
    const move = (ev: PointerEvent) => {
      dx = (ev.clientX - sx) / transformRef.current.k; dy = (ev.clientY - sy) / transformRef.current.k;
      if (raf.current) cancelAnimationFrame(raf.current);
      raf.current = requestAnimationFrame(() => setPreview(p => ({ ...p, [n.id]: { x: Math.max(0, original.x + dx), y: Math.max(0, original.y + dy) } })));
    };
    const up = () => {
      window.removeEventListener("pointermove", move); window.removeEventListener("pointerup", up);
      if (raf.current) cancelAnimationFrame(raf.current);
      setPreview(p => { const next = { ...p }; delete next[n.id]; return next; });
      if (Math.abs(dx) + Math.abs(dy) > 2) onMove(n.id, Math.max(0, original.x + dx), Math.max(0, original.y + dy));
    };
    window.addEventListener("pointermove", move); window.addEventListener("pointerup", up);
  };
  const onCanvasDown = (e: React.PointerEvent) => {
    if (e.button !== 0 || (e.target as HTMLElement).closest("[data-flow-node],button,input,select")) return;
    if (draftRef.current) { setDraftBoth(null); return; }
    onSelect("flow", flow.id);
    const t = transformRef.current, sx = e.clientX, sy = e.clientY;
    const move = (ev: PointerEvent) => setTransform({ ...t, x: t.x + ev.clientX - sx, y: t.y + ev.clientY - sy });
    const up = () => { window.removeEventListener("pointermove", move); window.removeEventListener("pointerup", up); };
    window.addEventListener("pointermove", move); window.addEventListener("pointerup", up);
  };
  const onWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const t = transformRef.current;
    if (e.ctrlKey || e.metaKey) {
      const scale = Math.min(2, Math.max(.25, t.k * Math.exp(-e.deltaY * .0016)));
      const r = canvasRef.current?.getBoundingClientRect(), px = e.clientX - (r?.left ?? 0), py = e.clientY - (r?.top ?? 0);
      setTransform({ k: scale, x: px - (px - t.x) / t.k * scale, y: py - (py - t.y) / t.k * scale });
    } else setTransform({ ...t, x: t.x - e.deltaX, y: t.y - e.deltaY });
  };
  const fit = () => {
    const minX = Math.min(0, ...flow.nodes.map(n => n.x)), minY = Math.min(0, ...flow.nodes.map(n => n.y));
    const maxX = Math.max(700, ...flow.nodes.map(n => n.x + NODE_W + 30)), maxY = Math.max(400, ...flow.nodes.map(n => n.y + NODE_H + 30));
    const k = Math.max(.25, Math.min(1.5, (size.w - 60) / (maxX - minX), (size.h - 60) / (maxY - minY)));
    setTransform({ k, x: (size.w - (maxX - minX) * k) / 2 - minX * k, y: (size.h - (maxY - minY) * k) / 2 - minY * k });
  };

  return (
    <div ref={canvasRef} className="flex-1 min-w-0 relative overflow-hidden fnd-canvas-bg" aria-label="Data flow canvas" onPointerDown={onCanvasDown}
      onPointerMove={e => { if (draftRef.current) setPointer(world(e.clientX, e.clientY)); }} onWheel={onWheel}
      onContextMenu={e => {
        if ((e.target as HTMLElement).closest("[data-flow-node]")) return;
        e.preventDefault(); const location = world(e.clientX, e.clientY);
        onMenu(e.clientX, e.clientY, FLOW_NODES.map(s => ({ label: `Add · ${s.label}`, onClick: () => onAdd(s.type, location.x, location.y) })));
      }}>
      <div className="absolute left-2 top-2 z-10 flex gap-1 fnd-panel p-1 rounded-sm">
        <button className="fnd-btn fnd-btn-minimal" aria-label="Zoom out" onClick={() => setTransform({ ...transform, k: Math.max(.25, transform.k / 1.25) })}>−</button>
        <span className="text-[10px] tabular-nums fnd-text-muted self-center" style={{ width: 42, textAlign: "center" }}>{Math.round(transform.k * 100)}%</span>
        <button className="fnd-btn fnd-btn-minimal" aria-label="Zoom in" onClick={() => setTransform({ ...transform, k: Math.min(2, transform.k * 1.25) })}>+</button>
        <button className="fnd-btn fnd-btn-minimal" onClick={fit}>Fit</button>
        {draft && <button className="fnd-btn fnd-btn-minimal" onClick={() => setDraftBoth(null)}>Cancel wire (Esc)</button>}
      </div>
      <div style={{ position: "absolute", left: transform.x, top: transform.y, width: stageW, height: stageH, transform: `scale(${transform.k})`, transformOrigin: "top left" }}>
        <svg width={stageW} height={stageH} style={{ position: "absolute", inset: 0, overflow: "visible", zIndex: 1, pointerEvents: "none" }}>
          <defs><marker id="flow-tip" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0 0L10 5L0 10z" fill="var(--fnd-border-strong)"/></marker></defs>
          {flow.edges.map(edge => {
            const p = edgePoints(edge); if (!p) return null;
            const d = path(p.x1, p.y1, p.x2, p.y2), selected = selection.kind === "flowEdge" && selection.id === edge.id;
            return <g key={edge.id} style={{ pointerEvents: "all", cursor: "pointer" }} onClick={e => { e.stopPropagation(); onSelect("flowEdge", edge.id); }} onContextMenu={e => { e.preventDefault(); e.stopPropagation(); onMenu(e.clientX, e.clientY, [{ label: edge.enabled === false ? "Enable connection" : "Disable connection", onClick: () => onToggleEdge(edge.id) }, { separator: true, label: "" }, { label: "Delete connection", danger: true, onClick: () => onDeleteEdge(edge.id) }]); }}>
              <path d={d} fill="none" stroke={selected ? "var(--fnd-accent)" : p.color} strokeWidth={selected ? 3 : 2} opacity={edge.enabled === false ? .25 : .85} strokeDasharray={edge.enabled === false ? "5 4" : undefined} markerEnd="url(#flow-tip)"/>
              <path d={d} fill="none" stroke="transparent" strokeWidth={16}/>
            </g>;
          })}
          {draft && <path d={path(draft.x, draft.y, pointer.x, pointer.y)} fill="none" stroke="var(--fnd-accent)" strokeWidth={2.5} strokeDasharray="7 4"/>}
        </svg>
        {flow.nodes.map(node => <FlowNodeCard key={node.id} node={{ ...node, ...preview[node.id] }} status={statuses[node.id]} selected={selection.kind === "flowNode" && selection.id === node.id}
          onRename={name => onRename(node.id, name)} onPointerDown={e => onNodeDown(e, node)} onSelect={() => onSelect("flowNode", node.id)}
          onOutput={(p, x, y) => { const location = world(x, y); setDraftBoth({ source: node.id, port: p.id, x: location.x, y: location.y }); setPointer(location); }}
          onInputUp={p => commitConnection(node.id, p.id)}
          onContext={e => { e.preventDefault(); e.stopPropagation(); onSelect("flowNode", node.id); onMenu(e.clientX, e.clientY, [{ label: "Duplicate", onClick: () => onDuplicateNode(node.id) }, { label: node.disabled ? "Enable" : "Disable", onClick: () => onToggleNode(node.id) }, { separator: true, label: "" }, { label: "Delete node", danger: true, onClick: () => onDeleteNode(node.id) }]); }}/>) }
      </div>
      {flow.nodes.length === 0 && <div className="absolute inset-0 grid place-items-center text-xs fnd-text-dim pointer-events-none">Click or drag a node from the library; connect typed ports to build an executable graph.</div>}
      {hoverInput && <div className="absolute bottom-2 right-2 text-[10px] fnd-tag">{hoverInput}</div>}
    </div>
  );
}
