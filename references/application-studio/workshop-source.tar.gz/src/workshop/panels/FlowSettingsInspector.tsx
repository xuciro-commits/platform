"use client";
import React from "react";
import { useWorkshop } from "../WorkshopContext";
import { getSpec, FLOW_NODES } from "../flowCatalog";
import { validateFlow } from "../flowEngine";
import { Icon } from "../widgets/icons";
import type { FlowDef } from "../flowTypes";

function Field({ label, children, hint }: { label: string; children: React.ReactNode; hint?: string }) {
  return <div><label className="fnd-field-label">{label}</label>{children}{hint && <div className="text-[10px] fnd-text-dim mt-0.5">{hint}</div>}</div>;
}
function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return <div className="p-3 space-y-2 border-b fnd-border"><div className="fnd-label">{title}</div>{children}</div>;
}

export function FlowSettingsInspector({ flowId }: { flowId: string }) {
  const { module, ontologyMeta, updateModule, requestConfirm, setActiveFlowId, select } = useWorkshop();
  const f = module.flows.find(item => item.id === flowId);
  if (!f) return <div className="p-3 fnd-text-dim text-xs">Select a pipeline.</div>;
  const update = (patch: Partial<FlowDef>) => updateModule(m => ({ ...m, flows: m.flows.map(flow => flow.id === flowId ? { ...flow, ...patch, version: flow.version + 1 } : flow) }), "edit flow");
  const execution = (patch: Partial<FlowDef["execution"]>) => update({ execution: { ...f.execution, ...patch } });
  const problems = validateFlow(f, { module, ontologyMeta });
  return <div className="h-full overflow-auto">
    <div className="px-3 py-2 border-b fnd-border"><div className="text-xs font-semibold">Operational pipeline</div><div className="fnd-text-dim text-[10px] font-mono">{f.id} · v{f.version}</div></div>
    <Section title="Identity">
      <Field label="Name"><input className="fnd-input" value={f.name} onChange={e => update({ name: e.target.value })}/></Field>
      <Field label="Description"><textarea className="fnd-input" style={{ height: 62, paddingTop: 4 }} value={f.description} onChange={e => update({ description: e.target.value })}/></Field>
      <label className="flex items-center gap-2 text-xs"><input type="checkbox" checked={f.enabled} onChange={e => update({ enabled: e.target.checked })}/> Enabled</label>
    </Section>
    <Section title="Execution contract">
      <Field label="Mode" hint="The Builder runs on demand; Stream runs repeatedly on the configured interval.">
        <select className="fnd-input fnd-select" value={f.execution.mode} onChange={e => execution({ mode: e.target.value as FlowDef["execution"]["mode"] })}><option value="onDemand">On demand</option><option value="stream">Stream</option><option value="scheduled">Scheduled</option></select>
      </Field>
      <Field label="Max concurrent nodes"><input className="fnd-input" type="number" min={1} max={16} value={f.execution.maxConcurrency} onChange={e => execution({ maxConcurrency: Number(e.target.value) })}/></Field>
      <Field label="Run interval (ms)"><input className="fnd-input" type="number" min={500} max={3600000} value={f.execution.scheduleMs ?? 1000} onChange={e => execution({ scheduleMs: Number(e.target.value) })}/></Field>
      <Field label="Checkpoint every N runs"><input className="fnd-input" type="number" min={1} max={10000} value={f.execution.checkpointEvery} onChange={e => execution({ checkpointEvery: Number(e.target.value) })}/></Field>
      <Field label="Error policy">
        <select className="fnd-input fnd-select" value={f.execution.errorPolicy} onChange={e => execution({ errorPolicy: e.target.value as FlowDef["execution"]["errorPolicy"] })}><option value="stop">Stop on error</option><option value="continue">Continue independent branches</option><option value="deadLetter">Continue + dead-letter</option></select>
      </Field>
      <div className="text-[10px] fnd-text-dim">Node retries use exponential backoff. The Delay node breaks feedback across runs; cycles without a Delay are rejected.</div>
    </Section>
    <Section title={`Graph · ${f.nodes.length} nodes / ${f.edges.length} connections`}>
      <div className="grid grid-cols-2 gap-1">{[...new Set(f.nodes.map(n => n.type))].map(type => <div key={type} className="fnd-tag" style={{ height: 22 }}><span>{getSpec(type).label}</span><span className="ml-1 fnd-text-dim">×{f.nodes.filter(n => n.type === type).length}</span></div>)}</div>
      {f.nodes.length === 0 && <div className="fnd-text-dim text-xs">Drag a node from the palette into the canvas.</div>}
      <div className="text-[10px] fnd-text-dim">{FLOW_NODES.length} available processor types. Every connection is typed and validated before execution.</div>
    </Section>
    <Section title={`Validation · ${problems.length} issue(s)`}>
      {problems.length === 0 ? <div className="text-xs" style={{ color: "var(--fnd-success)" }}>✓ Graph is valid and executable.</div> : problems.map((p, i) => <div key={i} className="text-[11px] py-1 flex items-start gap-1" style={{ color: "var(--fnd-danger)" }}><Icon.Warning size={11}/>{p}</div>)}
    </Section>
    <Section title="Governance">
      <div className="text-[11px] fnd-text-muted">Flow definitions are versioned with this Workshop module. Completed runs are audited to PostgreSQL (metadata and event summaries only; never raw 10-million-cell batches).</div>
      <button className="fnd-btn fnd-btn-danger" disabled={module.flows.length <= 1} onClick={() => requestConfirm({ title: "Delete pipeline", message: `Delete “${f.name}” and all its nodes/connections?`, impact: [`${f.nodes.length} nodes and ${f.edges.length} connections will be removed`, "Existing audit records remain available in the database"], onConfirm: () => { updateModule(m => ({ ...m, flows: m.flows.filter(item => item.id !== flowId) }), "delete flow"); const fallback = module.flows.find(item => item.id !== flowId); if (fallback) { setActiveFlowId(fallback.id); select({ kind: "flow", id: fallback.id }); } } })}><Icon.Trash size={12}/> Delete pipeline</button>
    </Section>
  </div>;
}

export function FlowEdgeInspector({ edgeId }: { edgeId: string }) {
  const { module, activeFlowId, updateModule, select } = useWorkshop();
  const flow = module.flows.find(f => f.id === activeFlowId), edge = flow?.edges.find(e => e.id === edgeId);
  if (!flow || !edge) return <div className="p-3 fnd-text-dim text-xs">Select a connection.</div>;
  const source = flow.nodes.find(n => n.id === edge.source), target = flow.nodes.find(n => n.id === edge.target);
  const update = (patch: Partial<typeof edge>) => updateModule(m => ({ ...m, flows: m.flows.map(f => f.id === flow.id ? { ...f, edges: f.edges.map(e => e.id === edge.id ? { ...e, ...patch } : e), version: f.version + 1 } : f) }), "edit flow connection");
  return <div className="h-full overflow-auto">
    <div className="px-3 py-2 border-b fnd-border"><div className="text-xs font-semibold">Typed connection</div><div className="text-[10px] fnd-text-dim font-mono">{edge.id}</div></div>
    <Section title="Route"><div className="fnd-panel-2 p-2 rounded-sm text-xs">{source?.name ?? edge.source}<span className="font-mono fnd-text-dim">.{edge.sourcePort}</span><span style={{ color: "var(--fnd-accent)" }}> → </span>{target?.name ?? edge.target}<span className="font-mono fnd-text-dim">.{edge.targetPort}</span></div>
      <Field label="Label"><input className="fnd-input" value={edge.label ?? ""} placeholder="Optional connection label" onChange={e => update({ label: e.target.value })}/></Field>
      <label className="flex items-center gap-2 text-xs"><input type="checkbox" checked={edge.enabled !== false} onChange={e => update({ enabled: e.target.checked })}/> Enabled</label>
      <div className="text-[10px] fnd-text-dim">A disabled connection is omitted from graph validation and execution.</div>
    </Section>
    <Section title="Actions"><button className="fnd-btn fnd-btn-danger" onClick={() => { updateModule(m => ({ ...m, flows: m.flows.map(f => f.id === flow.id ? { ...f, edges: f.edges.filter(e => e.id !== edge.id), version: f.version + 1 } : f) }), "delete flow connection"); select({ kind: "flow", id: flow.id }); }}><Icon.Trash size={11}/> Delete connection</button></Section>
  </div>;
}
