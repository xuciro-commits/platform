"use client";
import React, { useMemo, useState } from "react";
import { useWorkshop } from "../WorkshopContext";
import { ENTRIES } from "./WidgetSelector";
import { WidgetIcon } from "./LayoutTree";
import { Icon } from "../widgets/icons";
import { beginDrag } from "../dnd";

/** Left-sidebar palette: drag any widget onto a canvas drop zone, or click to add to the selected section. */
export function WidgetsPalette() {
  const { addWidgetOfType, selection, module } = useWorkshop();
  const [q, setQ] = useState("");
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});
  const grouped = useMemo(() => {
    const g: Record<string, typeof ENTRIES> = {};
    for (const e of ENTRIES) {
      if (q && !(e.name + " " + e.description + " " + e.category).toLowerCase().includes(q.toLowerCase())) continue;
      (g[e.category] ??= []).push(e);
    }
    return g;
  }, [q]);
  const total = Object.values(grouped).reduce((s, a) => s + a.length, 0);
  const target = selection.kind === "section" ? module.sections[selection.id ?? ""]?.name : null;

  return (
    <div className="h-full flex flex-col text-xs">
      <div className="px-2.5 py-2 border-b fnd-border flex items-center gap-2">
        <div className="fnd-label">Widgets</div>
        <span className="fnd-tag">{ENTRIES.length}</span>
      </div>
      <div className="p-2 border-b fnd-border space-y-1">
        <input className="fnd-input" placeholder="Search widgets…" value={q} onChange={e => setQ(e.target.value)}/>
        <div className="text-[10px] fnd-text-dim">
          Drag onto the canvas, or click to add to {target ? <strong>{target}</strong> : "the current page"}.
        </div>
      </div>
      <div className="flex-1 overflow-auto p-1.5">
        {total === 0 && <div className="p-4 text-center fnd-text-dim">No widgets match “{q}”.</div>}
        {Object.entries(grouped).map(([cat, items]) => (
          <div key={cat} className="mb-2">
            <button className="w-full flex items-center gap-1 px-1 py-1 fnd-label" onClick={() => setCollapsed(c => ({ ...c, [cat]: !c[cat] }))}>
              <Icon.Chevron size={9} dir={collapsed[cat] ? "right" : "down"}/>{cat}
              <span className="ml-auto fnd-tag" style={{ height: 16 }}>{items.length}</span>
            </button>
            {!collapsed[cat] && (
              <div className="grid grid-cols-2 gap-1">
                {items.map(e => (
                  <div key={e.type}
                    role="button"
                    tabIndex={0}
                    title={`${e.description} — drag onto the canvas`}
                    onPointerDown={ev => beginDrag({ kind: "new", widgetType: e.type, name: e.name }, ev.nativeEvent)}
                    onClick={() => addWidgetOfType(e.type, e.name)}
                    onKeyDown={ev => { if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); addWidgetOfType(e.type, e.name); } }}
                    className="fnd-row-hover rounded-sm px-1.5 py-1.5 flex items-center gap-1.5"
                    style={{ border: "1px solid var(--fnd-border)", background: "var(--fnd-panel)", cursor: "grab", minHeight: 30, touchAction: "none", userSelect: "none" }}>
                    <span style={{ color: "var(--fnd-accent)" }}><WidgetIcon type={e.type}/></span>
                    <span className="truncate" style={{ fontSize: 11, fontWeight: 500 }}>{e.name}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
