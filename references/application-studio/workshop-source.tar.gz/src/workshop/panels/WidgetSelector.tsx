"use client";
import React, { useMemo, useState } from "react";
import { useWorkshop } from "../WorkshopContext";
import { Icon } from "../widgets/icons";
import { WidgetIcon } from "./LayoutTree";
import type { WidgetType } from "../types";

export interface Entry { type: WidgetType; name: string; description: string; category: string; }

export const ENTRIES: Entry[] = [
  // Industrial operations
  { type: "TelemetryTable", name: "Telemetry Table · 100k × 100", description: "Worker-owned column store, two-axis virtualized industrial stream, cross-widget Asset selection", category: "Industrial operations" },
  { type: "TelemetryStats", name: "WASM Telemetry Statistics", description: "Window aggregates in WebAssembly, selected device signal and live trend", category: "Industrial operations" },
  { type: "Scene3D", name: "Digital Twin · GLB/GLTF", description: "WebGL2 3D scene with articulated joints, multilayer editor and signal-to-part mappings", category: "Industrial operations" },
  // Ontology-driven
  { type: "KanbanBoard", name: "Kanban Board", description: "Objects grouped by an enum property; drag cards to run an Action", category: "Ontology & workflow" },
  { type: "ApprovalInbox", name: "Approval Inbox", description: "Queue of objects with approve / reject Actions", category: "Ontology & workflow" },
  { type: "GraphExplorer", name: "Search Around Explorer", description: "Traverse link types from the active object", category: "Ontology & workflow" },
  { type: "ObjectCard", name: "Object Card", description: "Compact card for a single object using its title & prominent properties", category: "Ontology & workflow" },
  { type: "ObjectComparison", name: "Object Comparison", description: "Side-by-side comparison of selected objects", category: "Ontology & workflow" },
  { type: "ObjectSetBuilder", name: "Object Set Builder", description: "Runtime filter builder over object type properties", category: "Ontology & workflow" },
  { type: "NotificationFeed", name: "Action Feed", description: "Live feed of executed Actions and object edits", category: "Ontology & workflow" },
  // Analytics
  { type: "Histogram", name: "Histogram", description: "Distribution of a numeric property", category: "Analytics" },
  { type: "ScatterPlot", name: "Scatter Plot", description: "Two numeric properties; click a point to select the object", category: "Analytics" },
  { type: "Heatmap", name: "Heatmap", description: "Count matrix of two properties; click a cell to filter", category: "Analytics" },
  { type: "Treemap", name: "Treemap", description: "Hierarchical share by property; click to filter", category: "Analytics" },
  { type: "Gauge", name: "Gauge", description: "Radial gauge for a numeric variable", category: "Analytics" },
  { type: "SparklineKpi", name: "Sparkline KPI", description: "KPI value with trend sparkline", category: "Analytics" },
  { type: "ProgressBar", name: "Progress Bar", description: "Ratio of two numeric variables", category: "Analytics" },
  { type: "SummaryStats", name: "Summary Statistics", description: "Count / min / max / mean / sum of a property", category: "Analytics" },
  { type: "Leaderboard", name: "Leaderboard", description: "Top N objects ranked by a property", category: "Analytics" },
  { type: "Calendar", name: "Calendar", description: "Objects on a month grid by date property", category: "Analytics" },
  { type: "TagList", name: "Tag List", description: "Distinct values of a property as tags", category: "Analytics" },
  // Inputs
  { type: "RangeSlider", name: "Range Slider", description: "Numeric min/max bound to two variables", category: "Filtering" },
  { type: "ToggleSwitch", name: "Toggle Switch", description: "Boolean variable switch", category: "Filtering" },
  { type: "RadioGroup", name: "Radio Group", description: "Single choice bound to a string variable", category: "Filtering" },
  { type: "SegmentedControl", name: "Segmented Control", description: "Compact single-choice selector", category: "Filtering" },
  // Layout & content
  { type: "Breadcrumbs", name: "Breadcrumbs", description: "Page / object navigation trail", category: "Layout & content" },
  { type: "AlertBanner", name: "Alert Banner", description: "Conditional banner driven by a variable", category: "Layout & content" },
  { type: "Callout", name: "Callout", description: "Intent-colored informational block", category: "Layout & content" },
  { type: "Divider", name: "Divider", description: "Horizontal separator with optional label", category: "Layout & content" },
  { type: "Spacer", name: "Spacer", description: "Fixed vertical whitespace", category: "Layout & content" },
  { type: "ImageWidget", name: "Image", description: "Static or variable-driven image", category: "Layout & content" },
  { type: "SingleButton", name: "Button", description: "Single button running an event chain", category: "Layout & content" },
  { type: "AvatarStack", name: "Avatar Stack", description: "Operators linked to the current context", category: "Layout & content" },
  // Core display
  { type: "ObjectTable", name: "Object Table", description: "Tabular view of an object set with sorting, selection and inline edit", category: "Core display" },
  { type: "ObjectList", name: "Object List", description: "List or grid of objects with image, properties and selection", category: "Core display" },
  { type: "ObjectView", name: "Object View", description: "Full detail view of a single object with tabs", category: "Core display" },
  { type: "PropertyList", name: "Property List", description: "Compact 1-4 column property grid for a single object", category: "Core display" },
  { type: "Links", name: "Links", description: "Related objects grouped by link type", category: "Core display" },
  { type: "ObjectSetTitle", name: "Object Set Title", description: "Title + count for an object set", category: "Core display" },
  { type: "HeaderText", name: "Header Text", description: "Rich heading with sizing options", category: "Core display" },
  // Visualization
  { type: "ChartXY", name: "Chart: XY", description: "Line, bar, scatter or area chart over object properties", category: "Visualization" },
  { type: "ChartPie", name: "Chart: Pie", description: "Pie or donut distribution chart", category: "Visualization" },
  { type: "ChartVega", name: "Chart: Vega", description: "Fully custom Vega-Lite chart", category: "Visualization" },
  { type: "ChartWaterfall", name: "Chart: Waterfall", description: "Sequential delta chart", category: "Visualization" },
  { type: "Map", name: "Map", description: "Geospatial view with markers, clusters and selection", category: "Visualization" },
  { type: "FreeFormAnalysis", name: "Free-form Analysis", description: "Interactive analysis canvas", category: "Visualization" },
  { type: "TimeSeriesAnalysis", name: "Time Series Analysis", description: "Explore and compare time series", category: "Visualization" },
  { type: "Gantt", name: "Gantt Chart", description: "Schedule view with task bars across time", category: "Visualization" },
  { type: "ImageAnnotation", name: "Image Annotation", description: "Annotate images with bounding boxes and labels", category: "Visualization" },
  { type: "LinkedCompass", name: "Linked Compass Resources", description: "Embed Compass resources inline", category: "Visualization" },
  { type: "Markdown", name: "Markdown", description: "Rich text content with headings, lists and object refs", category: "Visualization" },
  { type: "MediaPreview", name: "Media Preview", description: "Preview images, videos, and attachments", category: "Visualization" },
  { type: "MetricCard", name: "Metric Card", description: "Bold KPI display with trend and color variants", category: "Visualization" },
  { type: "PdfViewer", name: "PDF Viewer", description: "Page-by-page PDF rendering", category: "Visualization" },
  { type: "PivotTable", name: "Pivot Table", description: "Cross-tabulate rows × columns with measures", category: "Visualization" },
  { type: "ResourceList", name: "Resource List", description: "List Foundry resources with status", category: "Visualization" },
  { type: "StatusTracker", name: "Status Tracker", description: "Visual tracker across lifecycle stages", category: "Visualization" },
  { type: "Stepper", name: "Stepper", description: "Workflow steps with current progress", category: "Visualization" },
  { type: "Timeline", name: "Timeline", description: "Chronological event timeline", category: "Visualization" },
  { type: "ActionLogTimeline", name: "Action Log Timeline", description: "Audit log of actions over time", category: "Visualization" },
  { type: "ObservabilityChart", name: "Observability Chart", description: "SLO / telemetry chart", category: "Visualization" },
  // Filtering
  { type: "FilterList", name: "Filter List", description: "Multi-facet filter panel with distributions and search", category: "Filtering" },
  { type: "ObjectDropdown", name: "Object Dropdown", description: "Dropdown that picks an object from a set", category: "Filtering" },
  { type: "ObjectSelector", name: "Object Selector", description: "Selector with keyboard search over an object set", category: "Filtering" },
  { type: "StringSelector", name: "String Selector", description: "Dropdown binding to a string variable", category: "Filtering" },
  { type: "Checkbox", name: "Checkbox", description: "Boolean checkbox control", category: "Filtering" },
  { type: "DateInput", name: "Date Input", description: "Date picker with calendar", category: "Filtering" },
  { type: "DateTimePicker", name: "Date & Time Picker", description: "Date + time picker", category: "Filtering" },
  { type: "TextInput", name: "Text Input", description: "Text input binding to a string variable", category: "Filtering" },
  { type: "NumericInput", name: "Numeric Input", description: "Number input with validation", category: "Filtering" },
  { type: "ExplorationFilter", name: "Exploration Filter Pills", description: "Interactive filter chip row", category: "Filtering" },
  { type: "ExplorationSearch", name: "Exploration Search Bar", description: "Prominent search for object sets", category: "Filtering" },
  { type: "ProminentTerms", name: "Prominent Terms", description: "Top terms over an object set", category: "Filtering" },
  { type: "UserSelect", name: "User Select", description: "Pick a Foundry user", category: "Filtering" },
  { type: "MultiSelector", name: "Multi Selector", description: "Multi-value selector", category: "Filtering" },
  // Action
  { type: "ButtonGroup", name: "Button Group", description: "Row of buttons bound to actions or events", category: "Action" },
  { type: "Comments", name: "Comments", description: "Threaded comments with authors and timestamps", category: "Action" },
  { type: "MediaUploader", name: "Media Uploader", description: "Drag + drop file uploader", category: "Action" },
  { type: "Tabs", name: "Tabs", description: "Tabs widget with variable-backed selection", category: "Action" },
  { type: "InlineAction", name: "Inline Action", description: "Inline action form or table for object mutations", category: "Action" },
  { type: "ActionTable", name: "Action Table", description: "Bulk staged edits across an object set with submit", category: "Action" },
  // AIP
  { type: "AIPAnalyst", name: "AIP Analyst", description: "Analysis thread with object context and outputs", category: "AIP" },
  { type: "AIPChatbot", name: "AIP Chatbot", description: "Conversational assistant with tool invocation", category: "AIP" },
  { type: "AIPGenerated", name: "AIP Generated Content", description: "Generated insights panel", category: "AIP" },
  // Embed
  { type: "Iframe", name: "Iframe", description: "Embed external URL as iframe", category: "Embed" },
  { type: "DerivedSeries", name: "Derived Series", description: "Embed a derived series", category: "Embed" },
  { type: "MapTemplate", name: "Map Application Template", description: "Launch Map application in context", category: "Embed" },
  { type: "NotepadEmbed", name: "Notepad Embedded Document", description: "Embed a Notepad document", category: "Embed" },
  { type: "QuiverDashboard", name: "Quiver Dashboard", description: "Embed a Quiver dashboard", category: "Embed" },
  { type: "VertexGraph", name: "Vertex Graph", description: "Embed a Vertex knowledge graph", category: "Embed" },
  { type: "EmbeddedModule", name: "Workshop Embedded Module", description: "Nest another Workshop module with variable bindings", category: "Embed" },
  { type: "CustomWidget", name: "Custom Widget", description: "Load a vendor custom widget set", category: "Custom" },
];

export function WidgetSelector({ onPick, onClose }: { onPick: (type: WidgetType, name: string) => void; onClose: () => void }) {
  const [q, setQ] = useState("");
  const [focusIdx, setFocusIdx] = useState(0);
  const filtered = useMemo(() => ENTRIES.filter(e => !q || e.name.toLowerCase().includes(q.toLowerCase()) || e.description.toLowerCase().includes(q.toLowerCase())), [q]);
  const grouped = useMemo(() => {
    const g: Record<string, Entry[]> = {};
    for (const e of filtered) (g[e.category] ??= []).push(e);
    return g;
  }, [filtered]);
  const categories = Object.keys(grouped);

  return (
    <div className="fnd-overlay-backdrop" onClick={onClose}>
      <div onClick={e => e.stopPropagation()} className="fnd-panel fnd-fade-in" style={{
        position: "fixed", top: "8%", left: "50%", transform: "translateX(-50%)",
        width: "min(880px, 90vw)", maxHeight: "80vh", zIndex: 60,
        display: "flex", flexDirection: "column", borderRadius: 4,
        boxShadow: "0 10px 40px rgba(0,0,0,0.2)",
      }}>
        <div className="flex items-center gap-2 px-3 py-2 border-b fnd-border">
          <div className="font-semibold text-sm">Add widget</div>
          <div className="flex-1"/>
          <button className="fnd-btn fnd-btn-minimal" onClick={onClose}><Icon.Close size={14}/></button>
        </div>
        <div className="px-3 py-2 border-b fnd-border">
          <input autoFocus className="fnd-input" style={{ height: 32 }} placeholder="Search widgets..." value={q} onChange={e => { setQ(e.target.value); setFocusIdx(0); }}
            onKeyDown={e => {
              if (e.key === "ArrowDown") { setFocusIdx(i => Math.min(filtered.length - 1, i + 1)); e.preventDefault(); }
              else if (e.key === "ArrowUp") { setFocusIdx(i => Math.max(0, i - 1)); e.preventDefault(); }
              else if (e.key === "Enter" && filtered[focusIdx]) { onPick(filtered[focusIdx].type, filtered[focusIdx].name); }
            }}
          />
          <div className="text-[11px] fnd-text-dim mt-1">{filtered.length} widgets · <span className="fnd-kbd">↑↓</span> navigate <span className="fnd-kbd">↵</span> add</div>
        </div>
        <div className="flex-1 overflow-auto p-3">
          {filtered.length === 0 && <div className="p-8 text-center fnd-text-dim">No widgets match &quot;{q}&quot;.</div>}
          {categories.map(cat => (
            <div key={cat} className="mb-4">
              <div className="fnd-label mb-2">{cat}</div>
              <div className="grid gap-2" style={{ gridTemplateColumns: "repeat(auto-fill, minmax(170px, 1fr))" }}>
                {grouped[cat].map((e) => {
                  const absIdx = filtered.indexOf(e);
                  return (
                    <button key={e.type + e.name} onClick={() => onPick(e.type, e.name)}
                      className={`fnd-panel rounded-sm p-2 text-left hover:border-blue-500 ${absIdx === focusIdx ? "fnd-selected-ring" : ""}`}
                      style={{ borderColor: absIdx === focusIdx ? "var(--fnd-accent)" : undefined, cursor: "pointer" }}>
                      <div className="flex items-center gap-1.5"><WidgetIcon type={e.type}/><div className="text-xs font-semibold">{e.name}</div></div>
                      <div className="text-[10px] fnd-text-dim mt-1 leading-snug line-clamp-2" style={{ display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>{e.description}</div>
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
