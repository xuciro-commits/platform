"use client";
import React, { useEffect, useMemo, useRef, useState } from "react";
import { TEXT_SCALES, useWorkshop, type TextScale } from "../WorkshopContext";
import { Icon } from "../widgets/icons";
import { metrics } from "../runtimeStores";
import { collectSectionSubtree, uniquifyTree } from "../moduleOps";
import type { ModuleDef } from "../types";

// ═══ Overview ═══════════════════════════════════════════════════════════════
interface Issue { widgetId: string; message: string }
function findIssues(m: ModuleDef, actionApis: Set<string>): Issue[] {
  const ids = new Set(m.variables.map(v => v.id));
  const out: Issue[] = [];
  const REF_KEY = /(VarId|VarIds|variableId)$/;
  for (const w of Object.values(m.widgets)) {
    if (m.unusedWidgetIds.includes(w.id)) continue;
    const walk = (x: unknown, key: string) => {
      if (typeof x === "string") {
        if (REF_KEY.test(key) && x && !ids.has(x)) out.push({ widgetId: w.id, message: `${w.name}: cannot resolve variable “${x}” (${key})` });
        if (/^(actionId|approveActionId|rejectActionId)$/.test(key) && x && !actionApis.has(x)) out.push({ widgetId: w.id, message: `${w.name}: action type “${x}” not found in the Ontology` });
      } else if (Array.isArray(x)) x.forEach(i => walk(i, key));
      else if (x && typeof x === "object") for (const [k, v] of Object.entries(x as Record<string, unknown>)) walk(v, k);
    };
    walk(w.config, "");
  }
  for (const o of m.overlays) if (o.openVariableId && !ids.has(o.openVariableId)) out.push({ widgetId: "", message: `Overlay ${o.name}: open-state variable “${o.openVariableId}” is missing` });
  return out;
}

export function OverviewPanel() {
  const { module, ontologyMeta, select, setLeftPanel } = useWorkshop();
  const issues = useMemo(() => findIssues(module, new Set(ontologyMeta.actionTypes.map(a => a.apiName))), [module, ontologyMeta]);
  const usedTypes = ontologyMeta.objectTypes.filter(o => module.variables.some(v => v.objectSet?.objectType === o.apiName));
  const pivots = [...new Set(module.variables.flatMap(v => (v.objectSet?.steps ?? []).filter(s => s.op === "pivotTo").map(s => (s as { linkTypeApiName: string }).linkTypeApiName)))];
  const usedActions = [...new Set(Object.values(module.widgets).flatMap(w => JSON.stringify(w.config).match(/"(?:actionId|approveActionId|rejectActionId)":"([^"]+)"/g)?.map(x => x.split('":"')[1].replace(/"$/, "")) ?? []))];
  const usedFns = [...new Set(module.variables.map(v => v.functionApiName).filter(Boolean) as string[])];
  return (
    <div className="h-full overflow-auto p-4 text-xs">
      <div className="fnd-label mb-1">Module</div>
      <div className="text-base font-semibold break-words">{module.name}</div>
      <div className="fnd-text-muted mt-1 mb-4">{module.description}</div>

      <OvSec title="Ontology resources used">
        {usedTypes.map(o => (
          <button key={o.apiName} className="w-full flex items-center gap-2 py-0.5 fnd-row-hover text-left" onClick={() => setLeftPanel("ontology")}>
            <span style={{ width: 14, height: 14, borderRadius: 2, background: o.color, color: "white", fontSize: 8, fontWeight: 800, display: "inline-flex", alignItems: "center", justifyContent: "center" }}>{o.icon}</span>
            <span className="flex-1 truncate">{o.displayName}</span>
            <span className="fnd-text-dim">{module.variables.filter(v => v.objectSet?.objectType === o.apiName).length} object set var(s)</span>
          </button>
        ))}
        <OvRow label="Action types" value={usedActions.join(", ") || "—"}/>
        <OvRow label="Functions" value={usedFns.join(", ") || "—"}/>
        <OvRow label="Link types (pivotTo)" value={pivots.join(", ") || "—"}/>
      </OvSec>

      <OvSec title="Composition">
        <OvRow label="Pages" value={String(module.pages.length)}/>
        <OvRow label="Sections" value={String(Object.keys(module.sections).length)}/>
        <OvRow label="Widgets" value={`${Object.keys(module.widgets).length - module.unusedWidgetIds.length} used · ${module.unusedWidgetIds.length} unused`}/>
        <OvRow label="Overlays" value={String(module.overlays.length)}/>
        <OvRow label="Variables" value={String(module.variables.length)}/>
      </OvSec>

      <OvSec title="Module interface">
        {module.moduleInterface.length === 0 && <div className="fnd-text-dim">No variables exposed. Add some in Settings → Module Interface.</div>}
        {module.moduleInterface.map(mi => (
          <div key={mi.variableId} className="flex items-center gap-2 py-1 border-b fnd-border">
            <Icon.Variable size={11}/><span className="font-semibold flex-1 truncate">{mi.externalId}</span><span className="fnd-tag">{mi.direction}</span>
          </div>
        ))}
      </OvSec>

      <OvSec title={`Warnings & unresolved references (${issues.length})`}>
        {issues.length === 0 && <div style={{ color: "var(--fnd-success)" }}>✓ All references resolve.</div>}
        {issues.map((i, n) => (
          <button key={n} className="w-full text-left py-1 flex gap-1.5 fnd-row-hover" style={{ color: "var(--fnd-danger)" }} onClick={() => i.widgetId && select({ kind: "widget", id: i.widgetId })}>
            <Icon.Warning size={11}/><span className="flex-1">{i.message}</span>
          </button>
        ))}
      </OvSec>
    </div>
  );
}
function OvSec({ title, children }: { title: string; children: React.ReactNode }) {
  return <div className="mb-5"><div className="fnd-label mb-2">{title}</div><div className="fnd-panel rounded-sm p-3 space-y-1">{children}</div></div>;
}
function OvRow({ label, value }: { label: string; value: string }) {
  return <div className="flex items-start gap-2 py-0.5"><span className="fnd-text-muted" style={{ width: 130, flexShrink: 0 }}>{label}</span><span className="flex-1 break-words min-w-0">{value}</span></div>;
}

// ═══ Settings ═══════════════════════════════════════════════════════════════
export function SettingsPanel() {
  const { module, updateModule, theme, toggleTheme, values, setValues, textScale, setTextScale, pages: _p, pushToast, requestConfirm, setMode } = useSettingsCtx();
  void _p;
  const [tab, setTab] = useState<"general" | "pages" | "interface" | "theme" | "autorefresh" | "state" | "prefs">("general");
  const fileRef = useRef<HTMLInputElement>(null);
  const autoRefresh = values.autoRefresh === true;

  const exportJson = () => {
    const url = URL.createObjectURL(new Blob([JSON.stringify(module, null, 2)], { type: "application/json" }));
    const a = document.createElement("a"); a.href = url; a.download = `${module.name.replace(/\W+/g, "_")}.workshop.json`; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };
  const importJson = async (file: File) => {
    try {
      const m = JSON.parse(await file.text()) as ModuleDef;
      if (!Array.isArray(m.pages) || !m.sections || !m.widgets || !Array.isArray(m.variables)) throw new Error("Not a Workshop module file");
      updateModule(() => uniquifyTree(m), "import module");
      pushToast({ kind: "success", message: `Imported “${m.name}”` });
    } catch (e) { pushToast({ kind: "error", message: `Import failed: ${(e as Error).message}` }); }
  };
  const movePage = (i: number, d: -1 | 1) => updateModule(m => { const p = [...m.pages]; const j = i + d; if (j < 0 || j >= p.length) return m; [p[i], p[j]] = [p[j], p[i]]; return { ...m, pages: p }; }, "move page");

  return (
    <div className="h-full overflow-auto">
      <div className="flex border-b fnd-border overflow-x-auto">
        {([["general", "General"], ["pages", "Pages"], ["interface", "Interface"], ["theme", "Theme"], ["autorefresh", "Refresh"], ["state", "State"], ["prefs", "Prefs"]] as const).map(([k, l]) => (
          <button key={k} onClick={() => setTab(k)} className="px-3 py-1.5 text-xs font-medium whitespace-nowrap" style={{ borderBottom: tab === k ? "2px solid var(--fnd-accent)" : "2px solid transparent", color: tab === k ? "var(--fnd-text)" : "var(--fnd-text-muted)" }}>{l}</button>
        ))}
      </div>
      <div className="p-4 text-xs space-y-3">
        {tab === "general" && (
          <>
            <div><label className="fnd-field-label">Module name</label><input className="fnd-input" value={module.name} onChange={e => updateModule(m => ({ ...m, name: e.target.value }), "edit module")}/></div>
            <div><label className="fnd-field-label">Description</label><textarea className="fnd-input" style={{ height: 70, paddingTop: 4 }} value={module.description} onChange={e => updateModule(m => ({ ...m, description: e.target.value }), "edit module")}/></div>
            <div><label className="fnd-field-label">Header title</label><input className="fnd-input" value={module.header.title} onChange={e => updateModule(m => ({ ...m, header: { ...m.header, title: e.target.value } }), "edit header")}/></div>
            <div><label className="fnd-field-label">Header orientation</label>
              <select className="fnd-input fnd-select" value={module.header.variant} onChange={e => updateModule(m => ({ ...m, header: { ...m.header, variant: e.target.value as "horizontal" | "vertical" } }), "edit header")}><option value="horizontal">Horizontal</option><option value="vertical">Vertical (collapsible)</option></select></div>
          </>
        )}
        {tab === "pages" && (
          <div className="space-y-1">
            {module.pages.map((p, i) => (
              <div key={p.id} className="flex items-center gap-1 p-1.5 fnd-panel rounded-sm">
                <Icon.Section size={12}/>
                <input className="fnd-input" value={p.name} onChange={e => updateModule(m => ({ ...m, pages: m.pages.map(pp => (pp.id === p.id ? { ...pp, name: e.target.value } : pp)) }), "rename page")}/>
                <button className="fnd-btn fnd-btn-minimal" title="Move up" aria-label="Move page up" disabled={i === 0} onClick={() => movePage(i, -1)}>▲</button>
                <button className="fnd-btn fnd-btn-minimal" title="Move down" aria-label="Move page down" disabled={i === module.pages.length - 1} onClick={() => movePage(i, 1)}>▼</button>
                <span className="fnd-tag" title="Page ID">{p.id}</span>
              </div>
            ))}
          </div>
        )}
        {tab === "interface" && (
          <div className="space-y-2">
            <div className="fnd-text-muted">Variables exposed here can be set by a parent module (Embedded Module) or initialised from the URL.</div>
            {module.moduleInterface.map((mi, i) => (
              <div key={i} className="fnd-panel rounded-sm p-2 space-y-1.5">
                <div className="flex gap-1">
                  <select className="fnd-input fnd-select" value={mi.variableId} onChange={e => updateModule(m => ({ ...m, moduleInterface: m.moduleInterface.map((x, j) => (j === i ? { ...x, variableId: e.target.value } : x)) }), "edit interface")}>
                    {module.variables.map(v => <option key={v.id} value={v.id}>@{v.name}</option>)}
                  </select>
                  <select className="fnd-input fnd-select" style={{ width: 110 }} value={mi.direction} onChange={e => updateModule(m => ({ ...m, moduleInterface: m.moduleInterface.map((x, j) => (j === i ? { ...x, direction: e.target.value as typeof mi.direction } : x)) }), "edit interface")}>
                    <option value="input">input</option><option value="output">output</option><option value="inputOutput">input/output</option>
                  </select>
                  <button className="fnd-btn fnd-btn-minimal" aria-label="Remove" title="Remove" onClick={() => updateModule(m => ({ ...m, moduleInterface: m.moduleInterface.filter((_, j) => j !== i) }), "delete interface entry")}><Icon.Trash size={11}/></button>
                </div>
                <input className="fnd-input" placeholder="External ID" value={mi.externalId} onChange={e => updateModule(m => ({ ...m, moduleInterface: m.moduleInterface.map((x, j) => (j === i ? { ...x, externalId: e.target.value } : x)) }), "edit interface")}/>
                <div className="text-[10px] fnd-text-dim font-mono">?{mi.externalId}=… initialises @{module.variables.find(v => v.id === mi.variableId)?.name}</div>
              </div>
            ))}
            <button className="fnd-btn" onClick={() => updateModule(m => ({ ...m, moduleInterface: [...m.moduleInterface, { variableId: m.variables[0]?.id ?? "", externalId: `param${m.moduleInterface.length + 1}`, direction: "input" }] }), "add interface entry")}><Icon.Plus size={11}/> Expose variable</button>
          </div>
        )}
        {tab === "theme" && (
          <div className="space-y-3">
            <div><label className="fnd-field-label">Colour theme</label>
              <div className="flex gap-1">{(["light", "dark"] as const).map(t => <button key={t} className={`fnd-btn ${theme === t ? "fnd-btn-primary" : ""}`} onClick={() => theme !== t && toggleTheme()}>{t === "light" ? "☀ Light" : "☾ Dark"}</button>)}</div></div>
            <div><label className="fnd-field-label">Text size</label>
              <div className="flex gap-1 flex-wrap">{(Object.keys(TEXT_SCALES) as TextScale[]).map(t => <button key={t} className={`fnd-btn ${textScale === t ? "fnd-btn-primary" : ""}`} onClick={() => setTextScale(t)}>{t} · {Math.round(TEXT_SCALES[t] * 100)}%</button>)}</div>
              <div className="text-[10px] fnd-text-dim mt-1">Scales all text and spacing that uses rem units; persisted per browser.</div></div>
          </div>
        )}
        {tab === "autorefresh" && (
          <div className="space-y-2">
            <label className="flex items-center gap-2"><input type="checkbox" checked={autoRefresh} onChange={e => setValues(p => ({ ...p, autoRefresh: e.target.checked }))}/> Auto-refresh every 30 s (re-evaluates every variable)</label>
            <button className="fnd-btn" onClick={() => setMode("runtime")}>Preview in View mode</button>
          </div>
        )}
        {tab === "state" && (
          <div className="space-y-2">
            <div className="fnd-text-muted">The module definition is persisted to this browser and to the database. Export it as JSON to version-control or share.</div>
            <div className="flex gap-1 flex-wrap">
              <button className="fnd-btn" onClick={exportJson}>Export JSON</button>
              <button className="fnd-btn" onClick={() => fileRef.current?.click()}>Import JSON…</button>
              <input ref={fileRef} type="file" accept="application/json,.json" hidden onChange={e => { const f = e.target.files?.[0]; if (f) void importJson(f); e.target.value = ""; }}/>
            </div>
          </div>
        )}
        {tab === "prefs" && (
          <div className="space-y-3">
            <div className="fnd-panel rounded-sm p-2">
              <div className="fnd-label mb-1">Keyboard shortcuts</div>
              {[["⌘K", "Command palette"], ["⌘Z / ⌘⇧Z", "Undo / redo"], ["⌘C ⌘X ⌘V ⌘D", "Copy / cut / paste / duplicate"], ["⌘G / ⌘⇧G", "Group / ungroup"], ["Alt+←→↑↓", "Reorder within parent"], ["Alt+⇧+←/→", "Move out of / into section"], ["⌘ scroll", "Zoom canvas at cursor"], ["Space + drag", "Pan canvas"], ["⌘0 / ⌘1", "Zoom 100% / fit"], ["Esc", "Cancel drag · close · deselect"]].map(([k, v]) => <div key={k} className="flex justify-between py-0.5"><span className="fnd-kbd">{k}</span><span className="fnd-text-muted">{v}</span></div>)}
            </div>
            <button className="fnd-btn fnd-btn-danger" onClick={() => requestConfirm({ title: "Reset local state", message: "Clear all locally stored module, variable, ontology and preference data and reload.", impact: ["Unpublished edits stored in this browser will be lost"], onConfirm: () => { localStorage.clear(); window.location.reload(); } })}>Reset local state</button>
          </div>
        )}
      </div>
    </div>
  );
}
function useSettingsCtx() {
  const w = useWorkshop();
  return { ...w, pages: w.module.pages };
}

// ═══ Profiler (real measurements) ═══════════════════════════════════════════
export function ProfilerPanel() {
  const { module } = useWorkshop();
  const [, tick] = useState(0);
  const [scope, setScope] = useState("");
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState<"last" | "total" | "runs">("last");
  useEffect(() => { const t = setInterval(() => tick(n => n + 1), 700); return () => clearInterval(t); }, []);

  const scopeIds = useMemo(() => {
    if (!scope) return null;
    const rootId = scope.startsWith("p:") ? module.pages.find(p => p.id === scope.slice(2))?.rootSectionId : module.overlays.find(o => o.id === scope.slice(2))?.rootSectionId;
    return rootId ? new Set(collectSectionSubtree(module, rootId).widgetIds) : new Set<string>();
  }, [scope, module]);

  const vars = [...metrics.variables.entries()].map(([id, m]) => ({ id, name: module.variables.find(v => v.id === id)?.name ?? id, ...m }))
    .filter(v => !search || v.name.toLowerCase().includes(search.toLowerCase())).sort((a, b) => (sort === "last" ? b.ms - a.ms : sort === "total" ? b.total - a.total : b.runs - a.runs));
  const widgets = [...metrics.widgets.entries()].filter(([id]) => !scopeIds || scopeIds.has(id)).map(([id, m]) => ({ id, name: module.widgets[id]?.name ?? id, ...m, avg: m.total / m.renders }))
    .filter(w => !search || w.name.toLowerCase().includes(search.toLowerCase())).sort((a, b) => (sort === "last" ? b.last - a.last : sort === "total" ? b.total - a.total : b.renders - a.renders));
  const maxV = Math.max(0.01, ...vars.map(v => v.ms)), maxW = Math.max(0.01, ...widgets.map(w => w.last));
  const evaluated = vars.filter(v => v.lastAt > 0).sort((a, b) => a.lastAt - b.lastAt);
  const t0 = evaluated[0]?.lastAt ?? 0, span = Math.max(1, (evaluated[evaluated.length - 1]?.lastAt ?? 0) - t0 + (evaluated[evaluated.length - 1]?.ms ?? 0));
  const fmt = (n: number) => (n < 1 ? `${(n * 1000).toFixed(0)}µs` : n < 1000 ? `${n.toFixed(1)}ms` : `${(n / 1000).toFixed(2)}s`);

  return (
    <div className="h-full flex flex-col text-xs">
      <div className="px-3 py-2 border-b fnd-border flex items-center gap-2">
        <div className="fnd-label">Performance profiler</div>
        <span className="fnd-tag" style={{ background: "#e4f1e5", color: "#296936", borderColor: "transparent" }}>● capturing</span>
        <div className="flex-1"/>
        <button className="fnd-btn fnd-btn-minimal" title="Clear captured samples" onClick={() => { metrics.clear(); tick(n => n + 1); }}>Clear capture</button>
      </div>
      <div className="grid grid-cols-3 gap-2 p-3 border-b fnd-border">
        <Stat k="First interactive" v={metrics.firstInteractiveMs ? fmt(metrics.firstInteractiveMs) : "—"}/>
        <Stat k="Last re-evaluation" v={fmt(metrics.lastEvalMs)}/>
        <Stat k="Evaluation passes" v={String(metrics.evalPasses)}/>
      </div>
      <div className="px-3 py-2 border-b fnd-border flex items-center gap-2">
        <select className="fnd-input fnd-select" style={{ width: 150 }} value={scope} onChange={e => setScope(e.target.value)} aria-label="Filter widgets by page or overlay">
          <option value="">All widgets</option>
          <optgroup label="Pages">{module.pages.map(p => <option key={p.id} value={`p:${p.id}`}>{p.name}</option>)}</optgroup>
          <optgroup label="Overlays">{module.overlays.map(o => <option key={o.id} value={`o:${o.id}`}>{o.name}</option>)}</optgroup>
        </select>
        <select className="fnd-input fnd-select" style={{ width: 96 }} value={sort} onChange={e => setSort(e.target.value as typeof sort)} aria-label="Sort"><option value="last">Last</option><option value="total">Total</option><option value="runs">Runs</option></select>
        <input className="fnd-input" placeholder="Search" value={search} onChange={e => setSearch(e.target.value)}/>
      </div>
      <div className="flex-1 overflow-auto p-3">
        <div className="fnd-label mb-1">Evaluation timeline</div>
        <div className="relative mb-4" style={{ height: 44, background: "var(--fnd-panel-2)", borderRadius: 2 }} aria-label="Variable evaluation timeline">
          {evaluated.map(v => <div key={v.id} title={`${v.name} · ${fmt(v.ms)}`} style={{ position: "absolute", left: `${((v.lastAt - t0) / span) * 100}%`, width: `${Math.max(0.6, (v.ms / span) * 100)}%`, top: 4 + (evaluated.indexOf(v) % 4) * 9, height: 7, background: "var(--fnd-accent)", borderRadius: 1 }}/>)}
          {evaluated.length === 0 && <div className="p-3 fnd-text-dim">No samples yet.</div>}
        </div>
        <div className="fnd-label mb-1">Variables · {vars.length}</div>
        <Rows items={vars.map(v => ({ key: v.id, name: v.name, frac: v.ms / maxV, label: fmt(v.ms), sub: `${v.runs}× · Σ ${fmt(v.total)}` }))}/>
        <div className="fnd-label mt-4 mb-1">Widget renders · {widgets.length}</div>
        <Rows items={widgets.map(w => ({ key: w.id, name: w.name, frac: w.last / maxW, label: fmt(w.last), sub: `${w.renders}× · avg ${fmt(w.avg)} · max ${fmt(w.max)}` }))}/>
      </div>
    </div>
  );
}
function Stat({ k, v }: { k: string; v: string }) {
  return <div className="fnd-panel rounded-sm px-2 py-1.5"><div className="text-[10px] uppercase fnd-text-muted">{k}</div><div className="text-sm font-bold tabular-nums">{v}</div></div>;
}
function Rows({ items }: { items: Array<{ key: string; name: string; frac: number; label: string; sub: string }> }) {
  if (items.length === 0) return <div className="fnd-text-dim py-2">No samples for this filter.</div>;
  return (
    <div className="space-y-1">
      {items.slice(0, 80).map(it => (
        <div key={it.key} className="flex items-center gap-2" title={`${it.name} — ${it.sub}`}>
          <div style={{ width: 150 }} className="truncate">{it.name}</div>
          <div className="flex-1 h-3 rounded-sm" style={{ background: "var(--fnd-panel-2)" }}><div style={{ width: `${Math.max(1, it.frac * 100)}%`, height: "100%", background: "var(--fnd-accent)", borderRadius: 2 }}/></div>
          <div style={{ width: 54, textAlign: "right" }} className="tabular-nums fnd-text-muted">{it.label}</div>
        </div>
      ))}
    </div>
  );
}

// ═══ Changelog ══════════════════════════════════════════════════════════════
interface Diff {
  added: string[]; deleted: string[]; madeUnused: string[]; moved: Array<{ name: string; from: string; to: string }>;
  changed: Array<{ name: string; detail: string[] }>;
}
function parentNames(m: ModuleDef) {
  const out: Record<string, string> = {};
  for (const [sid, s] of Object.entries(m.sections)) for (const c of s.children) out[c.id] = s.name;
  return out;
}
const short = (v: unknown) => { const s = typeof v === "string" ? v : JSON.stringify(v); return s == null ? "∅" : s.length > 40 ? s.slice(0, 37) + "…" : s; };

export function computeDiff(a: ModuleDef, b: ModuleDef): Diff {
  const d: Diff = { added: [], deleted: [], madeUnused: [], moved: [], changed: [] };
  const pa = parentNames(a), pb = parentNames(b);
  for (const id of Object.keys(b.widgets)) if (!a.widgets[id]) d.added.push(`Widget · ${b.widgets[id].name}`);
  for (const id of Object.keys(a.widgets)) if (!b.widgets[id]) d.deleted.push(`Widget · ${a.widgets[id].name}`);
  for (const id of Object.keys(b.sections)) if (!a.sections[id] && !b.sections[id].auto) d.added.push(`Section · ${b.sections[id].name}`);
  for (const id of Object.keys(a.sections)) if (!b.sections[id] && !a.sections[id].auto) d.deleted.push(`Section · ${a.sections[id].name}`);
  for (const p of b.pages) if (!a.pages.some(x => x.id === p.id)) d.added.push(`Page · ${p.name}`);
  for (const p of a.pages) if (!b.pages.some(x => x.id === p.id)) d.deleted.push(`Page · ${p.name}`);
  for (const o of b.overlays) if (!a.overlays.some(x => x.id === o.id)) d.added.push(`Overlay · ${o.name}`);
  for (const o of a.overlays) if (!b.overlays.some(x => x.id === o.id)) d.deleted.push(`Overlay · ${o.name}`);
  for (const v of b.variables) if (!a.variables.some(x => x.id === v.id)) d.added.push(`Variable · @${v.name}`);
  for (const v of a.variables) if (!b.variables.some(x => x.id === v.id)) d.deleted.push(`Variable · @${v.name}`);
  for (const id of b.unusedWidgetIds) if (!a.unusedWidgetIds.includes(id) && a.widgets[id]) d.madeUnused.push(b.widgets[id].name);
  for (const id of Object.keys(b.widgets)) {
    const A = a.widgets[id], B = b.widgets[id];
    if (!A) continue;
    if (pa[id] && pb[id] && pa[id] !== pb[id]) d.moved.push({ name: B.name, from: pa[id], to: pb[id] });
    const detail: string[] = [];
    if (A.name !== B.name) detail.push(`name: “${A.name}” → “${B.name}”`);
    const keys = new Set([...Object.keys(A.config), ...Object.keys(B.config)]);
    for (const k of keys) if (JSON.stringify(A.config[k]) !== JSON.stringify(B.config[k])) detail.push(`${k}: ${short(A.config[k])} → ${short(B.config[k])}`);
    for (const k of ["height", "flex", "hidden", "readOnly", "mountBehavior", "unmountBehavior", "emptyMessage"] as const) if (JSON.stringify(A[k]) !== JSON.stringify(B[k])) detail.push(`${k}: ${short(A[k])} → ${short(B[k])}`);
    if (JSON.stringify(A.events) !== JSON.stringify(B.events)) detail.push("events updated");
    if (JSON.stringify(A.style) !== JSON.stringify(B.style)) detail.push("style updated");
    if (detail.length) d.changed.push({ name: B.name, detail });
  }
  for (const id of Object.keys(b.sections)) {
    const A = a.sections[id], B = b.sections[id];
    if (!A || B.auto) continue;
    const detail: string[] = [];
    for (const k of ["name", "layout", "width", "height", "flex", "gap", "padding", "background", "border", "visibleVariableId", "stackBelow", "align", "justify"] as const) if (A[k] !== B[k]) detail.push(`${k}: ${short(A[k])} → ${short(B[k])}`);
    if (A.children.length !== B.children.length) detail.push(`children: ${A.children.length} → ${B.children.length}`);
    if (detail.length) d.changed.push({ name: `Section · ${B.name}`, detail });
  }
  for (const v of b.variables) {
    const A = a.variables.find(x => x.id === v.id);
    if (A && JSON.stringify(A) !== JSON.stringify(v)) d.changed.push({ name: `Variable · @${v.name}`, detail: ["definition updated"] });
  }
  return d;
}

export function ChangelogPanel() {
  const { savedSnapshots, snapshot, module, publishedVersion, isDirtySincePublish } = useWorkshop();
  const [a, setA] = useState<number>(-2);   // -2 = latest snapshot (default), -1 = current draft
  const [b, setB] = useState<number>(-1);
  const opts = [{ v: -1, label: "Current draft" }, ...savedSnapshots.map((s, i) => ({ v: i, label: `${s.label} · ${new Date(s.ts).toLocaleTimeString()}` }))];
  const resolve = (v: number) => (v === -1 ? module : savedSnapshots[v === -2 ? savedSnapshots.length - 1 : v]?.module);
  const mA = resolve(a), mB = resolve(b);
  const diff = useMemo(() => (mA && mB ? computeDiff(mA, mB) : null), [mA, mB]);
  const total = diff ? diff.added.length + diff.deleted.length + diff.madeUnused.length + diff.moved.length + diff.changed.length : 0;
  const Group = ({ title, color, children, n }: { title: string; color: string; children: React.ReactNode; n: number }) => n === 0 ? null : (
    <div><div className="fnd-label mb-1" style={{ color }}>{title} · {n}</div>{children}</div>
  );

  return (
    <div className="h-full flex flex-col text-xs">
      <div className="px-3 py-2 border-b fnd-border flex items-center gap-2">
        <div className="fnd-label">Changelog</div>
        <span className="fnd-tag">{publishedVersion ? `published v${publishedVersion}${isDirtySincePublish ? " · draft ahead" : ""}` : "unpublished"}</span>
        <div className="flex-1"/>
        <button className="fnd-btn fnd-btn-primary" onClick={() => snapshot(`v${savedSnapshots.length + 1}`)}><Icon.Save size={11}/> Snapshot</button>
      </div>
      <div className="px-3 py-2 border-b fnd-border flex items-center gap-1.5">
        <select className="fnd-input fnd-select" value={a === -2 ? (savedSnapshots.length ? savedSnapshots.length - 1 : -1) : a} onChange={e => setA(Number(e.target.value))} aria-label="Version A">{opts.map(o => <option key={o.v} value={o.v}>{o.label}</option>)}</select>
        <span className="fnd-text-muted">→</span>
        <select className="fnd-input fnd-select" value={b} onChange={e => setB(Number(e.target.value))} aria-label="Version B">{opts.map(o => <option key={o.v} value={o.v}>{o.label}</option>)}</select>
      </div>
      <div className="flex-1 overflow-auto p-3 space-y-3">
        {savedSnapshots.length === 0 && <div className="fnd-text-dim">Take a snapshot, edit the module, and the draft is compared against it here.</div>}
        {diff && total === 0 && savedSnapshots.length > 0 && <div className="fnd-text-dim">No differences between the selected versions.</div>}
        {diff && (
          <>
            <Group title="Added" color="#296936" n={diff.added.length}>{diff.added.map(k => <div key={k} className="pl-3 py-0.5">+ {k}</div>)}</Group>
            <Group title="Changed" color="#8a5a16" n={diff.changed.length}>{diff.changed.map(c => <div key={c.name} className="pl-3 py-0.5"><div>~ <strong>{c.name}</strong></div>{c.detail.map(x => <div key={x} className="pl-4 fnd-text-muted font-mono text-[11px] break-all">{x}</div>)}</div>)}</Group>
            <Group title="Moved" color="#1e4a85" n={diff.moved.length}>{diff.moved.map(m => <div key={m.name} className="pl-3 py-0.5">→ <strong>{m.name}</strong> <span className="fnd-text-muted">{m.from} → {m.to}</span></div>)}</Group>
            <Group title="Made unused" color="#5c7080" n={diff.madeUnused.length}>{diff.madeUnused.map(k => <div key={k} className="pl-3 py-0.5">⊘ {k}</div>)}</Group>
            <Group title="Deleted" color="#8a1f1f" n={diff.deleted.length}>{diff.deleted.map(k => <div key={k} className="pl-3 py-0.5">− {k}</div>)}</Group>
          </>
        )}
      </div>
    </div>
  );
}
