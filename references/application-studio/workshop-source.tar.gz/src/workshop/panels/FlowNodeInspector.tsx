"use client";
import React, { useEffect, useState } from "react";
import { useWorkshop } from "../WorkshopContext";
import { FLOW_NODES, PORT_COLORS, getSpec } from "../flowCatalog";
import { getFlowRuntime, validateFlow } from "../flowEngine";
import { telemetryStore, SIGNALS } from "../telemetry/telemetryStore";
import { Icon } from "../widgets/icons";
import type { FlowNodeDef } from "../flowTypes";

function Field({ title, children, hint }: { title: string; children: React.ReactNode; hint?: string }) {
  return <div><label className="fnd-field-label">{title}</label>{children}{hint && <div className="text-[10px] fnd-text-dim mt-0.5">{hint}</div>}</div>;
}
function Section({ title, children, initial = true }: { title: string; children: React.ReactNode; initial?: boolean }) {
  const [open, setOpen] = useState(initial);
  return <div className="border-b fnd-border"><button className="w-full flex items-center gap-1 px-3 py-2 text-left" onClick={() => setOpen(x => !x)} aria-expanded={open}><Icon.Chevron size={10} dir={open ? "down" : "right"}/><span className="fnd-label">{title}</span></button>{open && <div className="px-3 pb-3 space-y-2.5">{children}</div>}</div>;
}

export function FlowNodeInspector({ nodeId }: { nodeId: string | null }) {
  const { module, activeFlowId, updateModule, ontologyMeta, requestConfirm, select } = useWorkshop();
  const flow = module.flows.find(f => f.id === activeFlowId);
  const node = flow?.nodes.find(n => n.id === nodeId);
  const spec = node ? getSpec(node.type) : null;
  const [previewTick, setPreviewTick] = useState(0);
  const [fieldError, setFieldError] = useState<Record<string, string>>({});
  useEffect(() => { const t = setInterval(() => setPreviewTick(x => x + 1), 450); return () => clearInterval(t); }, []);
  void previewTick;
  if (!flow || !node || !spec) return <div className="p-4 text-xs fnd-text-dim">Select a processor to configure inputs, operators, retries and output bindings.</div>;
  const preview = getFlowRuntime(flow.id).previews[node.id];
  const inbound = flow.edges.filter(e => e.target === node.id && e.enabled !== false), outbound = flow.edges.filter(e => e.source === node.id && e.enabled !== false);
  const problems = validateFlow(flow, { module, ontologyMeta }).filter(p => p.includes(node.name));
  const update = (fn: (n: FlowNodeDef) => FlowNodeDef, label = "configure flow node") => updateModule(m => ({ ...m, flows: m.flows.map(f => f.id === flow.id ? { ...f, nodes: f.nodes.map(n => n.id === node.id ? fn(n) : n), version: f.version + 1 } : f) }), label);
  const put = (key: string, value: unknown) => update(n => ({ ...n, config: { ...n.config, [key]: value } }));
  const selectOptions = (key: string): string[] | null => {
    if (key === "objectType") return ontologyMeta.objectTypes.map(o => o.apiName);
    if (key === "linkType") return ontologyMeta.linkTypes.map(l => l.apiName);
    if (key === "actionType") return ontologyMeta.actionTypes.map(a => a.apiName);
    if (key === "variableId") return module.variables.map(v => v.id);
    if (key === "signal") return telemetryStore.get().columnNames.length ? telemetryStore.get().columnNames : Array.from({ length: 100 }, (_, i) => `${SIGNALS[Math.floor(i / 10)]}_${String(i % 10 + 1).padStart(2, "0")}`);
    if (key === "mode") return node.type === "join" ? ["left", "inner", "outer"] : ["replace", "append"];
    if (key === "windowKind") return ["sliding", "tumbling", "session"];
    if (key === "lateEvents") return ["sideOutput", "drop", "accept"];
    if (key === "backpressure") return ["dropOldest", "dropNewest", "block"];
    if (key === "join" ) return ["all", "any"];
    if (key === "method") return ["uniform", "last", "minMax"];
    if (key === "partitionBy") return ["deviceId", "plantId", "assetId"];
    if (key === "severity") return ["Critical", "High", "Medium", "Low"];
    if (key === "operator") return ["eq", "neq", "gt", "gte", "lt", "lte", "contains", "in"];
    return null;
  };
  const labelFor = (key: string) => key.replace(/([a-z])([A-Z])/g, "$1 $2").replace(/Ms$/, " (ms)").replace(/^./, s => s.toUpperCase());
  const configEditor = (key: string, value: unknown) => {
    const choices = selectOptions(key);
    if (choices) return <select className="fnd-input fnd-select" value={String(value ?? "")} onChange={e => put(key, e.target.value)}><option value="">— Select —</option>{choices.map(choice => <option key={choice} value={choice}>{choice}</option>)}</select>;
    if (typeof value === "boolean") return <label className="flex items-center gap-2 text-xs"><input type="checkbox" checked={value} onChange={e => put(key, e.target.checked)}/>{value ? "Enabled" : "Disabled"}</label>;
    if (typeof value === "number") return <input className="fnd-input" type="number" step={key.endsWith("Ms") || key === "batchSize" || key === "maxConcurrency" ? 1 : .1} value={value} onChange={e => put(key, Number(e.target.value))}/>;
    if (Array.isArray(value) || value && typeof value === "object") return <JsonField key={`${node.id}:${key}`} value={value} onCommit={next => { put(key, next); setFieldError(prev => ({ ...prev, [key]: "" })); }} onError={message => setFieldError(prev => ({ ...prev, [key]: message }))}/>;
    return <input className="fnd-input" value={String(value ?? "")} onChange={e => put(key, e.target.value)}/>;
  };
  const del = () => requestConfirm({ title: "Delete flow processor", message: `Delete “${node.name}” from ${flow.name}?`, impact: [`${inbound.length} incoming + ${outbound.length} outgoing connection(s) will be removed`], onConfirm: () => { updateModule(m => ({ ...m, flows: m.flows.map(f => f.id === flow.id ? { ...f, nodes: f.nodes.filter(n => n.id !== node.id), edges: f.edges.filter(e => e.source !== node.id && e.target !== node.id), version: f.version + 1 } : f) }), "delete flow node"); select({ kind: "flow", id: flow.id }); } });

  return <div className="h-full overflow-auto text-xs">
    <div className="px-3 py-2 border-b fnd-border"><div className="font-semibold">{node.name}</div><div className="font-mono text-[10px] fnd-text-dim">{node.type} · {node.id}</div></div>
    <Section title="Processor identity">
      <Field title="Name"><input className="fnd-input" value={node.name} onChange={e => update(n => ({ ...n, name: e.target.value }), "rename flow node")}/></Field>
      <div className="fnd-text-muted text-[11px]">{spec.description}</div>
      <label className="flex items-center gap-2"><input type="checkbox" checked={!node.disabled} onChange={e => update(n => ({ ...n, disabled: !e.target.checked }), "toggle flow node")}/> Processor enabled</label>
      {problems.map((p, i) => <div key={i} className="text-[11px]" style={{ color: "var(--fnd-danger)" }}>⚠ {p}</div>)}
    </Section>
    <Section title="Parameters">
      {Object.entries(node.config).map(([key, value]) => <Field key={key} title={labelFor(key)} hint={key === "batchSize" ? "Maximum records per cursor read. Source drains up to 16 batches / run (4,096 rows cap)." : key === "dryRun" ? "When enabled: validate inputs but never call a writeback Action." : key === "windowMs" ? "Event-time sliding window. Bounded to 50,000 rows; overflow routes to Late output." : undefined}>{configEditor(key, value)}{fieldError[key] && <div className="text-[10px]" style={{ color: "var(--fnd-danger)" }}>{fieldError[key]}</div>}</Field>)}
      {node.type === "branch" && <div className="text-[10px] fnd-text-dim">The Predicate object controls routing; edit its JSON fields `field`, `operator`, `value` above. The default Else route contains all nonmatches.</div>}
      {node.type === "aggregate" && <div className="fnd-tag">f32 SIMD-ready WASM statistics kernel</div>}
    </Section>
    <Section title={`Typed ports · ${inbound.length} in / ${outbound.length} out`}>
      {[...spec.inputs, ...spec.outputs].map(p => <div key={`${p.direction}:${p.id}`} className="flex items-center gap-1.5 py-0.5 text-[11px]"><span style={{ width: 9, height: 9, borderRadius: 5, background: PORT_COLORS[p.type] }}/><span className="font-mono">{p.direction === "input" ? "←" : "→"} {p.id}</span><span className="fnd-text-muted flex-1 truncate">{p.label}</span><span className="fnd-tag" style={{ height: 18 }}>{p.type}</span></div>)}
    </Section>
    <Section title="Retry & recovery">
      <Field title="Retry attempts"><input className="fnd-input" type="number" min={0} max={5} value={node.retry?.attempts ?? 0} onChange={e => update(n => ({ ...n, retry: { attempts: Number(e.target.value), backoffMs: n.retry?.backoffMs ?? 250 } }))}/></Field>
      <Field title="Base backoff (ms)"><input className="fnd-input" type="number" min={10} max={1500} value={node.retry?.backoffMs ?? 250} onChange={e => update(n => ({ ...n, retry: { attempts: n.retry?.attempts ?? 0, backoffMs: Number(e.target.value) } }))}/></Field>
      <div className="text-[10px] fnd-text-dim">Terminal failures follow the pipeline’s error policy: stop, continue or dead-letter.</div>
    </Section>
    <Section title="Last run output">
      {preview ? <><div className="flex items-center gap-2"><span className="fnd-tag">{preview.kind}</span><b className="tabular-nums">{preview.count.toLocaleString()} output records</b></div>{preview.example && <pre className="fnd-panel-2 p-2 rounded-sm text-[10px] font-mono whitespace-pre-wrap break-all mt-1">{JSON.stringify(preview.example, null, 2)}</pre>}</> : <div className="fnd-text-dim">Run the pipeline to inspect this node’s output.</div>}
    </Section>
    <Section title="Danger zone"><button className="fnd-btn fnd-btn-danger" onClick={del}><Icon.Trash size={11}/> Delete processor</button></Section>
  </div>;
}

function JsonField({ value, onCommit, onError }: { value: unknown; onCommit: (next: unknown) => void; onError: (message: string) => void }) {
  const [text, setText] = useState(() => JSON.stringify(value, null, 2));
  const [focused, setFocused] = useState(false);
  useEffect(() => { if (!focused) setText(JSON.stringify(value, null, 2)); }, [value, focused]);
  const submit = () => { try { const result = JSON.parse(text); onCommit(result); setFocused(false); } catch { onError("Invalid JSON; changes were not saved."); } };
  return <div><textarea className="fnd-input font-mono" style={{ height: Math.min(140, Math.max(55, text.split("\n").length * 18)), padding: 5, fontSize: 10 }} value={text} onFocus={() => setFocused(true)} onChange={e => setText(e.target.value)} onBlur={submit} onKeyDown={e => { if (e.key === "Escape") { setText(JSON.stringify(value, null, 2)); setFocused(false); (e.target as HTMLTextAreaElement).blur(); } }}/><div className="text-[10px] fnd-text-dim">JSON array/object · saves on blur</div></div>;
}
