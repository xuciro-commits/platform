"use client";
import React, { useEffect, useMemo, useRef, useState } from "react";
import { useCore } from "../WorkshopContext";
import { Icon } from "./icons";
import { useStore } from "../runtimeStores";
import {
  TELEMETRY_COLUMNS, STATUS_NAMES, telemetryStore, ensureTelemetry, startTelemetry, pauseTelemetry, resetTelemetryWorker,
  queryTelemetry, readTelemetryRange, type TelemetryRow, type TelemetryFilter, type TelemetrySort,
} from "../telemetry/telemetryStore";
import type { WidgetDef } from "../types";

const ROW = 30, GROUP = 23, HEADER = 31, HEAD_H = GROUP + HEADER, CELL = 120, META_W = 476;
const METADATA = [
  { key: "plant", title: "Plant", width: 105, left: 0 },
  { key: "device", title: "Device", width: 106, left: 105 },
  { key: "asset", title: "Asset", width: 105, left: 211 },
  { key: "status", title: "Status", width: 96, left: 316 },
  { key: "time", title: "Event time", width: 64, left: 412 },
];
const STATUS_STYLE: Record<string, { background: string; color: string }> = {
  Active: { background: "#e4f1e5", color: "#296936" }, Warning: { background: "#fdf1dc", color: "#8a5a16" },
  Offline: { background: "#fde0e0", color: "#8a1f1f" }, Maintenance: { background: "#e3ecfa", color: "#1e4a85" },
};
const GROUPS = ["Vibration", "Temperature", "Pressure", "Flow", "Electrical", "Rotating", "Process", "Environment", "Acoustic", "Derived"];
const numberLabel = (n: number) => n.toLocaleString("en-US");

/** 100k × 100 grid: ≤80 row slots, ≤20 signal columns, pinned metadata and a Worker-owned column store. */
export function TelemetryTable({ widget }: { widget: WidgetDef }) {
  const { ontology, values, setValues } = useCore();
  const cfg = widget.config as { assetVarId?: string; selectedSignalVarId?: string; rowHeight?: number };
  const stateReady = useStore(telemetryStore, s => s.ready);
  const stateLoading = useStore(telemetryStore, s => s.loading);
  const stateError = useStore(telemetryStore, s => s.error);
  const stateVersion = useStore(telemetryStore, s => Math.floor(s.version / 3)); // cap UI refresh to ~3Hz
  const statePaused = useStore(telemetryStore, s => s.paused);
  const throughput = useStore(telemetryStore, s => s.rowsPerSecond);
  const wasm = useStore(telemetryStore, s => s.wasm);
  const colNames = useStore(telemetryStore, s => s.columnNames);
  const plants = useStore(telemetryStore, s => s.plants);
  const [filter, setFilter] = useState<TelemetryFilter>({});
  const [sort, setSort] = useState<TelemetrySort>({ property: "eventTime", direction: "desc" });
  const [query, setQuery] = useState<{ indices: Uint32Array; total: number; ms: number; version: number } | null>(null);
  const [rows, setRows] = useState<TelemetryRow[]>([]);
  const [view, setView] = useState({ top: 0, left: 0, w: 1000, h: 440 });
  const [hidden, setHidden] = useState<Set<number>>(new Set());
  const [colSearch, setColSearch] = useState("");
  const [colMenu, setColMenu] = useState(false);
  const [exporting, setExporting] = useState<number | null>(null);
  const [selectedRow, setSelectedRow] = useState<number | null>(null);
  const [liveRefresh, setLiveRefresh] = useState(true);
  const [groupHeader, setGroupHeader] = useState(true);
  const scroller = useRef<HTMLDivElement>(null);
  const requestSeq = useRef(0);
  const querySeq = useRef(0);
  const scrollRaf = useRef(0);
  const visible = useMemo(() => Array.from({ length: TELEMETRY_COLUMNS }, (_, i) => i).filter(i => !hidden.has(i)), [hidden]);
  const rowHeight = Math.max(26, Math.min(44, cfg.rowHeight ?? ROW));
  const rowCount = query?.total ?? 0;
  const width = META_W + visible.length * CELL;
  const firstRow = Math.max(0, Math.floor(Math.max(0, view.top) / rowHeight) - 7);
  const rowEnd = Math.min(rowCount, Math.ceil((view.top + view.h) / rowHeight) + 8);
  const firstCol = Math.max(0, Math.floor(Math.max(0, view.left + (view.left > META_W ? META_W : 0) - META_W) / CELL) - 2);
  const colEnd = Math.min(visible.length, firstCol + Math.ceil(view.w / CELL) + 5);
  const windowColumns = visible.slice(firstCol, colEnd);
  const colFrom = windowColumns.length ? Math.min(...windowColumns) : 0;
  const colTo = windowColumns.length ? Math.max(...windowColumns) + 1 : 0;
  const assetById = useMemo(() => new Map(ontology.assets.map(a => [a.id, a])), [ontology.assets]);

  useEffect(() => { void ensureTelemetry().then(() => startTelemetry(100)).catch(() => {}); }, []);
  useEffect(() => {
    const element = scroller.current;
    if (!element) return;
    const ro = new ResizeObserver(entries => setView(s => ({ ...s, w: entries[0].contentRect.width, h: entries[0].contentRect.height })));
    ro.observe(element); setView(s => ({ ...s, w: element.clientWidth, h: element.clientHeight }));
    return () => ro.disconnect();
  }, []);
  useEffect(() => {
    if (!stateReady) return;
    const id = ++querySeq.current;
    const timer = window.setTimeout(() => {
      queryTelemetry(filter, sort).then(result => {
        if (id !== querySeq.current) return;
        setQuery({ indices: result.indices, total: result.total, ms: result.elapsedMs, version: result.version });
        if (scroller.current) scroller.current.scrollTop = 0;
        setView(v => ({ ...v, top: 0 }));
      }).catch(() => { if (id === querySeq.current) setQuery(null); });
    }, 90);
    return () => window.clearTimeout(timer);
  }, [filter, sort, stateReady]);
  // Statuses can change in the ring; re-evaluate predicates at a bounded 3s cadence, never at each 100ms tick.
  useEffect(() => {
    if (!stateReady || statePaused || !liveRefresh) return;
    const timer = window.setInterval(() => {
      queryTelemetry(filter, sort).then(result => {
        if (result.version < (query?.version ?? 0)) return;
        setQuery({ indices: result.indices, total: result.total, ms: result.elapsedMs, version: result.version });
      }).catch(() => {});
    }, 3000);
    return () => window.clearInterval(timer);
  }, [filter, sort, stateReady, statePaused, liveRefresh]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (!stateReady || !query || colTo <= colFrom || rowEnd <= firstRow) { setRows([]); return; }
    const id = ++requestSeq.current;
    readTelemetryRange(firstRow, rowEnd, colFrom, colTo, query.indices).then(batch => {
      if (id === requestSeq.current) setRows(batch);
    }).catch(() => { if (id === requestSeq.current) setRows([]); });
  }, [stateReady, query, firstRow, rowEnd, colFrom, colTo, stateVersion, liveRefresh]);
  useEffect(() => () => { if (scrollRaf.current) cancelAnimationFrame(scrollRaf.current); }, []);

  const onScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const el = e.currentTarget;
    if (scrollRaf.current) cancelAnimationFrame(scrollRaf.current);
    const top = el.scrollTop, left = el.scrollLeft;
    scrollRaf.current = requestAnimationFrame(() => setView(v => v.top === top && v.left === left ? v : { ...v, top, left }));
  };
  const setCategory = (kind: "plants" | "statuses", i: number) => {
    setFilter(prev => {
      const a = prev[kind] ?? [];
      return { ...prev, [kind]: a.includes(i) ? a.filter(x => x !== i) : [...a, i] };
    });
  };
  const toggleSort = (property: TelemetrySort["property"], signal?: number) => {
    setSort(prev => prev.property === property && prev.signal === signal ? { property, signal, direction: prev.direction === "asc" ? "desc" : "asc" } : { property, signal, direction: "asc" });
  };
  const select = (r: TelemetryRow, index: number) => {
    setSelectedRow(index);
    const asset = assetById.get(r.assetId);
    const metadata = { assetId: r.assetId, deviceId: r.deviceId, plantId: r.plantId, time: r.time, key: r.key, status: r.status };
    setValues(prev => ({ ...prev, [cfg.assetVarId ?? "selectedAsset"]: asset ?? null, currentTelemetryRow: metadata }));
  };
  const exportFiltered = async () => {
    if (!query || exporting !== null) return;
    const limit = Math.min(query.total, 10000);
    setExporting(0);
    try {
      const names = ["Plant", "Device", "Asset", "Status", "Event time", ...visible.map(i => colNames[i])];
      const pieces = [names.join(",") + "\n"];
      for (let offset = 0; offset < limit; offset += 200) {
        const chunk = await readTelemetryRange(offset, Math.min(limit, offset + 200), 0, TELEMETRY_COLUMNS, query.indices);
        pieces.push(chunk.map(r => [r.plant, r.device, r.assetId, r.status, new Date(r.time).toISOString(), ...visible.map(i => r.values[i]?.toFixed(3) ?? "")].join(",")).join("\n") + "\n");
        setExporting(Math.round(Math.min(limit, offset + 200) / limit * 100));
      }
      const url = URL.createObjectURL(new Blob(pieces, { type: "text/csv;charset=utf-8" }));
      const a = document.createElement("a"); a.href = url; a.download = `telemetry_${limit}_rows.csv`; a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch { /* network state is visible in the footer; no fictitious success */ }
    finally { setExporting(null); }
  };
  const groupSpans = useMemo(() => {
    const groups: Array<{ group: number; start: number; count: number }> = [];
    visible.forEach((signal, i) => {
      const group = Math.floor(signal / 10), last = groups[groups.length - 1];
      if (last?.group === group) last.count++;
      else groups.push({ group, start: i, count: 1 });
    });
    return groups;
  }, [visible]);

  if (stateError && !stateReady) return <div className="fnd-panel p-4 text-xs" role="alert"><b style={{ color: "var(--fnd-danger)" }}>Telemetry worker failed</b><p className="mt-2 fnd-text-muted">{stateError}</p><button className="fnd-btn mt-2" onClick={() => { resetTelemetryWorker(); void ensureTelemetry().then(() => startTelemetry()); }}>Retry</button></div>;

  return (
    <div className="fnd-panel rounded-sm h-full flex flex-col overflow-hidden" style={{ minHeight: 360 }}>
      <div className="flex items-center gap-2 px-2.5 border-b fnd-border" style={{ height: 38, flexShrink: 0 }}>
        <Icon.Table size={13}/><strong className="text-xs truncate" title={widget.name}>{widget.name}</strong>
        <span className="fnd-tag" title="100,000 rows live in a Worker-owned column store">{stateReady ? numberLabel(rowCount) : stateLoading ? "Loading 10M values…" : "Waiting"} rows</span>
        <span className="fnd-tag">{TELEMETRY_COLUMNS} signals</span>
        <span className="fnd-tag" style={{ background: statePaused ? "var(--fnd-panel-2)" : "#e4f1e5", color: statePaused ? "var(--fnd-text-muted)" : "#296936", borderColor: "transparent" }}>{statePaused ? "Ⅱ paused" : "● live"}</span>
        <div className="flex-1"/>
        <span className="text-[10px] tabular-nums fnd-text-muted">{numberLabel(throughput)} rows/s</span>
        <button className="fnd-btn fnd-btn-minimal" title={statePaused ? "Resume stream" : "Pause stream"} onClick={() => void (statePaused ? startTelemetry(100) : pauseTelemetry())}>{statePaused ? "▶ Resume" : "Ⅱ Pause"}</button>
        <button className={`fnd-btn fnd-btn-minimal ${liveRefresh ? "fnd-selected" : ""}`} title="Auto-refresh filtered row index every 3s" onClick={() => setLiveRefresh(x => !x)}>Index sync</button>
        <button className="fnd-btn fnd-btn-minimal" disabled={!query || exporting !== null} title={`Export up to 10,000 filtered rows and ${visible.length} visible signals as CSV`} onClick={() => void exportFiltered()}>{exporting === null ? "↓ CSV" : `Export ${exporting}%`}</button>
        <div className="relative">
          <button className="fnd-btn fnd-btn-minimal" aria-expanded={colMenu} aria-haspopup="true" title="Show or hide signal columns" onClick={() => setColMenu(x => !x)}>Columns ▾</button>
          {colMenu && <div className="fnd-panel p-2" style={{ position: "absolute", zIndex: 30, right: 0, top: 30, width: 230, maxHeight: 320, overflow: "auto", boxShadow: "0 8px 20px rgba(0,0,0,.16)" }}>
            <div className="flex gap-1"><input className="fnd-input mb-1" placeholder="Find signal…" value={colSearch} onChange={e => setColSearch(e.target.value)}/><button className="fnd-btn fnd-btn-minimal" title="Close" onClick={() => setColMenu(false)}>×</button></div>
            <div className="flex gap-1 mb-1"><button className="fnd-btn fnd-btn-minimal" onClick={() => setHidden(new Set())}>All</button><button className="fnd-btn fnd-btn-minimal" onClick={() => setHidden(new Set(Array.from({ length: TELEMETRY_COLUMNS }, (_, i) => i).filter(i => i % 10 !== 0)))}>Vibration only</button></div>
            {colNames.map((name, i) => name.toLowerCase().includes(colSearch.toLowerCase()) && <label key={i} className="flex items-center gap-1.5 text-[11px] py-0.5"><input type="checkbox" checked={!hidden.has(i)} onChange={() => setHidden(prev => { const n = new Set(prev); n.has(i) ? n.delete(i) : n.add(i); return n; })}/>{name}</label>)}
          </div>}
        </div>
      </div>
      <div className="flex items-center gap-1 px-2.5 border-b fnd-border overflow-x-auto" style={{ height: 31, flexShrink: 0, whiteSpace: "nowrap" }}>
        <span className="fnd-label mr-1">Plant</span>{plants.map((p, i) => <button key={p} className="fnd-tag" style={{ height: 19, cursor: "pointer", background: !filter.plants?.length || filter.plants.includes(i) ? "var(--fnd-selection)" : undefined, color: filter.plants?.length && !filter.plants.includes(i) ? "var(--fnd-text-dim)" : "var(--fnd-accent)" }} onClick={() => setCategory("plants", i)}>{p}</button>)}
        <span className="fnd-label ml-2 mr-1">Status</span>{STATUS_NAMES.map((s, i) => <button key={s} className="fnd-tag" style={{ height: 19, cursor: "pointer", opacity: filter.statuses?.length && !filter.statuses.includes(i) ? .46 : 1, ...STATUS_STYLE[s] }} onClick={() => setCategory("statuses", i)}>{s}</button>)}
        <input className="fnd-input" style={{ minWidth: 130, width: 165, height: 23 }} placeholder="Find device / asset…" value={filter.search ?? ""} onChange={e => setFilter(f => ({ ...f, search: e.target.value }))}/>
        {(filter.plants?.length || filter.statuses?.length || filter.search) && <button className="fnd-btn fnd-btn-minimal" style={{ height: 22 }} onClick={() => setFilter({})}>Clear filters</button>}
      </div>
      <div ref={scroller} role="grid" tabIndex={0} aria-rowcount={rowCount} className="flex-1 overflow-auto" style={{ minHeight: 0, position: "relative" }} onScroll={onScroll} onKeyDown={e => {
        if (e.key !== "ArrowDown" && e.key !== "ArrowUp" && e.key !== "PageDown") return;
        e.preventDefault(); const jump = e.key === "PageDown" ? Math.floor(view.h / rowHeight) : 1;
        const next = Math.max(0, Math.min(rowCount - 1, (selectedRow ?? 0) + (e.key === "ArrowUp" ? -jump : jump)));
        setSelectedRow(next); if (scroller.current) scroller.current.scrollTop = Math.max(0, next * rowHeight - view.h / 2);
      }}>
        <div style={{ width, height: HEAD_H + rowCount * rowHeight, minWidth: "100%", position: "relative" }}>
          <div style={{ position: "sticky", top: 0, height: HEAD_H, width, zIndex: 10, background: "var(--fnd-panel-2)", borderBottom: "1px solid var(--fnd-border)" }}>
            <div style={{ position: "sticky", left: 0, width: META_W, height: HEAD_H, zIndex: 12, background: "var(--fnd-panel-2)", borderRight: "1px solid var(--fnd-border)", float: "left" }}>
              <div className="fnd-label px-2" style={{ height: GROUP, display: "flex", alignItems: "center" }}>IDENTITY / ONTOLOGY OBJECT</div>
              {METADATA.map(m => <button key={m.key} role="columnheader" className="absolute text-left text-[10px] font-semibold fnd-row-hover" style={{ top: GROUP, left: m.left, width: m.width, height: HEADER, padding: "0 6px", borderRight: "1px solid var(--fnd-border)" }} onClick={() => toggleSort(m.key === "time" ? "eventTime" : m.key as TelemetrySort["property"])}>{m.title}{sort.property === (m.key === "time" ? "eventTime" : m.key) ? sort.direction === "asc" ? " ↑" : " ↓" : ""}</button>)}
            </div>
            {groupSpans.map(g => <button key={g.group} className="absolute fnd-label text-left px-2 fnd-row-hover" style={{ top: 0, left: META_W + g.start * CELL, height: GROUP, width: g.count * CELL, borderLeft: "1px solid var(--fnd-border)" }} onClick={() => setGroupHeader(x => !x)} title="Toggle subsystem bands">{groupHeader ? GROUPS[g.group] : `Signals ${g.start + 1}–${g.start + g.count}`}</button>)}
            {windowColumns.map((signal, j) => { const at = firstCol + j; return <button key={signal} role="columnheader" className="absolute text-[10px] font-semibold fnd-row-hover truncate" style={{ top: GROUP, left: META_W + at * CELL, width: CELL, height: HEADER, padding: "0 6px", borderLeft: "1px solid var(--fnd-border)" }} title={`Sort by ${colNames[signal]}`} onClick={() => toggleSort("signal", signal)}>{colNames[signal]}{sort.property === "signal" && sort.signal === signal ? sort.direction === "asc" ? " ↑" : " ↓" : ""}</button>; })}
          </div>
          {rows.map((r, i) => {
            const index = firstRow + i, selected = selectedRow === index || !!(values[cfg.assetVarId ?? "selectedAsset"] as { id?: string } | null)?.id && (values[cfg.assetVarId ?? "selectedAsset"] as { id?: string })?.id === r.assetId;
            return <div key={index} role="row" aria-rowindex={index + 1} aria-selected={!!selected} className="fnd-row-hover" onClick={() => select(r, index)}
              style={{ position: "absolute", top: HEAD_H + index * rowHeight, width, height: rowHeight, borderBottom: "1px solid var(--fnd-border)", background: selected ? "var(--fnd-selection)" : "var(--fnd-panel)", cursor: "pointer" }}>
              <div style={{ position: "sticky", left: 0, width: META_W, height: rowHeight, zIndex: 3, background: selected ? "var(--fnd-selection)" : "var(--fnd-panel)", borderRight: "1px solid var(--fnd-border)" }}>
                {[r.plant, r.device, r.assetId, r.status, new Date(r.time).toLocaleTimeString()].map((v, j) => <div key={j} role="gridcell" title={v} className="absolute flex items-center truncate text-[11px] tabular-nums px-1.5" style={{ left: METADATA[j].left, width: METADATA[j].width, height: rowHeight, borderRight: "1px solid var(--fnd-border)", fontFamily: j === 1 || j === 2 ? "ui-monospace,monospace" : undefined }}>
                  {j === 3 ? <span className="fnd-tag" style={{ height: 18, fontSize: 10, borderColor: "transparent", ...STATUS_STYLE[r.status] }}>{v}</span> : v}
                </div>)}
              </div>
              {windowColumns.map((signal, j) => <div key={signal} role="gridcell" aria-colindex={6 + firstCol + j} title={`${colNames[signal]}: ${r.values[signal - colFrom]?.toFixed(3) ?? "—"}`} className="absolute flex items-center justify-end pr-2 text-[11px] tabular-nums"
                style={{ left: META_W + (firstCol + j) * CELL, top: 0, width: CELL, height: rowHeight, borderRight: "1px solid var(--fnd-border)", color: signal < 10 && r.values[signal - colFrom] > 11.5 ? "var(--fnd-danger)" : undefined, fontFamily: "ui-monospace,monospace" }}>{r.values[signal - colFrom]?.toFixed(2) ?? "—"}</div>)}
            </div>;
          })}
          {stateReady && query && rowCount === 0 && <div style={{ position: "absolute", top: HEAD_H + 24, left: 20 }} className="text-xs fnd-text-muted">No matching telemetry rows. Adjust filters or search.</div>}
        </div>
      </div>
      <div className="flex items-center gap-3 px-2.5 border-t fnd-border text-[10px] fnd-text-muted" style={{ height: 25, flexShrink: 0 }}>
        <span>{numberLabel(rowCount)} indexed / {numberLabel(TELEMETRY_COLUMNS)} signals</span>
        <span>· DOM: {rows.length} rows × {windowColumns.length + METADATA.length} cells</span>
        <span>· Query: {query?.ms.toFixed(1) ?? "—"}ms</span>
        <span>· Worker v{telemetryStore.get().version}</span>
        <div className="flex-1"/><span>{wasm ? "WASM stats ready" : "WASM unavailable · JS fallback"}</span>
        {query && query.total > 10000 && <span title="CSV exports at most 10,000 filtered rows at a time">· CSV cap 10k</span>}
      </div>
    </div>
  );
}
