"use client";
import React from "react";

export const Icon = {
  Table: (p: { size?: number }) => svg(p, <><path d="M3 5h14v2H3zM3 9h14v2H3zM3 13h14v2H3z"/></>),
  List: (p: { size?: number }) => svg(p, <><circle cx="4" cy="5" r="1.3"/><circle cx="4" cy="10" r="1.3"/><circle cx="4" cy="15" r="1.3"/><path d="M7 4.5h10v1.2H7zM7 9.5h10v1.2H7zM7 14.5h10v1.2H7z"/></>),
  Grid: (p: { size?: number }) => svg(p, <><rect x="3" y="3" width="6" height="6" rx="1"/><rect x="11" y="3" width="6" height="6" rx="1"/><rect x="3" y="11" width="6" height="6" rx="1"/><rect x="11" y="11" width="6" height="6" rx="1"/></>),
  Object: (p: { size?: number }) => svg(p, <><rect x="3" y="3" width="14" height="14" rx="2" fill="none" stroke="currentColor" strokeWidth="1.4"/><circle cx="10" cy="10" r="2.5"/></>),
  Chart: (p: { size?: number }) => svg(p, <><path d="M3 15l4-5 3 3 5-7 2 2" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/></>),
  Pie: (p: { size?: number }) => svg(p, <><path d="M10 3v7l5 5a7 7 0 10-5 2z" fill="currentColor"/></>),
  Map: (p: { size?: number }) => svg(p, <><path d="M3 5l5-2 4 2 5-2v12l-5 2-4-2-5 2z" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round"/><path d="M8 3v14M12 5v14" fill="none" stroke="currentColor" strokeWidth="1.4"/></>),
  Filter: (p: { size?: number }) => svg(p, <><path d="M3 4h14l-5 7v5l-4 2v-7z" fill="currentColor"/></>),
  Search: (p: { size?: number }) => svg(p, <><circle cx="9" cy="9" r="5" fill="none" stroke="currentColor" strokeWidth="1.6"/><path d="M13 13l4 4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/></>),
  Plus: (p: { size?: number }) => svg(p, <><path d="M10 4v12M4 10h12" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></>),
  Minus: (p: { size?: number }) => svg(p, <><path d="M4 10h12" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></>),
  Chevron: (p: { size?: number; dir?: "right" | "down" | "up" | "left" }) => {
    const d = p.dir ?? "down";
    const rot = d === "right" ? -90 : d === "up" ? 180 : d === "left" ? 90 : 0;
    return svg(p, <g transform={`rotate(${rot} 10 10)`}><path d="M5 8l5 5 5-5" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/></g>);
  },
  More: (p: { size?: number }) => svg(p, <><circle cx="10" cy="4.5" r="1.3"/><circle cx="10" cy="10" r="1.3"/><circle cx="10" cy="15.5" r="1.3"/></>),
  Close: (p: { size?: number }) => svg(p, <><path d="M5 5l10 10M15 5L5 15" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/></>),
  Edit: (p: { size?: number }) => svg(p, <><path d="M3 15l9-9 2 2-9 9H3z" fill="currentColor"/><path d="M13 5l2-2 2 2-2 2z" fill="currentColor"/></>),
  Trash: (p: { size?: number }) => svg(p, <><path d="M4 6h12M8 4h4v2H8zM6 6l1 10h6l1-10" fill="none" stroke="currentColor" strokeWidth="1.4"/></>),
  Copy: (p: { size?: number }) => svg(p, <><rect x="6" y="6" width="10" height="11" rx="1" fill="none" stroke="currentColor" strokeWidth="1.4"/><rect x="3" y="3" width="10" height="11" rx="1" fill="none" stroke="currentColor" strokeWidth="1.4"/></>),
  Undo: (p: { size?: number }) => svg(p, <><path d="M4 10a6 6 0 1112-1" fill="none" stroke="currentColor" strokeWidth="1.6"/><path d="M4 5v5h5" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/></>),
  Redo: (p: { size?: number }) => svg(p, <><path d="M16 10a6 6 0 10-12-1" fill="none" stroke="currentColor" strokeWidth="1.6"/><path d="M16 5v5h-5" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/></>),
  Play: (p: { size?: number }) => svg(p, <><path d="M5 4l12 6-12 6z" fill="currentColor"/></>),
  Settings: (p: { size?: number }) => svg(p, <><circle cx="10" cy="10" r="2.5" fill="none" stroke="currentColor" strokeWidth="1.4"/><path d="M10 2v3M10 15v3M2 10h3M15 10h3M4 4l2 2M14 14l2 2M4 16l2-2M14 6l2-2" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/></>),
  Code: (p: { size?: number }) => svg(p, <><path d="M7 6l-4 4 4 4M13 6l4 4-4 4M11 5l-2 10" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/></>),
  Diagram: (p: { size?: number }) => svg(p, <><rect x="2" y="3" width="5" height="4" rx="1" fill="none" stroke="currentColor" strokeWidth="1.4"/><rect x="13" y="3" width="5" height="4" rx="1" fill="none" stroke="currentColor" strokeWidth="1.4"/><rect x="7.5" y="13" width="5" height="4" rx="1" fill="none" stroke="currentColor" strokeWidth="1.4"/><path d="M4.5 7v3h11V7M10 10v3" fill="none" stroke="currentColor" strokeWidth="1.4"/></>),
  Metric: (p: { size?: number }) => svg(p, <><text x="4" y="14" fontSize="12" fontWeight="700" fill="currentColor">42</text></>),
  Button: (p: { size?: number }) => svg(p, <><rect x="3" y="7" width="14" height="6" rx="2" fill="none" stroke="currentColor" strokeWidth="1.4"/><path d="M7 10h6" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/></>),
  Tabs: (p: { size?: number }) => svg(p, <><rect x="3" y="7" width="14" height="10" rx="1" fill="none" stroke="currentColor" strokeWidth="1.4"/><path d="M3 7l3-3h3l1 3M9 4h3l1 3" fill="none" stroke="currentColor" strokeWidth="1.4"/></>),
  Input: (p: { size?: number }) => svg(p, <><rect x="2" y="6" width="16" height="8" rx="1" fill="none" stroke="currentColor" strokeWidth="1.4"/><path d="M5 10v-2M5 10v2" stroke="currentColor" strokeWidth="1.4"/></>),
  Dropdown: (p: { size?: number }) => svg(p, <><rect x="2" y="6" width="16" height="8" rx="1" fill="none" stroke="currentColor" strokeWidth="1.4"/><path d="M13 9l2 2 2-2" fill="none" stroke="currentColor" strokeWidth="1.4"/></>),
  Check: (p: { size?: number }) => svg(p, <><path d="M4 10l4 4 8-9" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></>),
  Timeline: (p: { size?: number }) => svg(p, <><path d="M2 10h16" stroke="currentColor" strokeWidth="1.4"/><circle cx="6" cy="10" r="2" fill="currentColor"/><circle cx="12" cy="10" r="2" fill="currentColor"/></>),
  Gantt: (p: { size?: number }) => svg(p, <><rect x="2" y="4" width="10" height="2" fill="currentColor"/><rect x="5" y="8" width="12" height="2" fill="currentColor"/><rect x="3" y="12" width="7" height="2" fill="currentColor"/></>),
  Markdown: (p: { size?: number }) => svg(p, <><rect x="2" y="4" width="16" height="12" rx="1" fill="none" stroke="currentColor" strokeWidth="1.4"/><text x="4" y="13" fontSize="7" fontWeight="700" fill="currentColor">M↓</text></>),
  Pdf: (p: { size?: number }) => svg(p, <><rect x="4" y="2" width="12" height="16" rx="1" fill="none" stroke="currentColor" strokeWidth="1.4"/><text x="6" y="13" fontSize="5" fontWeight="700" fill="currentColor">PDF</text></>),
  Comment: (p: { size?: number }) => svg(p, <><path d="M3 4h14v10h-7l-4 3v-3H3z" fill="none" stroke="currentColor" strokeWidth="1.4"/></>),
  Upload: (p: { size?: number }) => svg(p, <><path d="M10 3v10M6 7l4-4 4 4M3 17h14" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/></>),
  AI: (p: { size?: number }) => svg(p, <><path d="M10 2l2 5 5 2-5 2-2 5-2-5-5-2 5-2z" fill="currentColor"/></>),
  Embed: (p: { size?: number }) => svg(p, <><rect x="2" y="4" width="16" height="12" rx="1" fill="none" stroke="currentColor" strokeWidth="1.4"/><circle cx="5" cy="6.5" r="0.6" fill="currentColor"/><circle cx="7" cy="6.5" r="0.6" fill="currentColor"/></>),
  Lock: (p: { size?: number }) => svg(p, <><rect x="5" y="9" width="10" height="8" rx="1" fill="none" stroke="currentColor" strokeWidth="1.4"/><path d="M7 9V7a3 3 0 016 0v2" fill="none" stroke="currentColor" strokeWidth="1.4"/></>),
  Warning: (p: { size?: number }) => svg(p, <><path d="M10 3l8 14H2z" fill="none" stroke="currentColor" strokeWidth="1.4"/><path d="M10 8v4M10 14v1" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/></>),
  Save: (p: { size?: number }) => svg(p, <><path d="M3 3h11l3 3v11H3z" fill="none" stroke="currentColor" strokeWidth="1.4"/><rect x="6" y="3" width="7" height="5" fill="none" stroke="currentColor" strokeWidth="1.4"/></>),
  Eye: (p: { size?: number }) => svg(p, <><path d="M1 10c3-5 15-5 18 0-3 5-15 5-18 0z" fill="none" stroke="currentColor" strokeWidth="1.4"/><circle cx="10" cy="10" r="2.5" fill="currentColor"/></>),
  Flow: (p: { size?: number }) => svg(p, <><rect x="2" y="3" width="16" height="3" rx="1" fill="currentColor" opacity="0.7"/><rect x="2" y="8" width="16" height="3" rx="1" fill="currentColor" opacity="0.5"/><rect x="2" y="13" width="16" height="3" rx="1" fill="currentColor" opacity="0.3"/></>),
  Overlay: (p: { size?: number }) => svg(p, <><rect x="2" y="3" width="12" height="12" fill="none" stroke="currentColor" strokeWidth="1.4"/><rect x="7" y="7" width="11" height="10" fill="currentColor" opacity="0.3" stroke="currentColor" strokeWidth="1.4"/></>),
  Section: (p: { size?: number }) => svg(p, <><rect x="2" y="3" width="16" height="14" rx="1" fill="none" stroke="currentColor" strokeWidth="1.4"/><rect x="2" y="3" width="16" height="4" fill="currentColor" opacity="0.2"/></>),
  Variable: (p: { size?: number }) => svg(p, <><text x="4" y="14" fontSize="12" fontWeight="700" fontStyle="italic" fill="currentColor">x</text><circle cx="14" cy="7" r="3" fill="none" stroke="currentColor" strokeWidth="1.4"/></>),
  Event: (p: { size?: number }) => svg(p, <><path d="M11 3l-6 9h4l-2 5 6-9h-4z" fill="currentColor"/></>),
  Action: (p: { size?: number }) => svg(p, <><circle cx="10" cy="10" r="7" fill="none" stroke="currentColor" strokeWidth="1.4"/><path d="M8 7l5 3-5 3z" fill="currentColor"/></>),
  Dot: (p: { size?: number; color?: string }) => (
    <span style={{ display: "inline-block", width: 8, height: 8, borderRadius: "50%", background: p.color ?? "currentColor" }}/>
  ),
};

function svg(p: { size?: number }, children: React.ReactNode) {
  const s = p.size ?? 14;
  return <svg width={s} height={s} viewBox="0 0 20 20" fill="currentColor" aria-hidden>{children}</svg>;
}
