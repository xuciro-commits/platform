"use client";
import React, { useMemo, useState } from "react";
import { useCore } from "../WorkshopContext";
import type { WidgetDef } from "../types";
import type { AssetObj } from "../ontology";
import { Icon } from "./icons";
import { MoreWidget } from "./MoreWidgets";

function StatusPill({ status }: { status: string }) {
  const map: Record<string, { bg: string; fg: string }> = {
    Active: { bg: "#e4f1e5", fg: "#296936" }, Warning: { bg: "#fdf1dc", fg: "#8a5a16" },
    Offline: { bg: "#fde0e0", fg: "#8a1f1f" }, Maintenance: { bg: "#e3ecfa", fg: "#1e4a85" },
  };
  const c = map[status] ?? { bg: "#e9ecef", fg: "#555" };
  return <span className="fnd-tag" style={{ background: c.bg, color: c.fg, borderColor: "transparent", fontWeight: 600 }}>{status}</span>;
}

function Shell({ title, icon, extra, children }: { title: string; icon?: React.ReactNode; extra?: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="fnd-panel rounded-sm h-full flex flex-col overflow-hidden">
      <div className="flex items-center gap-2 px-2.5 py-1.5 border-b fnd-border">
        {icon}<div className="text-xs font-semibold truncate">{title}</div>
        <div className="flex-1"/>{extra}
      </div>
      <div className="flex-1 overflow-auto p-3">{children}</div>
    </div>
  );
}

function asAssets(v: unknown): AssetObj[] {
  return Array.isArray(v) ? (v as AssetObj[]) : [];
}

export function ChartVega({ widget }: { widget: WidgetDef }) {
  const { values } = useCore();
  const cfg = widget.config as { objectSetVarId: string };
  const data = asAssets(values[cfg.objectSetVarId]);
  const groups: Record<string, number> = {};
  for (const a of data) groups[a.status] = (groups[a.status] || 0) + 1;
  const entries = Object.entries(groups);
  const max = Math.max(1, ...entries.map(([, n]) => n));
  return (
    <Shell title={widget.name} icon={<Icon.Chart size={14}/>} extra={<span className="fnd-tag">Vega-Lite</span>}>
      <div className="text-[10px] fnd-text-dim mb-2 font-mono">{`{ "mark": "bar", "encoding": { "x": "status", "y": "count" } }`}</div>
      <div className="space-y-1">
        {entries.map(([k, n]) => (
          <div key={k} className="flex items-center gap-2 text-xs">
            <span style={{ width: 90 }}>{k}</span>
            <div className="flex-1 h-4" style={{ background: "var(--fnd-panel-2)" }}>
              <div style={{ width: `${(n / max) * 100}%`, height: "100%", background: "var(--fnd-accent)" }}/>
            </div>
            <span className="tabular-nums fnd-text-muted" style={{ width: 28 }}>{n}</span>
          </div>
        ))}
      </div>
    </Shell>
  );
}

export function ChartWaterfall({ widget }: { widget: WidgetDef }) {
  const { values } = useCore();
  const cfg = widget.config as { objectSetVarId: string };
  const data = asAssets(values[cfg.objectSetVarId]);
  const steps = [
    { label: "Active", n: data.filter(a => a.status === "Active").length, pos: true },
    { label: "Warning", n: -data.filter(a => a.status === "Warning").length, pos: false },
    { label: "Maint.", n: -data.filter(a => a.status === "Maintenance").length, pos: false },
    { label: "Offline", n: -data.filter(a => a.status === "Offline").length, pos: false },
  ];
  let acc = 0;
  const max = Math.max(1, data.length);
  return (
    <Shell title={widget.name} icon={<Icon.Chart size={14}/>}>
      <div className="flex items-end gap-2 h-32">
        {steps.map((s, i) => {
          const start = acc;
          acc += s.n;
          const h = (Math.abs(s.n) / max) * 100;
          return (
            <div key={i} className="flex-1 flex flex-col items-center justify-end" style={{ height: "100%" }}>
              <div style={{ height: `${h}%`, width: "70%", background: s.pos ? "var(--fnd-success)" : "var(--fnd-danger)", opacity: 0.85 }} title={`${s.label} ${s.n}`}/>
              <div className="text-[10px] mt-1 fnd-text-muted">{s.label}</div>
              <div className="text-[10px] tabular-nums">{s.n}</div>
              <div className="text-[9px] fnd-text-dim">Σ {start + s.n}</div>
            </div>
          );
        })}
      </div>
    </Shell>
  );
}

export function MediaPreviewW({ widget }: { widget: WidgetDef }) {
  const { values } = useCore();
  const cfg = widget.config as { outputVarId: string };
  const file = (values[cfg.outputVarId] as string) ?? "";
  return (
    <Shell title={widget.name} icon={<Icon.Eye size={14}/>}>
      {!file ? <div className="text-xs fnd-text-dim text-center py-6">No media uploaded. Use Media Uploader to attach a file.</div> : (
        <div>
          <div className="h-28 rounded-sm mb-2" style={{ background: "linear-gradient(135deg,#c7d4e0,#e8ecf0)" }}/>
          <div className="text-xs font-semibold">{file}</div>
          <div className="text-[11px] fnd-text-muted">image/jpeg · 248 KB</div>
        </div>
      )}
    </Shell>
  );
}

export function ActionLogTimelineW({ widget }: { widget: WidgetDef }) {
  const { ontology } = useCore();
  const logs = ontology.alerts.slice(0, 18).map(a => ({
    id: a.id, ts: a.createdAt, actor: "system", action: a.acknowledged ? "AcknowledgeAlert" : "RaiseAlert", target: a.assetId, detail: a.title,
  }));
  return (
    <Shell title={widget.name} extra={<span className="fnd-tag">{logs.length}</span>}>
      <div className="space-y-1.5">
        {logs.map(l => (
          <div key={l.id} className="flex gap-2 text-xs border-b fnd-border pb-1">
            <span className="fnd-text-dim tabular-nums" style={{ width: 90 }}>{new Date(l.ts).toLocaleTimeString()}</span>
            <span className="fnd-tag" style={{ height: 16 }}>{l.action}</span>
            <span className="truncate flex-1">{l.detail}</span>
            <span className="fnd-text-dim">{l.target}</span>
          </div>
        ))}
      </div>
    </Shell>
  );
}

export function ObservabilityChartW({ widget }: { widget: WidgetDef }) {
  const { values } = useCore();
  const cfg = widget.config as { objectSetVarId: string };
  const data = asAssets(values[cfg.objectSetVarId]);
  const avg = data.length ? data.reduce((s, a) => s + a.availability, 0) / data.length : 0;
  const pts = Array.from({ length: 24 }, (_, i) => 90 + Math.sin(i / 3) * 6 + (i % 5 === 0 ? -4 : 0));
  const w = 420, h = 120, p = 16;
  return (
    <Shell title={widget.name} extra={<span className="fnd-tag">SLO 99.0%</span>}>
      <div className="text-xs mb-2">Availability · current {avg.toFixed(1)}%</div>
      <svg viewBox={`0 0 ${w} ${h}`} width="100%">
        <line x1={p} y1={h / 2} x2={w - p} y2={h / 2} stroke="var(--fnd-danger)" strokeDasharray="3 3" opacity="0.4"/>
        <polyline fill="none" stroke="var(--fnd-success)" strokeWidth="1.6"
          points={pts.map((y, i) => `${p + (i / 23) * (w - p * 2)},${h - p - ((y - 80) / 25) * (h - p * 2)}`).join(" ")}/>
      </svg>
      <div className="text-[10px] fnd-text-dim">Red dashed = SLO floor · last 24h</div>
    </Shell>
  );
}

export function ResourceListW({ widget }: { widget: WidgetDef }) {
  const { values, setValues } = useCore();
  const cfg = widget.config as { objectSetVarId: string; activeVarId?: string };
  const data = asAssets(values[cfg.objectSetVarId]).slice(0, 12);
  return (
    <Shell title={widget.name} extra={<span className="fnd-tag">{data.length}</span>}>
      {data.map(a => (
        <button key={a.id} className="w-full text-left flex items-center gap-2 py-1.5 border-b fnd-border fnd-row-hover"
          onClick={() => cfg.activeVarId && setValues(p => ({ ...p, [cfg.activeVarId!]: a }))}>
          <Icon.Object size={12}/>
          <span className="text-xs font-medium flex-1 truncate">{a.name}</span>
          <StatusPill status={a.status}/>
        </button>
      ))}
    </Shell>
  );
}

export function LinkedCompassW({ widget }: { widget: WidgetDef }) {
  const cfg = widget.config as { title?: string };
  return (
    <Shell title={cfg.title ?? widget.name} icon={<Icon.Embed size={14}/>} extra={<span className="fnd-tag">Compass</span>}>
      <div className="text-xs space-y-1">
        {["Operations / Assets", "Operations / Alerts", "Playbooks / SOP-14", "Datasets / telemetry_q3"].map(p => (
          <div key={p} className="flex items-center gap-2 py-1 border-b fnd-border"><Icon.Flow size={11}/><span>{p}</span></div>
        ))}
      </div>
    </Shell>
  );
}

export function ExplorationFilterW({ widget }: { widget: WidgetDef }) {
  const { values, setValues } = useCore();
  const cfg = widget.config as { variableId: string };
  const sel = ((values[cfg.variableId] as string[]) ?? []);
  const opts = ["Active", "Warning", "Offline", "Maintenance"];
  return (
    <div className="flex flex-wrap gap-1">
      {opts.map(o => {
        const on = sel.includes(o);
        return (
          <button key={o} onClick={() => setValues(p => ({ ...p, [cfg.variableId]: on ? sel.filter(x => x !== o) : [...sel, o] }))}
            className="fnd-tag" style={{ height: 22, cursor: "pointer", background: on ? "var(--fnd-selection)" : undefined, borderColor: on ? "var(--fnd-accent)" : undefined }}>
            {o}{on ? " ×" : ""}
          </button>
        );
      })}
      {sel.length > 0 && <button className="fnd-btn fnd-btn-minimal" style={{ height: 22 }} onClick={() => setValues(p => ({ ...p, [cfg.variableId]: [] }))}>Clear</button>}
    </div>
  );
}

export function ExplorationSearchW({ widget }: { widget: WidgetDef }) {
  const { values, setValues } = useCore();
  const cfg = widget.config as { variableId: string };
  return (
    <div className="relative">
      <input className="fnd-input" style={{ height: 32, paddingLeft: 28 }} placeholder="Search objects across the Ontology…"
        value={(values[cfg.variableId] as string) ?? ""} onChange={e => setValues(p => ({ ...p, [cfg.variableId]: e.target.value }))}/>
      <span style={{ position: "absolute", left: 8, top: 9, color: "var(--fnd-text-dim)" }}><Icon.Search size={13}/></span>
    </div>
  );
}

export function ProminentTermsW({ widget }: { widget: WidgetDef }) {
  const { values } = useCore();
  const cfg = widget.config as { objectSetVarId: string; property?: string };
  const data = asAssets(values[cfg.objectSetVarId]);
  const prop = cfg.property ?? "status";
  const counts: Record<string, number> = {};
  for (const a of data) {
    const k = String((a as unknown as Record<string, unknown>)[prop] ?? "—");
    counts[k] = (counts[k] || 0) + 1;
  }
  const terms = Object.entries(counts).sort((a, b) => b[1] - a[1]);
  const max = terms[0]?.[1] ?? 1;
  return (
    <Shell title={widget.name}>
      <div className="flex flex-wrap gap-2 items-end">
        {terms.map(([k, n]) => (
          <span key={k} className="fnd-tag" style={{ fontSize: 10 + (n / max) * 8, height: "auto", padding: "4px 8px" }}>{k} · {n}</span>
        ))}
        {terms.length === 0 && <div className="text-xs fnd-text-dim">No terms in the current object set.</div>}
      </div>
    </Shell>
  );
}

export function ObjectSelectorW({ widget }: { widget: WidgetDef }) {
  const { values, setValues } = useCore();
  const cfg = widget.config as { objectSetVarId: string; activeVarId?: string; label?: string };
  const data = asAssets(values[cfg.objectSetVarId]);
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const active = cfg.activeVarId ? (values[cfg.activeVarId] as AssetObj | null) : null;
  const filtered = data.filter(a => !q || a.name.toLowerCase().includes(q.toLowerCase()) || a.id.toLowerCase().includes(q.toLowerCase())).slice(0, 20);
  return (
    <div>
      {cfg.label && <label className="fnd-field-label">{cfg.label}</label>}
      <div className="relative">
        <button className="fnd-input text-left flex items-center" onClick={() => setOpen(o => !o)}>
          <span className="flex-1 truncate">{active ? `${active.name} (${active.id})` : "Select object…"}</span>
          <Icon.Chevron size={12}/>
        </button>
        {open && (
          <div className="fnd-panel" style={{ position: "absolute", zIndex: 20, left: 0, right: 0, top: 30, maxHeight: 220, overflow: "auto", boxShadow: "0 6px 18px rgba(0,0,0,0.12)" }}>
            <div className="p-1"><input className="fnd-input" autoFocus placeholder="Search…" value={q} onChange={e => setQ(e.target.value)}/></div>
            {filtered.length === 0 && <div className="p-2 text-xs fnd-text-dim">No matching objects.</div>}
            {filtered.map(a => (
              <button key={a.id} className="w-full text-left px-2 py-1 text-xs fnd-row-hover" onClick={() => { cfg.activeVarId && setValues(p => ({ ...p, [cfg.activeVarId!]: a })); setOpen(false); }}>
                {a.name} <span className="fnd-text-dim">{a.id}</span>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export function DateTimePickerW({ widget }: { widget: WidgetDef }) {
  const { values, setValues } = useCore();
  const cfg = widget.config as { variableId: string; label?: string };
  return (
    <div>
      {cfg.label && <label className="fnd-field-label">{cfg.label}</label>}
      <input className="fnd-input" type="datetime-local" value={String(values[cfg.variableId] ?? "").slice(0, 16)}
        onChange={e => setValues(p => ({ ...p, [cfg.variableId]: e.target.value }))}/>
    </div>
  );
}

export function MultiSelectorW({ widget }: { widget: WidgetDef }) {
  const { values, setValues } = useCore();
  const cfg = widget.config as { variableId: string; options?: string[]; label?: string };
  const sel = ((values[cfg.variableId] as string[]) ?? []);
  const opts = cfg.options ?? [];
  return (
    <div>
      {cfg.label && <label className="fnd-field-label">{cfg.label}</label>}
      <div className="flex flex-wrap gap-1">
        {opts.map(o => {
          const on = sel.includes(o);
          return (
            <button key={o} className="fnd-btn" style={{ height: 24, background: on ? "var(--fnd-selection)" : undefined }}
              onClick={() => setValues(p => ({ ...p, [cfg.variableId]: on ? sel.filter(x => x !== o) : [...sel, o] }))}>{o}</button>
          );
        })}
      </div>
    </div>
  );
}

export function FreeFormAnalysisW({ widget }: { widget: WidgetDef }) {
  const { values } = useCore();
  const cfg = widget.config as { objectSetVarId: string };
  const data = asAssets(values[cfg.objectSetVarId]);
  const [x, setX] = useState("pressure");
  const [y, setY] = useState("temperature");
  const pts = data.slice(0, 80);
  const xs = pts.map(a => Number((a as unknown as Record<string, unknown>)[x]) || 0);
  const ys = pts.map(a => Number((a as unknown as Record<string, unknown>)[y]) || 0);
  const minX = Math.min(...xs, 0), maxX = Math.max(...xs, 1);
  const minY = Math.min(...ys, 0), maxY = Math.max(...ys, 1);
  return (
    <Shell title={widget.name} extra={
      <div className="flex gap-1">
        <select className="fnd-input fnd-select" style={{ width: 90, height: 22 }} value={x} onChange={e => setX(e.target.value)}>
          {["pressure", "temperature", "availability", "revenueImpact"].map(k => <option key={k}>{k}</option>)}
        </select>
        <span className="fnd-text-dim">×</span>
        <select className="fnd-input fnd-select" style={{ width: 90, height: 22 }} value={y} onChange={e => setY(e.target.value)}>
          {["pressure", "temperature", "availability", "revenueImpact"].map(k => <option key={k}>{k}</option>)}
        </select>
      </div>
    }>
      <svg viewBox="0 0 360 180" width="100%">
        <line x1="24" y1="160" x2="350" y2="160" stroke="var(--fnd-border)"/>
        <line x1="24" y1="10" x2="24" y2="160" stroke="var(--fnd-border)"/>
        {pts.map((a, i) => {
          const px = 24 + ((xs[i] - minX) / (maxX - minX || 1)) * 320;
          const py = 160 - ((ys[i] - minY) / (maxY - minY || 1)) * 140;
          return <circle key={a.id} cx={px} cy={py} r="3" fill="var(--fnd-accent)" opacity="0.7"/>;
        })}
      </svg>
    </Shell>
  );
}

export function TimeSeriesAnalysisW({ widget }: { widget: WidgetDef }) {
  const { values } = useCore();
  const cfg = widget.config as { objectSetVarId: string };
  const data = asAssets(values[cfg.objectSetVarId]);
  const series = ["pressure", "temperature", "availability"].map((k, si) => {
    const pts = Array.from({ length: 30 }, (_, i) => {
      const base = data.length ? Number((data[i % data.length] as unknown as Record<string, unknown>)[k]) || 0 : 50;
      return base + Math.sin(i / 4 + si) * 4;
    });
    return { k, pts };
  });
  const colors = ["#2b6cb0", "#d9822b", "#0f9960"];
  return (
    <Shell title={widget.name} extra={<span className="fnd-tag">3 series</span>}>
      <svg viewBox="0 0 420 160" width="100%">
        {series.map((s, si) => {
          const max = Math.max(...s.pts, 1), min = Math.min(...s.pts, 0);
          return <polyline key={s.k} fill="none" stroke={colors[si]} strokeWidth="1.5"
            points={s.pts.map((y, i) => `${16 + (i / 29) * 390},${140 - ((y - min) / (max - min || 1)) * 120}`).join(" ")}/>;
        })}
      </svg>
      <div className="flex gap-3 text-[11px] mt-1">
        {series.map((s, i) => <span key={s.k} className="flex items-center gap-1"><span style={{ width: 8, height: 8, background: colors[i] }}/>{s.k}</span>)}
      </div>
    </Shell>
  );
}

export function ImageAnnotationW({ widget }: { widget: WidgetDef }) {
  const { values } = useCore();
  const cfg = widget.config as { objectVarId: string };
  const obj = values[cfg.objectVarId] as AssetObj | null;
  const [boxes, setBoxes] = useState([{ x: 20, y: 30, w: 80, h: 40, label: "hotspot" }]);
  return (
    <Shell title={widget.name} extra={obj ? <span className="fnd-tag">{obj.id}</span> : undefined}>
      <div className="relative rounded-sm overflow-hidden" style={{ height: 160, background: "linear-gradient(135deg,#9fb3c8,#d5dde4)" }}
        onClick={e => {
          const r = (e.currentTarget as HTMLDivElement).getBoundingClientRect();
          setBoxes(b => [...b, { x: e.clientX - r.left - 20, y: e.clientY - r.top - 12, w: 60, h: 28, label: "mark" }]);
        }}>
        {boxes.map((b, i) => (
          <div key={i} style={{ position: "absolute", left: b.x, top: b.y, width: b.w, height: b.h, border: "1.5px solid #c23030", background: "rgba(194,48,48,0.12)", fontSize: 9, color: "#8a1f1f", padding: 2 }}>{b.label}</div>
        ))}
      </div>
      <div className="text-[10px] fnd-text-dim mt-1">Click image to add annotation boxes · {boxes.length} region(s)</div>
    </Shell>
  );
}

export function DerivedSeriesW({ widget }: { widget: WidgetDef }) {
  const { values } = useCore();
  const cfg = widget.config as { objectSetVarId: string };
  const data = asAssets(values[cfg.objectSetVarId]);
  const avgP = data.length ? data.reduce((s, a) => s + a.pressure, 0) / data.length : 0;
  return (
    <Shell title={widget.name} extra={<span className="fnd-tag">derived</span>}>
      <div className="text-xs space-y-1">
        <div>Source object set: <strong>@{cfg.objectSetVarId}</strong> ({data.length})</div>
        <div>Expression: <code className="fnd-tag">mean(pressure)</code></div>
        <div className="text-lg font-bold tabular-nums">{avgP.toFixed(2)} bar</div>
      </div>
    </Shell>
  );
}

export function QuiverDashboardW({ widget }: { widget: WidgetDef }) {
  const cfg = widget.config as { title?: string };
  return (
    <Shell title={cfg.title ?? widget.name} icon={<Icon.Chart size={14}/>} extra={<span className="fnd-tag">Quiver</span>}>
      <div className="grid grid-cols-3 gap-2 mb-2">
        {["MTBF 142h", "MTTR 3.4h", "WO cycle 18h"].map(k => <div key={k} className="fnd-panel-2 p-2 text-xs font-semibold rounded-sm">{k}</div>)}
      </div>
      <div className="h-20 rounded-sm" style={{ background: "repeating-linear-gradient(90deg, var(--fnd-panel-2) 0 12px, var(--fnd-hover) 12px 24px)" }}/>
      <div className="text-[10px] fnd-text-dim mt-1">Embedded Quiver analysis · live</div>
    </Shell>
  );
}

export function VertexGraphW({ widget }: { widget: WidgetDef }) {
  const { values, ontology } = useCore();
  const cfg = widget.config as { objectVarId: string };
  const obj = values[cfg.objectVarId] as AssetObj | null;
  const sensors = obj ? ontology.sensors.filter(s => s.assetId === obj.id).slice(0, 4) : [];
  const alerts = obj ? ontology.alerts.filter(a => a.assetId === obj.id).slice(0, 3) : [];
  return (
    <Shell title={widget.name} extra={<span className="fnd-tag">Vertex</span>}>
      {!obj ? <div className="text-xs fnd-text-dim">Select an object to render its neighborhood graph.</div> : (
        <svg viewBox="0 0 360 180" width="100%">
          <circle cx="180" cy="90" r="22" fill="var(--fnd-accent)"/>
          <text x="180" y="94" textAnchor="middle" fontSize="8" fill="white">{obj.id}</text>
          {sensors.map((s, i) => {
            const a = (i / Math.max(1, sensors.length)) * Math.PI - Math.PI / 2;
            const x = 180 + Math.cos(a) * 90, y = 90 + Math.sin(a) * 55;
            return <g key={s.id}><line x1="180" y1="90" x2={x} y2={y} stroke="var(--fnd-border-strong)"/><circle cx={x} cy={y} r="12" fill="#0f9960"/><text x={x} y={y + 3} textAnchor="middle" fontSize="7" fill="white">S</text></g>;
          })}
          {alerts.map((al, i) => {
            const a = Math.PI / 2 + (i / Math.max(1, alerts.length)) * Math.PI;
            const x = 180 + Math.cos(a) * 90, y = 90 + Math.sin(a) * 55;
            return <g key={al.id}><line x1="180" y1="90" x2={x} y2={y} stroke="var(--fnd-border-strong)"/><circle cx={x} cy={y} r="12" fill="#c23030"/><text x={x} y={y + 3} textAnchor="middle" fontSize="7" fill="white">A</text></g>;
          })}
        </svg>
      )}
    </Shell>
  );
}

export function NotepadEmbedW({ widget }: { widget: WidgetDef }) {
  const [text, setText] = useState("## Shift handover\n\n- Compressor A-104 showing elevated pressure\n- WO-02012 assigned to Jane Smith\n- Await parts ETA 02 Oct");
  return (
    <Shell title={widget.name} extra={<span className="fnd-tag">Notepad</span>}>
      <textarea className="fnd-input" style={{ height: 140, fontFamily: "ui-monospace, Menlo, monospace", fontSize: 11 }} value={text} onChange={e => setText(e.target.value)}/>
    </Shell>
  );
}

export function MapTemplateW({ widget }: { widget: WidgetDef }) {
  const { values, setValues } = useCore();
  const cfg = widget.config as { objectSetVarId: string; activeVarId?: string };
  const data = asAssets(values[cfg.objectSetVarId]);
  return (
    <Shell title="Map Application" extra={<span className="fnd-tag">template</span>}>
      <div className="text-[11px] fnd-text-muted mb-2">Foundry Map template · {data.length} features · click to select</div>
      <div className="grid grid-cols-4 gap-1">
        {data.slice(0, 8).map(a => (
          <button key={a.id} className="fnd-panel-2 p-1 text-[10px] truncate" onClick={() => cfg.activeVarId && setValues(p => ({ ...p, [cfg.activeVarId!]: a }))}>{a.name}</button>
        ))}
      </div>
    </Shell>
  );
}

export function ActionTableW({ widget }: { widget: WidgetDef }) {
  const { values, ontologyMeta: meta, executeAction, requestConfirm } = useCore();
  const cfg = widget.config as { actionId: string; objectSetVarId: string };
  const at = meta.actionTypes.find(a => a.apiName === cfg.actionId);
  const rows = asAssets(values[cfg.objectSetVarId]).slice(0, 50);
  const [staged, setStaged] = useState<Record<string, Record<string, unknown>>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  if (!at) return <div className="fnd-panel p-3 text-xs" style={{ color: "var(--fnd-danger)" }}>⚠ Action type “{cfg.actionId}” not found in the Ontology.</div>;
  const objParam = at.parameters[0];
  const fields = at.parameters.slice(1);
  const setCell = (id: string, field: string, val: unknown, orig: unknown) => setStaged(s => {
    const r = { ...(s[id] ?? {}), [field]: val };
    if (String(val) === String(orig)) delete r[field];
    const n = { ...s };
    if (Object.keys(r).length) n[id] = r; else delete n[id];
    return n;
  });
  const count = Object.keys(staged).length;
  const submit = () => requestConfirm({
    title: "Submit changes", message: `Run “${at.displayName}” for ${count} object(s).`, impact: ["Each row is validated independently; failures stay staged with the message shown."],
    onConfirm: () => {
      setBusy(true);
      setTimeout(() => {
        const keep: typeof staged = {}; const errs: Record<string, string> = {};
        for (const [id, patch] of Object.entries(staged)) {
          const row = rows.find(r => r.id === id) as unknown as Record<string, unknown> | undefined;
          const params: Record<string, unknown> = { [objParam.apiName]: id };
          for (const p of fields) params[p.apiName] = row?.[p.apiName];
          const res = executeAction(at.apiName, { ...params, ...patch });
          if (!res.ok) { keep[id] = patch; errs[id] = res.errors[0] ?? "Validation failed"; }
        }
        setStaged(keep); setErrors(errs); setBusy(false);
      }, 200);
    },
  });
  return (
    <Shell title={at.displayName} extra={<span className="fnd-tag">{count} staged</span>}>
      <div className="overflow-auto" style={{ maxHeight: 360 }}>
        <table className="w-full text-xs">
          <thead><tr style={{ background: "var(--fnd-panel-2)" }}><th style={{ textAlign: "left", padding: 4 }}>Object</th>{fields.map(f => <th key={f.apiName} style={{ textAlign: "left", padding: 4 }}>{f.displayName}</th>)}</tr></thead>
          <tbody>
            {rows.map(r => {
              const rec = r as unknown as Record<string, unknown>;
              return (
                <tr key={r.id} title={errors[r.id]} style={{ borderBottom: "1px solid var(--fnd-border)", background: errors[r.id] ? "rgba(194,48,48,.12)" : staged[r.id] ? "rgba(255,196,87,.14)" : undefined }}>
                  <td style={{ padding: 4, whiteSpace: "nowrap" }}>{r.id}{errors[r.id] && <div className="text-[10px]" style={{ color: "var(--fnd-danger)" }}>{errors[r.id]}</div>}</td>
                  {fields.map(f => {
                    const cur = staged[r.id]?.[f.apiName] ?? rec[f.apiName];
                    return (
                      <td key={f.apiName} style={{ padding: 2 }}>
                        {f.validation.allowedValues ? (
                          <select className="fnd-input fnd-select" value={String(cur ?? "")} onChange={e => setCell(r.id, f.apiName, e.target.value, rec[f.apiName])}>{f.validation.allowedValues.map(o => <option key={o}>{o}</option>)}</select>
                        ) : (
                          <input className="fnd-input" type={f.type === "Double" || f.type === "Integer" ? "number" : "text"} value={String(cur ?? "")} onChange={e => setCell(r.id, f.apiName, f.type === "Double" || f.type === "Integer" ? Number(e.target.value) : e.target.value, rec[f.apiName])}/>
                        )}
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
        {rows.length === 0 && <div className="p-4 text-center fnd-text-dim">No objects in the bound set.</div>}
      </div>
      <div className="flex justify-end gap-2 mt-2">
        <button className="fnd-btn" disabled={!count} onClick={() => { setStaged({}); setErrors({}); }}>Cancel</button>
        <button className="fnd-btn fnd-btn-primary" disabled={busy || !count} onClick={submit}>{busy ? "Submitting…" : "Submit changes"}</button>
      </div>
    </Shell>
  );
}

export function ExtraWidget({ widget }: { widget: WidgetDef }) {
  switch (widget.type) {
    case "ChartVega": return <ChartVega widget={widget}/>;
    case "ChartWaterfall": return <ChartWaterfall widget={widget}/>;
    case "MediaPreview": return <MediaPreviewW widget={widget}/>;
    case "ActionLogTimeline": return <ActionLogTimelineW widget={widget}/>;
    case "ObservabilityChart": return <ObservabilityChartW widget={widget}/>;
    case "ResourceList": return <ResourceListW widget={widget}/>;
    case "LinkedCompass": return <LinkedCompassW widget={widget}/>;
    case "ExplorationFilter": return <ExplorationFilterW widget={widget}/>;
    case "ExplorationSearch": return <ExplorationSearchW widget={widget}/>;
    case "ProminentTerms": return <ProminentTermsW widget={widget}/>;
    case "ObjectSelector": return <ObjectSelectorW widget={widget}/>;
    case "DateTimePicker": return <DateTimePickerW widget={widget}/>;
    case "MultiSelector": return <MultiSelectorW widget={widget}/>;
    case "FreeFormAnalysis": return <FreeFormAnalysisW widget={widget}/>;
    case "TimeSeriesAnalysis": return <TimeSeriesAnalysisW widget={widget}/>;
    case "ImageAnnotation": return <ImageAnnotationW widget={widget}/>;
    case "DerivedSeries": return <DerivedSeriesW widget={widget}/>;
    case "QuiverDashboard": return <QuiverDashboardW widget={widget}/>;
    case "VertexGraph": return <VertexGraphW widget={widget}/>;
    case "NotepadEmbed": return <NotepadEmbedW widget={widget}/>;
    case "MapTemplate": return <MapTemplateW widget={widget}/>;
    case "ActionTable": return <ActionTableW widget={widget}/>;
    default:
      return <MoreWidget widget={widget}/>;
  }
}
