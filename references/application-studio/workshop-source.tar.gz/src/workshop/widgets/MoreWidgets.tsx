"use client";
import React, { useMemo, useState } from "react";
import { useCore } from "../WorkshopContext";
import type { WidgetDef, EventAction, FilterOp } from "../types";
import { Icon } from "./icons";
import { applyWhereClauses, formatPropertyValue, linkTypesFor, objectTypeOf, pivotTo, primaryKeyOf, propertyOf, titleOf, type Obj, type WhereClause } from "../ontologyMeta";
import { ValuePill, PropertyValue } from "./OntologyWidgets";

function Shell({ title, icon, extra, children, pad = true }: { title: string; icon?: React.ReactNode; extra?: React.ReactNode; children: React.ReactNode; pad?: boolean }) {
  return (
    <div className="fnd-panel rounded-sm h-full flex flex-col overflow-hidden">
      <div className="flex items-center gap-2 px-2.5 border-b fnd-border" style={{ height: 34, flexShrink: 0 }}>
        {icon}<div className="text-xs font-semibold truncate">{title}</div><div className="flex-1"/>{extra}
      </div>
      <div className={`flex-1 overflow-auto ${pad ? "p-3" : ""}`}>{children}</div>
    </div>
  );
}
const arr = (v: unknown): Obj[] => (Array.isArray(v) ? (v as Obj[]) : []);
const num = (o: Obj, k: string) => Number(o[k]) || 0;
const PALETTE = ["#2b6cb0", "#d9822b", "#0f9960", "#c23030", "#7157d9", "#5c7080", "#137cbd", "#8f398f"];

// ─── Kanban (drag card → Action) ──────────────────────────────────────────
function KanbanBoard({ widget }: { widget: WidgetDef }) {
  const { values, ontologyMeta: meta, executeAction, setValues } = useCore();
  const cfg = widget.config as { objectSetVarId: string; groupBy: string; actionId?: string; actionParam?: string; activeVarId?: string };
  const data = arr(values[cfg.objectSetVarId]);
  const type = String(data[0]?.__type ?? "Asset");
  const def = propertyOf(meta, type, cfg.groupBy);
  const columns: string[] = [...new Set(data.map(o => String(o[cfg.groupBy] ?? "—")))];
  void def;
  const [dragId, setDragId] = useState<string | null>(null);
  const [overCol, setOverCol] = useState<string | null>(null);
  const at = meta.actionTypes.find(a => a.apiName === cfg.actionId);
  const activeId = cfg.activeVarId ? (values[cfg.activeVarId] as Obj | null)?.id : null;

  const move = (id: string, col: string) => {
    const o = data.find(x => String(x.id) === id);
    if (!o || String(o[cfg.groupBy]) === col) return;
    if (!at) return;
    const params: Record<string, unknown> = { [at.parameters[0].apiName]: o.id, [cfg.actionParam ?? cfg.groupBy]: col };
    for (const p of at.parameters) if (params[p.apiName] === undefined && p.defaultFrom?.startsWith("object.")) params[p.apiName] = o[p.defaultFrom.slice(7)];
    executeAction(at.apiName, params);
  };

  return (
    <Shell title={widget.name} icon={<Icon.Grid size={13}/>} extra={<span className="fnd-tag">{at ? `drag → ${at.displayName}` : "read-only"}</span>}>
      <div className="flex gap-2 h-full" style={{ minHeight: 260 }}>
        {columns.map(col => {
          const items = data.filter(o => String(o[cfg.groupBy] ?? "—") === col);
          return (
            <div key={col} className="flex-1 rounded-sm flex flex-col min-w-0"
              style={{ background: overCol === col ? "var(--fnd-selection)" : "var(--fnd-panel-2)", border: `1px ${overCol === col ? "dashed var(--fnd-accent)" : "solid var(--fnd-border)"}` }}
              onDragOver={e => { if (dragId) { e.preventDefault(); e.stopPropagation(); setOverCol(col); } }}
              onDragLeave={() => setOverCol(null)}
              onDrop={e => { e.preventDefault(); e.stopPropagation(); if (dragId) move(dragId, col); setDragId(null); setOverCol(null); }}>
              <div className="flex items-center gap-1 px-2 py-1.5 border-b fnd-border"><ValuePill v={col}/><span className="ml-auto text-[11px] fnd-text-dim">{items.length}</span></div>
              <div className="flex-1 overflow-auto p-1.5 space-y-1" style={{ maxHeight: 360 }}>
                {items.slice(0, 30).map(o => (
                  <div key={String(o.id)} draggable
                    onDragStart={e => { e.stopPropagation(); e.dataTransfer.setData("text/plain", String(o.id)); setDragId(String(o.id)); }}
                    onDragEnd={() => { setDragId(null); setOverCol(null); }}
                    onClick={() => cfg.activeVarId && setValues(p => ({ ...p, [cfg.activeVarId!]: o }))}
                    className="fnd-panel rounded-sm p-1.5 text-[11px]"
                    style={{ cursor: "grab", opacity: dragId === String(o.id) ? 0.4 : 1, outline: activeId === o.id ? "2px solid var(--fnd-accent)" : undefined }}>
                    <div className="font-semibold truncate">{titleOf(meta, o)}</div>
                    <div className="flex items-center gap-1 mt-0.5 fnd-text-muted">
                      <span className="font-mono">{String(o.id)}</span>
                      {o.priority != null && <span className="ml-auto"><ValuePill v={String(o.priority)}/></span>}
                    </div>
                  </div>
                ))}
                {items.length > 30 && <div className="text-[10px] fnd-text-dim text-center">+{items.length - 30} more</div>}
                {items.length === 0 && <div className="text-[10px] fnd-text-dim text-center py-3">Drop here</div>}
              </div>
            </div>
          );
        })}
      </div>
    </Shell>
  );
}

// ─── Approval inbox ───────────────────────────────────────────────────────
function ApprovalInbox({ widget }: { widget: WidgetDef }) {
  const { values, ontologyMeta: meta, executeAction } = useCore();
  const cfg = widget.config as { objectSetVarId: string; approveActionId: string; rejectActionId: string; pendingProperty?: string; doneValue?: string };
  const all = arr(values[cfg.objectSetVarId]);
  const items = all.filter(o => String(o[cfg.pendingProperty ?? "status"]) !== (cfg.doneValue ?? "Done")).slice(0, 25);
  const ap = meta.actionTypes.find(a => a.apiName === cfg.approveActionId);
  const rj = meta.actionTypes.find(a => a.apiName === cfg.rejectActionId);
  return (
    <Shell title={widget.name} icon={<Icon.Check size={13}/>} extra={<span className="fnd-tag">{items.length} pending</span>} pad={false}>
      {items.length === 0 && <div className="p-6 text-center text-xs fnd-text-dim">Inbox zero — nothing awaiting approval.</div>}
      {items.map(o => (
        <div key={String(o.id)} className="flex items-center gap-2 px-3 py-2 border-b fnd-border text-xs fnd-row-hover">
          <div className="flex-1 min-w-0">
            <div className="font-semibold truncate">{titleOf(meta, o)}</div>
            <div className="text-[11px] fnd-text-muted"><span className="font-mono">{String(o.id)}</span> · asset {String(o.assetId ?? "—")} · due {o.due ? new Date(String(o.due)).toLocaleDateString() : "—"}</div>
          </div>
          <ValuePill v={String(o.status ?? "")}/>
          {ap && <button className="fnd-btn fnd-btn-primary" style={{ height: 24 }} onClick={() => executeAction(ap.apiName, { [ap.parameters[0].apiName]: o.id })}>Approve</button>}
          {rj && <button className="fnd-btn fnd-btn-danger" style={{ height: 24 }} onClick={() => executeAction(rj.apiName, { [rj.parameters[0].apiName]: o.id })}>Reject</button>}
        </div>
      ))}
    </Shell>
  );
}

// ─── Search Around explorer ───────────────────────────────────────────────
function GraphExplorer({ widget }: { widget: WidgetDef }) {
  const { values, setValues, ontology, ontologyMeta: meta } = useCore();
  const cfg = widget.config as { objectVarId: string; outputVarId?: string };
  const root = values[cfg.objectVarId] as Obj | null;
  const [path, setPath] = useState<Obj[]>([]);
  const cur = path.length ? path[path.length - 1] : root;
  const links = linkTypesFor(meta, String(cur?.__type ?? ""));
  const [linkApi, setLinkApi] = useState<string>("");
  const active = links.find(l => l.link.apiName === linkApi) ?? links[0];
  const results = cur && active ? pivotTo(ontology, meta, active.link.apiName, [cur]) : [];
  if (!root || typeof root !== "object") return <Shell title={widget.name} icon={<Icon.Diagram size={13}/>}><div className="text-xs fnd-text-dim">Select an object to start a Search Around.</div></Shell>;
  return (
    <Shell title={widget.name} icon={<Icon.Diagram size={13}/>} extra={<span className="fnd-tag">Search Around</span>}>
      <div className="flex items-center gap-1 flex-wrap text-[11px] mb-2">
        <button className="fnd-tag" style={{ cursor: "pointer" }} onClick={() => setPath([])}>{titleOf(meta, root)}</button>
        {path.map((p, i) => <React.Fragment key={i}><span className="fnd-text-dim">›</span><button className="fnd-tag" style={{ cursor: "pointer" }} onClick={() => setPath(path.slice(0, i + 1))}>{titleOf(meta, p)}</button></React.Fragment>)}
      </div>
      <div className="flex gap-1 flex-wrap mb-2">
        {links.map(l => (
          <button key={l.link.apiName + l.target} className="fnd-btn" style={{ height: 24, background: active?.link.apiName === l.link.apiName ? "var(--fnd-selection)" : undefined }} onClick={() => setLinkApi(l.link.apiName)}>
            {l.label} <span className="fnd-text-dim">({pivotTo(ontology, meta, l.link.apiName, [cur!]).length})</span>
          </button>
        ))}
        {links.length === 0 && <span className="text-xs fnd-text-dim">No link types from {String(cur?.__type)}.</span>}
      </div>
      <div className="space-y-0.5">
        {results.slice(0, 20).map((o: Obj) => (
          <div key={String(o.id)} className="flex items-center gap-2 text-xs py-1 px-1 fnd-row-hover rounded-sm">
            <span style={{ width: 8, height: 8, borderRadius: 2, background: objectTypeOf(meta, String(o.__type))?.color }}/>
            <span className="flex-1 truncate">{titleOf(meta, o)}</span>
            <button className="fnd-btn fnd-btn-minimal" style={{ height: 20 }} title="Traverse from this object" onClick={() => { setPath([...path, o]); setLinkApi(""); }}>→</button>
            {cfg.outputVarId && <button className="fnd-btn fnd-btn-minimal" style={{ height: 20 }} title="Set output variable" onClick={() => setValues(p => ({ ...p, [cfg.outputVarId!]: o }))}>Select</button>}
          </div>
        ))}
        {results.length === 0 && active && <div className="text-xs fnd-text-dim">No linked objects via {active.label}.</div>}
      </div>
    </Shell>
  );
}

// ─── Object card / comparison ─────────────────────────────────────────────
function ObjectCard({ widget }: { widget: WidgetDef }) {
  const { values, ontologyMeta: meta } = useCore();
  const cfg = widget.config as { objectVarId: string };
  const o = values[cfg.objectVarId] as Obj | null;
  if (!o || typeof o !== "object") return <div className="fnd-panel rounded-sm p-3 text-xs fnd-text-dim">No object in @{cfg.objectVarId}.</div>;
  const ot = objectTypeOf(meta, String(o.__type));
  const props = (ot?.properties ?? []).filter(p => p.visibility === "PROMINENT" && p.apiName !== ot?.titlePropertyApiName).slice(0, 4);
  return (
    <div className="fnd-panel rounded-sm p-3 flex gap-3" style={{ borderLeft: `3px solid ${ot?.color ?? "var(--fnd-accent)"}` }}>
      <div className="flex-1 min-w-0">
        <div className="text-[11px] fnd-text-muted">{ot?.displayName}</div>
        <div className="text-sm font-semibold truncate">{titleOf(meta, o)}</div>
        <div className="flex gap-3 mt-1.5 flex-wrap text-[11px]">{props.map(p => <div key={p.apiName}><span className="fnd-text-dim">{p.displayName}: </span><PropertyValue def={p} v={o[p.apiName]}/></div>)}</div>
      </div>
    </div>
  );
}

function ObjectComparison({ widget }: { widget: WidgetDef }) {
  const { values, ontologyMeta: meta } = useCore();
  const cfg = widget.config as { objectsVarId: string };
  const objs = arr(values[cfg.objectsVarId]).slice(0, 4);
  const ot = objectTypeOf(meta, String(objs[0]?.__type ?? ""));
  const props = (ot?.properties ?? []).filter(p => p.visibility !== "HIDDEN");
  return (
    <Shell title={widget.name} extra={<span className="fnd-tag">{objs.length} selected</span>}>
      {objs.length < 2 ? <div className="text-xs fnd-text-dim">Multi-select 2–4 objects (checkboxes in the Object Table) to compare.</div> : (
        <table className="w-full text-xs">
          <thead><tr><th/>{objs.map(o => <th key={String(o.id)} className="text-left p-1">{titleOf(meta, o)}</th>)}</tr></thead>
          <tbody>
            {props.map(p => {
              const vals = objs.map(o => String(o[p.apiName]));
              const differs = new Set(vals).size > 1;
              return (
                <tr key={p.apiName} style={{ borderTop: "1px solid var(--fnd-border)", background: differs ? "rgba(255,196,87,0.10)" : undefined }}>
                  <td className="p-1 fnd-text-muted">{p.displayName}</td>
                  {objs.map(o => <td key={String(o.id)} className="p-1"><PropertyValue def={p} v={o[p.apiName]}/></td>)}
                </tr>
              );
            })}
          </tbody>
        </table>
      )}
    </Shell>
  );
}

// ─── Object set builder (runtime filters) ─────────────────────────────────
function ObjectSetBuilder({ widget }: { widget: WidgetDef }) {
  const { values, setValues, ontologyMeta: meta } = useCore();
  const cfg = widget.config as { objectSetVarId: string; outputVarId: string };
  const base = arr(values[cfg.objectSetVarId]);
  const ot = objectTypeOf(meta, String(base[0]?.__type ?? "Asset"));
  const [filters, setFilters] = useState<WhereClause[]>([]);
  const result = useMemo(() => applyWhereClauses(base, filters, {}), [base, filters]);
  const apply = () => setValues(p => ({ ...p, [cfg.outputVarId]: result }));
  const enumProps = new Set(["status", "priority", "severity", "shift", "kind"]);
  return (
    <Shell title={widget.name} extra={<span className="fnd-tag">{result.length} / {base.length}</span>}>
      <div className="space-y-1">
        {filters.map((f, i) => {
          const def = ot?.properties.find(p => p.apiName === f.property);
          const isEnum = def && enumProps.has(def.apiName);
          return (
            <div key={f.id} className="flex gap-1">
              <select className="fnd-input fnd-select" value={f.property} onChange={e => setFilters(fs => fs.map((x, j) => j === i ? { ...x, property: e.target.value } : x))}>
                {(ot?.properties ?? []).map(p => <option key={p.apiName} value={p.apiName}>{p.displayName}</option>)}
              </select>
              <select className="fnd-input fnd-select" style={{ width: 150 }} value={f.op} onChange={e => setFilters(fs => fs.map((x, j) => j === i ? { ...x, op: e.target.value as FilterOp } : x))}>
                {(def && ["Double", "Integer", "Long", "Decimal"].includes(def.baseType) ? ["is", "isNot", "isGreaterThanOrEqualTo", "isLessThanOrEqualTo"] : ["is", "isNot", "contains"]).map(o => <option key={o}>{o}</option>)}
              </select>
              {isEnum ? (
                <select className="fnd-input fnd-select" value={String(f.value ?? "")} onChange={e => setFilters(fs => fs.map((x, j) => j === i ? { ...x, value: e.target.value } : x))}>
                  <option value="">—</option>{["Active", "Warning", "Maintenance", "Offline", "High", "Medium", "Low"].map(v => <option key={v}>{v}</option>)}
                </select>
              ) : <input className="fnd-input" value={String(f.value ?? "")} onChange={e => setFilters(fs => fs.map((x, j) => j === i ? { ...x, value: e.target.value } : x))}/>}
              <button className="fnd-btn fnd-btn-minimal" onClick={() => setFilters(fs => fs.filter((_, j) => j !== i))}><Icon.Close size={10}/></button>
            </div>
          );
        })}
        <div className="flex gap-1">
          <button className="fnd-btn" onClick={() => setFilters(fs => [...fs, { id: `f${Date.now()}`, property: ot?.properties[2]?.apiName ?? "id", op: "is" as FilterOp, value: "" }])}><Icon.Plus size={10}/> Filter</button>
          <div className="flex-1"/>
          <button className="fnd-btn fnd-btn-primary" onClick={apply}>Apply → @{cfg.outputVarId}</button>
        </div>
      </div>
    </Shell>
  );
}

function NotificationFeed({ widget }: { widget: WidgetDef }) {
  const { actionLog } = useCore();
  return (
    <Shell title={widget.name} icon={<Icon.Event size={13}/>} extra={<span className="fnd-tag">{actionLog.length}</span>} pad={false}>
      {actionLog.length === 0 && <div className="p-6 text-center text-xs fnd-text-dim">No actions executed this session. Submit an action to see writeback events here.</div>}
      {actionLog.slice(0, 40).map(l => (
        <div key={l.id} className="px-3 py-2 border-b fnd-border text-xs">
          <div className="flex items-center gap-2"><Icon.Action size={11}/><span className="font-semibold">{l.displayName}</span><span className="ml-auto fnd-text-dim tabular-nums">{new Date(l.ts).toLocaleTimeString()}</span></div>
          {l.edits.map((e, i) => <div key={i} className="text-[11px] fnd-text-muted pl-4">{e.kind} {e.objectType} <span className="font-mono">{e.objectId}</span></div>)}
        </div>
      ))}
    </Shell>
  );
}

// ─── Analytics ────────────────────────────────────────────────────────────
function Histogram({ widget }: { widget: WidgetDef }) {
  const { values, ontologyMeta: meta } = useCore();
  const cfg = widget.config as { objectSetVarId: string; property: string; bins?: number };
  const data = arr(values[cfg.objectSetVarId]);
  const def = propertyOf(meta, String(data[0]?.__type ?? ""), cfg.property);
  const xs = data.map(o => num(o, cfg.property));
  const bins = cfg.bins ?? 12;
  const min = xs.length ? Math.min(...xs) : 0, max = xs.length ? Math.max(...xs) : 1;
  const w = (max - min) / bins || 1;
  const counts = Array.from({ length: bins }, (_, i) => xs.filter(x => x >= min + i * w && (i === bins - 1 ? x <= max : x < min + (i + 1) * w)).length);
  const top = Math.max(1, ...counts);
  const [hover, setHover] = useState<number | null>(null);
  return (
    <Shell title={widget.name} extra={<span className="fnd-tag">{def?.displayName ?? cfg.property}</span>}>
      {data.length === 0 ? <div className="text-xs fnd-text-dim">No objects.</div> : (
        <>
          <div className="flex items-end gap-0.5" style={{ height: 120 }}>
            {counts.map((c, i) => (
              <div key={i} className="flex-1" onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)}
                style={{ height: `${(c / top) * 100}%`, minHeight: 1, background: hover === i ? "var(--fnd-accent-hover)" : "var(--fnd-accent)", opacity: 0.85 }}/>
            ))}
          </div>
          <div className="flex justify-between text-[10px] fnd-text-dim mt-1"><span>{formatPropertyValue(def, min)}</span><span>{formatPropertyValue(def, max)}</span></div>
          <div className="text-[11px] mt-1 fnd-text-muted" style={{ minHeight: 16 }}>{hover != null ? `${formatPropertyValue(def, min + hover * w)} – ${formatPropertyValue(def, min + (hover + 1) * w)}: ${counts[hover]} objects` : `${data.length} objects · ${bins} bins`}</div>
        </>
      )}
    </Shell>
  );
}

function ScatterPlot({ widget }: { widget: WidgetDef }) {
  const { values, setValues, ontologyMeta: meta } = useCore();
  const cfg = widget.config as { objectSetVarId: string; x: string; y: string; colorBy?: string; activeVarId?: string };
  const data = arr(values[cfg.objectSetVarId]).slice(0, 400);
  const active = cfg.activeVarId ? (values[cfg.activeVarId] as Obj | null) : null;
  const xs = data.map(o => num(o, cfg.x)), ys = data.map(o => num(o, cfg.y));
  const [mnx, mxx, mny, mxy] = [Math.min(...xs, 0), Math.max(...xs, 1), Math.min(...ys, 0), Math.max(...ys, 1)];
  const cats = [...new Set(data.map(o => String(o[cfg.colorBy ?? "status"])))];
  const [tip, setTip] = useState<Obj | null>(null);
  const W = 420, H = 200, P = 26;
  const type = String(data[0]?.__type ?? "");
  return (
    <Shell title={widget.name} extra={<span className="fnd-tag">{propertyOf(meta, type, cfg.x)?.displayName ?? cfg.x} × {propertyOf(meta, type, cfg.y)?.displayName ?? cfg.y}</span>}>
      <svg viewBox={`0 0 ${W} ${H}`} width="100%">
        <line x1={P} y1={H - P} x2={W - 8} y2={H - P} stroke="var(--fnd-border-strong)"/><line x1={P} y1={8} x2={P} y2={H - P} stroke="var(--fnd-border-strong)"/>
        {data.map((o, i) => {
          const cx = P + ((xs[i] - mnx) / (mxx - mnx || 1)) * (W - P - 12);
          const cy = H - P - ((ys[i] - mny) / (mxy - mny || 1)) * (H - P - 12);
          const sel = active?.id === o.id;
          return <circle key={String(o.id)} cx={cx} cy={cy} r={sel ? 6 : 3.5} fill={PALETTE[cats.indexOf(String(o[cfg.colorBy ?? "status"])) % PALETTE.length]} stroke={sel ? "var(--fnd-text)" : "none"} strokeWidth={1.5} opacity={0.8}
            style={{ cursor: "pointer" }} onMouseEnter={() => setTip(o)} onMouseLeave={() => setTip(null)} onClick={() => cfg.activeVarId && setValues(p => ({ ...p, [cfg.activeVarId!]: o }))}/>;
        })}
      </svg>
      <div className="flex gap-2 flex-wrap text-[10px]">{cats.map((c, i) => <span key={c} className="flex items-center gap-1"><span style={{ width: 8, height: 8, borderRadius: 4, background: PALETTE[i % PALETTE.length] }}/>{c}</span>)}</div>
      <div className="text-[11px] fnd-text-muted" style={{ minHeight: 16 }}>{tip ? `${titleOf(meta, tip)} · ${cfg.x} ${String(tip[cfg.x])} · ${cfg.y} ${String(tip[cfg.y])}` : "Hover a point · click to select"}</div>
    </Shell>
  );
}

function Heatmap({ widget }: { widget: WidgetDef }) {
  const { values, setValues } = useCore();
  const cfg = widget.config as { objectSetVarId: string; rows: string; cols: string; rowFilterVarId?: string; colFilterVarId?: string };
  const data = arr(values[cfg.objectSetVarId]);
  const rows = [...new Set(data.map(o => String(o[cfg.rows])))].sort();
  const cols = [...new Set(data.map(o => String(o[cfg.cols])))].sort();
  const m: Record<string, number> = {};
  for (const o of data) { const k = `${o[cfg.rows]}|${o[cfg.cols]}`; m[k] = (m[k] || 0) + 1; }
  const top = Math.max(1, ...Object.values(m));
  return (
    <Shell title={widget.name} extra={<span className="fnd-tag">click cell → filter</span>}>
      <div className="overflow-auto">
        <table className="text-[11px]" style={{ borderCollapse: "separate", borderSpacing: 2 }}>
          <thead><tr><th/>{cols.map(c => <th key={c} className="px-1 fnd-text-muted font-medium">{c}</th>)}</tr></thead>
          <tbody>
            {rows.map(r => (
              <tr key={r}>
                <td className="pr-2 fnd-text-muted whitespace-nowrap">{r}</td>
                {cols.map(c => {
                  const n = m[`${r}|${c}`] ?? 0;
                  return (
                    <td key={c} title={`${r} × ${c}: ${n}`} onClick={() => setValues(p => ({ ...p, ...(cfg.rowFilterVarId ? { [cfg.rowFilterVarId]: cfg.rowFilterVarId.endsWith("Filter") && Array.isArray(p[cfg.rowFilterVarId]) ? [r] : r } : {}), ...(cfg.colFilterVarId ? { [cfg.colFilterVarId]: Array.isArray(p[cfg.colFilterVarId]) ? [c] : c } : {}) }))}
                      style={{ width: 44, height: 26, textAlign: "center", cursor: "pointer", borderRadius: 2, background: `rgba(43,108,176,${0.08 + (n / top) * 0.85})`, color: n / top > 0.5 ? "white" : "var(--fnd-text)" }}>{n || ""}</td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Shell>
  );
}

function Treemap({ widget }: { widget: WidgetDef }) {
  const { values, setValues } = useCore();
  const cfg = widget.config as { objectSetVarId: string; groupBy: string; filterVarId?: string };
  const data = arr(values[cfg.objectSetVarId]);
  const g: Record<string, number> = {};
  for (const o of data) { const k = String(o[cfg.groupBy] ?? "—"); g[k] = (g[k] || 0) + 1; }
  const entries = Object.entries(g).sort((a, b) => b[1] - a[1]);
  const total = data.length || 1;
  return (
    <Shell title={widget.name} extra={<span className="fnd-tag">{cfg.groupBy}</span>}>
      <div className="flex flex-wrap gap-0.5" style={{ height: 150 }}>
        {entries.map(([k, n], i) => (
          <button key={k} onClick={() => cfg.filterVarId && setValues(p => ({ ...p, [cfg.filterVarId!]: Array.isArray(p[cfg.filterVarId!]) ? [k] : k }))}
            title={`${k}: ${n}`} className="text-left p-1.5 text-white text-[11px] rounded-sm"
            style={{ flexGrow: n, flexBasis: `${Math.max(12, (n / total) * 100)}%`, background: PALETTE[i % PALETTE.length], minWidth: 40 }}>
            <div className="font-semibold truncate">{k}</div><div className="opacity-80">{n} · {Math.round((n / total) * 100)}%</div>
          </button>
        ))}
        {entries.length === 0 && <div className="text-xs fnd-text-dim">No objects.</div>}
      </div>
    </Shell>
  );
}

function Gauge({ widget }: { widget: WidgetDef }) {
  const { values } = useCore();
  const cfg = widget.config as { variableId: string; label?: string; max?: number; suffix?: string; warnAt?: number };
  const v = Number(values[cfg.variableId]) || 0;
  const max = cfg.max ?? 100;
  const frac = Math.max(0, Math.min(1, v / max));
  const a = Math.PI * (1 - frac);
  const x = 60 + Math.cos(a) * 46, y = 60 - Math.sin(a) * 46;
  const color = cfg.warnAt !== undefined && v >= cfg.warnAt ? "var(--fnd-danger)" : "var(--fnd-success)";
  return (
    <div className="fnd-panel rounded-sm p-3 flex flex-col items-center">
      <div className="text-[11px] uppercase tracking-wide fnd-text-muted self-start">{cfg.label ?? widget.name}</div>
      <svg viewBox="0 0 120 70" width="160">
        <path d="M14 60 A46 46 0 0 1 106 60" fill="none" stroke="var(--fnd-panel-2)" strokeWidth="10"/>
        <path d={`M14 60 A46 46 0 0 1 ${x} ${y}`} fill="none" stroke={color} strokeWidth="10"/>
        <text x="60" y="58" textAnchor="middle" fontSize="16" fontWeight="700" fill="var(--fnd-text)">{v.toLocaleString(undefined, { maximumFractionDigits: 1 })}{cfg.suffix ?? ""}</text>
      </svg>
      <div className="text-[10px] fnd-text-dim">of {max}{cfg.suffix ?? ""} · @{cfg.variableId}</div>
    </div>
  );
}

function SparklineKpi({ widget }: { widget: WidgetDef }) {
  const { values } = useCore();
  const cfg = widget.config as { variableId: string; label?: string; seriesSetVarId?: string; seriesProperty?: string; suffix?: string };
  const v = values[cfg.variableId];
  const pts = arr(values[cfg.seriesSetVarId ?? ""]).slice(0, 30).map(o => num(o, cfg.seriesProperty ?? "availability"));
  const mn = Math.min(...pts, 0), mx = Math.max(...pts, 1);
  return (
    <div className="fnd-panel rounded-sm p-3">
      <div className="text-[11px] uppercase tracking-wide fnd-text-muted">{cfg.label ?? widget.name}</div>
      <div className="flex items-end justify-between gap-2">
        <div className="text-2xl font-bold tabular-nums">{typeof v === "number" ? v.toLocaleString(undefined, { maximumFractionDigits: 1 }) : String(v ?? "—")}{cfg.suffix ?? ""}</div>
        <svg viewBox="0 0 100 30" width="110" height="32">
          {pts.length > 1 && <polyline fill="none" stroke="var(--fnd-accent)" strokeWidth="1.5" points={pts.map((p, i) => `${(i / (pts.length - 1)) * 100},${28 - ((p - mn) / (mx - mn || 1)) * 26}`).join(" ")}/>}
        </svg>
      </div>
    </div>
  );
}

function ProgressBar({ widget }: { widget: WidgetDef }) {
  const { values } = useCore();
  const cfg = widget.config as { valueVarId: string; totalVarId?: string; total?: number; label?: string };
  const v = Number(values[cfg.valueVarId]) || 0;
  const t = cfg.totalVarId ? Number(values[cfg.totalVarId]) || 1 : cfg.total ?? 100;
  const pct = Math.max(0, Math.min(100, (v / (t || 1)) * 100));
  return (
    <div className="fnd-panel rounded-sm p-3">
      <div className="flex justify-between text-xs mb-1"><span className="font-medium">{cfg.label ?? widget.name}</span><span className="tabular-nums fnd-text-muted">{v.toLocaleString()} / {t.toLocaleString()} · {pct.toFixed(0)}%</span></div>
      <div style={{ height: 8, background: "var(--fnd-panel-2)", borderRadius: 2, overflow: "hidden" }}>
        <div style={{ width: `${pct}%`, height: "100%", background: pct > 80 ? "var(--fnd-success)" : pct > 40 ? "var(--fnd-accent)" : "var(--fnd-warning)", transition: "width 200ms" }}/>
      </div>
    </div>
  );
}

function SummaryStats({ widget }: { widget: WidgetDef }) {
  const { values, ontologyMeta: meta } = useCore();
  const cfg = widget.config as { objectSetVarId: string; property: string };
  const data = arr(values[cfg.objectSetVarId]);
  const def = propertyOf(meta, String(data[0]?.__type ?? ""), cfg.property);
  const xs = data.map(o => num(o, cfg.property));
  const sum = xs.reduce((a, b) => a + b, 0);
  const stats: Array<[string, number]> = [["Count", xs.length], ["Min", xs.length ? Math.min(...xs) : 0], ["Mean", xs.length ? sum / xs.length : 0], ["Max", xs.length ? Math.max(...xs) : 0], ["Sum", sum]];
  return (
    <Shell title={`${widget.name} · ${def?.displayName ?? cfg.property}`}>
      <div className="grid grid-cols-5 gap-2">
        {stats.map(([k, v]) => <div key={k}><div className="text-[10px] uppercase fnd-text-muted">{k}</div><div className="text-sm font-bold tabular-nums">{k === "Count" ? v : formatPropertyValue(def, Math.round(v * 10) / 10)}</div></div>)}
      </div>
    </Shell>
  );
}

function Leaderboard({ widget }: { widget: WidgetDef }) {
  const { values, setValues, ontologyMeta: meta } = useCore();
  const cfg = widget.config as { objectSetVarId: string; property: string; limit?: number; activeVarId?: string; ascending?: boolean };
  const data = [...arr(values[cfg.objectSetVarId])].sort((a, b) => cfg.ascending ? num(a, cfg.property) - num(b, cfg.property) : num(b, cfg.property) - num(a, cfg.property)).slice(0, cfg.limit ?? 8);
  const def = propertyOf(meta, String(data[0]?.__type ?? ""), cfg.property);
  const top = Math.max(1, ...data.map(o => Math.abs(num(o, cfg.property))));
  return (
    <Shell title={widget.name} extra={<span className="fnd-tag">by {def?.displayName ?? cfg.property}</span>}>
      {data.map((o, i) => (
        <button key={String(o.id)} className="w-full flex items-center gap-2 py-1 text-xs fnd-row-hover rounded-sm" onClick={() => cfg.activeVarId && setValues(p => ({ ...p, [cfg.activeVarId!]: o }))}>
          <span className="fnd-text-dim tabular-nums" style={{ width: 16 }}>{i + 1}</span>
          <span className="truncate text-left" style={{ width: 140 }}>{titleOf(meta, o)}</span>
          <div className="flex-1 h-2" style={{ background: "var(--fnd-panel-2)" }}><div style={{ width: `${(Math.abs(num(o, cfg.property)) / top) * 100}%`, height: "100%", background: "var(--fnd-accent)" }}/></div>
          <span className="tabular-nums" style={{ width: 70, textAlign: "right" }}>{formatPropertyValue(def, o[cfg.property])}</span>
        </button>
      ))}
      {data.length === 0 && <div className="text-xs fnd-text-dim">No objects.</div>}
    </Shell>
  );
}

function CalendarW({ widget }: { widget: WidgetDef }) {
  const { values, setValues, ontologyMeta: meta } = useCore();
  const cfg = widget.config as { objectSetVarId: string; dateProperty: string; activeVarId?: string };
  const data = arr(values[cfg.objectSetVarId]);
  const [month, setMonth] = useState(9); // October 2026 (0-indexed)
  const year = 2026;
  const first = new Date(year, month, 1);
  const days = new Date(year, month + 1, 0).getDate();
  const offset = first.getDay();
  const byDay: Record<number, Obj[]> = {};
  for (const o of data) {
    const d = new Date(String(o[cfg.dateProperty]));
    if (d.getFullYear() === year && d.getMonth() === month) (byDay[d.getDate()] ??= []).push(o);
  }
  const [sel, setSel] = useState<number | null>(null);
  return (
    <Shell title={widget.name} extra={
      <div className="flex items-center gap-1">
        <button className="fnd-btn fnd-btn-minimal" style={{ height: 22 }} title="Previous month" onClick={() => setMonth(m => Math.max(0, m - 1))}><Icon.Chevron size={10} dir="left"/></button>
        <span className="text-xs tabular-nums" style={{ width: 80, textAlign: "center" }}>{first.toLocaleString(undefined, { month: "short", year: "numeric" })}</span>
        <button className="fnd-btn fnd-btn-minimal" style={{ height: 22 }} title="Next month" onClick={() => setMonth(m => Math.min(11, m + 1))}><Icon.Chevron size={10} dir="right"/></button>
      </div>
    }>
      <div className="grid grid-cols-7 gap-0.5 text-[10px]">
        {["S", "M", "T", "W", "T", "F", "S"].map((d, i) => <div key={i} className="text-center fnd-text-dim">{d}</div>)}
        {Array.from({ length: offset }).map((_, i) => <div key={`e${i}`}/>)}
        {Array.from({ length: days }, (_, i) => i + 1).map(d => {
          const n = byDay[d]?.length ?? 0;
          return (
            <button key={d} onClick={() => setSel(d)} className="rounded-sm text-left p-1"
              style={{ height: 34, border: `1px solid ${sel === d ? "var(--fnd-accent)" : "var(--fnd-border)"}`, background: n ? `rgba(217,130,43,${0.1 + Math.min(0.6, n * 0.15)})` : "var(--fnd-panel)" }}>
              <div>{d}</div>{n > 0 && <div className="font-bold">{n}</div>}
            </button>
          );
        })}
      </div>
      {sel != null && (
        <div className="mt-2 space-y-0.5">
          {(byDay[sel] ?? []).map(o => <button key={String(o.id)} className="w-full text-left text-[11px] fnd-row-hover px-1 rounded-sm" onClick={() => cfg.activeVarId && setValues(p => ({ ...p, [cfg.activeVarId!]: o }))}>{titleOf(meta, o)} <ValuePill v={String(o.status ?? "")}/></button>)}
          {(byDay[sel] ?? []).length === 0 && <div className="text-[11px] fnd-text-dim">Nothing scheduled on this day.</div>}
        </div>
      )}
    </Shell>
  );
}

function TagList({ widget }: { widget: WidgetDef }) {
  const { values, setValues } = useCore();
  const cfg = widget.config as { objectSetVarId: string; property: string; filterVarId?: string };
  const data = arr(values[cfg.objectSetVarId]);
  const counts: Record<string, number> = {};
  for (const o of data) { const v = o[cfg.property]; for (const x of Array.isArray(v) ? v : [v]) { const k = String(x ?? "—"); counts[k] = (counts[k] || 0) + 1; } }
  return (
    <div className="flex flex-wrap gap-1">
      {Object.entries(counts).sort((a, b) => b[1] - a[1]).map(([k, n]) => (
        <button key={k} className="fnd-tag" style={{ cursor: cfg.filterVarId ? "pointer" : "default" }} onClick={() => cfg.filterVarId && setValues(p => ({ ...p, [cfg.filterVarId!]: k }))}>{k} <span className="ml-1 fnd-text-dim">{n}</span></button>
      ))}
    </div>
  );
}

// ─── Inputs ───────────────────────────────────────────────────────────────
function RangeSlider({ widget }: { widget: WidgetDef }) {
  const { values, setValues } = useCore();
  const cfg = widget.config as { minVarId: string; maxVarId: string; min?: number; max?: number; step?: number; label?: string; unit?: string };
  const lo = cfg.min ?? 0, hi = cfg.max ?? 100;
  const a = values[cfg.minVarId] === "" || values[cfg.minVarId] == null ? lo : Number(values[cfg.minVarId]);
  const b = values[cfg.maxVarId] === "" || values[cfg.maxVarId] == null ? hi : Number(values[cfg.maxVarId]);
  return (
    <div>
      <div className="flex justify-between"><label className="fnd-field-label">{cfg.label ?? widget.name}</label><span className="text-[11px] tabular-nums fnd-text-muted">{a}–{b}{cfg.unit ? ` ${cfg.unit}` : ""}</span></div>
      <div className="flex items-center gap-2">
        <input type="range" min={lo} max={hi} step={cfg.step ?? 1} value={a} onChange={e => setValues(p => ({ ...p, [cfg.minVarId]: Math.min(Number(e.target.value), b) }))} className="flex-1" style={{ accentColor: "var(--fnd-accent)" }}/>
        <input type="range" min={lo} max={hi} step={cfg.step ?? 1} value={b} onChange={e => setValues(p => ({ ...p, [cfg.maxVarId]: Math.max(Number(e.target.value), a) }))} className="flex-1" style={{ accentColor: "var(--fnd-accent)" }}/>
        <button className="fnd-btn fnd-btn-minimal" style={{ height: 22 }} title="Clear range" onClick={() => setValues(p => ({ ...p, [cfg.minVarId]: "", [cfg.maxVarId]: "" }))}>Clear</button>
      </div>
    </div>
  );
}

function ToggleSwitch({ widget }: { widget: WidgetDef }) {
  const { values, setValues } = useCore();
  const cfg = widget.config as { variableId: string; label?: string };
  const on = !!values[cfg.variableId];
  return (
    <button role="switch" aria-checked={on} className="flex items-center gap-2 text-xs" onClick={() => setValues(p => ({ ...p, [cfg.variableId]: !on }))}>
      <span style={{ width: 30, height: 16, borderRadius: 8, background: on ? "var(--fnd-accent)" : "var(--fnd-border-strong)", position: "relative", transition: "background 120ms" }}>
        <span style={{ position: "absolute", top: 2, left: on ? 16 : 2, width: 12, height: 12, borderRadius: 6, background: "white", transition: "left 120ms" }}/>
      </span>
      {cfg.label ?? widget.name}
    </button>
  );
}

function RadioGroup({ widget }: { widget: WidgetDef }) {
  const { values, setValues } = useCore();
  const cfg = widget.config as { variableId: string; options: string[]; label?: string };
  return (
    <div>
      {cfg.label && <label className="fnd-field-label">{cfg.label}</label>}
      <div className="flex flex-col gap-1">
        {cfg.options.map(o => <label key={o} className="flex items-center gap-2 text-xs cursor-pointer"><input type="radio" checked={values[cfg.variableId] === o} onChange={() => setValues(p => ({ ...p, [cfg.variableId]: o }))}/>{o}</label>)}
      </div>
    </div>
  );
}

function SegmentedControl({ widget }: { widget: WidgetDef }) {
  const { values, setValues } = useCore();
  const cfg = widget.config as { variableId: string; options: string[]; label?: string };
  return (
    <div className="flex items-center gap-2">
      {cfg.label && <span className="text-xs fnd-text-muted">{cfg.label}</span>}
      <div className="inline-flex rounded-sm overflow-hidden" style={{ border: "1px solid var(--fnd-border-strong)" }}>
        {cfg.options.map((o, i) => (
          <button key={o} onClick={() => setValues(p => ({ ...p, [cfg.variableId]: o }))} className="px-2.5 text-xs"
            style={{ height: 26, borderLeft: i ? "1px solid var(--fnd-border)" : undefined, background: values[cfg.variableId] === o ? "var(--fnd-accent)" : "var(--fnd-panel)", color: values[cfg.variableId] === o ? "white" : "var(--fnd-text)" }}>{o}</button>
        ))}
      </div>
    </div>
  );
}

// ─── Layout & content ─────────────────────────────────────────────────────
function Breadcrumbs({ widget }: { widget: WidgetDef }) {
  const { module, currentPageId, setCurrentPageId, values, ontologyMeta: meta, setValues } = useCore();
  const cfg = widget.config as { objectVarId?: string };
  const page = module.pages.find(p => p.id === currentPageId);
  const obj = cfg.objectVarId ? (values[cfg.objectVarId] as Obj | null) : null;
  return (
    <div className="flex items-center gap-1 text-xs">
      <button className="fnd-text-muted hover:underline" onClick={() => setCurrentPageId(module.pages[0]?.id)}>{module.header.title}</button>
      <span className="fnd-text-dim">/</span>
      <button className={obj ? "fnd-text-muted hover:underline" : "font-semibold"} onClick={() => cfg.objectVarId && setValues(p => ({ ...p, [cfg.objectVarId!]: null }))}>{page?.name}</button>
      {obj && typeof obj === "object" && <><span className="fnd-text-dim">/</span><span className="font-semibold">{titleOf(meta, obj)}</span></>}
    </div>
  );
}

function AlertBanner({ widget }: { widget: WidgetDef }) {
  const { values } = useCore();
  const cfg = widget.config as { variableId: string; threshold?: number; intent?: "warning" | "danger" | "info"; message: string };
  const v = Number(values[cfg.variableId]) || 0;
  if (v <= (cfg.threshold ?? 0)) return null;
  const c = cfg.intent === "danger" ? ["#fde0e0", "#8a1f1f", "#e8a9a9"] : cfg.intent === "info" ? ["#e3ecfa", "#1e4a85", "#a9c3e8"] : ["#fdf1dc", "#8a5a16", "#f0d49a"];
  return <div className="rounded-sm px-3 py-2 text-xs flex items-center gap-2" style={{ background: c[0], color: c[1], border: `1px solid ${c[2]}` }}><Icon.Warning size={13}/>{cfg.message.replace("{value}", String(v))}</div>;
}

function Callout({ widget }: { widget: WidgetDef }) {
  const cfg = widget.config as { title?: string; text: string; intent?: "primary" | "success" | "warning" | "danger" };
  const color = cfg.intent === "success" ? "var(--fnd-success)" : cfg.intent === "warning" ? "var(--fnd-warning)" : cfg.intent === "danger" ? "var(--fnd-danger)" : "var(--fnd-accent)";
  return (
    <div className="rounded-sm p-3 text-xs" style={{ background: "var(--fnd-panel-2)", borderLeft: `3px solid ${color}` }}>
      {cfg.title && <div className="font-semibold mb-0.5">{cfg.title}</div>}<div className="fnd-text-muted">{cfg.text}</div>
    </div>
  );
}

function Divider({ widget }: { widget: WidgetDef }) {
  const cfg = widget.config as { label?: string };
  return <div className="flex items-center gap-2 py-1"><div className="flex-1 fnd-divider"/>{cfg.label && <span className="fnd-label">{cfg.label}</span>}<div className="flex-1 fnd-divider"/></div>;
}
function Spacer({ widget }: { widget: WidgetDef }) { return <div style={{ height: Number((widget.config as { size?: number }).size ?? 16) }}/>; }

function ImageW({ widget }: { widget: WidgetDef }) {
  const cfg = widget.config as { url?: string; caption?: string; height?: number };
  return (
    <figure className="fnd-panel rounded-sm overflow-hidden">
      {cfg.url ? <img src={cfg.url} alt={cfg.caption ?? widget.name} style={{ width: "100%", height: cfg.height ?? 160, objectFit: "cover", display: "block" }}/>
        : <div style={{ height: cfg.height ?? 160, background: "linear-gradient(135deg,#9fb3c8,#e1e8ed)" }} className="flex items-center justify-center text-xs fnd-text-muted">No image URL configured</div>}
      {cfg.caption && <figcaption className="px-2 py-1 text-[11px] fnd-text-muted">{cfg.caption}</figcaption>}
    </figure>
  );
}

function SingleButton({ widget }: { widget: WidgetDef }) {
  const { fireEvents, values } = useCore();
  const cfg = widget.config as { label: string; variant?: string; eventActions?: EventAction[]; disabledWhenEmptyVarId?: string };
  const disabled = cfg.disabledWhenEmptyVarId ? !values[cfg.disabledWhenEmptyVarId] || (Array.isArray(values[cfg.disabledWhenEmptyVarId]) && (values[cfg.disabledWhenEmptyVarId] as unknown[]).length === 0) : false;
  const cls = cfg.variant === "primary" ? "fnd-btn-primary" : cfg.variant === "danger" ? "fnd-btn-danger" : cfg.variant === "minimal" ? "fnd-btn-minimal" : "";
  return (
    <div title={disabled ? `Disabled until @${cfg.disabledWhenEmptyVarId} has a value` : undefined}>
      <button className={`fnd-btn ${cls}`} disabled={disabled} onClick={() => {
        fireEvents(cfg.eventActions ?? []);
        for (const e of widget.events?.filter(x => x.trigger === "onClick") ?? []) fireEvents(e.actions);
      }}>{cfg.label}</button>
    </div>
  );
}

function AvatarStack({ widget }: { widget: WidgetDef }) {
  const { ontology, values } = useCore();
  const cfg = widget.config as { objectVarId?: string };
  const ctx = cfg.objectVarId ? (values[cfg.objectVarId] as Obj | null) : null;
  const ops = ctx ? ontology.operators.filter(o => o.id === ctx.ownerId || ontology.workOrders.some(w => w.assetId === ctx.id && w.operatorId === o.id)) : ontology.operators;
  return (
    <div className="flex items-center gap-2">
      <div className="flex">
        {ops.slice(0, 6).map((o, i) => (
          <span key={o.id} title={`${o.name} · ${o.shift} shift`} style={{ width: 26, height: 26, borderRadius: 13, marginLeft: i ? -6 : 0, background: PALETTE[i % PALETTE.length], color: "white", fontSize: 10, fontWeight: 700, display: "inline-flex", alignItems: "center", justifyContent: "center", border: "2px solid var(--fnd-panel)" }}>
            {o.name.split(" ").map(s => s[0]).join("")}
          </span>
        ))}
      </div>
      <span className="text-[11px] fnd-text-muted">{ops.length} operator{ops.length === 1 ? "" : "s"}{ctx ? " on this asset" : ""}</span>
    </div>
  );
}

export function MoreWidget({ widget }: { widget: WidgetDef }) {
  switch (widget.type) {
    case "KanbanBoard": return <KanbanBoard widget={widget}/>;
    case "ApprovalInbox": return <ApprovalInbox widget={widget}/>;
    case "GraphExplorer": return <GraphExplorer widget={widget}/>;
    case "ObjectCard": return <ObjectCard widget={widget}/>;
    case "ObjectComparison": return <ObjectComparison widget={widget}/>;
    case "ObjectSetBuilder": return <ObjectSetBuilder widget={widget}/>;
    case "NotificationFeed": return <NotificationFeed widget={widget}/>;
    case "Histogram": return <Histogram widget={widget}/>;
    case "ScatterPlot": return <ScatterPlot widget={widget}/>;
    case "Heatmap": return <Heatmap widget={widget}/>;
    case "Treemap": return <Treemap widget={widget}/>;
    case "Gauge": return <Gauge widget={widget}/>;
    case "SparklineKpi": return <SparklineKpi widget={widget}/>;
    case "ProgressBar": return <ProgressBar widget={widget}/>;
    case "SummaryStats": return <SummaryStats widget={widget}/>;
    case "Leaderboard": return <Leaderboard widget={widget}/>;
    case "Calendar": return <CalendarW widget={widget}/>;
    case "TagList": return <TagList widget={widget}/>;
    case "RangeSlider": return <RangeSlider widget={widget}/>;
    case "ToggleSwitch": return <ToggleSwitch widget={widget}/>;
    case "RadioGroup": return <RadioGroup widget={widget}/>;
    case "SegmentedControl": return <SegmentedControl widget={widget}/>;
    case "Breadcrumbs": return <Breadcrumbs widget={widget}/>;
    case "AlertBanner": return <AlertBanner widget={widget}/>;
    case "Callout": return <Callout widget={widget}/>;
    case "Divider": return <Divider widget={widget}/>;
    case "Spacer": return <Spacer widget={widget}/>;
    case "ImageWidget": return <ImageW widget={widget}/>;
    case "SingleButton": return <SingleButton widget={widget}/>;
    case "AvatarStack": return <AvatarStack widget={widget}/>;
    default:
      return (
        <div className="fnd-panel rounded-sm p-3 text-xs" style={{ color: "var(--fnd-danger)" }}>
          ⚠ Unsupported widget type “{widget.type}”.
        </div>
      );
  }
}
