"use client";
import React, { useEffect, useMemo, useState } from "react";
import { useCore } from "../WorkshopContext";
import type { WidgetDef } from "../types";
import { Icon } from "./icons";
import {
  formatPropertyValue, getObjects, linkTypesFor, objectTypeOf, pivotTo, primaryKeyOf, propertyOf, resolveExpr, titleOf, validateAction,
  type Obj, type PropertyTypeDef,
} from "../ontologyMeta";

const PILL: Record<string, { bg: string; fg: string }> = {
  Active: { bg: "#e4f1e5", fg: "#296936" }, Done: { bg: "#e4f1e5", fg: "#296936" }, Nominal: { bg: "#e4f1e5", fg: "#296936" },
  Warning: { bg: "#fdf1dc", fg: "#8a5a16" }, "In Progress": { bg: "#fdf1dc", fg: "#8a5a16" }, Degraded: { bg: "#fdf1dc", fg: "#8a5a16" }, High: { bg: "#fdf1dc", fg: "#8a5a16" },
  Offline: { bg: "#fde0e0", fg: "#8a1f1f" }, Blocked: { bg: "#fde0e0", fg: "#8a1f1f" }, Fault: { bg: "#fde0e0", fg: "#8a1f1f" }, Critical: { bg: "#fde0e0", fg: "#8a1f1f" },
  Maintenance: { bg: "#e3ecfa", fg: "#1e4a85" }, Open: { bg: "#e3ecfa", fg: "#1e4a85" }, Medium: { bg: "#e3ecfa", fg: "#1e4a85" },
};
export function ValuePill({ v }: { v: string }) {
  const c = PILL[v] ?? { bg: "var(--fnd-panel-2)", fg: "var(--fnd-text-muted)" };
  return <span className="fnd-tag" style={{ background: c.bg, color: c.fg, borderColor: "transparent", fontWeight: 600 }}>{v}</span>;
}

const ENUM_LIKE_PROPS = new Set(["status", "priority", "severity", "shift", "kind"]);

export function PropertyValue({ def, v }: { def?: PropertyTypeDef; v: unknown }) {
  if (def && v != null && def.baseType === "String" && ENUM_LIKE_PROPS.has(def.apiName)) return <ValuePill v={String(v)}/>;
  if (def?.baseType === "Boolean") return <span style={{ color: v ? "var(--fnd-success)" : "var(--fnd-text-dim)" }}>{v ? "✓ True" : "False"}</span>;
  return <span>{formatPropertyValue(def, v)}</span>;
}

function ObjBadge({ type, size = 18 }: { type?: string; size?: number }) {
  const { ontologyMeta } = useCore();
  const ot = objectTypeOf(ontologyMeta, type);
  return <span style={{ width: size, height: size, borderRadius: 3, background: ot?.color ?? "#8a9ba8", color: "white", display: "inline-flex", alignItems: "center", justifyContent: "center", fontSize: size * 0.5, fontWeight: 800, flexShrink: 0 }}>{ot?.icon ?? "?"}</span>;
}

function Empty({ text }: { text: string }) {
  return <div className="fnd-panel rounded-sm p-4 text-xs fnd-text-dim text-center">{text}</div>;
}

// ─── Object View ───────────────────────────────────────────────────────────
export function ObjectViewW({ widget }: { widget: WidgetDef }) {
  const { values, ontologyMeta: meta, ontology, setValues, executeAction } = useCore();
  const cfg = widget.config as { objectVarId: string; formFactor?: "full" | "panel"; viewMode?: "standard" | "configured"; tabs?: string[] };
  const obj = values[cfg.objectVarId] as Obj | null;
  const [tab, setTab] = useState(0);
  if (!obj || typeof obj !== "object") return <Empty text={`No object selected. Select a row to populate @${cfg.objectVarId}.`}/>;
  const type = String(obj.__type ?? "");
  const ot = objectTypeOf(meta, type);
  const prominent = (ot?.properties ?? []).filter(p => p.visibility === "PROMINENT" && p.apiName !== ot?.titlePropertyApiName);
  const visible = (ot?.properties ?? []).filter(p => p.visibility !== "HIDDEN");
  const links = linkTypesFor(meta, type);
  const actions = meta.actionTypes.filter(a => a.parameters[0]?.type === "ObjectReference" && a.parameters[0]?.validation.objectTypeApiName === type);
  const tabs = cfg.viewMode === "standard" ? ["Properties", "Links"] : (cfg.tabs ?? ["Overview", "Properties", "Links", "History"]);
  const t = tabs[Math.min(tab, tabs.length - 1)];
  const full = cfg.formFactor === "full";

  return (
    <div className="fnd-panel rounded-sm h-full flex flex-col">
      <div className="px-3 py-2.5 border-b fnd-border flex items-start gap-2.5">
        <ObjBadge type={type} size={full ? 36 : 28}/>
        <div className="flex-1 min-w-0">
          <div className="text-[11px] fnd-text-muted">{ot?.displayName ?? type} · <span className="font-mono">{String(obj[primaryKeyOf(ot)])}</span></div>
          <div className={`${full ? "text-base" : "text-sm"} font-semibold truncate`}>{titleOf(meta, obj)}</div>
          <div className="flex gap-1 mt-1 flex-wrap">{prominent.slice(0, 3).map(p => <PropertyValue key={p.apiName} def={p} v={obj[p.apiName]}/>)}</div>
        </div>
        {actions.length > 0 && (
          <select className="fnd-input fnd-select" style={{ width: 130 }} value="" onChange={e => {
            const a = actions.find(x => x.apiName === e.target.value);
            if (!a) return;
            const params: Record<string, unknown> = { [a.parameters[0].apiName]: obj[primaryKeyOf(ot)] };
            for (const p of a.parameters.slice(1)) if (p.defaultFrom) params[p.apiName] = resolveExpr(p.defaultFrom, params, obj);
            executeAction(a.apiName, params);
          }}>
            <option value="">Actions…</option>
            {actions.filter(a => a.parameters.length === 1).map(a => <option key={a.apiName} value={a.apiName}>{a.displayName}</option>)}
          </select>
        )}
      </div>
      <div className="flex border-b fnd-border px-2">
        {tabs.map((x, i) => (
          <button key={x} onClick={() => setTab(i)} className="px-3 py-1.5 text-xs font-medium"
            style={{ borderBottom: t === x ? "2px solid var(--fnd-accent)" : "2px solid transparent", color: t === x ? "var(--fnd-text)" : "var(--fnd-text-muted)" }}>{x}</button>
        ))}
      </div>
      <div className="flex-1 overflow-auto p-3 text-xs">
        {t === "Overview" && (
          <div className="grid gap-2" style={{ gridTemplateColumns: full ? "repeat(4,1fr)" : "repeat(2,1fr)" }}>
            {visible.filter(p => p.baseType === "Double" || p.baseType === "Integer").slice(0, 4).map(p => (
              <div key={p.apiName} className="rounded-sm p-2" style={{ background: "var(--fnd-panel-2)" }}>
                <div className="text-[10px] uppercase fnd-text-muted">{p.displayName}</div>
                <div className="text-base font-bold tabular-nums">{formatPropertyValue(p, obj[p.apiName])}</div>
              </div>
            ))}
            <div className="col-span-full">
              {links.map(l => <div key={l.link.apiName + l.target} className="flex justify-between py-1 border-b fnd-border"><span className="fnd-text-muted">{l.label}</span><span className="fnd-tag">{pivotTo(ontology, meta, l.link.apiName, [obj]).length}</span></div>)}
            </div>
          </div>
        )}
        {t === "Properties" && (
          <div className="grid gap-x-4" style={{ gridTemplateColumns: full ? "1fr 1fr" : "1fr" }}>
            {visible.map(p => (
              <div key={p.apiName} className="flex items-center justify-between gap-2 py-1 border-b fnd-border">
                <span className="fnd-text-muted flex items-center gap-1">{p.displayName}{p.sharedPropertyType && <span title="Shared property type" className="fnd-text-dim">◆</span>}{p.derivation && <span title="Derived property" className="fnd-text-dim">Σ</span>}</span>
                <PropertyValue def={p} v={p.derivation ? undefined : obj[p.apiName]}/>
              </div>
            ))}
          </div>
        )}
        {t === "Links" && <LinkGroups obj={obj} onPick={o => setValues(p => ({ ...p, [cfg.objectVarId]: o }))}/>}
        {t === "History" && <ObjectHistory obj={obj}/>}
      </div>
    </div>
  );
}

function ObjectHistory({ obj }: { obj: Obj }) {
  const { actionLog, ontology, ontologyMeta } = useCore();
  const id = String(obj.id);
  const edits = actionLog.flatMap(l => l.edits.filter(e => e.objectId === id).map(e => ({ l, e })));
  const alerts = pivotTo(ontology, ontologyMeta, "assetAlerts", [obj]);
  return (
    <div className="space-y-2">
      {edits.length === 0 && alerts.length === 0 && <div className="fnd-text-dim">No history for this object yet.</div>}
      {edits.map(({ l, e }, i) => (
        <div key={i} className="flex gap-2">
          <div className="w-1 rounded-full" style={{ background: "var(--fnd-accent)" }}/>
          <div>
            <div className="font-semibold">{l.displayName} <span className="fnd-text-dim font-normal">by {l.user}</span></div>
            <div className="text-[11px] fnd-text-muted">{new Date(l.ts).toLocaleString()} · {e.before && e.after ? Object.keys(e.after).filter(k => String(e.after![k]) !== String(e.before![k])).map(k => `${k}: ${String(e.before![k])} → ${String(e.after![k])}`).join("; ") : e.kind}</div>
          </div>
        </div>
      ))}
      {alerts.map(a => (
        <div key={String(a.id)} className="flex gap-2">
          <div className="w-1 rounded-full" style={{ background: "var(--fnd-danger)" }}/>
          <div><div className="font-semibold">{String(a.title)}</div><div className="text-[11px] fnd-text-muted">{new Date(String(a.createdAt)).toLocaleString()} · {String(a.severity)}</div></div>
        </div>
      ))}
    </div>
  );
}

function LinkGroups({ obj, linkApis, onPick }: { obj: Obj; linkApis?: string[]; onPick?: (o: Obj) => void }) {
  const { ontology, ontologyMeta: meta } = useCore();
  const all = linkTypesFor(meta, String(obj.__type));
  const links = linkApis && linkApis.length ? all.filter(l => linkApis.includes(l.link.apiName)) : all;
  const [open, setOpen] = useState<Record<string, boolean>>({});
  if (links.length === 0) return <div className="fnd-text-dim text-xs">This object type has no configured link types.</div>;
  return (
    <div className="space-y-1">
      {links.map(l => {
        const items = pivotTo(ontology, meta, l.link.apiName, [obj]);
        const isOpen = open[l.link.apiName] ?? items.length > 0;
        const tot = objectTypeOf(meta, l.target);
        return (
          <div key={l.link.apiName + l.target}>
            <button onClick={() => setOpen(s => ({ ...s, [l.link.apiName]: !isOpen }))} className="w-full flex items-center gap-1.5 py-1 text-xs font-semibold">
              <Icon.Chevron size={10} dir={isOpen ? "down" : "right"}/><ObjBadge type={l.target} size={14}/>
              <span>{l.label}</span>
              <span className="fnd-text-dim font-normal text-[10px]">{l.many ? "many" : "one"}</span>
              <span className="fnd-tag ml-auto">{items.length}</span>
            </button>
            {isOpen && (
              <div className="pl-6 space-y-0.5">
                {items.length === 0 && <div className="fnd-text-dim text-[11px]">No linked {tot?.pluralDisplayName.toLowerCase() ?? "objects"}.</div>}
                {items.slice(0, 8).map(o => {
                  const statusDef = tot?.properties.find(p => p.apiName === "status" || p.apiName === "severity");
                  return (
                    <button key={String(o.id)} className="w-full text-left text-[11px] flex items-center gap-2 py-0.5 fnd-row-hover rounded-sm px-1" onClick={() => onPick?.(o)}>
                      <span className="truncate flex-1">{titleOf(meta, o)}</span>
                      {statusDef && <PropertyValue def={statusDef} v={o[statusDef.apiName]}/>}
                    </button>
                  );
                })}
                {items.length > 8 && <div className="text-[11px] fnd-text-dim">+{items.length - 8} more</div>}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

// ─── Property List ─────────────────────────────────────────────────────────
export function PropertyListW({ widget }: { widget: WidgetDef }) {
  const { values, ontologyMeta: meta, executeAction } = useCore();
  const cfg = widget.config as { objectVarId: string; columns?: number; hideNull?: boolean; properties?: string[]; inlineEdit?: boolean; style?: "aligned" | "inline" };
  const obj = values[cfg.objectVarId] as Obj | null;
  const [editing, setEditing] = useState<string | null>(null);
  if (!obj || typeof obj !== "object") return <Empty text="No object selected."/>;
  const type = String(obj.__type);
  const ot = objectTypeOf(meta, type);
  const props = (cfg.properties && cfg.properties.length ? cfg.properties.map(a => propertyOf(meta, type, a)).filter(Boolean) as PropertyTypeDef[] : (ot?.properties ?? []).filter(p => p.visibility !== "HIDDEN"));
  const cols = Math.max(1, Math.min(4, cfg.columns ?? 2));
  const editAction = meta.actionTypes.find(a => a.parameters[0]?.validation.objectTypeApiName === type && a.rules.some(r => r.kind === "modifyObjectRule"));
  return (
    <div className="fnd-panel rounded-sm p-3">
      <div className="grid gap-x-4 gap-y-0.5" style={{ gridTemplateColumns: `repeat(${cols}, minmax(0,1fr))` }}>
        {props.map(p => {
          const v = p.derivation ? undefined : obj[p.apiName];
          if (cfg.hideNull && (v == null || v === "") && !p.derivation) return null;
          const editable = cfg.inlineEdit && editAction?.parameters.some(x => x.apiName === p.apiName);
          const param = editAction?.parameters.find(x => x.apiName === p.apiName);
          return (
            <div key={p.apiName} className={`py-1 border-b fnd-border min-w-0 ${cfg.style === "inline" ? "flex items-center justify-between gap-2" : "flex flex-col"}`}>
              <div className="text-[10px] uppercase tracking-wide fnd-text-dim flex items-center gap-1">{p.displayName}{p.unit && cfg.style !== "inline" ? <span className="normal-case">({p.unit})</span> : null}</div>
              {editing === p.apiName && editAction && param ? (
                param.validation.allowedValues ? (
                  <select autoFocus className="fnd-input fnd-select" defaultValue={String(v ?? "")} onBlur={() => setEditing(null)}
                    onChange={e => { executeAction(editAction.apiName, { [editAction.parameters[0].apiName]: obj.id, ...Object.fromEntries(editAction.parameters.slice(1).map(x => [x.apiName, x.defaultFrom ? resolveExpr(x.defaultFrom, {}, obj) : undefined])), [p.apiName]: e.target.value }); setEditing(null); }}>
                    {param.validation.allowedValues.map(o => <option key={o}>{o}</option>)}
                  </select>
                ) : (
                  <input autoFocus className="fnd-input" defaultValue={String(v ?? "")} onBlur={() => setEditing(null)}
                    onKeyDown={e => { if (e.key === "Enter") { const val = (e.target as HTMLInputElement).value; executeAction(editAction.apiName, { [editAction.parameters[0].apiName]: obj.id, ...Object.fromEntries(editAction.parameters.slice(1).map(x => [x.apiName, x.defaultFrom ? resolveExpr(x.defaultFrom, {}, obj) : undefined])), [p.apiName]: param.type === "Double" || param.type === "Integer" ? Number(val) : val }); setEditing(null); } if (e.key === "Escape") setEditing(null); }}/>
                )
              ) : (
                <div className={`text-xs font-medium truncate ${editable ? "cursor-text fnd-row-hover rounded-sm" : ""}`} title={editable ? "Click to edit (runs action)" : String(v ?? "")} onClick={() => editable && setEditing(p.apiName)}>
                  <PropertyValue def={p} v={v}/>{editable && <span className="fnd-text-dim ml-1"><Icon.Edit size={9}/></span>}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── Links ─────────────────────────────────────────────────────────────────
export function LinksW({ widget }: { widget: WidgetDef }) {
  const { values, setValues } = useCore();
  const cfg = widget.config as { objectVarId: string; linkTypeApiNames?: string[]; outputVarId?: string };
  const obj = values[cfg.objectVarId] as Obj | null;
  if (!obj || typeof obj !== "object") return <Empty text="No object selected — linked objects will appear here."/>;
  return (
    <div className="fnd-panel rounded-sm p-3">
      <div className="fnd-label mb-1">Related</div>
      <LinkGroups obj={obj} linkApis={cfg.linkTypeApiNames} onPick={o => cfg.outputVarId && setValues(p => ({ ...p, [cfg.outputVarId!]: o }))}/>
    </div>
  );
}

// ─── Inline Action (Action Type driven) ────────────────────────────────────
export function InlineActionW({ widget }: { widget: WidgetDef }) {
  const { values, ontology, ontologyMeta: meta, executeAction, module, closeOverlay, fireEvents } = useCore();
  const cfg = widget.config as { actionId: string; objectVarId?: string };
  const at = meta.actionTypes.find(a => a.apiName === cfg.actionId);
  const ctxObj = cfg.objectVarId ? (values[cfg.objectVarId] as Obj | null) : null;
  const [form, setForm] = useState<Record<string, unknown>>({});
  const [status, setStatus] = useState<"idle" | "editing" | "submitting" | "success" | "error">("idle");
  const [submitErrors, setSubmitErrors] = useState<string[]>([]);
  const ctxId = ctxObj && typeof ctxObj === "object" ? String(ctxObj.id) : "";

  // Defaults: object-reference params bound to the context object; defaultFrom expressions
  const defaults = useMemo(() => {
    const d: Record<string, unknown> = {};
    if (!at) return d;
    for (const p of at.parameters) {
      if (p.type === "ObjectReference" && ctxObj && ctxObj.__type === p.validation.objectTypeApiName) d[p.apiName] = ctxObj.id;
      else if (p.defaultFrom && ctxObj) d[p.apiName] = resolveExpr(p.defaultFrom, {}, ctxObj);
    }
    return d;
  }, [at, ctxObj]);
  useEffect(() => { setForm({}); setStatus("idle"); setSubmitErrors([]); }, [ctxId, cfg.actionId]);

  if (!at) return <div className="fnd-panel rounded-sm p-3 text-xs" style={{ color: "var(--fnd-danger)" }}>⚠ Widget configuration invalid: action type “{cfg.actionId}” not found in the ontology.</div>;
  const params = { ...defaults, ...form };
  const v = validateAction(at, ontology, meta, params);
  const touched = status !== "idle";

  const submit = () => {
    if (status === "submitting") return;
    if (Object.keys(v.fieldErrors).length || v.criteriaErrors.length) { setStatus("error"); setSubmitErrors(v.criteriaErrors); return; }
    setStatus("submitting");
    setTimeout(() => {
      const res = executeAction(at.apiName, params);
      if (res.ok) {
        setStatus("success");
        const evs = widget.events?.filter(e => e.trigger === "onFormSubmitSuccess" || e.trigger === "onSubmit") ?? [];
        for (const e of evs) fireEvents(e.actions);
        setTimeout(() => {
          for (const o of module.overlays) if (module.sections[o.rootSectionId]?.children.some(c => c.id === widget.id)) closeOverlay(o.id);
          setForm({}); setStatus("idle");
        }, 700);
      } else {
        setStatus("error"); setSubmitErrors(res.errors);
        for (const e of widget.events?.filter(x => x.trigger === "onFormSubmitError") ?? []) fireEvents(e.actions);
      }
    }, 350);
  };

  return (
    <div className="fnd-panel rounded-sm p-3">
      <div className="flex items-center gap-2 mb-1">
        <Icon.Action size={13}/><div className="text-xs font-semibold">{at.displayName}</div>
        <span className="fnd-tag ml-auto" title="Ontology action type">{at.apiName}</span>
      </div>
      {at.description && <div className="text-[11px] fnd-text-muted mb-2">{at.description}</div>}
      <div className="space-y-2">
        {at.parameters.map(p => {
          const err = touched ? v.fieldErrors[p.apiName] : undefined;
          const val = params[p.apiName];
          const lockedToContext = p.type === "ObjectReference" && ctxObj && ctxObj.__type === p.validation.objectTypeApiName;
          const ot = objectTypeOf(meta, p.validation.objectTypeApiName);
          const set = (x: unknown) => { setForm(s => ({ ...s, [p.apiName]: x })); if (status === "idle" || status === "error") setStatus("editing"); };
          return (
            <div key={p.apiName}>
              <label className="fnd-field-label">{p.displayName}{p.validation.required && <span style={{ color: "var(--fnd-danger)" }}> *</span>}</label>
              {p.type === "ObjectReference" ? (
                lockedToContext ? (
                  <div className="fnd-input flex items-center gap-2" style={{ background: "var(--fnd-panel-2)" }}><ObjBadge type={p.validation.objectTypeApiName} size={14}/>{titleOf(meta, ctxObj)} <span className="fnd-text-dim font-mono ml-auto">{String(ctxObj!.id)}</span></div>
                ) : (
                  <select className="fnd-input fnd-select" style={{ borderColor: err ? "var(--fnd-danger)" : undefined }} value={String(val ?? "")} onChange={e => set(e.target.value)}>
                    <option value="">Select {ot?.displayName ?? "object"}…</option>
                    {getObjects(ontology, p.validation.objectTypeApiName).slice(0, 300).map(o => <option key={String(o.id)} value={String(o[primaryKeyOf(ot)])}>{titleOf(meta, o)}</option>)}
                  </select>
                )
              ) : p.validation.allowedValues ? (
                <select className="fnd-input fnd-select" style={{ borderColor: err ? "var(--fnd-danger)" : undefined }} value={String(val ?? "")} onChange={e => set(e.target.value)}>
                  <option value="">—</option>{p.validation.allowedValues.map(o => <option key={o}>{o}</option>)}
                </select>
              ) : p.type === "Boolean" ? (
                <label className="flex items-center gap-2 text-xs"><input type="checkbox" checked={!!val} onChange={e => set(e.target.checked)}/> {p.displayName}</label>
              ) : (
                <input className="fnd-input" style={{ borderColor: err ? "var(--fnd-danger)" : undefined }}
                  type={p.type === "Date" || p.type === "Timestamp" ? "date" : p.type === "Integer" || p.type === "Double" ? "number" : "text"}
                  min={p.validation.range?.min} max={p.validation.range?.max}
                  value={String(val ?? "")} onChange={e => set(p.type === "Integer" || p.type === "Double" ? (e.target.value === "" ? "" : Number(e.target.value)) : e.target.value)}/>
              )}
              {err ? <div className="text-[11px]" style={{ color: "var(--fnd-danger)" }}>{err}</div>
                : p.validation.range && (p.validation.range.min !== undefined || p.validation.range.max !== undefined) ? <div className="text-[10px] fnd-text-dim">Allowed range {p.validation.range.min ?? "−∞"} – {p.validation.range.max ?? "∞"}</div> : null}
            </div>
          );
        })}
      </div>
      {(v.criteriaErrors.length > 0 && touched) || submitErrors.length > 0 ? (
        <div className="mt-2 rounded-sm p-2 text-[11px]" style={{ background: "#fde9e9", border: "1px solid #e8a9a9", color: "#8a1f1f" }}>
          {[...new Set([...(touched ? v.criteriaErrors : []), ...submitErrors])].map((m, i) => <div key={i}>⚠ {m}</div>)}
        </div>
      ) : null}
      {status === "success" && <div className="mt-2 rounded-sm p-2 text-[11px]" style={{ background: "#e4f1e5", color: "#296936" }}>✓ Submitted — ontology updated.</div>}
      <div className="mt-3 flex items-center justify-end gap-2">
        <span className="text-[10px] fnd-text-dim mr-auto">{status === "idle" ? "Idle" : status === "editing" ? "Editing" : status === "submitting" ? "Submitting…" : status === "success" ? "Success" : "Validation error"}</span>
        <button className="fnd-btn" onClick={() => { setForm({}); setStatus("idle"); setSubmitErrors([]); }}>Cancel</button>
        <button className="fnd-btn fnd-btn-primary" disabled={status === "submitting"} onClick={submit}>
          {status === "submitting" ? "Submitting…" : status === "success" ? "✓ Done" : "Submit"}
        </button>
      </div>
    </div>
  );
}
