"use client";
import React, { useMemo, useState } from "react";
import { useCore } from "../WorkshopContext";
import type { WidgetDef } from "../types";
import type { AnyObj, AssetObj } from "../ontology";
import { Icon } from "./icons";
import { ExtraWidget } from "./ExtraWidgets";
import { ObjectViewW, PropertyListW, LinksW, InlineActionW as OntologyInlineAction, PropertyValue } from "./OntologyWidgets";
import { ObjectTableW } from "./ObjectTableWidget";
import { MapWidgetImpl } from "./MapWidgetImpl";
import { TelemetryTable } from "./TelemetryTable";
import { TelemetryStatsWidget } from "./TelemetryStats";
import { Scene3DWidget } from "./Scene3D";
import { propertyOf, type PropertyDef } from "../ontologyMeta";

export function WidgetRenderer({ widget, isBuilder }: { widget: WidgetDef; isBuilder: boolean }) {
  switch (widget.type) {
    case "ObjectTable": return <ObjectTableW widget={widget} />;
    case "TelemetryTable": return <TelemetryTable widget={widget} />;
    case "TelemetryStats": return <TelemetryStatsWidget widget={widget} />;
    case "Scene3D": return <Scene3DWidget widget={widget} isBuilder={isBuilder} />;
    case "ObjectList": return <ObjectList widget={widget} isBuilder={isBuilder} />;
    case "ObjectView": return <ObjectViewW widget={widget} />;
    case "PropertyList": return <PropertyListW widget={widget} />;
    case "Links": return <LinksW widget={widget} />;
    case "HeaderText": return <HeaderTextW widget={widget} />;
    case "ObjectSetTitle": return <ObjectSetTitleW widget={widget} />;
    case "FilterList": return <FilterListW widget={widget} />;
    case "TextInput": return <TextInputW widget={widget} />;
    case "NumericInput": return <NumericInputW widget={widget} />;
    case "DateInput": return <DateInputW widget={widget} />;
    case "ObjectDropdown":
    case "StringSelector": return <StringSelectorW widget={widget} />;
    case "Checkbox": return <CheckboxW widget={widget} />;
    case "UserSelect": return <UserSelectW widget={widget} />;
    case "MetricCard": return <MetricCard widget={widget} />;
    case "ChartXY": return <ChartXY widget={widget} />;
    case "ChartPie": return <ChartPie widget={widget} />;
    case "Map": return <MapWidgetImpl widget={widget} />;
    case "Gantt": return <GanttWidget widget={widget} />;
    case "Timeline": return <TimelineWidget widget={widget} />;
    case "PivotTable": return <PivotTableW widget={widget} />;
    case "Markdown": return <MarkdownW widget={widget} />;
    case "PdfViewer": return <PdfViewerW widget={widget} />;
    case "ButtonGroup": return <ButtonGroupW widget={widget} />;
    case "Tabs": return <TabsW widget={widget} />;
    case "StatusTracker": return <StatusTrackerW widget={widget} />;
    case "Stepper": return <StepperW widget={widget} />;
    case "Comments": return <CommentsW widget={widget} />;
    case "MediaUploader": return <MediaUploadW widget={widget} />;
    case "InlineAction": return <OntologyInlineAction widget={widget} />;
    case "AIPChatbot": return <AIPChatW widget={widget} />;
    case "AIPAnalyst": return <AIPAnalystW widget={widget} />;
    case "AIPGenerated": return <AIPGenW widget={widget} />;
    case "EmbeddedModule": return <EmbeddedModuleW widget={widget} />;
    case "CustomWidget": return <CustomWidgetW widget={widget} />;
    case "Iframe": return <IframeW widget={widget} />;
    default:
      return <ExtraWidget widget={widget} />;
  }
}

function PlaceholderBox({ title, hint }: { title: string; hint?: string }) {
  return (
    <div className="fnd-panel p-3 rounded-sm h-full flex flex-col items-center justify-center text-center">
      <div className="text-xs font-medium mb-1">{title}</div>
      {hint && <div className="text-[11px] fnd-text-dim">{hint}</div>}
    </div>
  );
}

function GenericWidget({ widget }: { widget: WidgetDef }) {
  return <PlaceholderBox title={widget.name} hint={`${widget.type} widget`} />;
}


function CellValue({ value, formatter, def }: { value: unknown; formatter?: string; def?: PropertyDef }) {
  if (value == null || value === "") return <span className="fnd-text-dim">—</span>;
  if (!formatter && def) return <PropertyValue def={def} v={value}/>;
  if (formatter === "status") return <StatusPill status={String(value)} />;
  if (formatter === "priority") return <PriorityPill p={String(value)} />;
  if (formatter === "date") {
    try {
      const d = new Date(String(value));
      return <span>{d.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" })}</span>;
    } catch { return <span>{String(value)}</span>; }
  }
  if (formatter === "numeric") {
    const n = Number(value);
    return <span style={{ fontVariantNumeric: "tabular-nums" }}>{Number.isFinite(n) ? n.toLocaleString() : String(value)}</span>;
  }
  return <span>{String(value)}</span>;
}

export function StatusPill({ status }: { status: string }) {
  const map: Record<string, { bg: string; fg: string }> = {
    Active: { bg: "#e4f1e5", fg: "#296936" },
    Warning: { bg: "#fdf1dc", fg: "#8a5a16" },
    Offline: { bg: "#fde0e0", fg: "#8a1f1f" },
    Maintenance: { bg: "#e3ecfa", fg: "#1e4a85" },
    Open: { bg: "#e3ecfa", fg: "#1e4a85" },
    "In Progress": { bg: "#fdf1dc", fg: "#8a5a16" },
    Blocked: { bg: "#fde0e0", fg: "#8a1f1f" },
    Done: { bg: "#e4f1e5", fg: "#296936" },
    Nominal: { bg: "#e4f1e5", fg: "#296936" },
    Degraded: { bg: "#fdf1dc", fg: "#8a5a16" },
    Fault: { bg: "#fde0e0", fg: "#8a1f1f" },
    Critical: { bg: "#fde0e0", fg: "#8a1f1f" },
    High: { bg: "#fdf1dc", fg: "#8a5a16" },
    Medium: { bg: "#e3ecfa", fg: "#1e4a85" },
    Low: { bg: "#e9ecef", fg: "#555" },
  };
  const c = map[status] ?? { bg: "#e9ecef", fg: "#555" };
  return <span className="fnd-tag" style={{ background: c.bg, color: c.fg, borderColor: "transparent", fontWeight: 600 }}>{status}</span>;
}
function PriorityPill({ p }: { p: string }) { return <StatusPill status={p} />; }

// ─── Object List ─────────────────────────────────────────────────────────────
function ObjectList({ widget }: { widget: WidgetDef; isBuilder: boolean }) {
  const { values, setValues } = useCore();
  const cfg = widget.config as { objectSetVarId: string; layout: "list" | "grid"; activeVarId?: string };
  const list = (values[cfg.objectSetVarId] as AnyObj[]) ?? [];
  const [layout, setLayout] = useState(cfg.layout);
  const activeId = cfg.activeVarId ? (values[cfg.activeVarId] as unknown as { id?: string })?.id : undefined;

  return (
    <div className="fnd-panel rounded-sm h-full flex flex-col overflow-hidden">
      <div className="flex items-center gap-2 px-2.5 py-1.5 border-b fnd-border">
        <div className="text-xs font-semibold">{widget.name}</div>
        <span className="fnd-tag">{list.length}</span>
        <div className="flex-1"/>
        <button className={`fnd-btn fnd-btn-minimal ${layout === "list" ? "fnd-selected" : ""}`} onClick={() => setLayout("list")} title="List"><Icon.List size={12}/></button>
        <button className={`fnd-btn fnd-btn-minimal ${layout === "grid" ? "fnd-selected" : ""}`} onClick={() => setLayout("grid")} title="Grid"><Icon.Grid size={12}/></button>
      </div>
      <div className="flex-1 overflow-auto p-2">
        {list.length === 0 && <div className="p-6 text-center fnd-text-dim">No objects.</div>}
        {layout === "list" ? (
          <div className="space-y-1">
            {list.slice(0, 100).map(o => {
              const a = o as AssetObj;
              const active = a.id === activeId;
              return (
                <div key={a.id} onClick={() => cfg.activeVarId && setValues(p => ({ ...p, [cfg.activeVarId!]: a }))}
                  className={`fnd-row-hover rounded-sm px-2.5 py-2 cursor-pointer ${active ? "fnd-selected" : ""}`} style={{ border: "1px solid var(--fnd-border)" }}>
                  <div className="flex items-start gap-2">
                    <StatusPill status={a.status} />
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-semibold truncate">{a.name}</div>
                      <div className="text-[11px] fnd-text-muted truncate">{a.owner} · {a.priority} · {a.pressure} bar</div>
                    </div>
                    <div className="text-[11px] fnd-text-dim">{a.id}</div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="grid gap-2" style={{ gridTemplateColumns: "repeat(auto-fill,minmax(170px,1fr))" }}>
            {list.slice(0, 100).map(o => {
              const a = o as AssetObj;
              const active = a.id === activeId;
              return (
                <div key={a.id} onClick={() => cfg.activeVarId && setValues(p => ({ ...p, [cfg.activeVarId!]: a }))}
                  className={`fnd-row-hover rounded-sm cursor-pointer ${active ? "fnd-selected-ring" : ""}`} style={{ border: "1px solid var(--fnd-border)" }}>
                  <div style={{ height: 68, background: `linear-gradient(135deg, ${colorForStatus(a.status)} 0%, var(--fnd-panel-2) 100%)`, borderBottom: "1px solid var(--fnd-border)" }} />
                  <div className="p-2">
                    <div className="text-xs font-semibold truncate">{a.name}</div>
                    <div className="mt-1"><StatusPill status={a.status} /></div>
                    <div className="text-[11px] fnd-text-dim mt-1">{a.id}</div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

function colorForStatus(s: string) {
  if (s === "Active") return "#c7e1cb";
  if (s === "Warning") return "#f5dcae";
  if (s === "Offline") return "#f3c0c0";
  if (s === "Maintenance") return "#c6d9f1";
  return "#dde3e8";
}






function colorForSeverity(s: string) {
  return s === "Critical" ? "#c23030" : s === "High" ? "#d9822b" : s === "Medium" ? "#137cbd" : "#8a9ba8";
}



// ─── Header text / set title ─────────────────────────────────────────────────
function HeaderTextW({ widget }: { widget: WidgetDef }) {
  const cfg = widget.config as { text: string; variant?: "h1" | "h2" | "h3" };
  const size = cfg.variant === "h1" ? "text-xl" : cfg.variant === "h3" ? "text-sm" : "text-base";
  return <div className={`font-semibold ${size}`}>{cfg.text}</div>;
}
function ObjectSetTitleW({ widget }: { widget: WidgetDef }) {
  const { values } = useCore();
  const cfg = widget.config as { objectSetVarId: string };
  const arr = (values[cfg.objectSetVarId] as unknown[]) ?? [];
  return <div className="flex items-center gap-2 text-xs"><Icon.Object size={14}/><span className="font-semibold">{cfg.objectSetVarId}</span><span className="fnd-tag">{arr.length}</span></div>;
}

// ─── FilterList ──────────────────────────────────────────────────────────────
function FilterListW({ widget }: { widget: WidgetDef }) {
  const { values, setValues } = useCore();
  const cfg = widget.config as {
    objectSetVarId: string;
    facets: Array<{ property: string; label: string; type: "checkbox" | "histogram" | "search"; varId: string }>;
    searchVarId?: string;
  };
  const objSet = (values[cfg.objectSetVarId] as AnyObj[]) ?? [];

  return (
    <div className="space-y-3 text-xs">
      {cfg.facets.map(facet => {
        const counts: Record<string, number> = {};
        for (const o of objSet) {
          const k = String((o as unknown as Record<string, unknown>)[facet.property] ?? "—");
          counts[k] = (counts[k] || 0) + 1;
        }
        const keys = Object.keys(counts).sort();
        const max = Math.max(1, ...Object.values(counts));
        return (
          <div key={facet.property}>
            <div className="fnd-label mb-1">{facet.label}</div>
            {facet.type === "checkbox" && (
              <div className="space-y-0.5">
                {keys.map(k => {
                  const sel = (values[facet.varId] as string[]) ?? [];
                  const checked = sel.includes(k);
                  return (
                    <label key={k} className="flex items-center gap-2 fnd-row-hover px-1 py-0.5 rounded-sm cursor-pointer">
                      <input type="checkbox" checked={checked} onChange={() => {
                        const next = checked ? sel.filter(x => x !== k) : [...sel, k];
                        setValues(p => ({ ...p, [facet.varId]: next }));
                      }}/>
                      {facet.property === "status" ? <StatusPill status={k}/> : <span>{k}</span>}
                      <span className="ml-auto fnd-text-dim">{counts[k]}</span>
                    </label>
                  );
                })}
              </div>
            )}
            {facet.type === "histogram" && (
              <div className="space-y-1">
                {keys.map(k => {
                  const sel = (values[facet.varId] as string[]) ?? [];
                  const checked = sel.includes(k);
                  return (
                    <button key={k} onClick={() => {
                      const next = checked ? sel.filter(x => x !== k) : [...sel, k];
                      setValues(p => ({ ...p, [facet.varId]: next }));
                    }}
                      className={`w-full text-left flex items-center gap-2 fnd-row-hover px-1 py-0.5 rounded-sm ${checked ? "fnd-selected" : ""}`}>
                      <span style={{ width: 60 }}>{k}</span>
                      <div className="flex-1 h-2 rounded-sm" style={{ background: "var(--fnd-panel-2)", border: "1px solid var(--fnd-border)" }}>
                        <div style={{ width: `${(counts[k] / max) * 100}%`, height: "100%", background: "var(--fnd-accent)" }}/>
                      </div>
                      <span className="fnd-text-dim" style={{ width: 24, textAlign: "right" }}>{counts[k]}</span>
                    </button>
                  );
                })}
              </div>
            )}
            {facet.type === "search" && (
              <input className="fnd-input" placeholder={`Search ${facet.label.toLowerCase()}`}
                value={(values[facet.varId] as string) ?? ""}
                onChange={e => setValues(p => ({ ...p, [facet.varId]: e.target.value }))}/>
            )}
          </div>
        );
      })}
    </div>
  );
}

// ─── Inputs ─────────────────────────────────────────────────────────────────
function TextInputW({ widget }: { widget: WidgetDef }) {
  const { values, setValues } = useCore();
  const cfg = widget.config as { variableId: string; placeholder?: string; label?: string };
  return (
    <div>
      {cfg.label && <label className="fnd-field-label">{cfg.label}</label>}
      <input className="fnd-input" placeholder={cfg.placeholder} value={(values[cfg.variableId] as string) ?? ""}
        onChange={e => setValues(p => ({ ...p, [cfg.variableId]: e.target.value }))}/>
    </div>
  );
}
function NumericInputW({ widget }: { widget: WidgetDef }) {
  const { values, setValues } = useCore();
  const cfg = widget.config as { variableId: string; label?: string };
  return (
    <div>
      {cfg.label && <label className="fnd-field-label">{cfg.label}</label>}
      <input className="fnd-input" type="number" value={(values[cfg.variableId] as number) ?? 0}
        onChange={e => setValues(p => ({ ...p, [cfg.variableId]: Number(e.target.value) }))}/>
    </div>
  );
}
function DateInputW({ widget }: { widget: WidgetDef }) {
  const { values, setValues } = useCore();
  const cfg = widget.config as { variableId: string; label?: string };
  return (
    <div>
      {cfg.label && <label className="fnd-field-label">{cfg.label}</label>}
      <input className="fnd-input" type="date" value={(values[cfg.variableId] as string) ?? ""}
        onChange={e => setValues(p => ({ ...p, [cfg.variableId]: e.target.value }))}/>
    </div>
  );
}
function StringSelectorW({ widget }: { widget: WidgetDef }) {
  const { values, setValues } = useCore();
  const cfg = widget.config as { variableId: string; options?: string[]; label?: string };
  const opts = cfg.options ?? [];
  return (
    <div>
      {cfg.label && <label className="fnd-field-label">{cfg.label}</label>}
      <select className="fnd-input fnd-select" value={(values[cfg.variableId] as string) ?? ""}
        onChange={e => setValues(p => ({ ...p, [cfg.variableId]: e.target.value }))}>
        <option value="">—</option>
        {opts.map(o => <option key={o}>{o}</option>)}
      </select>
    </div>
  );
}
function CheckboxW({ widget }: { widget: WidgetDef }) {
  const { values, setValues } = useCore();
  const cfg = widget.config as { variableId: string; label?: string };
  return (
    <label className="flex items-center gap-2 text-xs">
      <input type="checkbox" checked={!!values[cfg.variableId]} onChange={e => setValues(p => ({ ...p, [cfg.variableId]: e.target.checked }))}/>
      {cfg.label ?? widget.name}
    </label>
  );
}
function UserSelectW({ widget }: { widget: WidgetDef }) {
  const { ontology } = useCore();
  return <StringSelectorW widget={{ ...widget, config: { ...widget.config, options: ontology.operators.map(o => o.name) } }} />;
}

// ─── Metric Card ─────────────────────────────────────────────────────────────
function MetricCard({ widget }: { widget: WidgetDef }) {
  const { values, fireEvents, setCurrentPageId } = useCore();
  const cfg = widget.config as { label: string; variableId: string; trend?: string; trendValue?: string; variant?: string; prefix?: string; suffix?: string; color?: string; formatter?: string };
  let val = values[cfg.variableId];
  let display = String(val ?? "—");
  if (cfg.formatter === "currencyShort" && typeof val === "number") {
    display = val >= 1e6 ? `${(val / 1e6).toFixed(1)}M` : val >= 1e3 ? `${(val / 1e3).toFixed(1)}K` : String(val);
  } else if (typeof val === "number") {
    display = val.toLocaleString();
  }
  display = `${cfg.prefix ?? ""}${display}${cfg.suffix ?? ""}`;
  const color = cfg.color === "warning" ? "#8a5a16" : cfg.color === "danger" ? "#8a1f1f" : cfg.color === "success" ? "#296936" : "var(--fnd-text)";
  if (cfg.variant === "tag") {
    return <div className="fnd-tag" style={{ height: 24 }}>{cfg.label}: <strong className="ml-1">{display}</strong></div>;
  }
  const onClick = () => {
    const evs = widget.events ?? [];
    for (const ev of evs) if (ev.trigger === "onClick") fireEvents(ev.actions);
    if (cfg.variant === "interactive") setCurrentPageId("pAnalytics");
  };
  return (
    <div className="fnd-panel rounded-sm p-3 flex flex-col justify-between" style={{ minHeight: 86, cursor: "pointer" }} onClick={onClick}>
      <div className="text-[11px] uppercase tracking-wide fnd-text-muted">{cfg.label}</div>
      <div className="flex items-baseline gap-2 mt-1">
        <div className="text-2xl font-bold tabular-nums" style={{ color }}>{display}</div>
        {cfg.trendValue && (
          <div className="text-xs" style={{ color: cfg.trend === "up" ? "#296936" : cfg.trend === "down" ? "#8a1f1f" : "var(--fnd-text-dim)" }}>
            {cfg.trend === "up" ? "↑" : cfg.trend === "down" ? "↓" : "→"} {cfg.trendValue}
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Chart XY ─────────────────────────────────────────────────────────────
function ChartXY({ widget }: { widget: WidgetDef }) {
  const { values } = useCore();
  const cfg = widget.config as { objectSetVarId: string; chartKind: string; xProperty: string; yProperty: string; agg?: string };
  const data = (values[cfg.objectSetVarId] as AnyObj[]) ?? [];
  // Aggregate: if agg="avg" group by x
  type Pt = { x: string; y: number };
  let points: Pt[] = [];
  if (cfg.agg === "avg") {
    const g: Record<string, number[]> = {};
    for (const o of data) {
      const x = String((o as unknown as Record<string, unknown>)[cfg.xProperty] ?? "—");
      const y = Number((o as unknown as Record<string, unknown>)[cfg.yProperty] ?? 0);
      (g[x] ??= []).push(y);
    }
    points = Object.entries(g).map(([x, ys]) => ({ x, y: ys.reduce((a, b) => a + b, 0) / ys.length }));
  } else {
    points = data.slice(0, 40).map(o => ({ x: String((o as unknown as Record<string, unknown>)[cfg.xProperty] ?? ""), y: Number((o as unknown as Record<string, unknown>)[cfg.yProperty] ?? 0) }));
  }
  const w = 400, h = 180, p = 24;
  const maxY = Math.max(1, ...points.map(p => p.y));
  const barW = points.length > 0 ? (w - p * 2) / points.length : 0;
  return (
    <div className="fnd-panel rounded-sm p-3 h-full flex flex-col">
      <div className="text-xs font-semibold mb-2">{widget.name}</div>
      <div className="flex-1 flex items-center justify-center">
        <svg viewBox={`0 0 ${w} ${h}`} width="100%" style={{ maxHeight: 220 }}>
          <line x1={p} y1={h - p} x2={w - p} y2={h - p} stroke="var(--fnd-border)" />
          <line x1={p} y1={p} x2={p} y2={h - p} stroke="var(--fnd-border)" />
          {cfg.chartKind === "bar" && points.map((pt, i) => {
            const bh = ((pt.y / maxY) * (h - p * 2));
            return <g key={i}>
              <rect x={p + i * barW + 2} y={h - p - bh} width={Math.max(1, barW - 4)} height={bh} fill="var(--fnd-accent)" />
              <text x={p + i * barW + barW / 2} y={h - p + 10} textAnchor="middle" fontSize="9" fill="var(--fnd-text-muted)">{pt.x.slice(0, 6)}</text>
            </g>;
          })}
          {cfg.chartKind !== "bar" && points.length > 1 && (
            <polyline fill="none" stroke="var(--fnd-accent)" strokeWidth="1.6"
              points={points.map((pt, i) => `${p + (i / (points.length - 1)) * (w - p * 2)},${h - p - (pt.y / maxY) * (h - p * 2)}`).join(" ")}/>
          )}
          {cfg.chartKind !== "bar" && points.map((pt, i) => (
            <circle key={i} cx={p + (i / Math.max(1, points.length - 1)) * (w - p * 2)} cy={h - p - (pt.y / maxY) * (h - p * 2)} r="2.5" fill="var(--fnd-accent)" />
          ))}
        </svg>
      </div>
      <div className="text-[10px] fnd-text-dim mt-1">{points.length} points · {cfg.yProperty} by {cfg.xProperty}</div>
    </div>
  );
}

function ChartPie({ widget }: { widget: WidgetDef }) {
  const { values } = useCore();
  const cfg = widget.config as { objectSetVarId: string; groupBy: string; variant?: "donut" };
  const data = (values[cfg.objectSetVarId] as AnyObj[]) ?? [];
  const g: Record<string, number> = {};
  for (const o of data) {
    const k = String((o as unknown as Record<string, unknown>)[cfg.groupBy] ?? "—");
    g[k] = (g[k] || 0) + 1;
  }
  const entries = Object.entries(g);
  const total = entries.reduce((a, [, v]) => a + v, 0) || 1;
  const palette = ["#2b6cb0", "#d9822b", "#0f9960", "#c23030", "#8a5a16", "#5c7080", "#137cbd"];
  let acc = 0;
  const r = 60, cx = 70, cy = 70;
  return (
    <div className="fnd-panel rounded-sm p-3 h-full flex flex-col">
      <div className="text-xs font-semibold mb-2">{widget.name}</div>
      <div className="flex-1 flex items-center gap-3">
        <svg width="140" height="140" viewBox="0 0 140 140">
          {entries.map(([k, v], i) => {
            const a0 = (acc / total) * Math.PI * 2 - Math.PI / 2;
            acc += v;
            const a1 = (acc / total) * Math.PI * 2 - Math.PI / 2;
            const x0 = cx + r * Math.cos(a0), y0 = cy + r * Math.sin(a0);
            const x1 = cx + r * Math.cos(a1), y1 = cy + r * Math.sin(a1);
            const large = (a1 - a0) > Math.PI ? 1 : 0;
            return <path key={k} d={`M${cx},${cy} L${x0},${y0} A${r},${r} 0 ${large} 1 ${x1},${y1} Z`} fill={palette[i % palette.length]} opacity="0.85"/>;
          })}
          {cfg.variant === "donut" && <circle cx={cx} cy={cy} r="28" fill="var(--fnd-panel)"/>}
        </svg>
        <div className="flex-1 space-y-0.5 text-xs">
          {entries.map(([k, v], i) => (
            <div key={k} className="flex items-center gap-1.5">
              <span style={{ width: 10, height: 10, background: palette[i % palette.length], borderRadius: 2 }}/>
              <span className="flex-1 truncate">{k}</span>
              <span className="fnd-text-dim tabular-nums">{v} · {Math.round((v / total) * 100)}%</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}


// ─── Gantt ─────────────────────────────────────────────────────────────
function GanttWidget({ widget }: { widget: WidgetDef }) {
  const { values } = useCore();
  const cfg = widget.config as { objectSetVarId: string };
  const wos = ((values[cfg.objectSetVarId] as unknown[]) ?? []) as Array<{ id: string; title: string; status: string; createdAt: string; due: string }>;
  const rows = wos.slice(0, 20);
  const startDate = new Date(2026, 8, 1).getTime();
  const endDate = new Date(2026, 10, 1).getTime();
  const span = endDate - startDate;
  return (
    <div className="fnd-panel rounded-sm overflow-hidden flex flex-col">
      <div className="flex items-center gap-2 px-2.5 py-1.5 border-b fnd-border">
        <Icon.Gantt size={14}/><div className="text-xs font-semibold">{widget.name}</div>
      </div>
      <div className="overflow-auto">
        <table className="w-full text-xs" style={{ minWidth: 500 }}>
          <thead>
            <tr style={{ background: "var(--fnd-panel-2)" }}>
              <th style={{ textAlign: "left", padding: "4px 8px", width: 200, borderBottom: "1px solid var(--fnd-border)" }}>Task</th>
              <th style={{ padding: "4px 8px", borderBottom: "1px solid var(--fnd-border)" }}>Sep 2026 — Oct 2026</th>
            </tr>
          </thead>
          <tbody>
            {rows.map(r => {
              const s = new Date(r.createdAt).getTime();
              const e = new Date(r.due).getTime();
              const left = Math.max(0, ((s - startDate) / span) * 100);
              const width = Math.max(2, ((e - s) / span) * 100);
              return (
                <tr key={r.id} style={{ borderBottom: "1px solid var(--fnd-border)" }}>
                  <td style={{ padding: "4px 8px", whiteSpace: "nowrap" }}>{r.id} · {r.title}</td>
                  <td style={{ padding: "4px 8px" }}>
                    <div style={{ position: "relative", height: 14, background: "var(--fnd-panel-2)", borderRadius: 2 }}>
                      <div style={{ position: "absolute", left: `${left}%`, width: `${width}%`, top: 0, height: "100%", background: colorForStatus(r.status === "Done" ? "Active" : r.status === "Blocked" ? "Offline" : "Warning"), borderRadius: 2 }} title={r.status}/>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ─── Timeline ─────────────────────────────────────────────────────────────
function TimelineWidget({ widget }: { widget: WidgetDef }) {
  const { values } = useCore();
  const cfg = widget.config as { objectSetVarId: string };
  const alerts = ((values[cfg.objectSetVarId] as unknown[]) ?? []) as Array<{ id: string; title: string; createdAt: string; severity: string }>;
  const rows = alerts.slice(0, 30);
  return (
    <div className="fnd-panel rounded-sm p-3">
      <div className="text-xs font-semibold mb-2">{widget.name}</div>
      <div className="relative" style={{ borderLeft: "2px solid var(--fnd-border)", marginLeft: 6, paddingLeft: 12 }}>
        {rows.length === 0 && <div className="fnd-text-dim text-xs">No events.</div>}
        {rows.map(a => (
          <div key={a.id} className="mb-2 relative">
            <div style={{ position: "absolute", left: -18, top: 3, width: 8, height: 8, borderRadius: "50%", background: colorForSeverity(a.severity) }}/>
            <div className="text-xs font-semibold">{a.title}</div>
            <div className="text-[11px] fnd-text-muted">{new Date(a.createdAt).toLocaleString()}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Pivot Table ─────────────────────────────────────────────────────────────
function PivotTableW({ widget }: { widget: WidgetDef }) {
  const { values } = useCore();
  const cfg = widget.config as { objectSetVarId: string; rows: string; cols: string; measure: string };
  const data = (values[cfg.objectSetVarId] as AnyObj[]) ?? [];
  const rowSet = new Set<string>(), colSet = new Set<string>();
  for (const o of data) {
    rowSet.add(String((o as unknown as Record<string, unknown>)[cfg.rows] ?? "—"));
    colSet.add(String((o as unknown as Record<string, unknown>)[cfg.cols] ?? "—"));
  }
  const rows = [...rowSet].sort(), cols = [...colSet].sort();
  const grid: Record<string, Record<string, number>> = {};
  for (const o of data) {
    const r = String((o as unknown as Record<string, unknown>)[cfg.rows] ?? "—");
    const c = String((o as unknown as Record<string, unknown>)[cfg.cols] ?? "—");
    (grid[r] ??= {})[c] = ((grid[r] ??= {})[c] ?? 0) + 1;
  }
  return (
    <div className="fnd-panel rounded-sm overflow-auto">
      <div className="px-2.5 py-1.5 border-b fnd-border text-xs font-semibold">{widget.name}</div>
      <table className="w-full text-xs">
        <thead>
          <tr style={{ background: "var(--fnd-panel-2)" }}>
            <th style={{ padding: "4px 8px", textAlign: "left", borderBottom: "1px solid var(--fnd-border)" }}>{cfg.rows} / {cfg.cols}</th>
            {cols.map(c => <th key={c} style={{ padding: "4px 8px", borderBottom: "1px solid var(--fnd-border)" }}>{c}</th>)}
            <th style={{ padding: "4px 8px", borderBottom: "1px solid var(--fnd-border)" }}>Total</th>
          </tr>
        </thead>
        <tbody>
          {rows.map(r => {
            const total = cols.reduce((a, c) => a + (grid[r]?.[c] ?? 0), 0);
            return (
              <tr key={r} style={{ borderBottom: "1px solid var(--fnd-border)" }}>
                <td style={{ padding: "4px 8px", fontWeight: 600 }}>{r}</td>
                {cols.map(c => <td key={c} style={{ padding: "4px 8px", textAlign: "center", tabularNums: "true" } as React.CSSProperties}>{grid[r]?.[c] ?? 0}</td>)}
                <td style={{ padding: "4px 8px", textAlign: "center", fontWeight: 600 }}>{total}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

// ─── Markdown ──────────────────────────────────────────────────────────────
function MarkdownW({ widget }: { widget: WidgetDef }) {
  const cfg = widget.config as { text: string };
  const html = renderMd(cfg.text);
  return <div className="fnd-panel rounded-sm p-4 prose-sm max-w-none" style={{ fontSize: 13, lineHeight: 1.6 }} dangerouslySetInnerHTML={{ __html: html }}/>;
}
function renderMd(md: string): string {
  let s = md
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/^## (.*)$/gm, '<h3 style="font-size:15px;font-weight:600;margin:12px 0 6px">$1</h3>')
    .replace(/^# (.*)$/gm, '<h2 style="font-size:17px;font-weight:700;margin:12px 0 6px">$1</h2>')
    .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
    .replace(/_(.+?)_/g, "<em>$1</em>")
    .replace(/`([^`]+)`/g, '<code style="background:var(--fnd-panel-2);padding:1px 4px;border-radius:2px;font-family:ui-monospace,Menlo,monospace;font-size:12px">$1</code>')
    .replace(/^> (.*)$/gm, '<blockquote style="border-left:3px solid var(--fnd-accent);padding-left:10px;color:var(--fnd-text-muted);margin:6px 0">$1</blockquote>')
    .replace(/^\d+\. (.*)$/gm, '<li>$1</li>')
    .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a style="color:var(--fnd-accent)" href="$2">$1</a>');
  s = s.replace(/(<li>[\s\S]*?<\/li>\s*)+/g, m => `<ol style="padding-left:20px;margin:4px 0">${m}</ol>`);
  s = s.replace(/\n\n/g, "<p/>").replace(/\n/g, "<br/>");
  return s;
}

// ─── PDF Viewer (mock) ─────────────────────────────────────────────────────
function PdfViewerW({ widget }: { widget: WidgetDef }) {
  const { values, setValues } = useCore();
  const cfg = widget.config as { source: string; pageVarId: string; totalPages: number };
  const page = (values[cfg.pageVarId] as number) ?? 1;
  return (
    <div className="fnd-panel rounded-sm h-full flex flex-col overflow-hidden">
      <div className="flex items-center gap-2 px-2.5 py-1.5 border-b fnd-border">
        <Icon.Pdf size={14}/>
        <div className="text-xs font-semibold truncate">{cfg.source}</div>
        <div className="flex-1"/>
        <button className="fnd-btn fnd-btn-minimal" onClick={() => setValues(p => ({ ...p, [cfg.pageVarId]: Math.max(1, page - 1) }))}><Icon.Chevron size={12} dir="left"/></button>
        <span className="text-xs tabular-nums">{page} / {cfg.totalPages}</span>
        <button className="fnd-btn fnd-btn-minimal" onClick={() => setValues(p => ({ ...p, [cfg.pageVarId]: Math.min(cfg.totalPages, page + 1) }))}><Icon.Chevron size={12} dir="right"/></button>
      </div>
      <div className="flex-1 overflow-auto p-4 flex items-start justify-center" style={{ background: "#e3e5e8" }}>
        <div style={{ width: 320, aspectRatio: "1 / 1.414", background: "white", boxShadow: "0 1px 4px rgba(0,0,0,0.15)", padding: 24, fontSize: 10 }}>
          <div style={{ fontWeight: 700, marginBottom: 10 }}>Compliance Report — Page {page}</div>
          <div style={{ color: "#888" }}>§{page}.1 Executive Summary</div>
          <div style={{ marginTop: 6 }}>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Operational metrics for Q3 2026 indicate stable availability across the fleet.</div>
          <div style={{ marginTop: 10, height: 2, background: "#eee" }}/>
          <div style={{ marginTop: 8, color: "#aaa", fontSize: 9 }}>Page {page} of {cfg.totalPages}</div>
        </div>
      </div>
    </div>
  );
}

// ─── Button Group ──────────────────────────────────────────────────────────
function ButtonGroupW({ widget }: { widget: WidgetDef }) {
  const { fireEvents } = useCore();
  const cfg = widget.config as { buttons: Array<{ label: string; variant?: string; icon?: string; eventActions: EventActionLike[] }> };
  return (
    <div className="flex flex-wrap gap-2">
      {cfg.buttons.map((b, i) => {
        const cls = b.variant === "primary" ? "fnd-btn-primary" : b.variant === "danger" ? "fnd-btn-danger" : b.variant === "minimal" ? "fnd-btn-minimal" : "";
        const icon = b.icon === "edit" ? <Icon.Edit size={12}/> : b.icon === "plus" ? <Icon.Plus size={12}/> : b.icon === "trash" ? <Icon.Trash size={12}/> : b.icon === "arrow" ? <Icon.Chevron size={12} dir="right"/> : null;
        return (
          <button key={i} className={`fnd-btn ${cls}`} onClick={() => fireEvents(b.eventActions as unknown as import("../types").EventAction[])}>
            {icon} {b.label}
          </button>
        );
      })}
    </div>
  );
}
type EventActionLike = { kind: string; [k: string]: unknown };

// ─── Tabs ─────────────────────────────────────────────────────────────────
function TabsW({ widget }: { widget: WidgetDef }) {
  const { values, setValues } = useCore();
  const cfg = widget.config as { tabs: string[]; variableId?: string };
  const active = cfg.variableId ? ((values[cfg.variableId] as number) ?? 0) : 0;
  return (
    <div className="flex gap-0 border-b fnd-border">
      {cfg.tabs.map((t, i) => (
        <button key={t} onClick={() => cfg.variableId && setValues(p => ({ ...p, [cfg.variableId!]: i }))}
          className="px-3 py-1.5 text-xs font-medium"
          style={{ borderBottom: active === i ? "2px solid var(--fnd-accent)" : "2px solid transparent", color: active === i ? "var(--fnd-text)" : "var(--fnd-text-muted)" }}>
          {t}
        </button>
      ))}
    </div>
  );
}

// ─── Status Tracker ─────────────────────────────────────────────────────────
function StatusTrackerW({ widget }: { widget: WidgetDef }) {
  const { values } = useCore();
  const cfg = widget.config as { objectVarId: string; stages: string[]; activeProp: string };
  const obj = values[cfg.objectVarId] as AssetObj | null;
  const current = obj ? (obj as unknown as Record<string, string>)[cfg.activeProp] : "";
  const idx = cfg.stages.indexOf(current);
  return (
    <div className="fnd-panel rounded-sm p-3">
      <div className="fnd-label mb-2">Status</div>
      <div className="flex items-center gap-1 text-[11px]">
        {cfg.stages.map((s, i) => {
          const active = i === idx;
          const past = i < idx;
          return (
            <React.Fragment key={s}>
              <div className="flex flex-col items-center gap-1">
                <div style={{ width: 16, height: 16, borderRadius: "50%", background: active ? "var(--fnd-accent)" : past ? "var(--fnd-success)" : "var(--fnd-panel-2)", border: "1.5px solid " + (active || past ? "transparent" : "var(--fnd-border-strong)") }}/>
                <span style={{ fontWeight: active ? 700 : 500, color: active ? "var(--fnd-text)" : "var(--fnd-text-muted)" }}>{s}</span>
              </div>
              {i < cfg.stages.length - 1 && <div style={{ flex: 1, height: 1, background: "var(--fnd-border)" }}/>}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
}

// ─── Stepper ──────────────────────────────────────────────────────────────
function StepperW({ widget }: { widget: WidgetDef }) {
  const { values, setValues } = useCore();
  const cfg = widget.config as { steps: string[]; currentVarId?: string };
  const current = cfg.currentVarId ? ((values[cfg.currentVarId] as number) ?? 0) : 0;
  return (
    <div className="fnd-panel rounded-sm p-3">
      <div className="fnd-label mb-2">Workflow</div>
      <div className="flex items-center justify-between gap-1">
        {cfg.steps.map((s, i) => (
          <React.Fragment key={s}>
            <button onClick={() => cfg.currentVarId && setValues(p => ({ ...p, [cfg.currentVarId!]: i }))} className="flex flex-col items-center gap-1 cursor-pointer">
              <div style={{ width: 24, height: 24, borderRadius: "50%", background: i <= current ? "var(--fnd-accent)" : "var(--fnd-panel-2)", color: i <= current ? "white" : "var(--fnd-text-muted)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 700 }}>
                {i + 1}
              </div>
              <span className="text-[11px]" style={{ fontWeight: i === current ? 700 : 500 }}>{s}</span>
            </button>
            {i < cfg.steps.length - 1 && <div style={{ flex: 1, height: 2, background: i < current ? "var(--fnd-accent)" : "var(--fnd-border)" }}/>}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
}

// ─── Comments ─────────────────────────────────────────────────────────────
interface CommentItem { author: string; text: string; ts: number; }
function CommentsW({ widget }: { widget: WidgetDef }) {
  const { values, setValues } = useCore();
  const cfg = widget.config as { listVarId: string; draftVarId: string };
  const list = ((values[cfg.listVarId] as CommentItem[]) ?? []);
  const draft = (values[cfg.draftVarId] as string) ?? "";
  const submit = () => {
    if (!draft.trim()) return;
    const next = [...list, { author: "You", text: draft, ts: Date.now() }];
    setValues(p => ({ ...p, [cfg.listVarId]: next, [cfg.draftVarId]: "" }));
  };
  return (
    <div className="fnd-panel rounded-sm p-3 flex flex-col gap-2 h-full">
      <div className="text-xs font-semibold">Discussion</div>
      <div className="flex-1 overflow-auto space-y-2">
        {list.length === 0 && <div className="fnd-text-dim text-xs p-4 text-center">No comments yet. Start a thread below.</div>}
        {list.map((c, i) => (
          <div key={i} className="flex gap-2">
            <div style={{ width: 24, height: 24, borderRadius: "50%", background: "var(--fnd-accent)", color: "white", fontSize: 11, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700 }}>{c.author[0]}</div>
            <div className="flex-1">
              <div className="text-[11px]"><strong>{c.author}</strong> · <span className="fnd-text-dim">{new Date(c.ts).toLocaleTimeString()}</span></div>
              <div className="text-xs">{c.text}</div>
            </div>
          </div>
        ))}
      </div>
      <div className="flex gap-2">
        <input className="fnd-input flex-1" placeholder="Add a comment..." value={draft} onChange={e => setValues(p => ({ ...p, [cfg.draftVarId]: e.target.value }))} onKeyDown={e => { if (e.key === "Enter") submit(); }}/>
        <button className="fnd-btn fnd-btn-primary" onClick={submit}>Post</button>
      </div>
    </div>
  );
}

// ─── Media Uploader ─────────────────────────────────────────────────────
function MediaUploadW({ widget }: { widget: WidgetDef }) {
  const { values, setValues } = useCore();
  const cfg = widget.config as { outputVarId: string };
  const file = (values[cfg.outputVarId] as string) ?? "";
  const [progress, setProgress] = useState(0);
  const upload = () => {
    const names = ["reading_2026-09-30.csv", "sensor_log.json", "incident_photo.jpg"];
    const name = names[Math.floor(Math.random() * names.length)];
    setProgress(1);
    const t = setInterval(() => setProgress(p => {
      if (p >= 100) { clearInterval(t); setValues(prev => ({ ...prev, [cfg.outputVarId]: name })); return 0; }
      return p + 10;
    }), 60);
  };
  return (
    <div className="fnd-panel rounded-sm p-3">
      <div className="text-xs font-semibold mb-2">Upload Reading</div>
      <div onClick={upload} className="rounded-sm border-2 border-dashed fnd-border cursor-pointer p-6 text-center" style={{ background: "var(--fnd-panel-2)" }}>
        <Icon.Upload size={24}/>
        <div className="text-xs mt-2 fnd-text-muted">Drag file here or <span style={{ color: "var(--fnd-accent)" }}>choose file</span></div>
      </div>
      {progress > 0 && (
        <div className="mt-2">
          <div className="text-[11px] fnd-text-muted">Uploading... {progress}%</div>
          <div style={{ height: 4, background: "var(--fnd-panel-2)", borderRadius: 2, marginTop: 4 }}>
            <div style={{ width: `${progress}%`, height: "100%", background: "var(--fnd-accent)", borderRadius: 2 }}/>
          </div>
        </div>
      )}
      {file && progress === 0 && <div className="mt-2 text-[11px]"><Icon.Check size={10}/> Uploaded: <strong>{file}</strong></div>}
    </div>
  );
}


// ─── AIP Chatbot ──────────────────────────────────────────────────────────
interface ChatMsg { role: "user" | "assistant"; text: string; }
function AIPChatW({ widget }: { widget: WidgetDef }) {
  const { values, setValues } = useCore();
  const cfg = widget.config as { historyVarId: string; inputVarId: string; suggestions?: string[] };
  const history = ((values[cfg.historyVarId] as ChatMsg[]) ?? []);
  const input = (values[cfg.inputVarId] as string) ?? "";
  const [loading, setLoading] = useState(false);

  const send = (msg?: string) => {
    const text = (msg ?? input).trim();
    if (!text) return;
    const next = [...history, { role: "user" as const, text }];
    setValues(p => ({ ...p, [cfg.historyVarId]: next, [cfg.inputVarId]: "" }));
    setLoading(true);
    setTimeout(() => {
      const reply = generateReply(text, values);
      setValues(p => ({ ...p, [cfg.historyVarId]: [...next, { role: "assistant" as const, text: reply }] }));
      setLoading(false);
    }, 700);
  };

  return (
    <div className="fnd-panel rounded-sm flex flex-col h-full overflow-hidden" style={{ minHeight: 320 }}>
      <div className="flex items-center gap-2 px-2.5 py-1.5 border-b fnd-border">
        <Icon.AI size={14}/>
        <div className="text-xs font-semibold">AIP Assistant</div>
        <div className="flex-1"/>
        <button className="fnd-btn fnd-btn-minimal" onClick={() => setValues(p => ({ ...p, [cfg.historyVarId]: [] }))}>Reset</button>
      </div>
      <div className="flex-1 overflow-auto p-3 space-y-3">
        {history.length === 0 && (
          <div className="text-center fnd-text-dim text-xs">
            <Icon.AI size={28}/>
            <div className="mt-2 mb-3">Ask the AIP assistant about your assets, alerts, and operations.</div>
            <div className="flex flex-col gap-1.5 items-center">
              {(cfg.suggestions ?? []).map(s => (
                <button key={s} className="fnd-btn fnd-btn-minimal" style={{ height: 24 }} onClick={() => send(s)}>{s}</button>
              ))}
            </div>
          </div>
        )}
        {history.map((m, i) => (
          <div key={i} className="flex gap-2">
            <div style={{ width: 20, height: 20, borderRadius: 3, background: m.role === "user" ? "var(--fnd-accent)" : "var(--fnd-success)", color: "white", fontSize: 10, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700 }}>
              {m.role === "user" ? "U" : "AI"}
            </div>
            <div className="flex-1 text-xs whitespace-pre-wrap">{m.text}</div>
          </div>
        ))}
        {loading && <div className="flex gap-2"><div style={{ width: 20, height: 20, borderRadius: 3, background: "var(--fnd-success)" }}/><div className="fnd-text-dim text-xs fnd-pulse">Thinking...</div></div>}
      </div>
      <div className="border-t fnd-border p-2 flex gap-2">
        <input className="fnd-input flex-1" placeholder="Ask a question..." value={input} onChange={e => setValues(p => ({ ...p, [cfg.inputVarId]: e.target.value }))} onKeyDown={e => { if (e.key === "Enter") send(); }}/>
        <button className="fnd-btn fnd-btn-primary" onClick={() => send()}>Send</button>
      </div>
    </div>
  );
}

function generateReply(text: string, values: Record<string, unknown>): string {
  const q = text.toLowerCase();
  const assets = (values.filteredAssets as AssetObj[]) ?? [];
  const alerts = (values.activeAlerts as unknown[]) ?? [];
  if (q.includes("alert")) {
    return `There are currently ${alerts.length} active alerts across the fleet. Highest severity items are concentrated in Warning-state assets. Open the Operations page to triage.`;
  }
  if (q.includes("revenue") || q.includes("risk")) {
    const top = [...assets].sort((a, b) => b.revenueImpact - a.revenueImpact)[0];
    return top ? `The asset with the highest revenue risk in the current filter is ${top.name} (${top.id}), with $${(top.revenueImpact / 1e6).toFixed(2)}M at risk.` : "No assets in filter.";
  }
  if (q.includes("filter")) {
    return `The Status Filter restricts the active Object Set to only assets with matching status values. All downstream widgets (Object Table, Map, Metrics, Charts) reactively update via the \`filteredAssets\` variable.`;
  }
  if (q.includes("summarise") || q.includes("summary")) {
    return `Fleet summary: ${assets.length} filtered assets, ${alerts.length} open alerts. Status breakdown is visible in the Status Distribution pie chart on the Analytics page.`;
  }
  return `I've referenced ${assets.length} assets in the current context. Try asking about alerts, revenue impact, or filters.`;
}

// ─── AIP Analyst ──────────────────────────────────────────────────────────
function AIPAnalystW({ widget }: { widget: WidgetDef }) {
  const { values } = useCore();
  const cfg = widget.config as { contextVarId: string };
  const obj = values[cfg.contextVarId] as AssetObj | null;
  return (
    <div className="fnd-panel rounded-sm p-3">
      <div className="flex items-center gap-2 mb-2">
        <Icon.AI size={14}/><div className="text-xs font-semibold">AIP Analyst</div>
      </div>
      <div className="text-xs fnd-text-muted mb-2">Context: {obj?.name ?? "No asset selected"}</div>
      <div className="space-y-2 text-xs">
        <div className="fnd-panel-2 rounded-sm p-2">
          <div className="fnd-label">Suggested prompts</div>
          <ul className="list-disc list-inside mt-1 fnd-text-muted">
            <li>Why is this asset in Warning state?</li>
            <li>Compare availability to peer fleet.</li>
            <li>Summarize work orders for Q3.</li>
          </ul>
        </div>
        <div className="fnd-panel-2 rounded-sm p-2">
          <div className="fnd-label">Analysis output</div>
          <div className="mt-1">{obj ? `${obj.name} shows elevated pressure (${obj.pressure} bar) relative to the fleet median. Recommend sensor recalibration within 48h.` : "Select an asset to generate analysis."}</div>
        </div>
      </div>
    </div>
  );
}

function AIPGenW({ widget }: { widget: WidgetDef }) {
  const { values } = useCore();
  const cfg = widget.config as { objectVarId: string };
  const obj = values[cfg.objectVarId] as AssetObj | null;
  return (
    <div className="fnd-panel rounded-sm p-3">
      <div className="flex items-center gap-2 mb-2"><Icon.AI size={14}/><div className="text-xs font-semibold">Insights</div></div>
      {!obj ? <div className="text-xs fnd-text-dim">No object context.</div> : (
        <div className="text-xs space-y-2">
          <div>• Pressure trend over last 7 days: <strong>stable</strong></div>
          <div>• Correlated with ambient temperature at 0.72</div>
          <div>• 2 similar assets in {obj.owner}&apos;s portfolio showed early warnings prior to incidents</div>
        </div>
      )}
    </div>
  );
}

// ─── Embedded Module ────────────────────────────────────────────────────
function EmbeddedModuleW({ widget }: { widget: WidgetDef }) {
  const { values } = useCore();
  const cfg = widget.config as { moduleId: string; bindings: Array<{ parentVar: string; childInterface: string }> };
  return (
    <div className="fnd-panel rounded-sm overflow-hidden h-full flex flex-col">
      <div className="flex items-center gap-2 px-2.5 py-1.5 border-b fnd-border" style={{ background: "var(--fnd-panel-2)" }}>
        <Icon.Embed size={14}/>
        <div className="text-xs font-semibold">Embedded: {cfg.moduleId}</div>
      </div>
      <div className="p-3 text-xs">
        <div className="fnd-label mb-2">Variable bindings</div>
        <table className="w-full text-xs">
          <thead><tr><th style={{ textAlign: "left" }}>Parent</th><th style={{ textAlign: "left" }}>Child Interface</th><th style={{ textAlign: "left" }}>Current value</th></tr></thead>
          <tbody>
            {cfg.bindings.map(b => (
              <tr key={b.parentVar}>
                <td className="py-1">@{b.parentVar}</td>
                <td>{b.childInterface}</td>
                <td className="truncate" style={{ maxWidth: 160 }}>{formatValue(values[b.parentVar])}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="mt-3 fnd-panel-2 rounded-sm p-3">
          <div className="text-xs fnd-text-muted">Embedded module runtime renders here with the above bindings. Mutations propagate back via <code>inputOutput</code> interface.</div>
        </div>
      </div>
    </div>
  );
}

export function formatValue(v: unknown): string {
  if (v == null) return "null";
  if (typeof v === "object") {
    const o = v as Record<string, unknown>;
    if (o.name) return String(o.name);
    if (o.id) return String(o.id);
    if (Array.isArray(v)) return `Array(${v.length})`;
    return JSON.stringify(v).slice(0, 60);
  }
  if (typeof v === "boolean") return v ? "true" : "false";
  return String(v);
}

function CustomWidgetW({ widget }: { widget: WidgetDef }) {
  const cfg = widget.config as { widgetSet: string; version: string; params: Array<{ name: string; varId?: string; value?: string }>; permissions: string[] };
  return (
    <div className="fnd-panel rounded-sm overflow-hidden">
      <div className="flex items-center gap-2 px-2.5 py-1.5 border-b fnd-border" style={{ background: "var(--fnd-panel-2)" }}>
        <Icon.Code size={14}/>
        <div className="text-xs font-semibold">Custom · {cfg.widgetSet}@{cfg.version}</div>
      </div>
      <div className="p-3 text-xs">
        <div className="fnd-label">Parameters</div>
        <ul className="my-1">
          {cfg.params.map(p => <li key={p.name} className="py-0.5">· {p.name} → {p.varId ? `@${p.varId}` : `"${p.value}"`}</li>)}
        </ul>
        <div className="fnd-label mt-2">Permissions</div>
        <div className="flex gap-1 flex-wrap mt-1">{cfg.permissions.map(p => <span key={p} className="fnd-tag">{p}</span>)}</div>
      </div>
    </div>
  );
}

function IframeW({ widget }: { widget: WidgetDef }) {
  const cfg = widget.config as { url: string; height?: number };
  return (
    <div className="fnd-panel rounded-sm overflow-hidden" style={{ height: cfg.height ?? 240 }}>
      <div className="px-2.5 py-1.5 border-b fnd-border text-xs flex items-center gap-2"><Icon.Embed size={12}/><span className="truncate">{cfg.url}</span></div>
      <div className="h-full flex items-center justify-center fnd-text-dim text-xs" style={{ background: "repeating-linear-gradient(45deg, var(--fnd-panel-2) 0 8px, var(--fnd-panel) 8px 16px)" }}>
        External embedded content
      </div>
    </div>
  );
}
