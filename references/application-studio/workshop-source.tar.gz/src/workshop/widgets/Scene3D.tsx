"use client";
import React, { useEffect, useMemo, useRef, useState } from "react";
import type { Object3D, Mesh, Material, WebGLRenderer, PerspectiveCamera, Scene, GridHelper, BoxHelper, Color } from "three";
import { useCore } from "../WorkshopContext";
import { telemetryStore, readAssetSample, startTelemetry, type AssetSample } from "../telemetry/telemetryStore";
import { useStore } from "../runtimeStores";
import { defaultSceneConfig, resolveMapping, sceneConfigFrom, type SceneConfig, type SceneMapping, type SceneLayer } from "../scene3d/mapping";
import { Icon } from "./icons";
import type { WidgetDef } from "../types";

interface SceneHandle {
  root: Object3D | null;
  scene: Scene;
  renderer: WebGLRenderer;
  camera: PerspectiveCamera;
  controls: { update: () => void; dispose: () => void; target: { set: (x: number, y: number, z: number) => void } };
  grid: GridHelper;
  originals: Map<Object3D, { x: number; y: number; z: number; rx: number; ry: number; rz: number; sx: number; sy: number; sz: number }>;
  materialColors: Map<Material, Color>;
  selectionBox: BoxHelper | null;
  smoothed: Map<string, number>;
  lastFrameAt: number;
  frame: number;
  disposed: boolean;
  fit: () => void;
}
const shorten = (s: string, n = 22) => s.length > n ? s.slice(0, n - 1) + "…" : s;
const partKind = (name: string) => /Pitch|Roll|Yaw|Finger/.test(name) ? "joint" : /Probe|Sensor|Beacon/.test(name) ? "sensor" : /Conveyor|Motor|Belt/.test(name) ? "equipment" : "structure";

export function Scene3DWidget({ widget, isBuilder }: { widget: WidgetDef; isBuilder: boolean }) {
  const { values, module, updateModule, ontologyMeta, setValues } = useCore();
  const cfg = useMemo(() => sceneConfigFrom(widget.config), [widget.config]);
  const cfgRef = useRef(cfg); cfgRef.current = cfg;
  const selectedAsset = values[cfg.assetVarId] as Record<string, unknown> | null;
  const assetId = typeof selectedAsset?.id === "string" ? selectedAsset.id : "AST-1000";
  const assetRef = useRef(selectedAsset); assetRef.current = selectedAsset;
  const sampleRef = useRef<AssetSample | null>(null);
  const [sample, setSample] = useState<AssetSample | null>(null);
  const [history, setHistory] = useState<AssetSample[]>([]);
  const [scrubIndex, setScrubIndex] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loadState, setLoadState] = useState<"loading" | "ready" | "error">("loading");
  const [modelParts, setModelParts] = useState<Array<{ name: string; depth: number; kind: string }>>([]);
  const [selectedPart, setSelectedPart] = useState<string | null>(null);
  const selectedRef = useRef(selectedPart); selectedRef.current = selectedPart;
  const [view, setView] = useState<"layers" | "bindings" | "parts">("layers");
  const [sideOpen, setSideOpen] = useState(true);
  const [explode, setExplode] = useState(0);
  const explodeRef = useRef(0); explodeRef.current = explode;
  const [isolate, setIsolate] = useState(false);
  const isolateRef = useRef(false); isolateRef.current = isolate;
  const [fps, setFps] = useState(0);
  const [meshCount, setMeshCount] = useState(0);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [loadedUrl, setLoadedUrl] = useState("");
  const [narrow, setNarrow] = useState(false);
  const selectedMapping = useRef<string | null>(null);
  const [mappingId, setMappingId] = useState<string | null>(null);
  const canvasHost = useRef<HTMLDivElement>(null);
  const outerRef = useRef<HTMLDivElement>(null);
  const engine = useRef<SceneHandle | null>(null);
  const qualityRef = useRef(cfg.quality); qualityRef.current = cfg.quality;
  const liveMode = useRef(cfg.live); liveMode.current = cfg.live;
  const scrubRef = useRef<AssetSample | null>(null);
  const modelFileRef = useRef(uploadedFile); modelFileRef.current = uploadedFile;
  const signalNames = useStore(telemetryStore, s => s.columnNames);
  const wasmReady = useStore(telemetryStore, s => s.wasm);
  const paused = useStore(telemetryStore, s => s.paused);
  const dataReady = useStore(telemetryStore, s => s.ready);

  const updateCfg = (changes: Partial<SceneConfig>) => updateModule(m => ({ ...m, widgets: { ...m.widgets, [widget.id]: { ...m.widgets[widget.id], config: { ...m.widgets[widget.id].config, ...changes } } } }), "edit 3D scene");
  const updateLayer = (id: string, patch: Partial<SceneLayer>) => updateCfg({ layers: cfg.layers.map(l => l.id === id ? { ...l, ...patch } : l) });
  const updateMapping = (id: string, patch: Partial<SceneMapping>) => updateCfg({ mappings: cfg.mappings.map(m => m.id === id ? { ...m, ...patch } : m) });
  const activeMap = cfg.mappings.find(m => m.id === mappingId) ?? cfg.mappings[0];

  useEffect(() => {
    const el = outerRef.current;
    if (!el) return;
    const ro = new ResizeObserver(entries => setNarrow(entries[0].contentRect.width < 760));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  // Only the selected Asset is sampled; no duplicate copy of the full stream exists in the component.
  useEffect(() => {
    if (!cfg.live) return;
    let live = true, pending = false;
    void startTelemetry(100).catch(() => {});
    const poll = () => {
      if (!live || pending) return;
      pending = true;
      readAssetSample(assetId).then(s => {
        if (!live) return;
        sampleRef.current = s;
        setSample(s);
        setHistory(prev => [...prev.slice(-119), s]);
      }).catch(() => {}).finally(() => { pending = false; });
    };
    poll();
    const timer = window.setInterval(poll, 180);
    return () => { live = false; window.clearInterval(timer); };
  }, [assetId, cfg.live]);
  useEffect(() => { if (scrubIndex !== null) scrubRef.current = history[scrubIndex] ?? null; else scrubRef.current = null; }, [scrubIndex, history]);
  useEffect(() => { setHistory([]); setScrubIndex(null); sampleRef.current = null; }, [assetId]);

  useEffect(() => {
    const host = canvasHost.current;
    if (!host) return;
    let cancelled = false, cleanup: (() => void) | null = null;
    setLoadState("loading"); setError(null); setModelParts([]); setLoadedUrl("");
    (async () => {
      try {
        const THREE = await import("three");
        const { OrbitControls } = await import("three/addons/controls/OrbitControls.js");
        const { GLTFLoader } = await import("three/addons/loaders/GLTFLoader.js");
        if (cancelled) return;
        const probe = document.createElement("canvas");
        if (!probe.getContext("webgl2")) throw new Error("WebGL2 is unavailable. Enable hardware acceleration or open this module in a WebGL2-capable browser.");
        const renderer = new THREE.WebGLRenderer({ antialias: cfgRef.current.quality !== "performance", alpha: false, powerPreference: "high-performance" });
        renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, cfgRef.current.quality === "high" ? 2 : cfgRef.current.quality === "performance" ? 1 : 1.5));
        renderer.outputColorSpace = THREE.SRGBColorSpace;
        renderer.toneMapping = THREE.ACESFilmicToneMapping;
        renderer.toneMappingExposure = 1.35;
        renderer.domElement.style.width = "100%";
        renderer.domElement.style.height = "100%";
        renderer.domElement.style.display = "block";
        host.appendChild(renderer.domElement);
        const scene = new THREE.Scene();
        scene.background = new THREE.Color(cfgRef.current.background === "dark" ? 0x101d2b : 0xe9f0f5);
        const camera = new THREE.PerspectiveCamera(46, 1, .01, 250);
        camera.position.set(4.4, 3.2, 4.3);
        const controls = new OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true; controls.dampingFactor = .1;
        controls.minDistance = .65; controls.maxDistance = 25;
        controls.target.set(.2, .9, 0);
        scene.add(new THREE.HemisphereLight(0xe5f3ff, 0x466377, 2.5));
        const keyLight = new THREE.DirectionalLight(0xffffff, 3.0); keyLight.position.set(3, 7, 5); scene.add(keyLight);
        const rimLight = new THREE.DirectionalLight(0x3aa0ed, 2.1); rimLight.position.set(-4, 3, -4); scene.add(rimLight);
        const grid = new THREE.GridHelper(6, 32, 0x284259, 0x22354b); grid.position.y = -.015; scene.add(grid);
        const originals = new Map<Object3D, { x: number; y: number; z: number; rx: number; ry: number; rz: number; sx: number; sy: number; sz: number }>();
        const materialColors = new Map<Material, Color>();
        const handle: SceneHandle = { root: null, scene, renderer, camera, controls, grid, originals, materialColors, selectionBox: null, smoothed: new Map(), lastFrameAt: performance.now(), frame: 0, disposed: false, fit: () => {} };
        engine.current = handle;
        const resize = () => {
          const w = Math.max(1, host.clientWidth), h = Math.max(1, host.clientHeight);
          renderer.setSize(w, h, false); camera.aspect = w / h; camera.updateProjectionMatrix();
        };
        const ro = new ResizeObserver(resize); ro.observe(host); resize();
        let inView = true;
        const io = new IntersectionObserver(entries => { inView = entries[0]?.isIntersecting ?? true; }, { threshold: .01 }); io.observe(host);
        const raycaster = new THREE.Raycaster(), mouse = new THREE.Vector2();
        let down = { x: 0, y: 0 };
        const onDown = (e: PointerEvent) => { down = { x: e.clientX, y: e.clientY }; };
        const onUp = (e: PointerEvent) => {
          if (!handle.root || Math.hypot(e.clientX - down.x, e.clientY - down.y) > 5) return;
          const rect = renderer.domElement.getBoundingClientRect();
          mouse.set((e.clientX - rect.left) / rect.width * 2 - 1, -((e.clientY - rect.top) / rect.height * 2 - 1));
          raycaster.setFromCamera(mouse, camera);
          const hits = raycaster.intersectObject(handle.root, true);
          if (!hits.length) return;
          const hit = hits[0].object;
          if (!hit.name) return;
          setSelectedPart(hit.name);
          const output = cfgRef.current.selectedPartVarId;
          if (output) setValues(prev => ({ ...prev, [output]: hit.name }));
        };
        renderer.domElement.addEventListener("pointerdown", onDown);
        renderer.domElement.addEventListener("pointerup", onUp);
        let contextLost = false;
        const lost = (e: Event) => { e.preventDefault(); contextLost = true; setError("WebGL context lost. Try reloading the model or reduce rendering quality."); };
        renderer.domElement.addEventListener("webglcontextlost", lost);
        const fpsTrack = { last: performance.now(), frames: 0 };
        const frame = (now: number) => {
          if (handle.disposed) return;
          if (inView && !contextLost) {
            handle.grid.visible = cfgRef.current.showGrid;
            const bg = cfgRef.current.background === "dark" ? 0x101d2b : 0xe9f0f5;
            (scene.background as Color).setHex(bg);
            if (handle.root) {
              const renderedSample = scrubRef.current ?? sampleRef.current;
              const delta = Math.min(.1, Math.max(.001, (now - handle.lastFrameAt) / 1000));
              applySceneMappings(THREE, handle, cfgRef.current, renderedSample, assetRef.current, explodeRef.current, isolateRef.current, selectedRef.current, delta);
              if (handle.selectionBox) handle.selectionBox.update();
            }
            controls.update(); renderer.render(scene, camera);
            fpsTrack.frames++;
            if (now - fpsTrack.last > 1100) { setFps(Math.round(fpsTrack.frames * 1000 / (now - fpsTrack.last))); fpsTrack.frames = 0; fpsTrack.last = now; }
          }
          handle.lastFrameAt = now;
          handle.frame = requestAnimationFrame(frame);
        };
        handle.frame = requestAnimationFrame(frame);
        cleanup = () => {
          if (handle.disposed) return;
          handle.disposed = true; cancelAnimationFrame(handle.frame);
          ro.disconnect(); io.disconnect();
          renderer.domElement.removeEventListener("pointerdown", onDown); renderer.domElement.removeEventListener("pointerup", onUp); renderer.domElement.removeEventListener("webglcontextlost", lost);
          controls.dispose();
          handle.selectionBox && scene.remove(handle.selectionBox);
          if (handle.root) { handle.root.traverse(object => { const mesh = object as Mesh; if (mesh.isMesh) { mesh.geometry.dispose(); const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material]; mats.forEach(m => m.dispose()); } }); scene.remove(handle.root); }
          renderer.dispose(); renderer.domElement.remove(); engine.current = null;
        };
        const loader = new GLTFLoader();
        const gltf = modelFileRef.current ? await loader.parseAsync(await modelFileRef.current.arrayBuffer(), "") : await loader.loadAsync(cfgRef.current.modelUrl);
        if (cancelled) return;
        const root = gltf.scene;
        scene.add(root); handle.root = root;
        const parts: Array<{ name: string; depth: number; kind: string }> = [];
        const walk = (object: Object3D, depth: number) => {
          if (object.name) parts.push({ name: object.name, depth, kind: partKind(object.name) });
          originals.set(object, { x: object.position.x, y: object.position.y, z: object.position.z, rx: object.rotation.x, ry: object.rotation.y, rz: object.rotation.z, sx: object.scale.x, sy: object.scale.y, sz: object.scale.z });
          const mesh = object as Mesh;
          if (mesh.isMesh) {
            mesh.material = Array.isArray(mesh.material) ? mesh.material.map(m => m.clone()) : mesh.material.clone();
            const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
            mats.forEach(m => { if ("color" in m) materialColors.set(m, (m as unknown as { color: Color }).color.clone()); });
          }
          object.children.forEach(c => walk(c, depth + 1));
        };
        walk(root, 0); setModelParts(parts);
        setMeshCount(parts.filter(p => !["RobotCell", "ConveyorLayer", "BaseYaw", "ShoulderPitch", "ElbowPitch", "WristRoll", "FingerLeft", "FingerRight"].includes(p.name)).length);
        handle.fit = () => {
          const box = new THREE.Box3().setFromObject(root); const center = box.getCenter(new THREE.Vector3()), size = box.getSize(new THREE.Vector3());
          controls.target.set(center.x, center.y, center.z);
          const distance = Math.max(size.x, size.y, size.z) * 2.15;
          camera.position.set(center.x + distance * .9, center.y + distance * .75, center.z + distance * 1.15);
          camera.near = .01; camera.far = Math.max(50, distance * 20); camera.updateProjectionMatrix(); controls.update();
        };
        handle.fit(); setLoadedUrl(modelFileRef.current?.name ?? cfgRef.current.modelUrl); setLoadState("ready");
      } catch (e) {
        if (!cancelled) { setError((e as Error).message || String(e)); setLoadState("error"); }
      }
    })();
    return () => { cancelled = true; cleanup?.(); };
  }, [cfg.modelUrl, uploadedFile, setValues]);

  const onUpload = async (file: File) => {
    if (!/\.(glb|gltf)$/i.test(file.name)) { setError("Choose a .glb or self-contained .gltf file."); return; }
    if (file.size > 15 * 1024 * 1024) { setError("Model exceeds the 15 MB upload limit."); return; }
    setUploading(true); setError(null);
    try {
      const data = new FormData(); data.append("file", file);
      const res = await fetch("/api/workshop/models", { method: "POST", body: data });
      if (!res.ok) throw new Error((await res.json() as { error?: string }).error ?? `Upload failed: ${res.status}`);
      const result = await res.json() as { url: string };
      setUploadedFile(null);
      updateCfg({ modelUrl: result.url });
    } catch (e) {
      setError(`Model was not saved: ${(e as Error).message}. Previewing only in this session.`);
      setUploadedFile(file);
    } finally { setUploading(false); }
  };
  const selectedLayer = cfg.layers.find(l => l.nodes.includes(selectedPart ?? ""));
  const partBound = cfg.mappings.filter(m => m.node === selectedPart);
  const assetProps = ontologyMeta.objectTypes.find(o => o.apiName === "Asset")?.properties.filter(p => ["Double", "Integer", "Long", "Float", "Decimal", "Boolean"].includes(p.baseType)) ?? [];

  return (
    <div ref={outerRef} className="fnd-panel rounded-sm h-full flex flex-col overflow-hidden" style={{ minHeight: 370 }}>
      <div className="flex items-center gap-2 px-2.5 border-b fnd-border" style={{ height: 37, flexShrink: 0 }}>
        <span style={{ width: 20, height: 20, background: "var(--fnd-accent)", color: "white", display: "inline-flex", alignItems: "center", justifyContent: "center", fontSize: 12, borderRadius: 2 }}>⬡</span>
        <span className="text-xs font-semibold truncate" title={widget.name}>{widget.name}</span>
        <span className="fnd-tag" title="Real GLB / GLTF file loaded with Three.js GLTFLoader">glTF 2.0</span>
        <span className="fnd-tag" style={{ background: dataReady && !paused ? "#e4f1e5" : "var(--fnd-panel-2)", color: dataReady && !paused ? "#296936" : "var(--fnd-text-muted)", borderColor: "transparent" }}>{dataReady && !paused ? "● live device" : "○ waiting"}</span>
        <div className="flex-1"/>
        <span className="text-[10px] fnd-text-muted tabular-nums" title="Renderer frames per second">{fps} fps</span>
        <button className={`fnd-btn fnd-btn-minimal ${cfg.showGrid ? "fnd-selected" : ""}`} title="Toggle floor grid" onClick={() => updateCfg({ showGrid: !cfg.showGrid })}>Grid</button>
        <button className="fnd-btn fnd-btn-minimal" title="Fit all" onClick={() => engine.current?.fit()}>Fit</button>
        <button className="fnd-btn fnd-btn-minimal" title={sideOpen ? "Hide layers and mappings" : "Show layers and mappings"} onClick={() => setSideOpen(!sideOpen)}>{sideOpen ? "◨" : "◧"}</button>
      </div>
      <div className="flex-1 flex min-h-0" style={{ flexDirection: narrow ? "column" : "row" }}>
        <div className="flex-1 min-w-0 relative" style={{ minHeight: narrow ? 250 : 320, background: cfg.background === "dark" ? "#101d2b" : "#e9f0f5" }}>
          <div ref={canvasHost} className="absolute inset-0"/>
          {loadState === "loading" && <div className="absolute inset-0 grid place-items-center text-xs text-white/80 fnd-pulse pointer-events-none">Loading 3D model…</div>}
          {loadState === "error" && <div className="absolute inset-0 grid place-items-center p-6 text-xs text-center text-white/80 pointer-events-none">3D rendering unavailable. The parts, layers and mappings remain editable on the right.<br/>{error}</div>}
          <div className="absolute left-2 top-2 flex flex-col gap-1 pointer-events-none" style={{ maxWidth: "55%" }}>
            <span className="fnd-tag" style={{ background: "rgba(16,28,40,.83)", color: "white", borderColor: "transparent", height: 23 }}>Asset · {assetId} {selectedAsset?.name ? "· " + String(selectedAsset.name) : ""}</span>
            {sample && <span className="fnd-tag" style={{ background: "rgba(16,28,40,.83)", color: "white", borderColor: "transparent", height: 22 }}>Device DEV-{String(sample.deviceId + 1).padStart(4, "0")} · {sample.plant} · {sample.status}</span>}
          </div>
          {selectedPart && <div className="absolute right-2 top-2 fnd-panel p-2 text-[11px]" style={{ minWidth: 145, maxWidth: 200, opacity: .95 }}>
            <div className="font-semibold truncate">{selectedPart}</div>
            <div className="fnd-text-dim">{partKind(selectedPart)} · {selectedLayer?.name ?? "Unassigned layer"}</div>
            {partBound.map(m => { const v = resolveMapping(m, sample, selectedAsset); return <div key={m.id} className="mt-1 tabular-nums">{m.source === "telemetry" ? signalNames[m.signalIndex ?? 0] ?? `signal_${m.signalIndex}` : m.property}: <b>{v?.raw.toFixed(2) ?? "—"}</b></div>; })}
          </div>}
          <div className="absolute bottom-2 left-2 fnd-panel px-2 py-1 flex items-center gap-2 text-[10px]" style={{ opacity: .95 }}>
            <button className="fnd-btn fnd-btn-minimal" style={{ height: 20 }} onClick={() => { updateCfg({ live: !cfg.live }); if (!cfg.live) setScrubIndex(null); }}>{cfg.live ? "Ⅱ Pause" : "▶ Live"}</button>
            <label className="flex items-center gap-1">Explode <input type="range" min={0} max={1} step={.01} value={explode} onChange={e => setExplode(Number(e.target.value))} style={{ width: 65 }}/></label>
            <button className={`fnd-btn fnd-btn-minimal ${isolate ? "fnd-selected" : ""}`} style={{ height: 20 }} disabled={!selectedPart} onClick={() => setIsolate(!isolate)}>Isolate</button>
          </div>
          {history.length > 1 && !cfg.live && <div className="absolute bottom-9 left-2 right-2 fnd-panel px-2 py-1 flex items-center gap-2 text-[10px]"><span>History</span><input className="flex-1" type="range" min={0} max={history.length - 1} value={scrubIndex ?? history.length - 1} onChange={e => setScrubIndex(Number(e.target.value))}/><span>{scrubIndex == null ? "latest" : `${scrubIndex + 1}/${history.length}`}</span></div>}
        </div>
        {sideOpen && <div className="border-l fnd-border flex flex-col min-h-0" style={{ width: narrow ? "100%" : 262, maxHeight: narrow ? 340 : undefined, flexShrink: 0, background: "var(--fnd-panel)" }}>
          <div className="flex border-b fnd-border" style={{ flexShrink: 0 }}>
            {(["layers", "parts", ...(isBuilder ? ["bindings"] as const : [])] as const).map(tab => <button key={tab} className="flex-1 py-1.5 text-[11px] font-semibold capitalize" style={{ borderBottom: view === tab ? "2px solid var(--fnd-accent)" : "2px solid transparent", color: view === tab ? "var(--fnd-accent)" : "var(--fnd-text-muted)" }} onClick={() => setView(tab)}>{tab}</button>)}
          </div>
          <div className="flex-1 overflow-auto p-2 text-[11px] min-h-0">
            {view === "layers" && <div className="space-y-1">
              <div className="fnd-label mb-2">Render layers · {cfg.layers.length}</div>
              {cfg.layers.map(layer => <div key={layer.id} className="fnd-panel rounded-sm p-1.5">
                <div className="flex items-center gap-1"><input type="checkbox" aria-label={`Show ${layer.name}`} checked={layer.visible} onChange={e => updateLayer(layer.id, { visible: e.target.checked })}/><span className="font-semibold truncate flex-1" title={layer.name}>{layer.name}</span><span className="fnd-tag" style={{ height: 17 }}>{layer.nodes.length}</span></div>
                <div className="flex items-center gap-1 mt-1"><span className="fnd-text-dim">opacity</span><input type="range" min={.08} max={1} step={.01} value={layer.opacity} onChange={e => updateLayer(layer.id, { opacity: Number(e.target.value) })} className="flex-1"/><span className="tabular-nums" style={{ width: 24 }}>{Math.round(layer.opacity * 100)}%</span></div>
                <label className="flex items-center gap-1 mt-0.5 fnd-text-muted"><input type="checkbox" checked={layer.wireframe} onChange={e => updateLayer(layer.id, { wireframe: e.target.checked })}/> Wireframe</label>
              </div>)}
              {isBuilder && selectedPart && <button className="fnd-btn w-full" onClick={() => { const id = `layer-${Date.now().toString(36)}`; updateCfg({ layers: [...cfg.layers, { id, name: selectedPart, nodes: [selectedPart], visible: true, opacity: 1, wireframe: false }] }); }}>＋ Layer for {shorten(selectedPart)}</button>}
            </div>}
            {view === "parts" && <div>
              <div className="fnd-label mb-1">glTF node hierarchy · {modelParts.length}</div>
              {modelParts.length === 0 && <div className="fnd-text-dim">The model's parts appear after loading.</div>}
              {modelParts.map((p, i) => <button key={`${p.name}-${i}`} className="w-full text-left py-0.5 fnd-row-hover rounded-sm flex items-center gap-1.5" style={{ paddingLeft: 2 + Math.min(p.depth, 5) * 9, background: selectedPart === p.name ? "var(--fnd-selection)" : undefined }} onClick={() => { setSelectedPart(p.name); if (cfg.selectedPartVarId) setValues(prev => ({ ...prev, [cfg.selectedPartVarId!]: p.name })); }}><span style={{ color: p.kind === "joint" ? "var(--fnd-accent)" : p.kind === "sensor" ? "var(--fnd-success)" : "var(--fnd-text-dim)" }}>◆</span><span className="truncate flex-1">{p.name}</span><span className="fnd-text-dim">{p.kind === "joint" ? "J" : p.kind === "sensor" ? "S" : ""}</span></button>)}
            </div>}
            {view === "bindings" && isBuilder && <div className="space-y-2">
              <div className="fnd-label">Signal → glTF node mappings</div>
              <div className="text-[10px] fnd-text-dim">Every mapping is stored on this Widget. Select a node on the model or Parts tab to bind it.</div>
              {cfg.mappings.map(m => <button key={m.id} className="w-full text-left fnd-row-hover rounded-sm p-1" style={{ border: `1px solid ${m.id === activeMap?.id ? "var(--fnd-accent)" : "var(--fnd-border)"}` }} onClick={() => { setMappingId(m.id); setSelectedPart(m.node); }}><span className="font-semibold">{m.node}</span><span className="fnd-text-dim ml-1">← {m.source === "telemetry" ? signalNames[m.signalIndex ?? 0] ?? `signal ${m.signalIndex}` : m.property}</span><span className="fnd-tag ml-1" style={{ height: 17 }}>{m.mode}</span></button>)}
              {selectedPart && <button className="fnd-btn w-full" onClick={() => { const id = `m-${Date.now().toString(36)}`; updateCfg({ mappings: [...cfg.mappings, { id, node: selectedPart, source: "telemetry", signalIndex: 0, mode: "rotation", axis: "z", inputMin: 0, inputMax: 20, outputMin: -1, outputMax: 1, smooth: .12, enabled: true }] }); setMappingId(id); }}>＋ Bind {shorten(selectedPart)}</button>}
              {activeMap && <MappingEditor mapping={activeMap} signals={signalNames} assetProps={assetProps.map(p => p.apiName)} onChange={patch => updateMapping(activeMap.id, patch)} onDelete={() => { updateCfg({ mappings: cfg.mappings.filter(m => m.id !== activeMap.id) }); setMappingId(null); }}/>} 
              <div className="border-t fnd-border pt-2"><label className="fnd-field-label">Asset variable</label><select className="fnd-input fnd-select" value={cfg.assetVarId} onChange={e => updateCfg({ assetVarId: e.target.value })}>{module.variables.filter(v => v.type === "object").map(v => <option key={v.id} value={v.id}>{v.name}</option>)}</select></div>
              <div><label className="fnd-field-label">Model URL</label><input className="fnd-input" value={cfg.modelUrl} onChange={e => updateCfg({ modelUrl: e.target.value })} placeholder="/models/example.glb"/></div>
              <label className="fnd-btn w-full justify-center cursor-pointer">{uploading ? "Uploading…" : "↑ Upload GLB / GLTF"}<input type="file" accept=".glb,.gltf,model/gltf-binary,model/gltf+json" hidden disabled={uploading} onChange={e => { const file = e.target.files?.[0]; if (file) void onUpload(file); e.target.value = ""; }}/></label>
              <div className="text-[10px] fnd-text-dim">GLB or self-contained GLTF · max 15 MB · uploads stored in module media storage.</div>
            </div>}
          </div>
        </div>}
      </div>
      <div className="flex items-center gap-2 px-2 border-t fnd-border text-[10px] fnd-text-muted" style={{ height: 24, flexShrink: 0 }}>
        <span>{loadedUrl ? shorten(loadedUrl, 44) : cfg.modelUrl}</span><span>· {meshCount} meshes / {modelParts.length} nodes</span><div className="flex-1"/><span>{wasmReady ? "WASM telemetry ready" : "WASM starting"}</span><span>· Simulation source</span>
      </div>
    </div>
  );
}

function MappingEditor({ mapping: m, signals, assetProps, onChange, onDelete }: {
  mapping: SceneMapping; signals: string[]; assetProps: string[]; onChange: (patch: Partial<SceneMapping>) => void; onDelete: () => void;
}) {
  return <div className="fnd-panel rounded-sm p-2 space-y-2">
    <div className="flex items-center gap-1"><strong className="text-[11px] flex-1 truncate">{m.node}</strong><button className="fnd-btn fnd-btn-minimal" title="Remove mapping" onClick={onDelete}><Icon.Trash size={11}/></button></div>
    <div className="flex gap-1"><select className="fnd-input fnd-select" value={m.source} onChange={e => onChange({ source: e.target.value as SceneMapping["source"] })}><option value="telemetry">Telemetry field</option><option value="ontology">Ontology property</option></select><select className="fnd-input fnd-select" value={m.mode} onChange={e => onChange({ mode: e.target.value as SceneMapping["mode"] })}><option value="rotation">Rotate</option><option value="position">Translate</option><option value="scale">Scale</option><option value="color">Color</option><option value="visibility">Visibility</option></select></div>
    {m.source === "telemetry" ? <div><label className="fnd-field-label">Signal column · {m.signalIndex}</label><select className="fnd-input fnd-select" value={m.signalIndex ?? 0} onChange={e => onChange({ signalIndex: Number(e.target.value) })}>{(signals.length ? signals : Array.from({ length: 100 }, (_, i) => `signal_${i + 1}`)).map((name, i) => <option key={i} value={i}>{name}</option>)}</select></div> : <div><label className="fnd-field-label">Asset property</label><select className="fnd-input fnd-select" value={m.property ?? "openAlerts"} onChange={e => onChange({ property: e.target.value })}>{assetProps.map(p => <option key={p}>{p}</option>)}</select></div>}
    <div className="flex gap-1"><div className="flex-1"><label className="fnd-field-label">Input min</label><input className="fnd-input" type="number" step={.01} value={m.inputMin} onChange={e => onChange({ inputMin: Number(e.target.value) })}/></div><div className="flex-1"><label className="fnd-field-label">Input max</label><input className="fnd-input" type="number" step={.01} value={m.inputMax} onChange={e => onChange({ inputMax: Number(e.target.value) })}/></div></div>
    <div className="flex gap-1"><div className="flex-1"><label className="fnd-field-label">Output min</label><input className="fnd-input" type="number" step={.01} value={m.outputMin} onChange={e => onChange({ outputMin: Number(e.target.value) })}/></div><div className="flex-1"><label className="fnd-field-label">Output max</label><input className="fnd-input" type="number" step={.01} value={m.outputMax} onChange={e => onChange({ outputMax: Number(e.target.value) })}/></div></div>
    {m.mode === "rotation" || m.mode === "position" || m.mode === "scale" ? <div><label className="fnd-field-label">Axis</label><select className="fnd-input fnd-select" value={m.axis} onChange={e => onChange({ axis: e.target.value as SceneMapping["axis"] })}><option>x</option><option>y</option><option>z</option></select></div> : null}
    {m.mode === "color" && <div className="flex items-center gap-2"><label className="text-[10px]">Low <input type="color" value={m.colorLow ?? "#12b981"} onChange={e => onChange({ colorLow: e.target.value })}/></label><label className="text-[10px]">High <input type="color" value={m.colorHigh ?? "#e65b43"} onChange={e => onChange({ colorHigh: e.target.value })}/></label></div>}
    <div><label className="fnd-field-label">Alarm threshold</label><input className="fnd-input" type="number" step={.1} value={m.threshold ?? ""} onChange={e => onChange({ threshold: e.target.value === "" ? undefined : Number(e.target.value) })}/></div>
    <label className="flex items-center gap-1 text-[10px]"><input type="checkbox" checked={m.enabled} onChange={e => onChange({ enabled: e.target.checked })}/> Enabled</label>
  </div>;
}

function applySceneMappings(
  THREE: typeof import("three"), handle: SceneHandle, cfg: SceneConfig, sample: AssetSample | null, asset: Record<string, unknown> | null,
  explode: number, isolate: boolean, selected: string | null, delta: number,
) {
  const root = handle.root;
  if (!root) return;
  // Reset transforms and materials from the loaded glTF. This prevents drift and makes playback deterministic.
  root.traverse(o => {
    const base = handle.originals.get(o);
    if (!base) return;
    o.position.set(base.x, base.y, base.z);
    o.rotation.set(base.rx, base.ry, base.rz);
    o.scale.set(base.sx, base.sy, base.sz);
    o.visible = true;
    const mesh = o as Mesh;
    if (mesh.isMesh) {
      const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
      for (const mat of mats) if (mat instanceof THREE.MeshStandardMaterial) {
        const color = handle.materialColors.get(mat);
        if (color) mat.color.copy(color);
        mat.opacity = 1; mat.transparent = false; mat.wireframe = false;
      }
    }
  });
  for (const layer of cfg.layers) {
    for (const name of layer.nodes) {
      const node = root.getObjectByName(name);
      if (!node) continue;
      node.visible = layer.visible;
      node.traverse(o => {
        const mesh = o as Mesh;
        if (!mesh.isMesh) return;
        for (const mat of Array.isArray(mesh.material) ? mesh.material : [mesh.material]) if (mat instanceof THREE.MeshStandardMaterial) {
          mat.opacity = layer.opacity; mat.transparent = layer.opacity < 1; mat.wireframe = layer.wireframe;
          if (layer.color) mat.color.set(layer.color);
        }
      });
    }
  }
  for (const m of cfg.mappings) {
    if (!m.enabled) continue;
    const node = root.getObjectByName(m.node);
    const mapped = resolveMapping(m, sample, asset);
    if (!node || !mapped) continue;
    const previous = handle.smoothed.get(m.id);
    const responseSeconds = Math.max(.02, Math.min(1.5, m.smooth ?? .12));
    const alpha = 1 - Math.exp(-delta / responseSeconds);
    const smooth = previous === undefined ? mapped.value : previous + (mapped.value - previous) * alpha;
    handle.smoothed.set(m.id, smooth);
    if (m.mode === "rotation") node.rotation[m.axis] = (handle.originals.get(node)?.[`r${m.axis}` as "rx" | "ry" | "rz"] ?? 0) + smooth;
    else if (m.mode === "position") node.position[m.axis] = (handle.originals.get(node)?.[m.axis] ?? 0) + smooth;
    else if (m.mode === "scale") node.scale[m.axis] = Math.max(.05, smooth);
    else if (m.mode === "visibility") node.visible = smooth >= .5;
    else if (m.mode === "color") {
      const low = new THREE.Color(m.colorLow ?? "#18bf79"), high = new THREE.Color(m.colorHigh ?? "#e65b43");
      const fraction = m.outputMax === m.outputMin ? mapped.normalised : Math.max(0, Math.min(1, (smooth - m.outputMin) / (m.outputMax - m.outputMin)));
      const color = low.lerp(high, fraction);
      node.traverse(o => {
        const mesh = o as Mesh;
        if (!mesh.isMesh) return;
        for (const mat of Array.isArray(mesh.material) ? mesh.material : [mesh.material]) if (mat instanceof THREE.MeshStandardMaterial) mat.color.copy(color);
      });
    }
  }
  const selectedGroup = selected ? root.getObjectByName(selected) : null;
  if (explode || isolate && selected) root.traverse(o => {
    const mesh = o as Mesh;
    if (!mesh.isMesh) return;
    if (explode) {
      const p = handle.originals.get(o);
      if (p) { const dir = new THREE.Vector3(p.x, p.y * .25, p.z); if (dir.lengthSq() < .001) dir.set(.2, .15, .2); dir.normalize().multiplyScalar(explode * .32); o.position.add(dir); }
    }
    const belongs = selectedGroup && (o === selectedGroup || selectedGroup.getObjectById(o.id) !== undefined || o.getObjectById(selectedGroup.id) !== undefined);
    if (isolate && selected && !belongs) {
      for (const mat of Array.isArray(mesh.material) ? mesh.material : [mesh.material]) if (mat instanceof THREE.MeshStandardMaterial) { mat.opacity = .12; mat.transparent = true; }
    }
  });
  if (selected) {
    const node = root.getObjectByName(selected);
    if (node) {
      if (!handle.selectionBox) { handle.selectionBox = new THREE.BoxHelper(node, 0x54c6f7); handle.scene.add(handle.selectionBox); }
      else { handle.selectionBox.setFromObject(node); handle.selectionBox.visible = true; }
    } else if (handle.selectionBox) handle.selectionBox.visible = false;
  } else if (handle.selectionBox) handle.selectionBox.visible = false;
}
