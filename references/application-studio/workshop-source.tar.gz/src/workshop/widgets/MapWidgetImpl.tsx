"use client";
import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { feature } from "topojson-client";
import type { Topology, GeometryCollection } from "topojson-specification";
import worldData from "world-atlas/countries-110m.json";
import { useCore } from "../WorkshopContext";
import type { WidgetDef } from "../types";
import { Icon } from "./icons";
import { objectTypeOf, titleOf, type Obj } from "../ontologyMeta";

const W = 1000, H = 500;
const proj = (lng: number, lat: number): [number, number] => [((lng + 180) / 360) * W, ((90 - lat) / 180) * H];
const PALETTE = ["#2b6cb0", "#d9822b", "#0f9960", "#c23030", "#7157d9", "#5c7080", "#137cbd", "#8f398f", "#a67908", "#00a396"];
const STATUS_COLORS: Record<string, string> = { Active: "#0f9960", Warning: "#d9822b", Offline: "#c23030", Maintenance: "#2b6cb0", High: "#c23030", Medium: "#d9822b", Low: "#0f9960" };

let landPath: string | null = null;
function buildLand(): string {
  if (landPath) return landPath;
  const topo = worldData as unknown as Topology;
  const fc = feature(topo, topo.objects.countries as GeometryCollection) as unknown as { features: Array<{ geometry: { type: string; coordinates: number[][][] | number[][][][] } }> };
  const ring = (r: number[][]) => r.map((p, i) => { const [x, y] = proj(p[0], p[1]); return `${i ? "L" : "M"}${x.toFixed(1)} ${y.toFixed(1)}`; }).join("") + "Z";
  const parts: string[] = [];
  for (const f of fc.features) {
    const g = f.geometry;
    if (g.type === "Polygon") (g.coordinates as number[][][]).forEach(r => parts.push(ring(r)));
    else if (g.type === "MultiPolygon") (g.coordinates as number[][][][]).forEach(poly => poly.forEach(r => parts.push(ring(r))));
  }
  landPath = parts.join("");
  return landPath;
}
const GRATICULE = (() => {
  const p: string[] = [];
  for (let lng = -180; lng <= 180; lng += 30) { const [x] = proj(lng, 0); p.push(`M${x} 0V${H}`); }
  for (let lat = -60; lat <= 60; lat += 30) { const [, y] = proj(0, lat); p.push(`M0 ${y}H${W}`); }
  return p.join("");
})();

interface View { k: number; x: number; y: number }
const MIN_K = 1, MAX_K = 40;

export function MapWidgetImpl({ widget }: { widget: WidgetDef }) {
  const { values, setValues, ontologyMeta: meta, fireEvents } = useCore();
  const cfg = widget.config as { objectSetVarId: string; activeVarId?: string; colorBy?: string; clusterEnabled?: boolean };
  const setVal = values[cfg.objectSetVarId];
  const objs = useMemo(() => (Array.isArray(setVal) ? (setVal as Obj[]) : []), [setVal]);
  const active = cfg.activeVarId ? (values[cfg.activeVarId] as Obj | null) : null;
  const activeId = active && typeof active === "object" ? String(active.id) : null;

  const svgRef = useRef<SVGSVGElement>(null);
  const [view, setView] = useState<View>({ k: 1, x: 0, y: 0 });
  const viewRef = useRef(view); viewRef.current = view;
  const [ready, setReady] = useState(false);
  const [colorBy, setColorBy] = useState(cfg.colorBy ?? "status");
  const [hiddenCats, setHiddenCats] = useState<Set<string>>(new Set());
  const [showLand, setShowLand] = useState(true);
  const [cluster, setCluster] = useState(cfg.clusterEnabled !== false);
  const [hover, setHover] = useState<{ o: Obj; px: number; py: number } | null>(null);
  const [size, setSize] = useState({ w: 600, h: 300 });
  const anim = useRef(0);

  useEffect(() => { const id = requestAnimationFrame(() => { buildLand(); setReady(true); }); return () => cancelAnimationFrame(id); }, []);
  useEffect(() => {
    const el = svgRef.current; if (!el) return;
    const ro = new ResizeObserver(() => { const r = el.getBoundingClientRect(); setSize({ w: r.width, h: r.height }); });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const unit = Math.min(size.w / W, size.h / H) || 1;     // px per viewBox unit at k=1
  const offX = (size.w - W * unit) / 2, offY = (size.h - H * unit) / 2;

  const points = useMemo(() => objs.flatMap(o => {
    const lat = Number(o.lat), lng = Number(o.lng);
    if (!Number.isFinite(lat) || !Number.isFinite(lng) || o.lat == null) return [];
    const [x, y] = proj(lng, lat);
    return [{ o, x, y, id: String(o.id), cat: String(o[colorBy] ?? "—") }];
  }), [objs, colorBy]);

  const cats = useMemo(() => [...new Set(points.map(p => p.cat))].sort(), [points]);
  const colorOf = (c: string) => (colorBy === "status" || colorBy === "priority") && STATUS_COLORS[c] ? STATUS_COLORS[c] : PALETTE[cats.indexOf(c) % PALETTE.length];

  const clamp = useCallback((v: View): View => {
    const k = Math.min(MAX_K, Math.max(MIN_K, v.k));
    const minX = -(W * k - W), minY = -(H * k - H);
    return { k, x: Math.min(0, Math.max(minX, v.x)), y: Math.min(0, Math.max(minY, v.y)) };
  }, []);

  const fly = useCallback((target: View) => {
    cancelAnimationFrame(anim.current);
    const from = viewRef.current, to = clamp(target), t0 = performance.now();
    const step = (t: number) => {
      const p = Math.min(1, (t - t0) / 320), e = 1 - Math.pow(1 - p, 3);
      setView({ k: from.k + (to.k - from.k) * e, x: from.x + (to.x - from.x) * e, y: from.y + (to.y - from.y) * e });
      if (p < 1) anim.current = requestAnimationFrame(step);
    };
    anim.current = requestAnimationFrame(step);
  }, [clamp]);

  // point in viewBox coords → centred target view
  const centerOn = useCallback((x: number, y: number, k: number) => fly({ k, x: W / 2 - x * k, y: H / 2 - y * k }), [fly]);
  const fit = useCallback(() => {
    if (!points.length) return fly({ k: 1, x: 0, y: 0 });
    const xs = points.map(p => p.x), ys = points.map(p => p.y);
    const [x0, x1, y0, y1] = [Math.min(...xs), Math.max(...xs), Math.min(...ys), Math.max(...ys)];
    const k = Math.min(MAX_K, Math.max(1, 0.8 * Math.min(W / Math.max(30, x1 - x0), H / Math.max(30, y1 - y0))));
    centerOn((x0 + x1) / 2, (y0 + y1) / 2, k);
  }, [points, fly, centerOn]);

  // Table → Map: bring the selected object into view
  useEffect(() => {
    if (!activeId) return;
    const p = points.find(pt => pt.id === activeId);
    if (!p) return;
    const v = viewRef.current;
    const sx = p.x * v.k + v.x, sy = p.y * v.k + v.y;
    if (sx < 40 || sx > W - 40 || sy < 40 || sy > H - 40) centerOn(p.x, p.y, Math.max(v.k, 4));
  }, [activeId, points, centerOn]);

  const zoomAt = (px: number, py: number, factor: number) => {
    const v = viewRef.current;
    const ux = (px - offX) / unit, uy = (py - offY) / unit;
    const k = Math.min(MAX_K, Math.max(MIN_K, v.k * factor));
    setView(clamp({ k, x: ux - ((ux - v.x) / v.k) * k, y: uy - ((uy - v.y) / v.k) * k }));
  };
  useEffect(() => {
    const el = svgRef.current; if (!el) return;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const r = el.getBoundingClientRect();
      zoomAt(e.clientX - r.left, e.clientY - r.top, Math.exp(-e.deltaY * 0.0016));
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => el.removeEventListener("wheel", onWheel);
  });

  const drag = useRef<{ x: number; y: number; vx: number; vy: number; moved: boolean } | null>(null);
  const onPointerDown = (e: React.PointerEvent) => {
    if (e.button !== 0) return;
    (e.currentTarget as Element).setPointerCapture(e.pointerId);
    drag.current = { x: e.clientX, y: e.clientY, vx: viewRef.current.x, vy: viewRef.current.y, moved: false };
  };
  const onPointerMove = (e: React.PointerEvent) => {
    const d = drag.current; if (!d) return;
    const dx = e.clientX - d.x, dy = e.clientY - d.y;
    if (!d.moved && Math.hypot(dx, dy) < 3) return;
    d.moved = true; setHover(null);
    setView(clamp({ k: viewRef.current.k, x: d.vx + dx / unit, y: d.vy + dy / unit }));
  };
  const onPointerUp = () => { setTimeout(() => { drag.current = null; }, 0); };

  const select = (o: Obj) => {
    if (cfg.activeVarId) setValues(p => ({ ...p, [cfg.activeVarId!]: o }));
    for (const ev of widget.events ?? []) if (ev.trigger === "onSelect") fireEvents(ev.actions, o);
  };

  // clustering in screen space
  const marks = useMemo(() => {
    const vis = points.filter(p => !hiddenCats.has(p.cat));
    if (!cluster || view.k >= 18) return vis.map(p => ({ kind: "pt" as const, p }));
    const cell = 34 / (unit * view.k);
    const grid = new Map<string, typeof vis>();
    for (const p of vis) { const key = `${Math.floor(p.x / cell)},${Math.floor(p.y / cell)}`; (grid.get(key) ?? grid.set(key, []).get(key)!).push(p); }
    const out: Array<{ kind: "pt"; p: (typeof vis)[number] } | { kind: "cl"; x: number; y: number; items: typeof vis; key: string }> = [];
    for (const [key, items] of grid) {
      if (items.length === 1 || items.some(i => i.id === activeId)) items.forEach(p => out.push({ kind: "pt", p }));
      else out.push({ kind: "cl", key, x: items.reduce((a, i) => a + i.x, 0) / items.length, y: items.reduce((a, i) => a + i.y, 0) / items.length, items });
    }
    return out;
  }, [points, hiddenCats, cluster, view.k, unit, activeId]);

  const ot = objectTypeOf(meta, String(objs[0]?.__type ?? ""));
  const colorOptions = ot?.properties.filter(p => p.baseType === "String" && p.visibility !== "HIDDEN" && !["id", "name"].includes(p.apiName)).map(p => p.apiName) ?? ["status"];
  const r = 5 / unit;

  return (
    <div className="fnd-panel rounded-sm h-full flex flex-col overflow-hidden" style={{ minHeight: 300 }}>
      <div className="flex items-center gap-2 px-2.5 border-b fnd-border" style={{ height: 34, flexShrink: 0 }}>
        <Icon.Map size={14}/><div className="text-xs font-semibold truncate">{widget.name}</div>
        <span className="fnd-tag">{points.length} / {objs.length} located</span>
        <div className="flex-1"/>
        <label className="text-[11px] fnd-text-muted flex items-center gap-1">Color by
          <select className="fnd-input fnd-select" style={{ width: 96, height: 22 }} value={colorBy} onChange={e => { setColorBy(e.target.value); setHiddenCats(new Set()); }}>
            {colorOptions.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </label>
        <button className={`fnd-btn fnd-btn-minimal ${cluster ? "fnd-selected" : ""}`} title="Toggle clustering" aria-pressed={cluster} onClick={() => setCluster(c => !c)}>Cluster</button>
        <button className={`fnd-btn fnd-btn-minimal ${showLand ? "fnd-selected" : ""}`} title="Toggle basemap" aria-pressed={showLand} onClick={() => setShowLand(s => !s)}>Basemap</button>
        <button className="fnd-btn fnd-btn-minimal" title="Zoom in" aria-label="Zoom in" onClick={() => zoomAt(size.w / 2, size.h / 2, 1.6)}><Icon.Plus size={12}/></button>
        <button className="fnd-btn fnd-btn-minimal" title="Zoom out" aria-label="Zoom out" onClick={() => zoomAt(size.w / 2, size.h / 2, 1 / 1.6)}><Icon.Minus size={12}/></button>
        <button className="fnd-btn fnd-btn-minimal" title="Fit to data" onClick={fit}>Fit</button>
      </div>
      <div className="flex-1 relative" style={{ background: "var(--fnd-panel-2)", minHeight: 0 }}>
        {!ready && <div className="fnd-skeleton absolute inset-0" aria-busy="true" aria-label="Loading map"/>}
        <svg ref={svgRef} width="100%" height="100%" viewBox={`0 0 ${size.w} ${size.h}`} role="img" aria-label="Map of objects"
          style={{ display: "block", touchAction: "none", cursor: drag.current?.moved ? "grabbing" : "grab" }}
          onPointerDown={onPointerDown} onPointerMove={onPointerMove} onPointerUp={onPointerUp}
          onDoubleClick={e => { const rc = svgRef.current!.getBoundingClientRect(); zoomAt(e.clientX - rc.left, e.clientY - rc.top, 2); }}>
          <g transform={`translate(${offX + view.x * unit} ${offY + view.y * unit}) scale(${unit * view.k})`}>
            <rect x={0} y={0} width={W} height={H} fill="var(--fnd-panel)"/>
            <path d={GRATICULE} stroke="var(--fnd-border)" strokeWidth={1} fill="none" vectorEffect="non-scaling-stroke" opacity={0.7}/>
            {ready && showLand && <path d={buildLand()} fill="var(--fnd-hover)" stroke="var(--fnd-border-strong)" strokeWidth={0.6} vectorEffect="non-scaling-stroke" fillRule="evenodd"/>}
          </g>
          <g>
            {marks.map(m => {
              if (m.kind === "cl") {
                const cx = offX + (m.x * view.k + view.x) * unit, cy = offY + (m.y * view.k + view.y) * unit;
                const rad = Math.min(22, 11 + Math.log2(m.items.length) * 3.2);
                return (
                  <g key={m.key} transform={`translate(${cx} ${cy})`} style={{ cursor: "zoom-in" }}
                    onClick={e => { e.stopPropagation(); if (drag.current?.moved) return; const xs = m.items.map(i => i.x), ys = m.items.map(i => i.y); const span = Math.max(30, Math.max(...xs) - Math.min(...xs), (Math.max(...ys) - Math.min(...ys)) * 2); centerOn(m.x, m.y, Math.min(MAX_K, Math.max(view.k * 1.8, (W * 0.5) / span))); }}>
                    <circle r={rad} fill="var(--fnd-accent)" opacity={0.85} stroke="white" strokeWidth={1.5}/>
                    <text textAnchor="middle" dy="0.35em" fontSize={11} fontWeight={700} fill="white" style={{ pointerEvents: "none" }}>{m.items.length}</text>
                  </g>
                );
              }
              const { p } = m;
              const cx = offX + (p.x * view.k + view.x) * unit, cy = offY + (p.y * view.k + view.y) * unit;
              if (cx < -20 || cy < -20 || cx > size.w + 20 || cy > size.h + 20) return null;
              const isActive = p.id === activeId;
              return (
                <g key={p.id} transform={`translate(${cx} ${cy})`} style={{ cursor: "pointer" }}
                  onClick={e => { e.stopPropagation(); if (!drag.current?.moved) select(p.o); }}
                  onPointerEnter={e => { const rc = svgRef.current!.getBoundingClientRect(); setHover({ o: p.o, px: e.clientX - rc.left, py: e.clientY - rc.top }); }}
                  onPointerLeave={() => setHover(null)}>
                  {isActive && <circle r={r * unit + 6} fill="none" stroke="var(--fnd-accent)" strokeWidth={2}><animate attributeName="r" values={`${r * unit + 4};${r * unit + 9};${r * unit + 4}`} dur="1.6s" repeatCount="indefinite"/></circle>}
                  <circle r={isActive ? r * unit + 2 : r * unit} fill={colorOf(p.cat)} stroke="white" strokeWidth={1.5}/>
                </g>
              );
            })}
          </g>
        </svg>
        {points.length === 0 && ready && (
          <div className="absolute inset-0 flex items-center justify-center text-xs fnd-text-dim text-center p-6" style={{ pointerEvents: "none" }}>
            {objs.length === 0 ? "No objects in the bound object set." : "These objects have no geospatial (lat/lng) properties."}
          </div>
        )}
        {hover && (
          <div className="fnd-panel" role="tooltip" style={{ position: "absolute", left: Math.min(hover.px + 12, size.w - 190), top: Math.min(hover.py + 12, size.h - 70), padding: "6px 8px", fontSize: 11, pointerEvents: "none", boxShadow: "0 4px 14px rgba(0,0,0,.18)", maxWidth: 180 }}>
            <div className="font-semibold truncate">{titleOf(meta, hover.o)}</div>
            <div className="fnd-text-muted">{String(hover.o.id)} · {String(hover.o[colorBy] ?? "—")}</div>
          </div>
        )}
        <div className="absolute left-2 bottom-2 fnd-panel flex flex-wrap gap-x-2 gap-y-0.5 px-2 py-1" style={{ maxWidth: "70%", fontSize: 10 }}>
          {cats.map(c => (
            <button key={c} className="flex items-center gap-1" onClick={() => setHiddenCats(h => { const n = new Set(h); if (n.has(c)) n.delete(c); else n.add(c); return n; })} aria-pressed={!hiddenCats.has(c)} title={`Toggle ${c}`}>
              <span style={{ width: 8, height: 8, borderRadius: 4, background: colorOf(c), opacity: hiddenCats.has(c) ? 0.25 : 1 }}/>
              <span style={{ textDecoration: hiddenCats.has(c) ? "line-through" : undefined, opacity: hiddenCats.has(c) ? 0.5 : 1 }}>{c} {points.filter(p => p.cat === c).length}</span>
            </button>
          ))}
        </div>
        <div className="absolute right-2 bottom-2 text-[10px] fnd-text-dim fnd-panel px-1.5 py-0.5">{view.k.toFixed(1)}×</div>
      </div>
    </div>
  );
}
