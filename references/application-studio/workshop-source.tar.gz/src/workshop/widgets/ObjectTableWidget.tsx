"use client";
import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useCore } from "../WorkshopContext";
import type { WidgetDef } from "../types";
import { Icon } from "./icons";
import { PropertyValue } from "./OntologyWidgets";
import { getProperty, objectTypeOf, primaryKeyOf, propertyOf, resolveExpr, type Obj } from "../ontologyMeta";

interface Col { key: string; label: string; width: number; formatter?: string; align?: "left" | "right" | "center" }
interface Cfg {
  objectSetVarId: string; activeVarId?: string; selectedVarId?: string; columns: Col[]; density?: "compact" | "normal";
  enableSelection?: boolean; selectionMode?: "single" | "multiple"; enableInlineEdit?: boolean; showToolbar?: boolean; titleTemplate?: string;
}
interface Sort { key: string; dir: "asc" | "desc" }
type Staged = Record<string, Record<string, unknown>>;

const OVERSCAN = 8;

function csvEscape(v: unknown) { const s = v == null ? "" : String(v); return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; }

export function ObjectTableW({ widget }: { widget: WidgetDef }) {
  const { values, setValues, fireEvents, executeAction, openContextMenu, openOverlay, ontology, ontologyMeta: meta, module, requestConfirm, pushToast } = useCore();
  const cfg = widget.config as unknown as Cfg;
  const setVal = values[cfg.objectSetVarId];
  const rowsRaw = useMemo(() => (Array.isArray(setVal) ? (setVal as Obj[]) : []), [setVal]);
  const varMissing = !cfg.objectSetVarId || !module.variables.some(v => v.id === cfg.objectSetVarId);
  const varError = setVal && !Array.isArray(setVal) && typeof setVal === "object" && "__error" in (setVal as object) ? String((setVal as { __error: string }).__error) : null;

  const type = String(rowsRaw[0]?.__type ?? module.variables.find(v => v.id === cfg.objectSetVarId)?.objectSet?.objectType ?? "");
  const ot = objectTypeOf(meta, type);
  const pk = primaryKeyOf(ot);

  const activeObj = cfg.activeVarId ? (values[cfg.activeVarId] as Obj | null) : null;
  const selected = (cfg.selectedVarId ? (values[cfg.selectedVarId] as Obj[] | undefined) : undefined) ?? [];
  const selectedIds = useMemo(() => new Set(selected.map(o => String(o[pk]))), [selected, pk]);
  const activeId = activeObj && typeof activeObj === "object" ? String(activeObj[pk]) : null;

  // ── local UI state ──
  const [search, setSearch] = useState("");
  const [sorts, setSorts] = useState<Sort[]>([]);
  const [widths, setWidths] = useState<Record<string, number>>({});
  const [hidden, setHidden] = useState<Set<string>>(new Set());
  const [density, setDensity] = useState<"compact" | "normal">(cfg.density === "normal" ? "normal" : "compact");
  const [scrollTop, setScrollTop] = useState(0);
  const [viewH, setViewH] = useState(420);
  const [editMode, setEditMode] = useState(false);
  const [staged, setStaged] = useState<Staged>({});
  const [cellErrors, setCellErrors] = useState<Record<string, string>>({});
  const [editing, setEditing] = useState<{ row: string; key: string } | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const anchor = useRef<number>(-1);
  const scroller = useRef<HTMLDivElement>(null);

  const rowH = density === "compact" ? 28 : 36;
  const cols = useMemo(() => cfg.columns.filter(c => !hidden.has(c.key)).map(c => ({ ...c, width: widths[c.key] ?? c.width })), [cfg.columns, hidden, widths]);
  const totalW = cols.reduce((a, c) => a + c.width, 0) + (cfg.selectionMode === "multiple" ? 32 : 0);

  const valueOf = useCallback((o: Obj, key: string) => {
    const def = propertyOf(meta, String(o.__type), key);
    return def?.derivation ? getProperty(ontology, meta, o, key) : o[key];
  }, [meta, ontology]);

  const rows = useMemo(() => {
    let r = rowsRaw;
    if (search.trim()) {
      const q = search.toLowerCase();
      r = r.filter(o => cols.some(c => String(valueOf(o, c.key) ?? "").toLowerCase().includes(q)));
    }
    if (sorts.length) {
      r = [...r].sort((a, b) => {
        for (const s of sorts) {
          const av = valueOf(a, s.key), bv = valueOf(b, s.key);
          if (av == null && bv == null) continue;
          if (av == null) return 1;
          if (bv == null) return -1;
          const c = typeof av === "number" && typeof bv === "number" ? av - bv : String(av).localeCompare(String(bv), undefined, { numeric: true });
          if (c !== 0) return s.dir === "asc" ? c : -c;
        }
        return 0;
      });
    }
    return r;
  }, [rowsRaw, search, sorts, cols, valueOf]);

  // viewport measurement
  useEffect(() => {
    const el = scroller.current; if (!el) return;
    setViewH(el.clientHeight);
    const ro = new ResizeObserver(() => setViewH(el.clientHeight));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const first = Math.max(0, Math.floor(scrollTop / rowH) - OVERSCAN);
  const last = Math.min(rows.length, Math.ceil((scrollTop + viewH) / rowH) + OVERSCAN);

  // ── selection ──
  const emit = useCallback((o: Obj) => { for (const ev of widget.events ?? []) if (ev.trigger === "onSelect") fireEvents(ev.actions, o); }, [widget.events, fireEvents]);
  const choose = useCallback((o: Obj, i: number, mod: { shift?: boolean; toggle?: boolean } = {}) => {
    if (!cfg.enableSelection) return;
    const multi = cfg.selectionMode === "multiple";
    setValues(prev => {
      const next = { ...prev };
      if (cfg.activeVarId) next[cfg.activeVarId] = o;
      if (multi && cfg.selectedVarId) {
        const cur = ((prev[cfg.selectedVarId] as Obj[] | undefined) ?? []);
        if (mod.shift && anchor.current >= 0) {
          const [a, b] = [Math.min(anchor.current, i), Math.max(anchor.current, i)];
          next[cfg.selectedVarId] = rows.slice(a, b + 1);
        } else if (mod.toggle) {
          const id = String(o[pk]);
          next[cfg.selectedVarId] = cur.some(x => String(x[pk]) === id) ? cur.filter(x => String(x[pk]) !== id) : [...cur, o];
        } else next[cfg.selectedVarId] = [o];
      }
      return next;
    });
    if (!mod.shift) anchor.current = i;
    emit(o);
  }, [cfg.enableSelection, cfg.selectionMode, cfg.activeVarId, cfg.selectedVarId, setValues, rows, pk, emit]);

  const ensureVisible = (i: number) => {
    const el = scroller.current; if (!el) return;
    const top = i * rowH, bottom = top + rowH;
    if (top < el.scrollTop) el.scrollTop = top;
    else if (bottom > el.scrollTop + el.clientHeight - rowH) el.scrollTop = bottom - el.clientHeight + rowH;
  };
  const onKeyDown = (e: React.KeyboardEvent) => {
    if (editing || !rows.length) return;
    const cur = activeId ? rows.findIndex(r => String(r[pk]) === activeId) : -1;
    const go = (i: number) => { const n = Math.max(0, Math.min(rows.length - 1, i)); choose(rows[n], n, { shift: e.shiftKey }); ensureVisible(n); e.preventDefault(); };
    if (e.key === "ArrowDown") go(cur + 1);
    else if (e.key === "ArrowUp") go(cur - 1);
    else if (e.key === "PageDown") go(cur + Math.floor(viewH / rowH));
    else if (e.key === "PageUp") go(cur - Math.floor(viewH / rowH));
    else if (e.key === "Home") go(0);
    else if (e.key === "End") go(rows.length - 1);
    else if (e.key === " " && cur >= 0) { choose(rows[cur], cur, { toggle: true }); e.preventDefault(); }
  };

  // ── inline edit through an Action Type (never writes around validation) ──
  const editAction = useMemo(() => meta.actionTypes.find(a => a.parameters[0]?.type === "ObjectReference" && a.parameters[0].validation.objectTypeApiName === type && a.rules.some(r => r.kind === "modifyObjectRule") && a.parameters.length > 1), [meta, type]);
  const editable = useMemo(() => new Set((editAction?.parameters.slice(1) ?? []).map(p => p.apiName).filter(k => cfg.columns.some(c => c.key === k))), [editAction, cfg.columns]);
  const stagedCount = Object.values(staged).reduce((a, r) => a + Object.keys(r).length, 0);

  const stageCell = (row: Obj, key: string, v: unknown) => {
    const id = String(row[pk]);
    setStaged(s => {
      const r = { ...(s[id] ?? {}) };
      if (String(v) === String(row[key])) delete r[key]; else r[key] = v;
      const n = { ...s };
      if (Object.keys(r).length) n[id] = r; else delete n[id];
      return n;
    });
    setCellErrors(e => { const n = { ...e }; delete n[`${id}:${key}`]; return n; });
    setEditing(null);
  };
  const unstage = (id: string, key: string) => {
    setStaged(s => { const r = { ...(s[id] ?? {}) }; delete r[key]; const n = { ...s }; if (Object.keys(r).length) n[id] = r; else delete n[id]; return n; });
    setCellErrors(e => { const n = { ...e }; delete n[`${id}:${key}`]; return n; });
  };
  const submit = () => {
    if (!editAction) return;
    requestConfirm({
      title: "Submit staged edits", message: `Apply ${stagedCount} cell edit(s) across ${Object.keys(staged).length} ${ot?.pluralDisplayName.toLowerCase() ?? "objects"} using “${editAction.displayName}”.`,
      impact: [`Each row is validated against ${editAction.apiName}'s parameters and submission criteria`, "Rows that fail validation stay staged with the error shown on the cell"],
      onConfirm: () => {
        setSubmitting(true);
        setTimeout(() => {
          const nextStaged: Staged = {}; const errs: Record<string, string> = {};
          let ok = 0;
          for (const [id, patch] of Object.entries(staged)) {
            const row = rowsRaw.find(r => String(r[pk]) === id);
            if (!row) continue;
            const params: Record<string, unknown> = { [editAction.parameters[0].apiName]: id };
            for (const p of editAction.parameters.slice(1)) params[p.apiName] = p.defaultFrom ? resolveExpr(p.defaultFrom, params, row) : row[p.apiName];
            Object.assign(params, patch);
            const res = executeAction(editAction.apiName, params);
            if (res.ok) ok++;
            else { nextStaged[id] = patch; for (const k of Object.keys(patch)) errs[`${id}:${k}`] = res.errors[0] ?? "Validation failed"; }
          }
          setStaged(nextStaged); setCellErrors(errs); setSubmitting(false);
          if (Object.keys(nextStaged).length === 0) setEditMode(false);
          pushToast({ kind: ok ? "success" : "warning", message: `${ok} row(s) updated${Object.keys(nextStaged).length ? ` · ${Object.keys(nextStaged).length} failed validation` : ""}` });
        }, 250);
      },
    });
  };

  // ── toolbar / menus ──
  const exportCsv = () => {
    const head = cols.map(c => csvEscape(c.label)).join(",");
    const body = rows.map(o => cols.map(c => csvEscape(valueOf(o, c.key))).join(",")).join("\n");
    const url = URL.createObjectURL(new Blob([`${head}\n${body}`], { type: "text/csv;charset=utf-8" }));
    const a = document.createElement("a"); a.href = url; a.download = `${widget.name.replace(/\W+/g, "_")}.csv`; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };
  const moreMenu = (e: React.MouseEvent) => {
    const r = (e.currentTarget as HTMLElement).getBoundingClientRect();
    openContextMenu(r.right - 200, r.bottom + 2, [
      { label: `Export ${rows.length.toLocaleString()} rows as CSV`, onClick: exportCsv },
      { separator: true, label: "" },
      { label: `${density === "compact" ? "✓ " : ""}Compact density`, onClick: () => setDensity("compact") },
      { label: `${density === "normal" ? "✓ " : ""}Comfortable density`, onClick: () => setDensity("normal") },
      { separator: true, label: "" },
      ...cfg.columns.map(c => ({ label: `${hidden.has(c.key) ? "   " : "✓ "}${c.label}`, onClick: () => setHidden(h => { const n = new Set(h); if (n.has(c.key)) n.delete(c.key); else n.add(c.key); return n; }) })),
      { separator: true, label: "" },
      { label: "Reset columns & sort", onClick: () => { setWidths({}); setHidden(new Set()); setSorts([]); } },
    ]);
  };
  const rowMenu = (e: React.MouseEvent, o: Obj, i: number) => {
    e.preventDefault();
    choose(o, i);
    openContextMenu(e.clientX, e.clientY, [
      ...module.overlays.map(ov => ({ label: `Open ${ov.name}`, onClick: () => openOverlay(ov.id) })),
      ...(module.overlays.length ? [{ separator: true, label: "" }] : []),
      { label: "Copy ID", onClick: () => { void navigator.clipboard?.writeText(String(o[pk])); } },
      { label: "Copy row as JSON", onClick: () => { void navigator.clipboard?.writeText(JSON.stringify(o, null, 2)); } },
    ]);
  };
  const startResize = (e: React.PointerEvent, c: Col & { width: number }) => {
    e.preventDefault(); e.stopPropagation();
    const sx = e.clientX, sw = c.width;
    const move = (ev: PointerEvent) => setWidths(w => ({ ...w, [c.key]: Math.max(48, sw + ev.clientX - sx) }));
    const up = () => { window.removeEventListener("pointermove", move); window.removeEventListener("pointerup", up); };
    window.addEventListener("pointermove", move); window.addEventListener("pointerup", up);
  };
  const toggleSort = (key: string, shift: boolean) => setSorts(prev => {
    const cur = prev.find(s => s.key === key);
    const nextSort: Sort | null = !cur ? { key, dir: "asc" } : cur.dir === "asc" ? { key, dir: "desc" } : null;
    const rest = shift ? prev.filter(s => s.key !== key) : [];
    return nextSort ? [...rest, nextSort] : rest;
  });

  const title = (cfg.titleTemplate ?? "Objects ({count})").replace("{count}", rows.length.toLocaleString());

  if (varMissing) return <div className="fnd-panel rounded-sm p-3 text-xs" style={{ color: "var(--fnd-danger)" }}>⚠ Widget configuration invalid — cannot resolve variable “{cfg.objectSetVarId || "(none)"}”. Bind an Object set in the Inspector.</div>;
  if (varError) return <div className="fnd-panel rounded-sm p-3 text-xs" style={{ color: "var(--fnd-danger)" }}>⚠ Object set failed to evaluate: {varError}</div>;

  return (
    <div className="fnd-panel rounded-sm flex flex-col h-full overflow-hidden" style={{ minHeight: 220, position: "relative" }}>
      {cfg.showToolbar !== false && (
        <div className="flex items-center gap-2 px-2.5 border-b fnd-border" style={{ height: 36, flexShrink: 0 }}>
          <div className="text-xs font-semibold truncate" title={title}>{title}</div>
          {editMode && stagedCount > 0 && <span className="fnd-tag" style={{ background: "rgba(255,196,87,.25)", borderColor: "rgba(217,130,43,.5)" }}>{stagedCount} staged</span>}
          <div className="flex-1"/>
          {cfg.enableInlineEdit && !editMode && (
            <button className="fnd-btn fnd-btn-minimal" disabled={!editAction} title={editAction ? `Edit cells via “${editAction.displayName}”` : `No Action Type modifies ${ot?.pluralDisplayName ?? "this object type"}`} onClick={() => setEditMode(true)}><Icon.Edit size={12}/> Edit</button>
          )}
          {editMode && (
            <>
              <button className="fnd-btn" onClick={() => { setStaged({}); setCellErrors({}); setEditMode(false); }}>Cancel</button>
              <button className="fnd-btn fnd-btn-primary" disabled={!stagedCount || submitting} onClick={submit}>{submitting ? "Submitting…" : "Submit"}</button>
            </>
          )}
          <div className="relative" style={{ width: 160 }}>
            <span style={{ position: "absolute", left: 7, top: 7, color: "var(--fnd-text-dim)" }}><Icon.Search size={12}/></span>
            <input value={search} onChange={e => { setSearch(e.target.value); setScrollTop(0); if (scroller.current) scroller.current.scrollTop = 0; }} placeholder="Search" aria-label="Search table" className="fnd-input" style={{ paddingLeft: 24 }}/>
          </div>
          <button className="fnd-btn fnd-btn-minimal" title="Table options" aria-haspopup="menu" onClick={moreMenu}><Icon.More size={14}/></button>
        </div>
      )}
      <div ref={scroller} className="flex-1 overflow-auto" role="grid" aria-rowcount={rows.length} aria-multiselectable={cfg.selectionMode === "multiple"} tabIndex={0} onKeyDown={onKeyDown}
        onScroll={e => { const t = (e.currentTarget as HTMLDivElement).scrollTop; requestAnimationFrame(() => setScrollTop(t)); }}
        style={{ outline: "none", position: "relative" }}>
        <div style={{ width: totalW, minWidth: "100%" }}>
          <div role="row" className="flex" style={{ position: "sticky", top: 0, zIndex: 2, background: "var(--fnd-panel-2)", borderBottom: "1px solid var(--fnd-border)", height: 30 }}>
            {cfg.selectionMode === "multiple" && (
              <div role="columnheader" style={{ width: 32, flex: "0 0 auto" }} className="flex items-center justify-center">
                <input type="checkbox" aria-label="Select all" checked={rows.length > 0 && rows.every(o => selectedIds.has(String(o[pk])))}
                  onChange={e => cfg.selectedVarId && setValues(p => ({ ...p, [cfg.selectedVarId!]: e.target.checked ? rows : [] }))}/>
              </div>
            )}
            {cols.map(c => {
              const si = sorts.findIndex(s => s.key === c.key);
              return (
                <div key={c.key} role="columnheader" aria-sort={si >= 0 ? (sorts[si].dir === "asc" ? "ascending" : "descending") : "none"}
                  onClick={e => toggleSort(c.key, e.shiftKey)} title={`${c.label} — click to sort, Shift+click for multi-sort`}
                  className="flex items-center gap-1 px-2 text-[11px] font-semibold uppercase tracking-wide select-none cursor-pointer relative"
                  style={{ width: c.width, flex: "0 0 auto", color: "var(--fnd-text-muted)", borderRight: "1px solid var(--fnd-border)", justifyContent: c.align === "right" ? "flex-end" : undefined }}>
                  <span className="truncate">{c.label}</span>
                  {si >= 0 && <span className="inline-flex items-center"><Icon.Chevron size={10} dir={sorts[si].dir === "asc" ? "up" : "down"}/>{sorts.length > 1 && <sub style={{ fontSize: 8 }}>{si + 1}</sub>}</span>}
                  {editMode && editable.has(c.key) && <span title="Editable" style={{ color: "var(--fnd-accent)" }}>✎</span>}
                  <span onPointerDown={e => startResize(e, c)} onClick={e => e.stopPropagation()} role="separator" aria-label={`Resize ${c.label}`}
                    style={{ position: "absolute", right: -3, top: 0, bottom: 0, width: 7, cursor: "col-resize", zIndex: 3 }}/>
                </div>
              );
            })}
          </div>
          {rows.length === 0 ? (
            <div className="p-8 text-center text-xs fnd-text-dim">
              {rowsRaw.length === 0 ? `No ${ot?.pluralDisplayName.toLowerCase() ?? "objects"} in @${cfg.objectSetVarId}. Adjust the upstream filters.` : `No results for “${search}”.`}
            </div>
          ) : (
            <div style={{ height: rows.length * rowH, position: "relative" }}>
              {rows.slice(first, last).map((o, k) => {
                const i = first + k;
                const id = String(o[pk]);
                const isActive = id === activeId, isSel = selectedIds.has(id);
                return (
                  <div key={id} role="row" aria-selected={isActive || isSel} aria-rowindex={i + 1}
                    onClick={e => choose(o, i, { shift: e.shiftKey, toggle: e.metaKey || e.ctrlKey })} onContextMenu={e => rowMenu(e, o, i)}
                    className={`flex items-center fnd-row-hover ${isActive ? "fnd-selected" : isSel ? "fnd-selected" : ""}`}
                    style={{ position: "absolute", top: i * rowH, left: 0, right: 0, height: rowH, borderBottom: "1px solid var(--fnd-border)", cursor: cfg.enableSelection ? "pointer" : "default", opacity: isSel && !isActive ? 0.92 : 1 }}>
                    {cfg.selectionMode === "multiple" && (
                      <div role="gridcell" style={{ width: 32, flex: "0 0 auto" }} className="flex items-center justify-center" onClick={e => e.stopPropagation()}>
                        <input type="checkbox" aria-label={`Select ${id}`} checked={isSel} onChange={() => choose(o, i, { toggle: true })}/>
                      </div>
                    )}
                    {cols.map(c => {
                      const def = propertyOf(meta, String(o.__type), c.key);
                      const stagedVal = staged[id]?.[c.key];
                      const dirty = stagedVal !== undefined;
                      const err = cellErrors[`${id}:${c.key}`];
                      const shown = dirty ? stagedVal : valueOf(o, c.key);
                      const isEditing = editing?.row === id && editing.key === c.key;
                      const param = editAction?.parameters.find(p => p.apiName === c.key);
                      return (
                        <div key={c.key} role="gridcell" title={err ?? (shown == null ? "" : String(shown))}
                          onDoubleClick={() => { if (editMode && editable.has(c.key)) setEditing({ row: id, key: c.key }); }}
                          className="px-2 truncate text-xs relative group"
                          style={{ width: c.width, flex: "0 0 auto", textAlign: c.align, background: err ? "rgba(194,48,48,.14)" : dirty ? "rgba(255,196,87,.18)" : editMode && editable.has(c.key) ? "rgba(43,108,176,.04)" : undefined, outline: err ? "1px solid var(--fnd-danger)" : undefined, outlineOffset: -1, fontVariantNumeric: "tabular-nums" }}>
                          {isEditing ? (
                            param?.validation.allowedValues ? (
                              <select autoFocus className="fnd-input fnd-select" style={{ height: rowH - 6 }} defaultValue={String(shown ?? "")} onClick={e => e.stopPropagation()}
                                onBlur={() => setEditing(null)} onChange={e => stageCell(o, c.key, e.target.value)}>
                                {param.validation.allowedValues.map(v => <option key={v}>{v}</option>)}
                              </select>
                            ) : (
                              <input autoFocus className="fnd-input" style={{ height: rowH - 6 }} defaultValue={String(shown ?? "")} onClick={e => e.stopPropagation()}
                                type={param?.type === "Double" || param?.type === "Integer" ? "number" : "text"}
                                onBlur={e => stageCell(o, c.key, param?.type === "Double" || param?.type === "Integer" ? Number(e.target.value) : e.target.value)}
                                onKeyDown={e => { if (e.key === "Enter") (e.target as HTMLInputElement).blur(); if (e.key === "Escape") setEditing(null); }}/>
                            )
                          ) : shown == null || shown === "" ? <span className="fnd-text-dim">—</span> : def ? <PropertyValue def={def} v={shown}/> : <span>{String(shown)}</span>}
                          {dirty && !isEditing && (
                            <button className="fnd-btn fnd-btn-minimal opacity-0 group-hover:opacity-100" title="Revert this cell" aria-label="Revert cell" style={{ position: "absolute", right: 2, top: 3, height: 18, padding: "0 3px" }}
                              onClick={e => { e.stopPropagation(); unstage(id, c.key); }}><Icon.Undo size={10}/></button>
                          )}
                        </div>
                      );
                    })}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
      <div className="flex items-center gap-3 px-2.5 text-[11px] fnd-text-muted border-t fnd-border" style={{ height: 24, flexShrink: 0 }}>
        <span>{rows.length.toLocaleString()}{rows.length !== rowsRaw.length ? ` of ${rowsRaw.length.toLocaleString()}` : ""} rows</span>
        {selectedIds.size > 0 && <span>· {selectedIds.size} selected</span>}
        {sorts.length > 0 && <span>· sorted by {sorts.map(s => `${cfg.columns.find(c => c.key === s.key)?.label ?? s.key} ${s.dir === "asc" ? "↑" : "↓"}`).join(", ")}</span>}
        <div className="flex-1"/>
        <span className="fnd-text-dim">@{cfg.objectSetVarId}</span>
      </div>
      {submitting && <div className="fnd-skeleton" style={{ position: "absolute", left: 0, right: 0, top: 36, height: 3 }} aria-busy="true"/>}
    </div>
  );
}
