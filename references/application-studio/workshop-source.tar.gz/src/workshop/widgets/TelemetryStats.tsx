"use client";
import React, { useEffect, useMemo, useRef, useState } from "react";
import { useCore } from "../WorkshopContext";
import { useStore } from "../runtimeStores";
import { telemetryStore, aggregateTelemetry, readAssetSample, ensureTelemetry, type AssetSample, type TelemetryStats } from "../telemetry/telemetryStore";
import { Icon } from "./icons";
import type { WidgetDef } from "../types";

const WINDOW_SIZES = [1000, 10000, 100000] as const;
function display(n: number | undefined, digits = 2) { return n == null || !Number.isFinite(n) ? "—" : n.toLocaleString("en-US", { maximumFractionDigits: digits }); }

export function TelemetryStatsWidget({ widget }: { widget: WidgetDef }) {
  const { values } = useCore();
  const cfg = widget.config as { assetVarId?: string; signalIndex?: number; threshold?: number; windowRows?: number; flowStatsVarId?: string };
  const ready = useStore(telemetryStore, s => s.ready);
  const error = useStore(telemetryStore, s => s.error);
  const tick = useStore(telemetryStore, s => Math.floor(s.version / 8));
  const wasmReady = useStore(telemetryStore, s => s.wasm);
  const plants = useStore(telemetryStore, s => s.plants);
  const name = useStore(telemetryStore, s => s.columnNames[cfg.signalIndex ?? 0] ?? "vibration_01");
  const [signal, setSignal] = useState(cfg.signalIndex ?? 0);
  const [threshold, setThreshold] = useState(cfg.threshold ?? 11.5);
  const [windowRows, setWindowRows] = useState(cfg.windowRows ?? 10000);
  const [stats, setStats] = useState<TelemetryStats | null>(null);
  const [sample, setSample] = useState<AssetSample | null>(null);
  const [history, setHistory] = useState<number[]>([]);
  const [busy, setBusy] = useState(false);
  const seq = useRef(0);
  const asset = values[cfg.assetVarId ?? "selectedAsset"] as { id?: string; name?: string } | null;
  const assetId = asset?.id ?? "AST-1000";

  useEffect(() => { void ensureTelemetry().catch(() => {}); }, []);
  useEffect(() => {
    if (!ready) return;
    const id = ++seq.current;
    setBusy(true);
    const from = Math.max(0, 100000 - windowRows);
    Promise.all([aggregateTelemetry(from, 100000, signal, threshold), readAssetSample(assetId)]).then(([result, latest]) => {
      if (seq.current !== id) return;
      setStats(result); setSample(latest);
      setHistory(prev => [...prev.slice(-59), latest.signals[signal] ?? 0]);
    }).catch(() => {}).finally(() => { if (seq.current === id) setBusy(false); });
  }, [ready, tick, signal, threshold, windowRows, assetId]);
  const points = useMemo(() => {
    if (history.length < 2) return "";
    const min = Math.min(...history, threshold - 2), max = Math.max(...history, threshold + 2);
    return history.map((v, i) => `${(i / (history.length - 1)) * 300},${75 - ((v - min) / Math.max(.001, max - min)) * 64}`).join(" ");
  }, [history, threshold]);
  const current = sample?.signals[signal];
  const above = current !== undefined && current > threshold;
  const flowStats = cfg.flowStatsVarId ? values[cfg.flowStatsVarId] as Record<string, unknown> | undefined : undefined;

  if (error && !ready) return <div className="fnd-panel rounded-sm p-3 text-xs" style={{ color: "var(--fnd-danger)" }}>⚠ Telemetry engine unavailable: {error}</div>;

  return (
    <div className="fnd-panel rounded-sm h-full flex flex-col overflow-hidden" style={{ minHeight: 178 }}>
      <div className="flex items-center gap-2 px-3 border-b fnd-border" style={{ height: 36, flexShrink: 0 }}>
        <Icon.Chart size={14}/><span className="text-xs font-semibold">{widget.name}</span>
        <span className="fnd-tag">{wasmReady ? "WASM compute" : "JS fallback"}</span>
        <div className="flex-1"/>
        <select className="fnd-input fnd-select" aria-label="Signal" style={{ width: 142, height: 24 }} value={signal} onChange={e => { setSignal(Number(e.target.value)); setHistory([]); }}>
          {Array.from({ length: 100 }, (_, i) => <option key={i} value={i}>{telemetryStore.get().columnNames[i] ?? `signal_${i}`}</option>)}
        </select>
        <select className="fnd-input fnd-select" aria-label="Window rows" style={{ width: 110, height: 24 }} value={windowRows} onChange={e => setWindowRows(Number(e.target.value))}>
          {WINDOW_SIZES.map(n => <option key={n} value={n}>{n.toLocaleString()} rows</option>)}
        </select>
      </div>
      <div className="grid grid-cols-4 gap-0 border-b fnd-border" style={{ background: "var(--fnd-panel-2)" }}>
        {[["Mean", stats?.mean], ["Min", stats?.min], ["Max", stats?.max], [`Above ${display(threshold, 1)}`, stats?.above]].map(([label, value]) => (
          <div key={String(label)} className="px-3 py-2" style={{ borderRight: "1px solid var(--fnd-border)" }}><div className="text-[10px] uppercase fnd-text-muted">{String(label)}</div><div className="text-lg font-bold tabular-nums" style={{ color: String(label).startsWith("Above") && Number(value) > 0 ? "var(--fnd-warning)" : undefined }}>{display(value as number, 2)}</div></div>
        ))}
      </div>
      <div className="flex-1 px-3 py-2 flex gap-3 min-h-0">
        <div style={{ width: "37%", minWidth: 130 }}>
          <div className="fnd-label">Active asset · {assetId}</div>
          <div className="text-[11px] fnd-text-muted truncate" title={asset?.name}>{asset?.name ?? "Select a row"}</div>
          <div className="text-xl font-bold tabular-nums mt-1" style={{ color: above ? "var(--fnd-danger)" : "var(--fnd-success)" }}>{display(current)}</div>
          <div className="text-[10px] fnd-text-muted">{sample ? `${sample.plant} · DEV-${String(sample.deviceId + 1).padStart(4, "0")}` : "Awaiting sample"}</div>
          <label className="text-[10px] fnd-text-muted flex items-center gap-1 mt-1">Alarm &gt;
            <input className="fnd-input" style={{ height: 22, width: 65 }} type="number" step={0.1} value={threshold} onChange={e => setThreshold(Number(e.target.value))}/>
          </label>
        </div>
        <div className="flex-1 min-w-0 flex flex-col justify-center">
          <div className="text-[10px] fnd-text-muted mb-1">Live signal · {name}{busy ? " · computing" : ""}</div>
          <svg viewBox="0 0 300 85" preserveAspectRatio="none" width="100%" height="80" role="img" aria-label={`${name} live trend`}>
            <line x1="0" x2="300" y1="74" y2="74" stroke="var(--fnd-border)"/>
            {points && <polyline points={points} fill="none" stroke={above ? "var(--fnd-danger)" : "var(--fnd-accent)"} strokeWidth="2"/>}
          </svg>
          <div className="text-[10px] fnd-text-dim">{stats ? `${stats.count.toLocaleString()} rows · ${stats.elapsedMs.toFixed(1)}ms ${stats.wasm ? "on WASM" : "fallback"}` : "Building numeric window…"}{flowStats && <span> · Flow output linked</span>}</div>
        </div>
      </div>
    </div>
  );
}
