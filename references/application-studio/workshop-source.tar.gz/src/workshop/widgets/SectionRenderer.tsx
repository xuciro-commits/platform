"use client";
import React, { Profiler, createContext, memo, useContext, useLayoutEffect, useMemo, useRef, useState } from "react";
import { CoreCtx, StoreCtx, useWS, useWSShallow, type CoreState } from "../WorkshopContext";
import type { SectionDef, VariableDef, WidgetDef } from "../types";
import { WidgetRenderer } from "./WidgetRenderer";
import { Icon } from "./icons";
import { metrics, useLive } from "../runtimeStores";
import { orientOf, type Orient } from "../layoutOps";

interface Parent { id: string; index: number; orient: Orient; stacked: boolean }
interface NodeProps { isBuilder: boolean; parent?: Parent }

// ─── hooks ─────────────────────────────────────────────────────────────────
function useIsNarrow(ref: React.RefObject<HTMLElement | null>, threshold: number, enabled: boolean) {
  const [narrow, setNarrow] = useState(false);
  useLayoutEffect(() => {
    const el = ref.current;
    if (!enabled || !el) { setNarrow(false); return; }
    setNarrow(el.clientWidth < threshold);
    const ro = new ResizeObserver(entries => setNarrow(entries[0].contentRect.width < threshold));
    ro.observe(el);
    return () => ro.disconnect();
  }, [enabled, threshold, ref]);
  return narrow;
}

function useOnScreen(ref: React.RefObject<HTMLElement | null>, enabled: boolean) {
  const [state, setState] = useState({ visible: !enabled, ever: !enabled });
  useLayoutEffect(() => {
    const el = ref.current;
    if (!enabled || !el) { setState({ visible: true, ever: true }); return; }
    const io = new IntersectionObserver(es => {
      const v = es.some(e => e.isIntersecting);
      setState(s => (s.visible === v && (s.ever || !v) ? s : { visible: v, ever: s.ever || v }));
    }, { rootMargin: "200px" });
    io.observe(el);
    return () => io.disconnect();
  }, [enabled, ref]);
  return state;
}

// ─── dependency analysis: which variables does a widget actually read? ─────
const idSets = new WeakMap<VariableDef[], Set<string>>();
function idSetOf(vars: VariableDef[]) {
  let s = idSets.get(vars);
  if (!s) { s = new Set(vars.map(v => v.id)); idSets.set(vars, s); }
  return s;
}
const depCache = new WeakMap<WidgetDef, { vars: VariableDef[]; deps: string[] }>();
export function widgetDeps(w: WidgetDef, vars: VariableDef[]): string[] {
  const hit = depCache.get(w);
  if (hit && hit.vars === vars) return hit.deps;
  const ids = idSetOf(vars);
  const out = new Set<string>();
  const walk = (x: unknown, depth: number) => {
    if (depth > 6 || x == null) return;
    if (typeof x === "string") { if (ids.has(x)) out.add(x); }
    else if (Array.isArray(x)) for (const i of x) walk(i, depth + 1);
    else if (typeof x === "object") for (const v of Object.values(x as Record<string, unknown>)) walk(v, depth + 1);
  };
  walk(w.config, 0); walk(w.events, 0);
  if (w.type.startsWith("AIP")) { out.add("filteredAssets"); out.add("activeAlerts"); }
  const deps = [...out];
  depCache.set(w, { vars, deps });
  return deps;
}
function pick(values: Record<string, unknown>, ids: string[]) {
  const o: Record<string, unknown> = {};
  for (const id of ids) o[id] = values[id];
  return o;
}

// ─── loop item scope ───────────────────────────────────────────────────────
const LoopCtx = createContext<{ varId: string; item: unknown } | null>(null);

// ─── error boundary (a failing widget must never take the module down) ─────
class WidgetBoundary extends React.Component<{ name: string; resetKey: unknown; children: React.ReactNode }, { err: Error | null }> {
  state = { err: null as Error | null };
  static getDerivedStateFromError(err: Error) { return { err }; }
  componentDidUpdate(prev: { resetKey: unknown }) { if (prev.resetKey !== this.props.resetKey && this.state.err) this.setState({ err: null }); }
  render() {
    if (!this.state.err) return this.props.children;
    return (
      <div role="alert" className="fnd-panel rounded-sm p-3 text-xs" style={{ borderColor: "var(--fnd-danger)" }}>
        <div className="font-semibold" style={{ color: "var(--fnd-danger)" }}>⚠ “{this.props.name}” failed to render</div>
        <div className="fnd-text-muted mt-1 break-words">{this.state.err.message}</div>
        <button className="fnd-btn mt-2" onClick={() => this.setState({ err: null })}>Retry</button>
      </div>
    );
  }
}

const MemoRenderer = memo(WidgetRenderer);

function flexStyle(parent: Parent | undefined, weight: number, fixedWidth?: string): React.CSSProperties {
  if (!parent) return { flex: "1 1 auto", minWidth: 0, minHeight: 0 };
  if (parent.orient === "h" && !parent.stacked) {
    return fixedWidth ? { flex: "0 0 auto", width: fixedWidth, minWidth: 0 } : { flex: `${weight} 1 0%`, minWidth: 0 };
  }
  return { flex: "0 0 auto", width: fixedWidth && parent.orient === "v" ? fixedWidth : "100%", maxWidth: "100%", minWidth: 0 };
}

const BG: Record<string, string | undefined> = { panel: "var(--fnd-panel)", muted: "var(--fnd-panel-2)", none: "transparent", default: undefined };
const SHADOW = ["none", "0 1px 2px rgba(16,22,26,0.08)", "0 2px 8px rgba(16,22,26,0.14)"];

// ─── Widget node ───────────────────────────────────────────────────────────
const WidgetNode = memo(function WidgetNode({ widgetId, isBuilder, parent }: NodeProps & { widgetId: string }) {
  const widget = useWS(s => s.core.module.widgets[widgetId]);
  const variables = useWS(s => s.core.module.variables);
  const deps = useMemo(() => (widget ? widgetDeps(widget, variables) : []), [widget, variables]);
  const vals = useWSShallow(s => pick(s.core.values, deps));
  // widgets see a projection of the module that ignores edits to other widgets' own definitions
  const modParts = useWSShallow(s => ({ variables: s.core.module.variables, overlays: s.core.module.overlays, pages: s.core.module.pages, header: s.core.module.header, sections: s.core.module.sections }));
  const env0 = useWSShallow(s => ({ ontology: s.core.ontology, ontologyMeta: s.core.ontologyMeta, dataVersion: s.core.dataVersion, theme: s.core.theme, currentPageId: s.core.currentPageId, actionLog: s.core.actionLog, mode: s.core.mode }));
  const loop = useContext(LoopCtx);
  const store = useContext(StoreCtx)!;
  const live = useLive(widgetId);
  const ref = useRef<HTMLDivElement>(null);
  const lazy = widget?.mountBehavior === "delayUntilOnScreen" || widget?.unmountBehavior === "unmountOffScreen";
  const screen = useOnScreen(ref, !!lazy);

  const env = useMemo(() => ({ ...env0, module: { ...store.getSnapshot().core.module, ...modParts } }), [env0, modParts, store]);
  const scoped = useMemo<CoreState>(
    () => ({ ...store.getSnapshot().core, ...env, values: loop ? { ...vals, [loop.varId]: loop.item } : vals }),
    [store, env, vals, loop],
  );
  if (!widget) return null;

  if (widget.hidden && !isBuilder) return null;
  const cfg = widget.config as { objectSetVarId?: string };
  const setVal = cfg.objectSetVarId ? vals[cfg.objectSetVarId] : undefined;
  const showEmpty = !!widget.emptyMessage && Array.isArray(setVal) && setVal.length === 0;
  const renderBody = !lazy || (widget.unmountBehavior === "unmountOffScreen" ? screen.visible : screen.ever);
  const height = live?.height ?? widget.height;
  const st = widget.style;

  return (
    <div
      ref={ref}
      data-node-id={widgetId} data-node-kind="widget"
      data-parent-id={parent?.id} data-index={parent?.index} data-parent-orient={parent?.orient}
      data-no-border={st?.border === false ? "1" : undefined}
      style={{
        position: "relative", display: "flex", flexDirection: "column", minHeight: 0,
        ...flexStyle(parent, live?.flex ?? widget.flex ?? 1),
        height: height || undefined,
        overflow: height ? "auto" : undefined,
        background: st?.background ? BG[st.background] : undefined,
        border: st?.border ? "1px solid var(--fnd-border)" : undefined,
        boxShadow: st?.elevation ? SHADOW[st.elevation] : undefined,
        padding: st?.padding || undefined,
        borderRadius: 3,
        opacity: widget.hidden ? 0.45 : undefined,
        outline: widget.hidden ? "1px dashed var(--fnd-border-strong)" : undefined,
      }}
    >
      {widget.hidden ? (
        <div className="p-3 text-[11px] fnd-text-dim">Hidden widget “{widget.name}” — not shown at runtime</div>
      ) : showEmpty ? (
        <div className="fnd-panel rounded-sm p-6 text-xs fnd-text-dim text-center">{widget.emptyMessage}</div>
      ) : !renderBody ? (
        <div className="fnd-skeleton" style={{ minHeight: 96 }} aria-busy="true"/>
      ) : (
        <div inert={widget.readOnly || undefined} style={{ display: "flex", flexDirection: "column", flex: 1, minHeight: 0 }}>
          <CoreCtx.Provider value={scoped}>
            <WidgetBoundary name={widget.name} resetKey={widget}>
              <Profiler id={widgetId} onRender={(_id, _phase, actual) => metrics.recordWidget(widgetId, actual)}>
                <MemoRenderer widget={widget} isBuilder={isBuilder}/>
              </Profiler>
            </WidgetBoundary>
          </CoreCtx.Provider>
        </div>
      )}
      {widget.readOnly && <span className="fnd-tag" style={{ position: "absolute", top: 4, right: 4, height: 18 }} title="Read-only: interaction disabled">🔒 read-only</span>}
    </div>
  );
});

// ─── Section node ──────────────────────────────────────────────────────────
export const SectionView = memo(function SectionView({ sectionId, isBuilder, parent }: NodeProps & { sectionId: string }) {
  const section = useWS(s => s.core.module.sections[sectionId]);
  const visVar = section?.visibleVariableId;
  const visible = useWS(s => (visVar ? s.core.values[visVar] : true));
  const collapsedState = useWS(s => s.ui.collapsedSections[sectionId]);
  const tabIdx = useWS(s => s.ui.tabSelection[sectionId] ?? 0);
  const loopVar = section?.layout === "loop" ? section.loopVariableId ?? "" : "";
  const loopItems = useWS(s => (loopVar ? s.core.values[loopVar] : undefined));
  const keepKey = useWS(s => section?.layout === "tabs" ? section.children.map(c => (c.kind === "widget" && s.core.module.widgets[c.id]?.unmountBehavior === "neverUnmount" ? "1" : "0")).join("") : "");
  const tabNames = useWS(s => section?.layout === "tabs" ? section.children.map((c, i) => section.tabs?.find(t => t.childIndex === i)?.label ?? (c.kind === "widget" ? s.core.module.widgets[c.id]?.name : s.core.module.sections[c.id]?.name) ?? `Tab ${i + 1}`).join("\u0001") : "");
  const setTab = useWS(s => s.core.setTabIndex);
  const setCollapsed = useWS(s => s.core.setSectionCollapsed);
  const select = useWS(s => s.ui.select);
  const live = useLive(sectionId);
  const ref = useRef<HTMLDivElement>(null);

  const horizontalLayout = section ? orientOf(section.layout) === "h" : false;
  const narrow = useIsNarrow(ref, section?.stackBelow ?? 640, horizontalLayout && !section?.noStack && (section?.children.length ?? 0) > 1);
  if (!section) return null;

  if (visVar && visible === false) {
    if (!isBuilder) return null;
    return (
      <div className="text-[11px] fnd-text-dim px-2 py-1 rounded-sm" style={{ border: "1px dashed var(--fnd-border-strong)", ...flexStyle(parent, 1) }}
        data-node-id={sectionId} data-node-kind="section" data-parent-id={parent?.id} data-index={parent?.index} data-parent-orient={parent?.orient} data-orient="v"
        onPointerDown={() => select({ kind: "section", id: sectionId })}>
        Hidden section “{section.name}” — visible when @{visVar} = true
      </div>
    );
  }

  const baseOrient = orientOf(section.layout);
  const stacked = baseOrient === "h" && narrow;
  const orient: Orient = stacked ? "v" : baseOrient;
  const collapsed = collapsedState ?? section.defaultCollapsed;
  const width = live?.width !== undefined ? `${live.width}px` : section.width;
  const me: Parent = { id: sectionId, index: 0, orient, stacked };
  const child = (c: SectionDef["children"][number], i: number) => c.kind === "section"
    ? <SectionView key={c.id} sectionId={c.id} isBuilder={isBuilder} parent={{ ...me, index: i, orient: orient === "tabs" || orient === "loop" ? orient : orient }}/>
    : <WidgetNode key={c.id} widgetId={c.id} isBuilder={isBuilder} parent={{ ...me, index: i }}/>;

  let body: React.ReactNode;
  if (section.children.length === 0 && isBuilder) {
    body = <div className="flex items-center justify-center text-[11px] rounded-sm fnd-text-dim" style={{ minHeight: 72, border: "1.5px dashed var(--fnd-border-strong)" }}>Empty section — drag widgets here</div>;
  } else if (section.layout === "loop") {
    const items = Array.isArray(loopItems) ? (loopItems as Array<Record<string, unknown>>) : [];
    body = items.length === 0
      ? <div className="text-xs fnd-text-dim p-3">Loop has no objects. Bind a loop object set in the Inspector.</div>
      : (
        <div className="flex flex-col" style={{ gap: section.gap ?? 8 }}>
          {items.slice(0, 25).map((item, n) => (
            <LoopCtx.Provider key={String(item.id ?? n)} value={{ varId: section.loopItemVarId ?? "selectedAsset", item }}>
              <div className="fnd-panel rounded-sm p-2 flex flex-col" style={{ gap: 6 }}>
                <div className="text-[10px] fnd-text-dim">#{n + 1} · {String(item.name ?? item.title ?? item.id ?? "item")}</div>
                {section.children.map((c, i) => child(c, i))}
              </div>
            </LoopCtx.Provider>
          ))}
          {items.length > 25 && <div className="text-[11px] fnd-text-dim">+{items.length - 25} more</div>}
        </div>
      );
  } else if (section.layout === "tabs") {
    const names = tabNames.split("\u0001");
    const active = Math.min(tabIdx, Math.max(0, section.children.length - 1));
    body = (
      <div className="flex flex-col gap-2 flex-1 min-h-0">
        <div role="tablist" className="flex border-b fnd-border overflow-x-auto" style={{ flexShrink: 0 }}>
          {names.map((n, i) => (
            <button key={i} role="tab" aria-selected={active === i} onClick={() => setTab(sectionId, i)} className="px-3 py-1.5 text-xs font-medium whitespace-nowrap"
              style={{ borderBottom: active === i ? "2px solid var(--fnd-accent)" : "2px solid transparent", color: active === i ? "var(--fnd-text)" : "var(--fnd-text-muted)" }}>{n}</button>
          ))}
        </div>
        <div data-children-of={sectionId} style={{ flex: 1, minHeight: 0, display: "flex", flexDirection: "column" }}>
          {section.children.map((c, i) => (i === active || keepKey[i] === "1")
            ? <div key={c.id} style={{ display: i === active ? "flex" : "none", flexDirection: "column", flex: 1, minHeight: 0 }}>{child(c, i)}</div>
            : null)}
        </div>
      </div>
    );
  } else {
    const alignMap = { stretch: "stretch", start: "flex-start", center: "center", end: "flex-end" } as const;
    const justMap = { start: "flex-start", center: "center", end: "flex-end", between: "space-between" } as const;
    body = (
      <div data-children-of={sectionId}
        style={{
          display: "flex", flexDirection: orient === "h" ? "row" : "column", gap: section.gap ?? 8, flex: 1, minHeight: 0, minWidth: 0,
          alignItems: section.layout === "toolbar" ? "center" : alignMap[section.align ?? "stretch"],
          justifyContent: section.layout === "toolbar" ? "space-between" : justMap[section.justify ?? "start"],
          flexWrap: section.wrap || section.layout === "toolbar" ? "wrap" : "nowrap",
        }}>
        {section.children.map((c, i) => child(c, i))}
      </div>
    );
  }

  return (
    <div
      ref={ref}
      data-node-id={sectionId} data-node-kind="section" data-orient={orient}
      data-parent-id={parent?.id} data-index={parent?.index} data-parent-orient={parent?.orient}
      style={{
        display: "flex", flexDirection: "column", position: "relative", boxSizing: "border-box",
        ...flexStyle(parent, live?.flex ?? section.flex ?? 1, width),
        background: BG[section.background ?? "default"], border: section.border ? "1px solid var(--fnd-border)" : undefined, borderRadius: 3,
        padding: section.padding ?? 0, boxShadow: section.elevation ? SHADOW[section.elevation] : undefined,
        overflow: section.scroll ? "auto" : undefined,
        height: live?.height ?? section.height ?? undefined,
        minWidth: section.minWidth ?? 0, maxWidth: section.maxWidth,
      }}
    >
      {section.showHeader && (section.title || section.description) && (
        <div className="flex items-center gap-2 mb-2 pb-1 border-b fnd-border" style={{ flexShrink: 0 }}>
          {section.collapsible && (
            <button className="fnd-btn fnd-btn-minimal" title={collapsed ? "Expand" : "Collapse"} aria-expanded={!collapsed} style={{ height: 18, padding: "0 2px" }} onClick={e => { e.stopPropagation(); setCollapsed(sectionId, !collapsed); }}>
              <Icon.Chevron size={10} dir={collapsed ? "right" : "down"}/>
            </button>
          )}
          <div className="text-xs font-semibold truncate" title={section.title}>{section.title}</div>
          {section.description && <div className="text-xs fnd-text-muted truncate" title={section.description}>{section.description}</div>}
        </div>
      )}
      {collapsed ? <div className="text-[11px] fnd-text-dim">Collapsed</div> : body}
    </div>
  );
});

export function SectionRenderer({ sectionId, isBuilder }: { sectionId: string; isBuilder: boolean }) {
  return <SectionView sectionId={sectionId} isBuilder={isBuilder}/>;
}
