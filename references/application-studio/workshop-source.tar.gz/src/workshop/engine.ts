import type { ModuleDef, VariableDef, EventAction, TransformationStep } from "./types";
import type { Ontology, AnyObj } from "./ontology";
import { getObjects, runFunction, evaluateObjectSet, defaultOntologyMeta, type OntologyMeta } from "./ontologyMeta";
import { metrics } from "./runtimeStores";

// Variable value store
export type VarValues = Record<string, unknown>;

/** All variables a variable reads from (used for topo sort + lineage graph). */
export function variableDeps(v: VariableDef): string[] {
  const out = new Set<string>(v.dependsOn ?? []);
  if (v.inputVarId) out.add(v.inputVarId);
  for (const step of v.objectSet?.steps ?? []) {
    if (step.op === "where") { for (const c of step.clauses) if (c.varId) out.add(c.varId); }
    else if (step.op === "union" || step.op === "intersect" || step.op === "subtract") out.add(step.otherVarId);
  }
  for (const t of v.transformations ?? []) {
    const a = t.args?.varId;
    if (typeof a === "string") out.add(a);
  }
  return [...out];
}

interface CacheEntry { def: VariableDef; ontology: Ontology; meta: OntologyMeta; version: number; base: unknown; deps: unknown[]; result: unknown }
/** Memoization cache: a variable is recomputed only when its definition, base value, ontology or any dependency changed (by identity). */
export class EvalCache {
  entries = new Map<string, CacheEntry>();
  topo: { vars: VariableDef[]; order: string[] } | null = null;
}

/** Compute all variable values from current state + ontology. Incremental when `cache` is supplied. */
export function computeVariables(
  mod: ModuleDef, ontology: Ontology, baseValues: VarValues, dataVersion: number,
  meta: OntologyMeta = defaultOntologyMeta(), cache?: EvalCache,
): VarValues {
  const t0 = performance.now();
  const out: VarValues = { ...baseValues };
  const resolveObjectSet = (sourceType?: string): AnyObj[] => getObjects(ontology, sourceType) as unknown as AnyObj[];

  const varsById = new Map(mod.variables.map(v => [v.id, v]));
  let order: string[];
  if (cache?.topo && cache.topo.vars === mod.variables) order = cache.topo.order;
  else { order = topoSort(mod.variables); if (cache) cache.topo = { vars: mod.variables, order }; }

  for (const vId of order) {
    const vdef = varsById.get(vId);
    if (!vdef) continue;
    const deps = variableDeps(vdef).map(d => out[d]);
    const base = baseValues[vId];

    const hit = cache?.entries.get(vId);
    if (hit && hit.def === vdef && hit.ontology === ontology && hit.meta === meta && hit.version === dataVersion && Object.is(hit.base, base)
      && hit.deps.length === deps.length && hit.deps.every((d, i) => Object.is(d, deps[i]))) {
      out[vId] = hit.result;
      continue;
    }

    const s = performance.now();
    let result: unknown;
    try {
      if (vdef.definitionKind === "objectSetDefinition") {
        result = vdef.objectSet ? (evaluateObjectSet(vdef.objectSet, ontology, meta, out) as unknown as AnyObj[]) : resolveObjectSet(vdef.sourceObjectType);
      } else if (vdef.definitionKind === "function") {
        result = runFunction(vdef.functionApiName, vdef.inputVarId ? out[vdef.inputVarId] : null, ontology);
      } else {
        result = evalVariable(vdef, out, mod, ontology, resolveObjectSet);
      }
    } catch (e) {
      result = { __error: (e as Error).message };
    }
    out[vId] = result;
    metrics.recordVariable(vId, performance.now() - s);
    cache?.entries.set(vId, { def: vdef, ontology, meta, version: dataVersion, base, deps, result });
  }
  metrics.evalPasses += 1;
  metrics.lastEvalMs = performance.now() - t0;
  return out;
}

function topoSort(vars: VariableDef[]): string[] {
  const map = new Map(vars.map(v => [v.id, v]));
  const visited = new Set<string>();
  const result: string[] = [];
  const visit = (id: string, stack: Set<string>) => {
    if (visited.has(id)) return;
    if (stack.has(id)) return; // cycle; break
    stack.add(id);
    const v = map.get(id);
    if (v) for (const d of variableDeps(v)) visit(d, stack);
    stack.delete(id);
    visited.add(id);
    result.push(id);
  };
  for (const v of vars) visit(v.id, new Set());
  return result;
}

function evalVariable(
  vdef: VariableDef,
  values: VarValues,
  mod: ModuleDef,
  ontology: Ontology,
  resolveObjectSet: (sourceType?: string) => AnyObj[],
): unknown {
  switch (vdef.definitionKind) {
    case "static":
      // if present in base values, use that, else default to staticValue
      return values[vdef.id] !== undefined ? values[vdef.id] : vdef.staticValue;
    case "objectSetDefinition":
      return resolveObjectSet(vdef.sourceObjectType);
    case "widgetOutput":
      // widget outputs are set via events; read as-is
      return values[vdef.id] !== undefined ? values[vdef.id] : (vdef.staticValue ?? null);
    case "variableTransformation":
    case "objectSetAggregation": {
      let acc: unknown = vdef.inputVarId ? values[vdef.inputVarId] : null;
      for (const step of (vdef.transformations ?? [])) {
        acc = applyTransform(acc, step, values, mod, ontology);
      }
      return acc;
    }
    case "function":
    case "objectProperty":
    case "sqlQuery":
      return values[vdef.id] ?? null;
  }
}

function applyTransform(
  input: unknown,
  step: TransformationStep,
  values: VarValues,
  mod: ModuleDef,
  ontology: Ontology,
): unknown {
  void mod; void ontology;
  switch (step.op) {
    case "cardinality":
      return Array.isArray(input) ? input.length : (input ? 1 : 0);
    case "objectProperty": {
      const prop = (step.args?.prop as string) ?? "id";
      if (input && typeof input === "object") {
        return (input as Record<string, unknown>)[prop] ?? null;
      }
      return null;
    }
    case "isEmpty":
      return Array.isArray(input) ? input.length === 0 : !input;
    case "isNotEmpty":
      return Array.isArray(input) ? input.length > 0 : !!input;
    case "ifElse": {
      const threshold = (step.args?.threshold as number) ?? 0;
      return (typeof input === "number" ? input : 0) > threshold;
    }
    case "cast":
      return String(input);
    case "concat":
      return `${input ?? ""}${(step.args?.suffix as string) ?? ""}`;
    case "add": return (Number(input) || 0) + ((step.args?.by as number) ?? 0);
    case "subtract": return (Number(input) || 0) - ((step.args?.by as number) ?? 0);
    case "multiply": return (Number(input) || 0) * ((step.args?.by as number) ?? 1);
    case "divide": {
      const d = (step.args?.by as number) ?? 1;
      return d === 0 ? 0 : (Number(input) || 0) / d;
    }
    case "filterStatus": {
      const varId = step.args?.varId as string;
      const sel = (values[varId] as string[]) ?? [];
      if (!Array.isArray(input)) return input;
      if (sel.length === 0) return input;
      return (input as AnyObj[]).filter(o => "status" in o && sel.includes((o as { status: string }).status));
    }
    case "filterPriority": {
      const varId = step.args?.varId as string;
      const sel = (values[varId] as string[]) ?? [];
      if (!Array.isArray(input)) return input;
      if (sel.length === 0) return input;
      return (input as AnyObj[]).filter(o => "priority" in o && sel.includes((o as { priority: string }).priority));
    }
    case "filterOwner": {
      const varId = step.args?.varId as string;
      const q = ((values[varId] as string) ?? "").trim().toLowerCase();
      if (!Array.isArray(input)) return input;
      if (!q) return input;
      return (input as AnyObj[]).filter(o => "owner" in o && String((o as { owner: string }).owner).toLowerCase().includes(q));
    }
    case "filterSearch": {
      const varId = step.args?.varId as string;
      const q = ((values[varId] as string) ?? "").trim().toLowerCase();
      if (!Array.isArray(input)) return input;
      if (!q) return input;
      return (input as AnyObj[]).filter(o => {
        return Object.values(o).some(v => typeof v === "string" && v.toLowerCase().includes(q));
      });
    }
    case "aggregate": {
      const by = step.args?.by as string;
      if (!Array.isArray(input)) return 0;
      const arr = input as AnyObj[];
      if (by === "status" || by === "priority") {
        const buckets: Record<string, number> = {};
        for (const o of arr) {
          const k = String((o as unknown as Record<string, unknown>)[by] ?? "—");
          buckets[k] = (buckets[k] || 0) + 1;
        }
        return buckets;
      }
      if (by === "avgAvailability") {
        if (!arr.length) return 0;
        const vals = arr.map(o => Number((o as unknown as Record<string, unknown>).availability) || 0);
        return Math.round((vals.reduce((a, b) => a + b, 0) / vals.length) * 10) / 10;
      }
      if (by === "sumRevenueImpact") {
        return arr.reduce((a, o) => a + (Number((o as unknown as Record<string, unknown>).revenueImpact) || 0), 0);
      }
      if (by === "countOffline") return arr.filter(o => (o as unknown as Record<string, unknown>).status === "Offline").length;
      if (by === "countWarning") return arr.filter(o => (o as unknown as Record<string, unknown>).status === "Warning").length;
      if (by === "countActive") return arr.filter(o => (o as unknown as Record<string, unknown>).status === "Active").length;
      return 0;
    }
  }
}

// Event application → mutate values + possibly module layout state
export interface EventContext {
  values: VarValues;
  setValues: (updater: (prev: VarValues) => VarValues) => void;
  module: ModuleDef;
  // UI setters
  switchPage: (pageId: string) => void;
  openOverlay: (id: string) => void;
  closeOverlay: (id: string) => void;
  toggleTheme: () => void;
  refreshData: () => void;
  runAction: (actionId: string) => void;
  setSectionCollapsed: (sectionId: string, collapsed: boolean) => void;
  setTabIndex: (sectionId: string, idx: number) => void;
}

export function applyEventAction(action: EventAction, ctx: EventContext, triggerValue?: unknown) {
  switch (action.kind) {
    case "setVariable": {
      let val: unknown = action.valueExpr;
      // very simple expression evaluator
      if (action.valueExpr === "true") val = true;
      else if (action.valueExpr === "false") val = false;
      else if (action.valueExpr === "null") val = null;
      else if (action.valueExpr === "triggerValue") val = triggerValue;
      else if (/^-?\d+(\.\d+)?$/.test(action.valueExpr)) val = Number(action.valueExpr);
      else if (action.valueExpr.startsWith("@")) val = ctx.values[action.valueExpr.slice(1)];
      else val = action.valueExpr;
      ctx.setValues(prev => ({ ...prev, [action.variableId]: val }));
      break;
    }
    case "resetVariable": {
      const v = ctx.module.variables.find(x => x.id === action.variableId);
      ctx.setValues(prev => ({ ...prev, [action.variableId]: v?.staticValue ?? null }));
      break;
    }
    case "recomputeVariable":
      // Trigger recompute via refresh
      ctx.refreshData();
      break;
    case "openOverlay": {
      ctx.openOverlay(action.overlayId);
      // also set open variable if present
      const o = ctx.module.overlays.find(x => x.id === action.overlayId);
      if (o?.openVariableId) ctx.setValues(prev => ({ ...prev, [o.openVariableId!]: true }));
      break;
    }
    case "closeOverlay": {
      ctx.closeOverlay(action.overlayId);
      const o = ctx.module.overlays.find(x => x.id === action.overlayId);
      if (o?.openVariableId) ctx.setValues(prev => ({ ...prev, [o.openVariableId!]: false }));
      break;
    }
    case "expandSection":
      ctx.setSectionCollapsed(action.sectionId, false);
      break;
    case "collapseSection":
      ctx.setSectionCollapsed(action.sectionId, true);
      break;
    case "toggleSection":
      ctx.setSectionCollapsed(action.sectionId, "toggle" as unknown as boolean);
      break;
    case "switchPage":
      ctx.switchPage(action.pageId);
      ctx.setValues(prev => ({ ...prev, currentPage: action.pageId }));
      break;
    case "switchTab":
      ctx.setTabIndex(action.sectionId, action.tabIndex);
      break;
    case "openModule":
    case "openObjectView":
    case "openUrl":
      // simulate
      break;
    case "refreshData":
      ctx.refreshData();
      break;
    case "enableAutoRefresh":
      ctx.setValues(prev => ({ ...prev, autoRefresh: true }));
      break;
    case "disableAutoRefresh":
      ctx.setValues(prev => ({ ...prev, autoRefresh: false }));
      break;
    case "toggleTheme":
      ctx.toggleTheme();
      break;
    case "runAction":
      ctx.runAction(action.actionId);
      break;
    case "exportData":
      // noop (would export widget data)
      break;
  }
}
