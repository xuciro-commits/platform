// ═════════════════════════════════════════════════════════════════════════
// ONTOLOGY METADATA MODEL
// Mirrors Palantir Foundry's actual Ontology data model as configured in
// Ontology Manager and consumed through the Ontology SDK (OSDK):
//
//   Object Type   — apiName, rid, primary key, title key, status, properties,
//                    interface implementations, backing datasource.
//   Property Type — typed (Ontology base type taxonomy), visibility,
//                    optionally backed by a Shared Property Type, optionally
//                    *derived* via link-type traversal + aggregation
//                    (Object & Link Types → Properties → Derived properties).
//   Link Type     — backed either by a foreign key on one side
//                    ("Object type foreign keys") or by a join table dataset
//                    ("Join table dataset", required for MANY_TO_MANY).
//   Interface     — a set of Shared Property Types; Object Types *implement*
//                    an interface via an explicit property mapping.
//   Action Type   — Parameters (typed, with per-parameter Validation) →
//                    Rules ("Logic" tab: Add/Modify/Delete object, Add/Remove
//                    link) → Submission Criteria ("Security & Submission
//                    Criteria" tab).
//   Function      — an Ontology-backed Function/Query: typed inputs/output,
//                    runnable against the live Ontology, usable from Actions
//                    and Workshop Variables.
//
// On top of this, Object Sets are modelled the same way the OSDK models
// them: a base Object Type, a chain of `.where(...)` / `.pivotTo(...)`
// steps, and set algebra (`union` / `intersect` / `subtract`) against other
// Object Sets. See `ObjectSetDef` + `evaluateObjectSet` below.
// ═════════════════════════════════════════════════════════════════════════
import type { Ontology } from "./ontology";

// ─── Identifiers ────────────────────────────────────────────────────────────
let ridCounter = 0;
export function rid(kind: string): string {
  ridCounter += 1;
  return `ri.ontology.main.${kind}.${ridCounter.toString(36).padStart(6, "0")}`;
}

export type EntityStatus = "ACTIVE" | "EXPERIMENTAL" | "DEPRECATED";

// ─── Ontology base type taxonomy (matches Foundry's Property Type types) ──
export type BaseType =
  | "Boolean" | "Byte" | "Short" | "Integer" | "Long" | "Float" | "Double" | "Decimal"
  | "String" | "Date" | "Timestamp" | "Array" | "Struct"
  | "GeoPoint" | "GeoShape" | "Marking" | "MediaReference" | "TimeSeries" | "Vector" | "Attachment" | "CipherText";

export const BASE_TYPES: BaseType[] = [
  "Boolean", "Byte", "Short", "Integer", "Long", "Float", "Double", "Decimal",
  "String", "Date", "Timestamp", "Array", "Struct",
  "GeoPoint", "GeoShape", "Marking", "MediaReference", "TimeSeries", "Vector", "Attachment", "CipherText",
];

export type AggregationKind = "count" | "avg" | "sum" | "min" | "max" | "approxCardinality" | "exactCardinality" | "collectList";
export const AGGREGATIONS: Array<{ v: AggregationKind; label: string }> = [
  { v: "count", label: "Count" }, { v: "avg", label: "Average" }, { v: "sum", label: "Sum" },
  { v: "min", label: "Minimum" }, { v: "max", label: "Maximum" },
  { v: "approxCardinality", label: "Approximate cardinality" }, { v: "exactCardinality", label: "Exact cardinality" },
  { v: "collectList", label: "Collect list" },
];

/** A property computed at read time by traversing 1-3 link types and aggregating a property on the final object type. */
export interface PropertyDerivation {
  linkTypeApiNames: string[]; // traversal path, 1-3 hops
  aggregation: AggregationKind;
  property?: string; // property on the final linked object type (omitted for "count")
}

export interface PropertyTypeDef {
  apiName: string;
  rid: string;
  displayName: string;
  description?: string;
  baseType: BaseType;
  array?: boolean;
  nullable?: boolean;
  visibility: "PROMINENT" | "NORMAL" | "HIDDEN";
  searchable?: boolean;
  sortable?: boolean;
  unit?: string;
  valueFormatting?: "none" | "number" | "percent" | "currency" | "date" | "datetime" | "unit";
  /** This property implements a Shared Property Type (used by Interfaces). */
  sharedPropertyType?: string;
  /** Derived properties: configured via Object & Link Types → Properties → Derived properties. */
  derivation?: PropertyDerivation;
}
// Backward-compat alias used throughout the widget layer.
export type PropertyDef = PropertyTypeDef;

export interface InterfaceImplementation {
  interfaceApiName: string;
  /** Maps this object type's local property apiName to each shared property apiName it implements. */
  propertyMapping: Record<string, string>;
}

export interface DatasourceDef {
  rid: string;
  type: "dataset" | "stream" | "media-set";
  path: string;
  syncMode: "snapshot" | "incremental";
}

export interface ObjectTypeDef {
  apiName: string;
  rid: string;
  apiNamespace: string;
  displayName: string;
  pluralDisplayName: string;
  description: string;
  icon: string;
  color: string;
  status: EntityStatus;
  /** Composite primary keys are supported by the Ontology; most types here use a single key. */
  primaryKeyPropertyApiNames: string[];
  titlePropertyApiName: string;
  properties: PropertyTypeDef[];
  implementsInterfaces: InterfaceImplementation[];
  datasource: DatasourceDef;
  groups: string[];
}

export type LinkCardinality = "ONE_TO_ONE" | "ONE_TO_MANY" | "MANY_TO_ONE" | "MANY_TO_MANY";

export type LinkDefinition =
  | { type: "foreignKey"; foreignKeyObjectType: string; foreignKeyProperty: string; primaryKeyObjectType: string }
  | { type: "joinTable"; datasetRid: string; objectTypeAProperty: string; objectTypeBProperty: string };

export interface LinkTypeDef {
  apiName: string;
  rid: string;
  displayName: string;       // label when traversing objectTypeA -> objectTypeB
  reverseDisplayName: string; // label when traversing objectTypeB -> objectTypeA
  objectTypeA: string;
  objectTypeB: string;
  cardinality: LinkCardinality;
  definition: LinkDefinition;
  status: EntityStatus;
}
// Backward-compat field accessors used by UI code written against from/to.
export type Cardinality = LinkCardinality;

export interface SharedPropertyTypeDef {
  apiName: string;
  rid: string;
  displayName: string;
  baseType: BaseType;
  description: string;
}
export type SharedPropertyDef = SharedPropertyTypeDef;

export interface InterfaceDef {
  apiName: string;
  rid: string;
  displayName: string;
  description: string;
  extendsInterfaces: string[];
  sharedPropertyApiNames: string[];
}

// ─── Action Types ───────────────────────────────────────────────────────────
export type ActionParamType = "String" | "Integer" | "Double" | "Boolean" | "Date" | "Timestamp" | "ObjectReference" | "ObjectSetReference" | "InterfaceReference" | "Attachment";

export interface ParameterValidation {
  required: boolean;
  allowedValues?: string[];   // "Allowed values" constraint (renders as dropdown)
  range?: { min?: number; max?: number };
  minLength?: number;
  regex?: string;
  objectTypeApiName?: string; // for ObjectReference / ObjectSetReference
  interfaceApiName?: string;  // for InterfaceReference
}

export interface ActionParameterDef {
  apiName: string;
  displayName: string;
  description?: string;
  type: ActionParamType;
  validation: ParameterValidation;
  /** Prefill expression, e.g. "object.status" or "currentUser()". */
  defaultFrom?: string;
}

/** The "Logic" tab: rules describing how parameters translate into Ontology edits. */
export type ActionRuleDef =
  | { kind: "addObjectRule"; objectTypeApiName: string; propertyMappings: Record<string, string> }
  | { kind: "modifyObjectRule"; objectParameterApiName: string; propertyMappings: Record<string, string> }
  | { kind: "deleteObjectRule"; objectParameterApiName: string }
  | { kind: "addLinkRule"; linkTypeApiName: string; objectAParameterApiName: string; objectBParameterApiName: string }
  | { kind: "removeLinkRule"; linkTypeApiName: string; objectAParameterApiName: string; objectBParameterApiName: string };

export type ConditionOperator = "is" | "isNot" | "isOneOf" | "isNotOneOf" | "isEmpty" | "isNotEmpty" | "isGreaterThanOrEqualTo" | "isLessThanOrEqualTo";
export const CONDITION_OPERATORS: Array<{ v: ConditionOperator; label: string }> = [
  { v: "is", label: "is" }, { v: "isNot", label: "is not" },
  { v: "isOneOf", label: "is one of" }, { v: "isNotOneOf", label: "is not one of" },
  { v: "isEmpty", label: "is empty" }, { v: "isNotEmpty", label: "is not empty" },
  { v: "isGreaterThanOrEqualTo", label: "is ≥" }, { v: "isLessThanOrEqualTo", label: "is ≤" },
];
// legacy short codes kept for a few call sites
export type CriterionOp = ConditionOperator;

export interface ConditionExpr { left: string; op: ConditionOperator; right?: unknown }

/** "Security & Submission Criteria" tab: a condition template gating submission, with a failure message. */
export interface SubmissionCriterion {
  id: string;
  conditionType: "parameter" | "object";
  when?: ConditionExpr;     // optional guard: only evaluate `condition` if this holds
  condition: ConditionExpr;
  failureMessage: string;
}

export interface ActionTypeDef {
  apiName: string;
  rid: string;
  displayName: string;
  description: string;
  status: EntityStatus;
  parameters: ActionParameterDef[];
  rules: ActionRuleDef[];
  submissionCriteria: SubmissionCriterion[];
  notifications: string[]; // webhook / email side effects (Notifications tab)
  submissionGroups: string[]; // who can submit (Security tab)
}

export interface FunctionDef {
  apiName: string;
  rid: string;
  displayName: string;
  description: string;
  inputs: Array<{ name: string; type: string }>;
  output: string;
  language: "TypeScript" | "Python" | "Java";
  version: string;
  source: string;
  isEditFunction?: boolean; // can be invoked as part of an Action's Logic
}

export interface OntologyMeta {
  apiNamespace: string;
  objectTypes: ObjectTypeDef[];
  linkTypes: LinkTypeDef[];
  actionTypes: ActionTypeDef[];
  functions: FunctionDef[];
  interfaces: InterfaceDef[];
  sharedProperties: SharedPropertyTypeDef[];
}

export type Obj = Record<string, unknown>;

// ═════════════════════════════════════════════════════════════════════════
// Object storage access
// ═════════════════════════════════════════════════════════════════════════
const TYPE_KEY: Record<string, "assets" | "sensors" | "alerts" | "workOrders" | "operators" | "locations"> = {
  Asset: "assets", Sensor: "sensors", Alert: "alerts", WorkOrder: "workOrders", Operator: "operators", Location: "locations",
};

export function getObjects(ont: Ontology, type: string | undefined): Obj[] {
  if (!type) return [];
  const key = TYPE_KEY[type];
  if (key) return ont[key] as unknown as Obj[];
  return ont.extra[type] ?? [];
}

export function setObjects(ont: Ontology, type: string, objs: Obj[]): Ontology {
  const key = TYPE_KEY[type];
  if (key) return { ...ont, [key]: objs } as Ontology;
  return { ...ont, extra: { ...ont.extra, [type]: objs } };
}

export function objectTypeOf(meta: OntologyMeta, apiName: string | undefined): ObjectTypeDef | undefined {
  return meta.objectTypes.find(o => o.apiName === apiName);
}
export function primaryKeyOf(ot: ObjectTypeDef | undefined): string { return ot?.primaryKeyPropertyApiNames[0] ?? "id"; }
export function propertyOf(meta: OntologyMeta, type: string | undefined, prop: string): PropertyTypeDef | undefined {
  return objectTypeOf(meta, type)?.properties.find(p => p.apiName === prop);
}

export function titleOf(meta: OntologyMeta, obj: Obj | null | undefined): string {
  if (!obj) return "—";
  const ot = objectTypeOf(meta, obj.__type as string);
  const t = ot ? obj[ot.titlePropertyApiName] : obj.name ?? obj.title;
  return String(t ?? obj.id ?? "—");
}

/** All link types touching `type`, oriented so `label`/`target` read naturally from `type`'s perspective. */
export function linkTypesFor(meta: OntologyMeta, type: string | undefined) {
  const out: Array<{ link: LinkTypeDef; target: string; label: string; many: boolean }> = [];
  if (!type) return out;
  for (const l of meta.linkTypes) {
    if (l.objectTypeA === type) out.push({ link: l, target: l.objectTypeB, label: l.displayName, many: l.cardinality === "ONE_TO_MANY" || l.cardinality === "MANY_TO_MANY" });
    if (l.objectTypeB === type && l.objectTypeA !== type) out.push({ link: l, target: l.objectTypeA, label: l.reverseDisplayName, many: l.cardinality === "MANY_TO_ONE" || l.cardinality === "MANY_TO_MANY" });
  }
  return out;
}

/** OSDK `.pivotTo(linkApiName)` — traverse a link type from a set of source objects. */
export function pivotTo(ont: Ontology, meta: OntologyMeta, linkApi: string, sources: Obj[]): Obj[] {
  const l = meta.linkTypes.find(x => x.apiName === linkApi);
  if (!l || sources.length === 0) return [];
  const sourceType = String(sources[0].__type ?? "");
  const forward = sourceType === l.objectTypeA;
  const targetType = forward ? l.objectTypeB : l.objectTypeA;
  const targetOt = objectTypeOf(meta, targetType);
  const sourceOt = objectTypeOf(meta, sourceType);
  const tpk = primaryKeyOf(targetOt), spk = primaryKeyOf(sourceOt);
  const targets = getObjects(ont, targetType);

  if (l.definition.type === "joinTable") {
    const { objectTypeAProperty, objectTypeBProperty } = l.definition;
    const srcProp = forward ? objectTypeAProperty : objectTypeBProperty;
    const dstProp = forward ? objectTypeBProperty : objectTypeAProperty;
    void srcProp; // join-table rows aren't separately materialized in this mock; fall back to FK-equivalent matching
    const keys = new Set(sources.map(s => s[spk]));
    return targets.filter(t => keys.has(t[dstProp] ?? t[spk]));
  }
  const fkOnSource = (forward && l.definition.foreignKeyObjectType === l.objectTypeA) || (!forward && l.definition.foreignKeyObjectType === l.objectTypeB);
  if (fkOnSource) {
    const keys = new Set(sources.map(s => s[l.definition.type === "foreignKey" ? l.definition.foreignKeyProperty : ""]));
    return targets.filter(t => keys.has(t[tpk]));
  }
  const keys = new Set(sources.map(s => s[spk]));
  return targets.filter(t => keys.has(t[l.definition.type === "foreignKey" ? l.definition.foreignKeyProperty : ""]));
}
/** @deprecated use pivotTo — kept for readability at a few call sites. */
export const traverseLink = pivotTo;

function aggregateValues(objs: Obj[], kind: AggregationKind, prop?: string): unknown {
  if (kind === "count") return objs.length;
  const vals = prop ? objs.map(o => o[prop]) : [];
  const nums = vals.map(v => Number(v)).filter(n => Number.isFinite(n));
  switch (kind) {
    case "avg": return nums.length ? nums.reduce((a, b) => a + b, 0) / nums.length : 0;
    case "sum": return nums.reduce((a, b) => a + b, 0);
    case "min": return nums.length ? Math.min(...nums) : 0;
    case "max": return nums.length ? Math.max(...nums) : 0;
    case "approxCardinality": case "exactCardinality": return new Set(vals.map(String)).size;
    case "collectList": return vals;
    default: return null;
  }
}

/** Compute a derived property for a single object by walking its link path and aggregating. */
export function resolveDerivedProperty(ont: Ontology, meta: OntologyMeta, obj: Obj, def: PropertyTypeDef): unknown {
  if (!def.derivation) return obj[def.apiName];
  let frontier = [obj];
  for (const linkApi of def.derivation.linkTypeApiNames) frontier = pivotTo(ont, meta, linkApi, frontier);
  return aggregateValues(frontier, def.derivation.aggregation, def.derivation.property);
}

/** Read a property value, resolving derived properties transparently. */
export function getProperty(ont: Ontology, meta: OntologyMeta, obj: Obj, propApiName: string): unknown {
  const def = propertyOf(meta, String(obj.__type), propApiName);
  if (def?.derivation) return resolveDerivedProperty(ont, meta, obj, def);
  return obj[propApiName];
}

export function formatPropertyValue(def: PropertyTypeDef | undefined, v: unknown): string {
  if (v == null || v === "") return "—";
  if (!def) return Array.isArray(v) ? v.join(", ") : String(v);
  switch (def.baseType) {
    case "Date":
      return new Date(String(v)).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
    case "Timestamp":
      return new Date(String(v)).toLocaleString(undefined, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
    case "Boolean":
      return v ? "True" : "False";
    case "Array":
      return Array.isArray(v) ? v.join(", ") : String(v);
    case "Byte": case "Short": case "Integer": case "Long": case "Float": case "Double": case "Decimal": {
      const n = Number(v);
      if (def.valueFormatting === "currency") return `$${n >= 1e6 ? (n / 1e6).toFixed(2) + "M" : n >= 1e3 ? (n / 1e3).toFixed(1) + "K" : n.toLocaleString()}`;
      if (def.valueFormatting === "percent") return `${n.toFixed(1)}%`;
      return `${n.toLocaleString()}${def.unit ? " " + def.unit : ""}`;
    }
    default:
      return String(v);
  }
}

// ═════════════════════════════════════════════════════════════════════════
// Object Set — mirrors the OSDK fluent chain: Objects(Type).where(...).pivotTo(...)
// combined with set algebra (union / intersect / subtract) against other
// Workshop variables holding Object Sets.
// ═════════════════════════════════════════════════════════════════════════
export type FilterOp = "is" | "isNot" | "isOneOf" | "isNotOneOf" | "contains" | "isGreaterThanOrEqualTo" | "isLessThanOrEqualTo" | "isEmpty" | "isNotEmpty" | "fullTextSearch";
export const FILTER_OPS: Array<{ v: FilterOp; label: string }> = [
  { v: "is", label: "is" }, { v: "isNot", label: "is not" },
  { v: "isOneOf", label: "is one of" }, { v: "isNotOneOf", label: "is not one of" },
  { v: "contains", label: "contains" },
  { v: "isGreaterThanOrEqualTo", label: "≥" }, { v: "isLessThanOrEqualTo", label: "≤" },
  { v: "isEmpty", label: "is empty" }, { v: "isNotEmpty", label: "is not empty" },
];

export interface WhereClause {
  id: string;
  property: string; // "*" = full text search (fullTextSearch op)
  op: FilterOp;
  value?: unknown;
  varId?: string; // bind right-hand side to a Workshop variable
}

export type ObjectSetStep =
  | { op: "where"; clauses: WhereClause[] }
  | { op: "pivotTo"; linkTypeApiName: string }
  | { op: "union"; otherVarId: string }
  | { op: "intersect"; otherVarId: string }
  | { op: "subtract"; otherVarId: string };

/** The full definition of a Workshop "Object Set" variable: `Objects(objectType)` + a chain of steps. */
export interface ObjectSetDef {
  objectType: string;
  steps: ObjectSetStep[];
}

function clauseEmpty(v: unknown) { return v == null || v === "" || (Array.isArray(v) && v.length === 0); }

export function applyWhereClauses(objs: Obj[], clauses: WhereClause[], values: Record<string, unknown>): Obj[] {
  let out = objs;
  for (const c of clauses) {
    const val = c.varId ? values[c.varId] : c.value;
    if (c.op !== "isEmpty" && c.op !== "isNotEmpty" && clauseEmpty(val)) continue; // unbound filter = pass-through (matches optional Workshop filter widgets)
    out = out.filter(o => {
      const pv = c.property === "*" ? null : o[c.property];
      switch (c.op) {
        case "is": return Array.isArray(val) ? val.map(String).includes(String(pv)) : String(pv) === String(val);
        case "isNot": return String(pv) !== String(val);
        case "isOneOf": return Array.isArray(val) ? val.map(String).includes(String(pv)) : String(pv) === String(val);
        case "isNotOneOf": return Array.isArray(val) ? !val.map(String).includes(String(pv)) : String(pv) !== String(val);
        case "contains": return String(pv ?? "").toLowerCase().includes(String(val).toLowerCase());
        case "isGreaterThanOrEqualTo": return Number(pv) >= Number(val);
        case "isLessThanOrEqualTo": return Number(pv) <= Number(val);
        case "isEmpty": return pv == null || pv === "";
        case "isNotEmpty": return !(pv == null || pv === "");
        case "fullTextSearch": {
          const q = String(val).toLowerCase();
          return Object.values(o).some(x => typeof x === "string" && x.toLowerCase().includes(q));
        }
      }
    });
  }
  return out;
}

/** Evaluate a Workshop Object Set variable definition against the live Ontology + current variable values. */
export function evaluateObjectSet(def: ObjectSetDef, ont: Ontology, meta: OntologyMeta, values: Record<string, unknown>): Obj[] {
  let set = getObjects(ont, def.objectType);
  for (const step of def.steps) {
    if (step.op === "where") set = applyWhereClauses(set, step.clauses, values);
    else if (step.op === "pivotTo") set = pivotTo(ont, meta, step.linkTypeApiName, set);
    else {
      const other = values[step.otherVarId];
      const otherArr = Array.isArray(other) ? other as Obj[] : [];
      const otherKeys = new Set(otherArr.map(o => o.id));
      if (step.op === "union") { const seen = new Set(set.map(o => o.id)); set = [...set, ...otherArr.filter(o => !seen.has(o.id))]; }
      else if (step.op === "intersect") set = set.filter(o => otherKeys.has(o.id));
      else if (step.op === "subtract") set = set.filter(o => !otherKeys.has(o.id));
    }
  }
  return set;
}

// ═════════════════════════════════════════════════════════════════════════
// Functions (Ontology-backed Functions / Queries)
// ═════════════════════════════════════════════════════════════════════════
export function runFunction(apiName: string | undefined, input: unknown, ont: Ontology): unknown {
  const asArr = (x: unknown): Obj[] => Array.isArray(x) ? x as Obj[] : x ? [x as Obj] : [];
  switch (apiName) {
    case "predictFailureRisk": {
      const a = input as Obj | null;
      if (!a) return null;
      const p = Number(a.pressure) || 0, t = Number(a.temperature) || 0, av = Number(a.availability) || 100, al = Number(a.openAlerts) || 0;
      const risk = Math.min(0.99, Math.max(0.01, (p / 60) * 0.35 + (t / 100) * 0.25 + ((100 - av) / 30) * 0.25 + al * 0.08));
      return Math.round(risk * 1000) / 10;
    }
    case "revenueAtRisk":
      return asArr(input).filter(a => a.status !== "Active").reduce((s, a) => s + (Number(a.revenueImpact) || 0), 0);
    case "aggregateByStatus": {
      const out: Record<string, number> = {};
      for (const a of asArr(input)) { const k = String(a.status ?? "—"); out[k] = (out[k] || 0) + 1; }
      return out;
    }
    case "openWorkOrderCount": {
      const ids = new Set(asArr(input).map(a => a.id));
      return ont.workOrders.filter(w => ids.has(w.assetId) && w.status !== "Done").length;
    }
    default:
      return null;
  }
}
/** @deprecated alias kept for widget code written against "runFunction" vs. "runQuery" naming. */
export const runQuery = runFunction;

// ═════════════════════════════════════════════════════════════════════════
// Action execution — Parameters → Validation → Logic (Rules) →
// Security & Submission Criteria, exactly as laid out in Ontology Manager.
// ═════════════════════════════════════════════════════════════════════════
export interface ActionEdit { kind: "modify" | "create" | "delete" | "link" | "unlink"; objectType: string; objectId: string; before?: Obj; after?: Obj }
export interface ActionResult { ok: boolean; errors: string[]; ontology?: Ontology; edits: ActionEdit[] }

function findByPk(ont: Ontology, meta: OntologyMeta, type: string, pk: unknown): Obj | undefined {
  const ot = objectTypeOf(meta, type);
  const key = primaryKeyOf(ot);
  return getObjects(ont, type).find(o => o[key] === pk);
}

export function resolveExpr(expr: string, params: Record<string, unknown>, obj: Obj | undefined): unknown {
  const e = expr.trim();
  if (e.startsWith("param.")) return params[e.slice(6)];
  if (e.startsWith("object.")) return obj ? obj[e.slice(7)] : undefined;
  if (e === "now()") return new Date().toISOString();
  if (e === "currentUser()") return "Jane Smith";
  if (e === "true") return true;
  if (e === "false") return false;
  if (e === "null") return null;
  if (/^'.*'$/.test(e)) return e.slice(1, -1);
  if (/^-?\d+(\.\d+)?$/.test(e)) return Number(e);
  return e;
}

function isEmptyVal(v: unknown) { return v == null || v === "" || (Array.isArray(v) && v.length === 0); }

export function evalCondition(c: ConditionExpr, params: Record<string, unknown>, obj: Obj | undefined): boolean {
  const l = resolveExpr(c.left, params, obj);
  const r = c.right;
  switch (c.op) {
    case "is": return String(l) === String(r);
    case "isNot": return String(l) !== String(r);
    case "isOneOf": return Array.isArray(r) && r.map(String).includes(String(l));
    case "isNotOneOf": return !(Array.isArray(r) && r.map(String).includes(String(l)));
    case "isEmpty": return isEmptyVal(l);
    case "isNotEmpty": return !isEmptyVal(l);
    case "isGreaterThanOrEqualTo": return Number(l) >= Number(r);
    case "isLessThanOrEqualTo": return Number(l) <= Number(r);
  }
}

/** Primary object for an action — the first object-reference parameter. */
export function primaryObjectFor(at: ActionTypeDef, ont: Ontology, meta: OntologyMeta, params: Record<string, unknown>): Obj | undefined {
  const p = at.parameters.find(x => x.type === "ObjectReference" && x.validation.objectTypeApiName);
  if (!p) return undefined;
  return findByPk(ont, meta, p.validation.objectTypeApiName!, params[p.apiName]);
}

export function validateAction(at: ActionTypeDef, ont: Ontology, meta: OntologyMeta, params: Record<string, unknown>): { fieldErrors: Record<string, string>; criteriaErrors: string[] } {
  const fieldErrors: Record<string, string> = {};
  for (const p of at.parameters) {
    const v = params[p.apiName];
    const val = p.validation;
    if (val.required && isEmptyVal(v)) { fieldErrors[p.apiName] = "Required"; continue; }
    if (isEmptyVal(v)) continue;
    if (p.type === "ObjectReference" && val.objectTypeApiName && !findByPk(ont, meta, val.objectTypeApiName, v)) fieldErrors[p.apiName] = `No ${val.objectTypeApiName} with key "${String(v)}"`;
    if (val.allowedValues && val.allowedValues.length && !val.allowedValues.includes(String(v))) fieldErrors[p.apiName] = `Must be one of: ${val.allowedValues.join(", ")}`;
    if (val.range?.min !== undefined && Number(v) < val.range.min) fieldErrors[p.apiName] = `Must be ≥ ${val.range.min}`;
    if (val.range?.max !== undefined && Number(v) > val.range.max) fieldErrors[p.apiName] = `Must be ≤ ${val.range.max}`;
    if (val.minLength !== undefined && String(v).length < val.minLength) fieldErrors[p.apiName] = `At least ${val.minLength} characters`;
    if (val.regex) { try { if (!new RegExp(val.regex).test(String(v))) fieldErrors[p.apiName] = `Must match /${val.regex}/`; } catch { /* ignore invalid pattern */ } }
  }
  const obj = primaryObjectFor(at, ont, meta, params);
  const criteriaErrors: string[] = [];
  for (const sc of at.submissionCriteria) {
    if (sc.when && !evalCondition(sc.when, params, obj)) continue;
    if (!evalCondition(sc.condition, params, obj)) criteriaErrors.push(sc.failureMessage);
  }
  return { fieldErrors, criteriaErrors };
}

export function applyAction(ont: Ontology, meta: OntologyMeta, apiName: string, params: Record<string, unknown>): ActionResult {
  const at = meta.actionTypes.find(a => a.apiName === apiName);
  if (!at) return { ok: false, errors: [`Unknown action type "${apiName}"`], edits: [] };
  const v = validateAction(at, ont, meta, params);
  const errors = [...Object.entries(v.fieldErrors).map(([k, m]) => `${k}: ${m}`), ...v.criteriaErrors];
  if (errors.length) return { ok: false, errors, edits: [] };

  let next = ont;
  const edits: ActionEdit[] = [];
  for (const rule of at.rules) {
    if (rule.kind === "modifyObjectRule") {
      const p = at.parameters.find(x => x.apiName === rule.objectParameterApiName);
      const type = p?.validation.objectTypeApiName;
      if (!type) continue;
      const ot = objectTypeOf(meta, type);
      const pk = primaryKeyOf(ot);
      const before = findByPk(next, meta, type, params[rule.objectParameterApiName]);
      if (!before) continue;
      const patch: Obj = {};
      for (const [prop, expr] of Object.entries(rule.propertyMappings)) {
        if (ot?.primaryKeyPropertyApiNames.includes(prop)) continue; // primary keys cannot be modified by any action type
        const val = resolveExpr(expr, params, before);
        if (val !== undefined && val !== "") patch[prop] = val;
      }
      const after = { ...before, ...patch };
      next = setObjects(next, type, getObjects(next, type).map(o => o[pk] === before[pk] ? after : o));
      edits.push({ kind: "modify", objectType: type, objectId: String(before[pk]), before, after });
    } else if (rule.kind === "addObjectRule") {
      const ot = objectTypeOf(meta, rule.objectTypeApiName);
      const pk = primaryKeyOf(ot);
      const obj: Obj = { __type: rule.objectTypeApiName };
      const ctxObj = primaryObjectFor(at, next, meta, params);
      for (const [prop, expr] of Object.entries(rule.propertyMappings)) obj[prop] = resolveExpr(expr, params, ctxObj);
      if (!obj[pk]) obj[pk] = `${rule.objectTypeApiName.slice(0, 3).toUpperCase()}-${Date.now().toString(36).toUpperCase()}`;
      if (!obj.createdAt && ot?.properties.some(x => x.apiName === "createdAt")) obj.createdAt = new Date().toISOString();
      next = setObjects(next, rule.objectTypeApiName, [obj, ...getObjects(next, rule.objectTypeApiName)]);
      edits.push({ kind: "create", objectType: rule.objectTypeApiName, objectId: String(obj[pk]), after: obj });
    } else if (rule.kind === "deleteObjectRule") {
      const p = at.parameters.find(x => x.apiName === rule.objectParameterApiName);
      const type = p?.validation.objectTypeApiName;
      if (!type) continue;
      const ot = objectTypeOf(meta, type);
      const pk = primaryKeyOf(ot);
      const before = findByPk(next, meta, type, params[rule.objectParameterApiName]);
      if (!before) continue;
      next = setObjects(next, type, getObjects(next, type).filter(o => o[pk] !== before[pk]));
      edits.push({ kind: "delete", objectType: type, objectId: String(before[pk]), before });
    } else if (rule.kind === "addLinkRule" || rule.kind === "removeLinkRule") {
      const lt = meta.linkTypes.find(l => l.apiName === rule.linkTypeApiName);
      const pa = at.parameters.find(x => x.apiName === rule.objectAParameterApiName);
      const pb = at.parameters.find(x => x.apiName === rule.objectBParameterApiName);
      if (!lt || !pa?.validation.objectTypeApiName || !pb?.validation.objectTypeApiName || lt.definition.type !== "foreignKey") continue;
      const a = findByPk(next, meta, pa.validation.objectTypeApiName, params[pa.apiName]);
      const b = findByPk(next, meta, pb.validation.objectTypeApiName, params[pb.apiName]);
      if (!a || !b) continue;
      const fkHolder = lt.definition.foreignKeyObjectType === pa.validation.objectTypeApiName ? a : b;
      const other = fkHolder === a ? b : a;
      const otherOt = objectTypeOf(meta, String(other.__type));
      const before = { ...fkHolder };
      const after = { ...fkHolder, [lt.definition.foreignKeyProperty]: rule.kind === "addLinkRule" ? other[primaryKeyOf(otherOt)] : null };
      const fkType = String(fkHolder.__type);
      next = setObjects(next, fkType, getObjects(next, fkType).map(o => o === fkHolder ? after : o));
      edits.push({ kind: rule.kind === "addLinkRule" ? "link" : "unlink", objectType: fkType, objectId: String(before[primaryKeyOf(objectTypeOf(meta, fkType))]), before, after });
    }
  }
  return { ok: true, errors: [], ontology: next, edits };
}

// ═════════════════════════════════════════════════════════════════════════
// Default Ontology — industrial operations, modelled exactly as it would be
// authored in Ontology Manager.
// ═════════════════════════════════════════════════════════════════════════
const P = (apiName: string, displayName: string, baseType: BaseType, extra: Partial<PropertyTypeDef> = {}): PropertyTypeDef =>
  ({ apiName, rid: rid("property-type"), displayName, baseType, visibility: "NORMAL", searchable: baseType === "String", sortable: true, ...extra });

const param = (apiName: string, displayName: string, type: ActionParamType, validation: Partial<ParameterValidation> = {}, extra: Partial<ActionParameterDef> = {}): ActionParameterDef =>
  ({ apiName, displayName, type, validation: { required: false, ...validation }, ...extra });

const STATUSES = ["Active", "Warning", "Maintenance", "Offline"];
const PRIORITIES = ["High", "Medium", "Low"];
const OPERATOR_NAMES = ["Jane Smith", "Marcus Chen", "Priya Patel", "Diego Alvarez", "Yuki Tanaka", "Sarah Okafor", "Lars Nielsen", "Amina Hassan", "Tom Reilly", "Zara Khan"];

export function defaultOntologyMeta(): OntologyMeta {
  const ns = "com.foundry.operations";
  return {
    apiNamespace: ns,
    sharedProperties: [
      { apiName: "status", rid: rid("shared-property-type"), displayName: "Status", baseType: "String", description: "Operational lifecycle status shared across maintainable entities" },
      { apiName: "owner", rid: rid("shared-property-type"), displayName: "Owner", baseType: "String", description: "Accountable operator" },
      { apiName: "lastInspection", rid: rid("shared-property-type"), displayName: "Last inspection", baseType: "Timestamp", description: "Most recent inspection time" },
      { apiName: "geo", rid: rid("shared-property-type"), displayName: "Geo location", baseType: "GeoPoint", description: "WGS84 coordinate" },
    ],
    interfaces: [
      { apiName: "Maintainable", rid: rid("interface"), displayName: "Maintainable", description: "Any physical entity that can be inspected and maintained", extendsInterfaces: [], sharedPropertyApiNames: ["status", "lastInspection"] },
      { apiName: "Locatable", rid: rid("interface"), displayName: "Locatable", description: "Entities with a geographic position", extendsInterfaces: [], sharedPropertyApiNames: ["geo"] },
      { apiName: "Assignable", rid: rid("interface"), displayName: "Assignable", description: "Work that can be assigned to an operator", extendsInterfaces: [], sharedPropertyApiNames: ["owner", "status"] },
    ],
    objectTypes: [
      {
        apiName: "Asset", rid: rid("object-type"), apiNamespace: ns, displayName: "Asset", pluralDisplayName: "Assets", icon: "A", color: "#2b6cb0",
        description: "Physical equipment deployed at an operational site.", primaryKeyPropertyApiNames: ["id"], titlePropertyApiName: "name",
        status: "ACTIVE", datasource: { rid: rid("dataset"), type: "dataset", path: "/ontology/datasets/assets_clean", syncMode: "incremental" }, groups: ["Operations", "Reliability"],
        implementsInterfaces: [
          { interfaceApiName: "Maintainable", propertyMapping: { status: "status", lastInspection: "lastInspection" } },
          { interfaceApiName: "Locatable", propertyMapping: { geo: "lat" } },
          { interfaceApiName: "Assignable", propertyMapping: { owner: "owner", status: "status" } },
        ],
        properties: [
          P("id", "Asset ID", "String", { required: true, visibility: "PROMINENT" } as never),
          P("name", "Name", "String", { visibility: "PROMINENT" }),
          P("status", "Status", "String", { visibility: "PROMINENT", sharedPropertyType: "status" }),
          P("priority", "Priority", "String", { visibility: "PROMINENT" }),
          P("owner", "Owner", "String", { sharedPropertyType: "owner" }),
          P("ownerId", "Owner ID", "String", { visibility: "HIDDEN" }),
          P("locationId", "Location ID", "String", { visibility: "HIDDEN" }),
          P("model", "Model", "String"),
          P("pressure", "Pressure", "Double", { unit: "bar", valueFormatting: "unit" }),
          P("temperature", "Temperature", "Double", { unit: "°C", valueFormatting: "unit" }),
          P("availability", "Availability", "Double", { valueFormatting: "percent" }),
          P("revenueImpact", "Revenue impact", "Double", { valueFormatting: "currency" }),
          P("openAlerts", "Open alerts", "Integer"),
          P("installedAt", "Installed", "Date"),
          P("lastInspection", "Last inspection", "Timestamp", { sharedPropertyType: "lastInspection" }),
          P("nextMaintenance", "Next maintenance", "Date"),
          P("lat", "Latitude", "Double", { visibility: "HIDDEN", sharedPropertyType: "geo" }),
          P("lng", "Longitude", "Double", { visibility: "HIDDEN", sharedPropertyType: "geo" }),
          P("openWorkOrderCount", "Open work orders (derived)", "Integer", { derivation: { linkTypeApiNames: ["assetWorkOrders"], aggregation: "count" } }),
          P("sensorAvgReading", "Avg sensor reading (derived)", "Double", { derivation: { linkTypeApiNames: ["assetSensors"], aggregation: "avg", property: "current" } }),
        ],
      },
      {
        apiName: "Sensor", rid: rid("object-type"), apiNamespace: ns, displayName: "Sensor", pluralDisplayName: "Sensors", icon: "S", color: "#0f9960",
        description: "Telemetry device attached to an asset.", primaryKeyPropertyApiNames: ["id"], titlePropertyApiName: "name",
        status: "ACTIVE", datasource: { rid: rid("dataset"), type: "dataset", path: "/ontology/datasets/sensor_registry", syncMode: "incremental" }, groups: ["Telemetry"],
        implementsInterfaces: [{ interfaceApiName: "Maintainable", propertyMapping: { status: "status", lastInspection: "status" } }],
        properties: [
          P("id", "Sensor ID", "String", { visibility: "PROMINENT" }),
          P("name", "Name", "String", { visibility: "PROMINENT" }),
          P("assetId", "Asset ID", "String", { visibility: "HIDDEN" }),
          P("kind", "Kind", "String", { visibility: "PROMINENT" }),
          P("unit", "Unit", "String"),
          P("current", "Current reading", "Double"),
          P("threshold", "Threshold", "Double"),
          P("status", "Status", "String", { sharedPropertyType: "status", visibility: "PROMINENT" }),
        ],
      },
      {
        apiName: "Alert", rid: rid("object-type"), apiNamespace: ns, displayName: "Alert", pluralDisplayName: "Alerts", icon: "!", color: "#c23030",
        description: "Anomaly raised by monitoring rules.", primaryKeyPropertyApiNames: ["id"], titlePropertyApiName: "title",
        status: "ACTIVE", datasource: { rid: rid("stream"), type: "stream", path: "/ontology/streams/alerts_stream", syncMode: "incremental" }, groups: ["Operations"], implementsInterfaces: [],
        properties: [
          P("id", "Alert ID", "String", { visibility: "PROMINENT" }),
          P("title", "Title", "String", { visibility: "PROMINENT" }),
          P("severity", "Severity", "String", { visibility: "PROMINENT" }),
          P("description", "Description", "String"),
          P("assetId", "Asset ID", "String", { visibility: "HIDDEN" }),
          P("createdAt", "Raised at", "Timestamp"),
          P("acknowledged", "Acknowledged", "Boolean"),
          P("reading", "Measured value", "Double"),
        ],
      },
      {
        apiName: "WorkOrder", rid: rid("object-type"), apiNamespace: ns, displayName: "Work Order", pluralDisplayName: "Work Orders", icon: "W", color: "#d9822b",
        description: "Unit of maintenance work scheduled against an asset.", primaryKeyPropertyApiNames: ["id"], titlePropertyApiName: "title",
        status: "ACTIVE", datasource: { rid: rid("dataset"), type: "dataset", path: "/ontology/datasets/work_orders", syncMode: "incremental" }, groups: ["Maintenance"],
        implementsInterfaces: [{ interfaceApiName: "Assignable", propertyMapping: { owner: "operatorId", status: "status" } }],
        properties: [
          P("id", "Work order ID", "String", { visibility: "PROMINENT" }),
          P("title", "Title", "String", { visibility: "PROMINENT" }),
          P("status", "Status", "String", { sharedPropertyType: "status", visibility: "PROMINENT" }),
          P("assetId", "Asset ID", "String"),
          P("operatorId", "Operator ID", "String", { visibility: "HIDDEN" }),
          P("due", "Due", "Date"),
          P("createdAt", "Created", "Timestamp"),
        ],
      },
      {
        apiName: "Operator", rid: rid("object-type"), apiNamespace: ns, displayName: "Operator", pluralDisplayName: "Operators", icon: "O", color: "#7157d9",
        description: "Certified field technician.", primaryKeyPropertyApiNames: ["id"], titlePropertyApiName: "name",
        status: "ACTIVE", datasource: { rid: rid("dataset"), type: "dataset", path: "/ontology/datasets/hr_operators", syncMode: "snapshot" }, groups: ["People"], implementsInterfaces: [],
        properties: [
          P("id", "Operator ID", "String"),
          P("name", "Name", "String", { visibility: "PROMINENT" }),
          P("shift", "Shift", "String"),
          P("certifications", "Certifications", "Array"),
        ],
      },
      {
        apiName: "Location", rid: rid("object-type"), apiNamespace: ns, displayName: "Location", pluralDisplayName: "Locations", icon: "L", color: "#5c7080",
        description: "Operational site / facility.", primaryKeyPropertyApiNames: ["id"], titlePropertyApiName: "name",
        status: "ACTIVE", datasource: { rid: rid("dataset"), type: "dataset", path: "/ontology/datasets/sites", syncMode: "snapshot" }, groups: ["Operations"],
        implementsInterfaces: [{ interfaceApiName: "Locatable", propertyMapping: { geo: "lat" } }],
        properties: [
          P("id", "Location ID", "String"),
          P("name", "Name", "String", { visibility: "PROMINENT" }),
          P("region", "Region", "String"),
          P("lat", "Latitude", "Double", { sharedPropertyType: "geo" }),
          P("lng", "Longitude", "Double", { sharedPropertyType: "geo" }),
        ],
      },
    ],
    linkTypes: [
      { apiName: "assetSensors", rid: rid("link-type"), displayName: "Sensors", reverseDisplayName: "Asset", objectTypeA: "Asset", objectTypeB: "Sensor", cardinality: "ONE_TO_MANY", definition: { type: "foreignKey", foreignKeyObjectType: "Sensor", foreignKeyProperty: "assetId", primaryKeyObjectType: "Asset" }, status: "ACTIVE" },
      { apiName: "assetAlerts", rid: rid("link-type"), displayName: "Alerts", reverseDisplayName: "Asset", objectTypeA: "Asset", objectTypeB: "Alert", cardinality: "ONE_TO_MANY", definition: { type: "foreignKey", foreignKeyObjectType: "Alert", foreignKeyProperty: "assetId", primaryKeyObjectType: "Asset" }, status: "ACTIVE" },
      { apiName: "assetWorkOrders", rid: rid("link-type"), displayName: "Work Orders", reverseDisplayName: "Asset", objectTypeA: "Asset", objectTypeB: "WorkOrder", cardinality: "ONE_TO_MANY", definition: { type: "foreignKey", foreignKeyObjectType: "WorkOrder", foreignKeyProperty: "assetId", primaryKeyObjectType: "Asset" }, status: "ACTIVE" },
      { apiName: "assetLocation", rid: rid("link-type"), displayName: "Location", reverseDisplayName: "Assets", objectTypeA: "Asset", objectTypeB: "Location", cardinality: "MANY_TO_ONE", definition: { type: "foreignKey", foreignKeyObjectType: "Asset", foreignKeyProperty: "locationId", primaryKeyObjectType: "Location" }, status: "ACTIVE" },
      { apiName: "assetOwner", rid: rid("link-type"), displayName: "Owner", reverseDisplayName: "Owned assets", objectTypeA: "Asset", objectTypeB: "Operator", cardinality: "MANY_TO_ONE", definition: { type: "foreignKey", foreignKeyObjectType: "Asset", foreignKeyProperty: "ownerId", primaryKeyObjectType: "Operator" }, status: "ACTIVE" },
      { apiName: "workOrderOperator", rid: rid("link-type"), displayName: "Assigned operator", reverseDisplayName: "Work orders", objectTypeA: "WorkOrder", objectTypeB: "Operator", cardinality: "MANY_TO_ONE", definition: { type: "foreignKey", foreignKeyObjectType: "WorkOrder", foreignKeyProperty: "operatorId", primaryKeyObjectType: "Operator" }, status: "ACTIVE" },
    ],
    actionTypes: [
      {
        apiName: "updateAssetStatus", rid: rid("action-type"), displayName: "Update asset status", description: "Change operational status, owner and priority of an asset.",
        status: "ACTIVE", submissionGroups: ["ops-editors"], notifications: ["Notify owner"],
        parameters: [
          param("asset", "Asset", "ObjectReference", { required: true, objectTypeApiName: "Asset" }),
          param("status", "Status", "String", { required: true, allowedValues: STATUSES }, { defaultFrom: "object.status" }),
          param("priority", "Priority", "String", { allowedValues: PRIORITIES }, { defaultFrom: "object.priority" }),
          param("owner", "Owner", "String", { allowedValues: OPERATOR_NAMES }, { defaultFrom: "object.owner" }),
        ],
        rules: [{ kind: "modifyObjectRule", objectParameterApiName: "asset", propertyMappings: { status: "param.status", priority: "param.priority", owner: "param.owner", lastInspection: "now()" } }],
        submissionCriteria: [
          { id: "c1", conditionType: "parameter", when: { left: "param.status", op: "is", right: "Offline" }, condition: { left: "param.priority", op: "is", right: "High" }, failureMessage: "Assets taken Offline must be set to High priority." },
          { id: "c2", conditionType: "object", condition: { left: "object.status", op: "isNot", right: "Decommissioned" }, failureMessage: "Decommissioned assets cannot be modified." },
        ],
      },
      {
        apiName: "createWorkOrder", rid: rid("action-type"), displayName: "Create work order", description: "Open a new work order linked to an asset.",
        status: "ACTIVE", submissionGroups: ["maintenance-planners"], notifications: ["Notify assigned operator"],
        parameters: [
          param("asset", "Asset", "ObjectReference", { required: true, objectTypeApiName: "Asset" }),
          param("title", "Title", "String", { required: true, minLength: 4 }),
          param("operator", "Assigned operator", "ObjectReference", { required: true, objectTypeApiName: "Operator" }),
          param("due", "Due date", "Date", { required: true }),
        ],
        rules: [{ kind: "addObjectRule", objectTypeApiName: "WorkOrder", propertyMappings: { assetId: "param.asset", title: "param.title", operatorId: "param.operator", due: "param.due", status: "'Open'" } }],
        submissionCriteria: [{ id: "c1", conditionType: "object", condition: { left: "object.status", op: "isNot", right: "Offline" }, failureMessage: "Cannot schedule work on an Offline asset — bring it to Maintenance first." }],
      },
      {
        apiName: "completeWorkOrder", rid: rid("action-type"), displayName: "Complete work order", description: "Mark a work order done.",
        status: "ACTIVE", submissionGroups: ["operators"], notifications: [],
        parameters: [param("workOrder", "Work order", "ObjectReference", { required: true, objectTypeApiName: "WorkOrder" })],
        rules: [{ kind: "modifyObjectRule", objectParameterApiName: "workOrder", propertyMappings: { status: "'Done'" } }],
        submissionCriteria: [{ id: "c1", conditionType: "object", condition: { left: "object.status", op: "isNot", right: "Done" }, failureMessage: "Work order is already completed." }],
      },
      {
        apiName: "cancelWorkOrder", rid: rid("action-type"), displayName: "Cancel work order", description: "Delete a work order that has not started.",
        status: "ACTIVE", submissionGroups: ["maintenance-planners"], notifications: [],
        parameters: [param("workOrder", "Work order", "ObjectReference", { required: true, objectTypeApiName: "WorkOrder" })],
        rules: [{ kind: "deleteObjectRule", objectParameterApiName: "workOrder" }],
        submissionCriteria: [{ id: "c1", conditionType: "object", condition: { left: "object.status", op: "isNotOneOf", right: ["In Progress", "Done"] }, failureMessage: "Only Open or Blocked work orders can be cancelled." }],
      },
      {
        apiName: "createOperationalAlert", rid: rid("action-type"), displayName: "Create operational alert", description: "Create an Alert linked to the measured Asset after a validated stream threshold event.",
        status: "ACTIVE", submissionGroups: ["operators"], notifications: ["Operations feed"],
        parameters: [
          param("asset", "Asset", "ObjectReference", { required: true, objectTypeApiName: "Asset" }),
          param("title", "Title", "String", { required: true, minLength: 5 }),
          param("severity", "Severity", "String", { required: true, allowedValues: ["Critical", "High", "Medium", "Low"] }),
          param("description", "Description", "String", { required: true, minLength: 4 }),
          param("reading", "Measurement", "Double", { required: false }),
        ],
        rules: [{ kind: "addObjectRule", objectTypeApiName: "Alert", propertyMappings: { assetId: "param.asset", title: "param.title", severity: "param.severity", description: "param.description", reading: "param.reading", createdAt: "now()", acknowledged: "false" } }],
        submissionCriteria: [],
      },
      {
        apiName: "acknowledgeAlert", rid: rid("action-type"), displayName: "Acknowledge alert", description: "Acknowledge an alert.",
        status: "ACTIVE", submissionGroups: ["operators"], notifications: [],
        parameters: [param("alert", "Alert", "ObjectReference", { required: true, objectTypeApiName: "Alert" })],
        rules: [{ kind: "modifyObjectRule", objectParameterApiName: "alert", propertyMappings: { acknowledged: "true" } }],
        submissionCriteria: [{ id: "c1", conditionType: "object", condition: { left: "object.acknowledged", op: "isNot", right: true }, failureMessage: "Alert already acknowledged." }],
      },
      {
        apiName: "adjustPressureSetpoint", rid: rid("action-type"), displayName: "Adjust pressure setpoint", description: "Write a new pressure setpoint within the safe envelope.",
        status: "EXPERIMENTAL", submissionGroups: ["control-engineers"], notifications: ["Write to SCADA (simulated)"],
        parameters: [
          param("asset", "Asset", "ObjectReference", { required: true, objectTypeApiName: "Asset" }),
          param("pressure", "Setpoint (bar)", "Double", { required: true, range: { min: 5, max: 45 } }, { defaultFrom: "object.pressure" }),
        ],
        rules: [{ kind: "modifyObjectRule", objectParameterApiName: "asset", propertyMappings: { pressure: "param.pressure" } }],
        submissionCriteria: [{ id: "c1", conditionType: "object", condition: { left: "object.status", op: "isOneOf", right: ["Active", "Warning"] }, failureMessage: "Setpoint can only be adjusted on running assets." }],
      },
      {
        apiName: "assignOperator", rid: rid("action-type"), displayName: "Assign operator to asset", description: "Create the Owner link between an Asset and an Operator.",
        status: "ACTIVE", submissionGroups: ["maintenance-planners"], notifications: [],
        parameters: [
          param("asset", "Asset", "ObjectReference", { required: true, objectTypeApiName: "Asset" }),
          param("operator", "Operator", "ObjectReference", { required: true, objectTypeApiName: "Operator" }),
        ],
        rules: [{ kind: "addLinkRule", linkTypeApiName: "assetOwner", objectAParameterApiName: "asset", objectBParameterApiName: "operator" }],
        submissionCriteria: [],
      },
    ],
    functions: [
      { apiName: "predictFailureRisk", rid: rid("query"), displayName: "Predict failure risk", description: "Heuristic failure probability (%) from telemetry & alerts.", inputs: [{ name: "asset", type: "Object<Asset>" }], output: "Double", language: "TypeScript", version: "2.3.0", source: "export function predictFailureRisk(asset: Asset): Double {\n  const p = asset.pressure / 60 * 0.35;\n  const t = asset.temperature / 100 * 0.25;\n  const a = (100 - asset.availability) / 30 * 0.25;\n  return clamp(p + t + a + asset.openAlerts * 0.08) * 100;\n}" },
      { apiName: "revenueAtRisk", rid: rid("query"), displayName: "Revenue at risk", description: "Sum of revenue impact for non-Active assets.", inputs: [{ name: "assets", type: "ObjectSet<Asset>" }], output: "Double", language: "TypeScript", version: "1.1.0", source: "export function revenueAtRisk(assets: ObjectSet<Asset>): Double {\n  return assets.filter(a => a.status !== 'Active').sum(a => a.revenueImpact);\n}" },
      { apiName: "aggregateByStatus", rid: rid("query"), displayName: "Aggregate by status", description: "Count objects grouped by status.", inputs: [{ name: "objects", type: "ObjectSet<Maintainable>" }], output: "Map<String, Integer>", language: "TypeScript", version: "1.0.2", source: "export function aggregateByStatus(objects) {\n  return objects.groupBy(o => o.status).count();\n}" },
      { apiName: "openWorkOrderCount", rid: rid("query"), displayName: "Open work order count", description: "Count non-done work orders linked to assets.", inputs: [{ name: "assets", type: "ObjectSet<Asset>" }], output: "Integer", language: "Python", version: "0.9.0", source: "@query\ndef open_work_order_count(assets: ObjectSet[Asset]) -> int:\n    return assets.pivot_to('assetWorkOrders').filter(status != 'Done').count()", isEditFunction: false },
    ],
  };
}
