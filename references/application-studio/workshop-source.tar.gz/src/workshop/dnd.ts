"use client";
import { createStore } from "./runtimeStores";
import type { ModuleDef } from "./types";
import { collectSectionSubtree } from "./moduleOps";

/**
 * Pointer-based drag & drop engine.
 *
 * Why not HTML5 DnD: no drag threshold, no custom ghost, no auto-scroll, no zoom-aware hit-testing and
 * poor touch support. Here a single window-level pointer session resolves ONE drop target per animation
 * frame by hit-testing `data-*` attributes emitted by the renderers; React renders only a single overlay.
 */
export type DragPayload =
  | { kind: "new"; widgetType: string; name: string }
  | { kind: "move"; childKind: "widget" | "section"; id: string; name: string };

export interface Rect { x: number; y: number; w: number; h: number }
export type Side = "left" | "right" | "top" | "bottom";

export type DropTarget =
  | { kind: "insert"; sectionId: string; index: number; line: Rect; vertical: boolean; label: string }
  | { kind: "into"; sectionId: string; rect: Rect; label: string }
  | { kind: "wrap"; targetId: string; targetKind: "widget" | "section"; side: Side; rect: Rect; label: string }
  | { kind: "swap"; targetId: string; targetKind: "widget" | "section"; rect: Rect; label: string };

export interface DndState { active: boolean; payload: DragPayload | null; x: number; y: number; target: DropTarget | null }
const IDLE: DndState = { active: false, payload: null, x: 0, y: 0, target: null };
export const dndStore = createStore<DndState>(IDLE);

interface DndConfig { getModule: () => ModuleDef; commit: (p: DragPayload, t: DropTarget) => void; getScroller: () => HTMLElement | null }
let cfg: DndConfig | null = null;
export function configureDnd(c: DndConfig) { cfg = c; }

const rectOf = (el: Element): Rect => { const r = el.getBoundingClientRect(); return { x: r.left, y: r.top, w: r.width, h: r.height }; };
const LINE = 3;

function lineFor(r: Rect, side: Side): Rect {
  switch (side) {
    case "left": return { x: r.x - 2, y: r.y, w: LINE, h: r.h };
    case "right": return { x: r.x + r.w - 1, y: r.y, w: LINE, h: r.h };
    case "top": return { x: r.x, y: r.y - 2, w: r.w, h: LINE };
    default: return { x: r.x, y: r.y + r.h - 1, w: r.w, h: LINE };
  }
}
function halfFor(r: Rect, side: Side): Rect {
  switch (side) {
    case "left": return { x: r.x, y: r.y, w: r.w / 2, h: r.h };
    case "right": return { x: r.x + r.w / 2, y: r.y, w: r.w / 2, h: r.h };
    case "top": return { x: r.x, y: r.y, w: r.w, h: r.h / 2 };
    default: return { x: r.x, y: r.y + r.h / 2, w: r.w, h: r.h / 2 };
  }
}

/** Which edge band (if any) is the pointer in? Returns the closest edge by normalised depth. */
function edgeSide(r: Rect, x: number, y: number, bandX: number, bandY: number): Side | null {
  const cands: Array<[Side, number]> = [];
  const dl = x - r.x, dr = r.x + r.w - x, dt = y - r.y, db = r.y + r.h - y;
  if (dl < 0 || dr < 0 || dt < 0 || db < 0) return null; // pointer is outside this rect
  if (dl < bandX) cands.push(["left", dl / bandX]);
  if (dr < bandX) cands.push(["right", dr / bandX]);
  if (dt < bandY) cands.push(["top", dt / bandY]);
  if (db < bandY) cands.push(["bottom", db / bandY]);
  if (!cands.length) return null;
  cands.sort((a, b) => a[1] - b[1]);
  return cands[0][0];
}

function excludedIds(p: DragPayload, m: ModuleDef): Set<string> {
  if (p.kind !== "move") return new Set();
  if (p.childKind === "widget") return new Set([p.id]);
  const { sectionIds, widgetIds } = collectSectionSubtree(m, p.id);
  return new Set([...sectionIds, ...widgetIds]);
}

function nameOf(m: ModuleDef, id: string) { return m.sections[id]?.name ?? m.widgets[id]?.name ?? id; }

function relative(el: HTMLElement, side: Side, p: DragPayload, m: ModuleDef): DropTarget | null {
  const parentId = el.dataset.parentId;
  if (!parentId) return null;
  const idx = Number(el.dataset.index ?? 0);
  const orient = el.dataset.parentOrient;
  const r = rectOf(el);
  const horizontal = side === "left" || side === "right";
  const after = side === "right" || side === "bottom";
  const id = el.dataset.nodeId!;
  const kind = (el.dataset.nodeKind as "widget" | "section") ?? "widget";
  if ((horizontal && orient === "h") || (!horizontal && orient === "v") || orient === "tabs" || orient === "loop") {
    if (p.kind === "move") {
      const sameParent = m.sections[parentId]?.children.findIndex(c => c.id === p.id) ?? -1;
      if (sameParent >= 0 && (idx + (after ? 1 : 0) === sameParent || idx + (after ? 1 : 0) === sameParent + 1)) return null; // no-op position
    }
    return { kind: "insert", sectionId: parentId, index: idx + (after ? 1 : 0), line: lineFor(r, side), vertical: horizontal || orient === "tabs", label: `${after ? "After" : "Before"} ${nameOf(m, id)}` };
  }
  return { kind: "wrap", targetId: id, targetKind: kind, side, rect: halfFor(r, side), label: `${horizontal ? "Beside" : side === "top" ? "Above" : "Below"} ${nameOf(m, id)} (new ${horizontal ? "row" : "column"})` };
}

function insertInto(secEl: HTMLElement, x: number, y: number, p: DragPayload, m: ModuleDef): DropTarget | null {
  const sectionId = secEl.dataset.nodeId!;
  const excluded = excludedIds(p, m);
  const kids = Array.from(secEl.querySelectorAll<HTMLElement>(`[data-parent-id="${CSS.escape(sectionId)}"]`)).filter(k => !excluded.has(k.dataset.nodeId ?? ""));
  const orient = secEl.dataset.orient ?? "v";
  if (kids.length === 0) return { kind: "into", sectionId, rect: rectOf(secEl), label: `Into ${nameOf(m, sectionId)}` };
  const rects = kids.map(rectOf);
  let index = 0;
  const horizontal = orient === "h";
  for (let i = 0; i < rects.length; i++) {
    const c = horizontal ? rects[i].x + rects[i].w / 2 : rects[i].y + rects[i].h / 2;
    if ((horizontal ? x : y) > c) index = i + 1;
  }
  if (orient === "tabs") index = rects.length;
  // index refers to the filtered list; map back to real children index
  const real = m.sections[sectionId]?.children ?? [];
  const keptIds = kids.map(k => k.dataset.nodeId);
  const realIndex = index >= keptIds.length ? real.length : real.findIndex(c => c.id === keptIds[index]);
  let line: Rect;
  if (index === 0) line = lineFor(rects[0], horizontal ? "left" : "top");
  else if (index >= rects.length) line = lineFor(rects[rects.length - 1], horizontal ? "right" : "bottom");
  else {
    const a = rects[index - 1], b = rects[index];
    line = horizontal ? { x: (a.x + a.w + b.x) / 2 - 1, y: Math.min(a.y, b.y), w: LINE, h: Math.max(a.h, b.h) } : { x: Math.min(a.x, b.x), y: (a.y + a.h + b.y) / 2 - 1, w: Math.max(a.w, b.w), h: LINE };
  }
  if (p.kind === "move") {
    const cur = real.findIndex(c => c.id === p.id);
    if (cur >= 0 && (realIndex === cur || realIndex === cur + 1)) return null;
  }
  return { kind: "insert", sectionId, index: realIndex < 0 ? real.length : realIndex, line, vertical: horizontal, label: `Into ${nameOf(m, sectionId)}` };
}

function resolveTree(el: HTMLElement, y: number, p: DragPayload, m: ModuleDef): DropTarget | null {
  const kind = el.dataset.treeNode;
  const id = el.dataset.treeId!;
  const excluded = excludedIds(p, m);
  if (excluded.has(id)) return null;
  const r = rectOf(el);
  const ry = (y - r.y) / r.h;
  if (kind === "section") {
    const parent = el.dataset.treeParent;
    if (parent && ry < 0.25) return { kind: "insert", sectionId: parent, index: Number(el.dataset.treeIndex), line: lineFor(r, "top"), vertical: false, label: `Before ${nameOf(m, id)}` };
    if (parent && ry > 0.75) return { kind: "insert", sectionId: parent, index: Number(el.dataset.treeIndex) + 1, line: lineFor(r, "bottom"), vertical: false, label: `After ${nameOf(m, id)}` };
    return { kind: "into", sectionId: id, rect: r, label: `Into ${nameOf(m, id)}` };
  }
  if (kind === "widget") {
    const parent = el.dataset.treeParent;
    if (!parent) return null;
    const after = ry > 0.5;
    return { kind: "insert", sectionId: parent, index: Number(el.dataset.treeIndex) + (after ? 1 : 0), line: lineFor(r, after ? "bottom" : "top"), vertical: false, label: `${after ? "After" : "Before"} ${nameOf(m, id)}` };
  }
  return null;
}

export function resolveTarget(p: DragPayload, x: number, y: number): DropTarget | null {
  if (!cfg) return null;
  const m = cfg.getModule();
  const els = document.elementsFromPoint(x, y) as HTMLElement[];
  const tree = els.find(e => e.dataset?.treeNode);
  if (tree) return resolveTree(tree, y, p, m);

  const excluded = excludedIds(p, m);
  const nodes = els.filter(e => e.dataset?.nodeId && !excluded.has(e.dataset.nodeId));
  if (!nodes.length) return null;
  const el = nodes[0];
  const kind = el.dataset.nodeKind;
  const r = rectOf(el);

  if (kind === "section") {
    const band = Math.min(14, r.w * 0.1, r.h * 0.2);
    const side = el.dataset.parentId ? edgeSide(r, x, y, band, band) : null;
    if (side) return relative(el, side, p, m);
    return insertInto(el, x, y, p, m);
  }
  // widget
  const bandX = Math.max(14, Math.min(r.w * 0.28, 96));
  const bandY = Math.max(14, Math.min(r.h * 0.28, 72));
  const side = edgeSide(r, x, y, bandX, bandY);
  if (side) return relative(el, side, p, m);
  if (p.kind === "move") return { kind: "swap", targetId: el.dataset.nodeId!, targetKind: "widget", rect: r, label: `Swap with ${nameOf(m, el.dataset.nodeId!)}` };
  // new widget over centre → before/after along the parent's main axis
  const orient = el.dataset.parentOrient;
  const s2: Side = orient === "h" ? (x < r.x + r.w / 2 ? "left" : "right") : (y < r.y + r.h / 2 ? "top" : "bottom");
  return relative(el, s2, p, m) ?? insertInto(el.closest<HTMLElement>('[data-orient]') ?? el, x, y, p, m);
}

function suppressNextClick() {
  const stop = (e: Event) => { e.stopPropagation(); e.preventDefault(); };
  window.addEventListener("click", stop, { capture: true, once: true });
  setTimeout(() => window.removeEventListener("click", stop, { capture: true }), 80);
}

/** Start a drag session from a pointerdown. A 5px threshold keeps plain clicks working. */
export function beginDrag(payload: DragPayload, ev: { clientX: number; clientY: number; button: number }) {
  if (ev.button !== 0 || dndStore.get().active) return;
  const sx = ev.clientX, sy = ev.clientY;
  let started = false, raf = 0, scrollRaf = 0, lx = sx, ly = sy;

  const update = () => {
    raf = 0;
    dndStore.set({ active: true, payload, x: lx, y: ly, target: resolveTarget(payload, lx, ly) });
  };
  const scrollLoop = () => {
    const sc = cfg?.getScroller();
    if (sc) {
      const r = sc.getBoundingClientRect();
      const edge = 56, max = 22;
      let dy = 0, dx = 0;
      if (ly < r.top + edge && ly > r.top - 40) dy = -max * (1 - (ly - r.top) / edge);
      else if (ly > r.bottom - edge && ly < r.bottom + 40) dy = max * (1 - (r.bottom - ly) / edge);
      if (lx < r.left + edge && lx > r.left - 40) dx = -max * (1 - (lx - r.left) / edge);
      else if (lx > r.right - edge && lx < r.right + 40) dx = max * (1 - (r.right - lx) / edge);
      if (dx || dy) { sc.scrollLeft += dx; sc.scrollTop += dy; if (!raf) raf = requestAnimationFrame(update); }
    }
    scrollRaf = requestAnimationFrame(scrollLoop);
  };

  const onMove = (e: PointerEvent) => {
    lx = e.clientX; ly = e.clientY;
    if (!started) {
      if (Math.hypot(lx - sx, ly - sy) < 5) return;
      started = true;
      document.body.classList.add("fnd-dragging");
      scrollRaf = requestAnimationFrame(scrollLoop);
    }
    if (!raf) raf = requestAnimationFrame(update);
  };
  const cleanup = () => {
    window.removeEventListener("pointermove", onMove);
    window.removeEventListener("pointerup", onUp);
    window.removeEventListener("pointercancel", onCancel);
    window.removeEventListener("keydown", onKey, true);
    if (raf) cancelAnimationFrame(raf);
    if (scrollRaf) cancelAnimationFrame(scrollRaf);
    document.body.classList.remove("fnd-dragging");
  };
  const finish = (commit: boolean) => {
    // resolve once more at the final position so the drop matches what the user sees
    const final = started && commit ? resolveTarget(payload, lx, ly) : null;
    cleanup();
    dndStore.set(IDLE);
    if (started) { suppressNextClick(); if (final) cfg?.commit(payload, final); }
  };
  const onUp = () => finish(true);
  const onCancel = () => finish(false);
  const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") { e.stopPropagation(); finish(false); } };
  window.addEventListener("pointermove", onMove);
  window.addEventListener("pointerup", onUp);
  window.addEventListener("pointercancel", onCancel);
  window.addEventListener("keydown", onKey, true);
}
