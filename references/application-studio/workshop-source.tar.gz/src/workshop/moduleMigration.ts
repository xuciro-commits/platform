import type { ModuleDef, SectionDef } from "./types";
import { buildDefaultModule } from "./seedModule";
import { makeDemoFlow } from "./flowCatalog";

export const WORKSHOP_SCHEMA_VERSION = 6;

/** Non-destructive upgrade from prior saved Workshop modules.
 * User-authored pages, widgets and variables are never overwritten or reset.
 */
export function migrateModule(saved: ModuleDef): ModuleDef {
  const defaults = buildDefaultModule();
  const root = defaults.pages.find(p => p.id === "pTelemetry");
  const sections = { ...saved.sections }, widgets = { ...saved.widgets };
  const visit = (id: string) => {
    const s: SectionDef | undefined = defaults.sections[id];
    if (!s || sections[id]) return;
    sections[id] = s;
    for (const child of s.children) {
      if (child.kind === "section") visit(child.id);
      else if (!widgets[child.id] && defaults.widgets[child.id]) widgets[child.id] = defaults.widgets[child.id];
    }
  };
  if (root && !saved.pages.some(p => p.id === root.id)) visit(root.rootSectionId);
  const extraVariables = defaults.variables.filter(v => ["liveTelemetryStats", "currentTelemetryRow", "selectedScenePart", "selectedSignal"].includes(v.id) && !saved.variables.some(x => x.id === v.id));
  const flows = (saved.flows?.length ? saved.flows : [makeDemoFlow()]).map(f => {
    if (f.id !== "flow-telemetry" || f.version > 3) return f;
    return {
      ...f, version: 4,
      nodes: f.nodes.map(n => n.id === "flow-alert" ? { ...n, name: "Create operational alert", config: { ...n.config, actionType: "createOperationalAlert", dryRun: false } }
        : n.id === "flow-threshold" ? { ...n, config: { ...n.config, high: 15.5, low: 13.5, debounceMs: 1000, key: "assetId" } }
        : n.id === "flow-wasm" ? { ...n, config: { ...n.config, signal: "vibration_01", threshold: 15.5 } } : n),
      edges: f.edges.map(e => e.id === "fe3" ? { ...e, sourcePort: "stats" } : e),
    };
  });
  return {
    ...saved,
    sections,
    widgets,
    pages: root && !saved.pages.some(p => p.id === root.id) ? [...saved.pages, root] : saved.pages,
    variables: [...saved.variables, ...extraVariables],
    flows,
  };
}
