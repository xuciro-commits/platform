import type { FlowEdgeDef, FlowNodeDef, FlowNodeType, FlowPortDef, FlowValueType } from "./flowTypes";
import { newId } from "./moduleOps";

export interface NodeSpec {
  type: FlowNodeType;
  label: string;
  category: string;
  description: string;
  color: string;
  inputs: FlowPortDef[];
  outputs: FlowPortDef[];
  defaults: Record<string, unknown>;
  cost: "low" | "medium" | "high";
}
const input = (id: string, label: string, type: FlowValueType, extra: Partial<FlowPortDef> = {}): FlowPortDef => ({ id, label, type, direction: "input", required: true, ...extra });
const output = (id: string, label: string, type: FlowValueType): FlowPortDef => ({ id, label, type, direction: "output" });

export const FLOW_NODES: NodeSpec[] = [
  { type: "objectSource", label: "Ontology object set", category: "Sources", description: "Read a bounded, typed Ontology Object Set by apiName (with a configurable row limit).",  color: "#2b6cb0", inputs: [], outputs: [output("objects", "Objects", "ObjectSet")], defaults: { objectType: "Asset", limit: 50000 }, cost: "low" },
  { type: "telemetrySource", label: "Telemetry stream", category: "Sources", description: "Consume a live multi-plant, multi-device columnar telemetry stream.", color: "#137cbd", inputs: [], outputs: [output("batch", "Telemetry batch", "TelemetryBatch")], defaults: { plants: ["Houston", "Rotterdam", "Singapore", "Calgary", "Perth"], batchSize: 256, partitionBy: "deviceId", offset: "latest" }, cost: "low" },
  { type: "filter", label: "Filter rows", category: "Transform", description: "Filter typed properties using one or more AND/OR predicates.", color: "#7157d9", inputs: [input("in", "Input", "Any")], outputs: [output("out", "Filtered", "Any"), output("rejected", "Rejected", "Any")], defaults: { predicates: [{ field: "status", operator: "eq", value: "Warning" }], join: "all" }, cost: "low" },
  { type: "window", label: "Event-time window", category: "Streaming", description: "Tumbling, sliding or session window with watermark, late-event and checkpoint settings.", color: "#9b59b6", inputs: [input("in", "Events", "TelemetryBatch")], outputs: [output("window", "Window", "TelemetryBatch"), output("late", "Late events", "TelemetryBatch")], defaults: { windowMs: 60000, slideMs: 10000, watermarkMs: 5000, lateEvents: "sideOutput", windowKind: "sliding" }, cost: "medium" },
  { type: "aggregate", label: "WASM aggregate", category: "Compute", description: "Compute mean/min/max/count-above-threshold in a WebAssembly SIMD-ready kernel.", color: "#c23030", inputs: [input("in", "Numeric values", "TelemetryBatch")], outputs: [output("stats", "Statistics", "Scalar"), output("alerts", "Threshold events", "Alert")], defaults: { signal: "vibration", threshold: 12, kernel: "wasm:f32-window-stats", groupBy: ["plantId", "deviceId"] }, cost: "high" },
  { type: "join", label: "Temporal join", category: "Transform", description: "Join stream rows with an Ontology object set on key + tolerance interval.", color: "#5c7080", inputs: [input("stream", "Stream", "TelemetryBatch"), input("objects", "Objects", "ObjectSet")], outputs: [output("joined", "Enriched rows", "Any"), output("unmatched", "Unmatched", "Any")], defaults: { leftKey: "assetId", rightKey: "id", toleranceMs: 30000, mode: "left", lateJoin: "sideOutput" }, cost: "medium" },
  { type: "formula", label: "Formula / expression", category: "Transform", description: "Evaluate a safe, typed expression over the incoming row (no eval / Function constructor).", color: "#d9822b", inputs: [input("in", "Input", "Any")], outputs: [output("out", "Output", "Any")], defaults: { expression: "vibration_01 * 1.05", outputName: "calibratedVibration", outputType: "Double" }, cost: "medium" },
  { type: "branch", label: "Branch / route", category: "Control flow", description: "Route events to named output ports according to ordered predicates.", color: "#008c95", inputs: [input("in", "Input", "Any")], outputs: [output("match", "Matched", "Any"), output("else", "Else", "Any")], defaults: { predicate: { field: "status", operator: "eq", value: "Critical" } }, cost: "low" },
  { type: "enrich", label: "Ontology enrichment", category: "Ontology", description: "Resolve device / asset / work-order links and derived Ontology properties.", color: "#296936", inputs: [input("in", "Input", "Any"), input("objects", "Reference set", "ObjectSet")], outputs: [output("enriched", "Enriched", "Any"), output("unresolved", "Unresolved", "Any")], defaults: { joinKey: "assetId", properties: ["status", "priority", "owner", "locationId"], link: "assetWorkOrders" }, cost: "medium" },
  { type: "threshold", label: "Threshold & hysteresis", category: "Control flow", description: "Evaluate high/low threshold, hysteresis, debounce and alert severity.", color: "#c23030", inputs: [input("in", "Input", "Any")], outputs: [output("triggered", "Triggered", "Alert"), output("normal", "Normal", "Any")], defaults: { field: "mean", high: 12, low: 10, debounceMs: 3000, severity: "High" }, cost: "low" },
  { type: "rateLimit", label: "Rate limit", category: "Streaming", description: "Per-key token bucket with burst and max event rate.", color: "#8a5a16", inputs: [input("in", "Input", "Any")], outputs: [output("allowed", "Allowed", "Any"), output("limited", "Rate-limited", "Any")], defaults: { key: "deviceId", maxPerSecond: 20, burst: 100 }, cost: "low" },
  { type: "delay", label: "Delay / buffer", category: "Streaming", description: "Bounded buffer with event-time ordering and backpressure policy.", color: "#5c7080", inputs: [input("in", "Input", "Any")], outputs: [output("out", "Buffered", "Any"), output("overflow", "Overflow", "Any")], defaults: { maxBuffer: 10000, flushMs: 1000, backpressure: "dropOldest" }, cost: "medium" },
  { type: "deduplicate", label: "Deduplicate", category: "Streaming", description: "Remove duplicates by event id or composite keys over a TTL horizon.", color: "#8f398f", inputs: [input("in", "Input", "Any")], outputs: [output("unique", "Unique", "Any"), output("duplicates", "Duplicates", "Any")], defaults: { keys: ["deviceId", "eventId"], ttlMs: 300000 }, cost: "medium" },
  { type: "sample", label: "Downsample / sample", category: "Streaming", description: "Reduce visualization load with last, min/max, LTTB-like, or uniform sampling.", color: "#5c7080", inputs: [input("in", "Input", "TelemetryBatch")], outputs: [output("sampled", "Sampled", "TelemetryBatch")], defaults: { method: "minMax", maxPoints: 2000 }, cost: "medium" },
  { type: "union", label: "Union streams", category: "Transform", description: "Merge compatible streams while retaining source partition metadata.", color: "#137cbd", inputs: [input("a", "Stream A", "Any"), input("b", "Stream B", "Any")], outputs: [output("out", "Merged", "Any")], defaults: { preserveOrder: true }, cost: "medium" },
  { type: "pivotTo", label: "Search Around", category: "Ontology", description: "Traverse a link type with Ontology cardinality semantics (one → object, many → object set).", color: "#296936", inputs: [input("objects", "Objects", "ObjectSet")], outputs: [output("linked", "Linked objects", "ObjectSet")], defaults: { linkType: "assetSensors" }, cost: "low" },
  { type: "action", label: "Submit Ontology Action", category: "Sinks", description: "Submit a real Action Type with parameter validation, submission criteria and transaction audit.", color: "#d9822b", inputs: [input("in", "Action parameters", "Any")], outputs: [output("result", "Action result", "Any"), output("errors", "Validation errors", "Any")], defaults: { actionType: "updateAssetStatus", dryRun: true }, cost: "high" },
  { type: "variableOutput", label: "Set Workshop variable", category: "Sinks", description: "Publish a flow output into a typed Workshop Variable; downstream widgets re-evaluate.", color: "#2b6cb0", inputs: [input("in", "Value", "Any")], outputs: [output("done", "Published", "Any")], defaults: { variableId: "filteredAssets", mode: "replace" }, cost: "low" },
  { type: "alertOutput", label: "Ontology alert sink", category: "Sinks", description: "Submit createOperationalAlert Action for threshold events; rejected records go to the dead-letter path.", color: "#c23030", inputs: [input("in", "Alerts", "Alert")], outputs: [output("done", "Submitted", "Any"), output("errors", "Rejected", "Any")], defaults: { severity: "High", actionType: "createOperationalAlert", dryRun: false }, cost: "medium" },
  { type: "deadLetter", label: "Dead-letter queue", category: "Reliability", description: "Retain failed records with source, error and retry metadata for replay.", color: "#8a1f1f", inputs: [input("in", "Failed records", "Any")], outputs: [output("queue", "Dead-lettered", "Any")], defaults: { maxRecords: 10000, retry: true, ttlMs: 86400000 }, cost: "low" },
  { type: "debug", label: "Inspect / metrics", category: "Reliability", description: "Sample payloads, throughput, latency and cardinality without changing the stream.", color: "#5c7080", inputs: [input("in", "Input", "Any")], outputs: [output("out", "Pass through", "Any")], defaults: { sampleRows: 10, capturePayload: true }, cost: "low" },
];

export const PORT_COLORS: Record<FlowValueType, string> = { ObjectSet: "#2b6cb0", TelemetryBatch: "#137cbd", Scalar: "#d9822b", Boolean: "#7157d9", Alert: "#c23030", Any: "#5c7080" };
export const getSpec = (t: FlowNodeType) => FLOW_NODES.find(n => n.type === t)!;

export function makeNode(type: FlowNodeType, x: number, y: number): FlowNodeDef {
  const s = getSpec(type);
  return { id: newId("fn"), type, name: s.label, x, y, config: structuredClone(s.defaults), retry: { attempts: 3, backoffMs: 250 } };
}
export function makeDemoFlow() {
  const nodes: FlowNodeDef[] = [
    { ...makeNode("telemetrySource", 80, 180), id: "flow-stream", name: "Plant telemetry · live", config: { plants: [], batchSize: 512, partitionBy: "deviceId", offset: "latest" } },
    { ...makeNode("window", 340, 180), id: "flow-window", name: "30s vibration window", config: { windowMs: 30000, slideMs: 5000, watermarkMs: 2000, lateEvents: "sideOutput", windowKind: "sliding" } },
    { ...makeNode("aggregate", 600, 180), id: "flow-wasm", name: "WASM vibration stats", config: { signal: "vibration", threshold: 11.5, kernel: "wasm:f32-window-stats", groupBy: ["plantId", "deviceId"] } },
    { ...makeNode("threshold", 860, 80), id: "flow-threshold", name: "Hysteresis · High", config: { field: "mean", high: 11.5, low: 9.5, debounceMs: 3000, severity: "High" } },
    { ...makeNode("alertOutput", 1120, 80), id: "flow-alert", name: "Emit operational alert", config: { severity: "High", actionType: "acknowledgeAlert" } },
    { ...makeNode("variableOutput", 860, 300), id: "flow-output", name: "Publish rolling statistics", config: { variableId: "liveTelemetryStats", mode: "replace" } },
    { ...makeNode("deadLetter", 600, 390), id: "flow-dlq", name: "Late / malformed events", config: { maxRecords: 10000, retry: true, ttlMs: 86400000 } },
  ];
  const edges: FlowEdgeDef[] = [
    { id: "fe1", source: "flow-stream", sourcePort: "batch", target: "flow-window", targetPort: "in" },
    { id: "fe2", source: "flow-window", sourcePort: "window", target: "flow-wasm", targetPort: "in" },
    { id: "fe3", source: "flow-wasm", sourcePort: "alerts", target: "flow-threshold", targetPort: "in" },
    { id: "fe4", source: "flow-threshold", sourcePort: "triggered", target: "flow-alert", targetPort: "in" },
    { id: "fe5", source: "flow-wasm", sourcePort: "stats", target: "flow-output", targetPort: "in" },
    { id: "fe6", source: "flow-window", sourcePort: "late", target: "flow-dlq", targetPort: "in" },
  ];
  return { id: "flow-telemetry", name: "Critical vibration detection", description: "Plant stream → event-time window → WebAssembly aggregation → hysteresis threshold → Ontology alert + variable output.", enabled: true, version: 4, nodes, edges, execution: { mode: "stream" as const, maxConcurrency: 8, checkpointEvery: 5000, errorPolicy: "deadLetter" as const, scheduleMs: 1000 } };
}
