"use client";
import React, { useContext, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { StoreCtx, useWS } from "../WorkshopContext";
import { beginDrag, dndStore, type Rect } from "../dnd";
import { clearLive, getZoom, hoverStore, setLive, useStore, viewStore } from "../runtimeStores";
import { flexOf, setFlex } from "../layoutOps";
import { Icon } from "../widgets/icons";

const ACCENT = "var(--fnd-accent)";

// ─── Drag layer: one portal, zero per-node components ──────────────────────
export function DragLayer() {
  const st = useStore(dndStore, s => s);
  if (!st.active || !st.payload || typeof document === "undefined") return null;
  const t = st.target;
  const box = (r: Rect, fill: string, extra: React.CSSProperties = {}) => (
    <div style={{ position: "fixed", left: r.x, top: r.y, width: r.w, height: r.h, pointerEvents: "none", ...extra, background: fill }}/>
  );
  return createPortal(
    <div style={{ position: "fixed", inset: 0, zIndex: 400, pointerEvents: "none" }} aria-hidden>
      {t?.kind === "insert" && (
        <>
          {box(t.line, ACCENT, { borderRadius: 2, boxShadow: "0 0 0 3px rgba(43,108,176,.25)" })}
          <div style={{ position: "fixed", left: t.line.x - 3, top: t.line.y - 3, width: 8, height: 8, borderRadius: 4, background: ACCENT, pointerEvents: "none" }}/>
          <div style={{ position: "fixed", left: t.line.x + t.line.w - 5, top: t.line.y + t.line.h - 5, width: 8, height: 8, borderRadius: 4, background: ACCENT, pointerEvents: "none" }}/>
        </>
      )}
      {(t?.kind === "into" || t?.kind === "wrap" || t?.kind === "swap") && box(t.rect, "rgba(43,108,176,.14)", { outline: `2px ${t.kind === "swap" ? "solid" : "dashed"} ${ACCENT}`, outlineOffset: -2, borderRadius: 3 })}
      {t?.kind === "swap" && (
        <div style={{ position: "fixed", left: t.rect.x + t.rect.w / 2 - 16, top: t.rect.y + t.rect.h / 2 - 16, width: 32, height: 32, borderRadius: 16, background: ACCENT, color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 }}>⇄</div>
      )}
      <div style={{ position: "fixed", left: st.x + 14, top: st.y + 14, background: "var(--fnd-text)", color: "var(--fnd-panel)", borderRadius: 3, padding: "4px 8px", fontSize: 11, fontWeight: 600, boxShadow: "0 4px 14px rgba(0,0,0,.25)", whiteSpace: "nowrap", maxWidth: 320, overflow: "hidden", textOverflow: "ellipsis" }}>
        ⠿ {st.payload.name}{t ? <span style={{ fontWeight: 400, opacity: 0.8 }}> → {t.label}</span> : <span style={{ fontWeight: 400, opacity: 0.6 }}> · move over a drop zone</span>}
      </div>
    </div>,
    document.body,
  );
}

// ─── Selection overlay (screen-space; never scaled by canvas zoom) ─────────
interface Box { x: number; y: number; w: number; h: number }
interface Measured { sel: Box | null; hover: Box | null; selMeta: { kind: string; parentId?: string; parentOrient?: string; index: number; siblings: number } | null }
const same = (a: Box | null, b: Box | null) => (!a && !b) || (!!a && !!b && Math.abs(a.x - b.x) < 0.5 && Math.abs(a.y - b.y) < 0.5 && Math.abs(a.w - b.w) < 0.5 && Math.abs(a.h - b.h) < 0.5);

export function SelectionOverlay({ rootRef }: { rootRef: React.RefObject<HTMLElement | null> }) {
  const selection = useWS(s => s.ui.selection);
  const name = useWS(s => {
    const id = s.ui.selection.id; if (!id) return "";
    return s.core.module.sections[id]?.name ?? s.core.module.widgets[id]?.name ?? "";
  });
  const typeLabel = useWS(s => { const id = s.ui.selection.id; return id ? (s.core.module.widgets[id]?.type ?? (s.core.module.sections[id] ? `section · ${s.core.module.sections[id].layout}` : "")) : ""; });
  const ui = useWS(s => s.ui);
  const updateModule = useWS(s => s.core.updateModule);
  const storeApi = useContext(StoreCtx)!;
  const hoverId = useStore(hoverStore, s => s.id);
  const dragging = useStore(dndStore, s => s.active);
  useStore(viewStore, s => s.zoom);

  const ref = useRef<HTMLDivElement>(null);
  const [m, setM] = useState<Measured>({ sel: null, hover: null, selMeta: null });
  const [resizeInfo, setResizeInfo] = useState<string | null>(null);
  const selId = selection.kind === "widget" || selection.kind === "section" ? selection.id : null;

  // measurement loop: cheap (≤ 2 rects/frame) and only commits state when something actually moved
  useEffect(() => {
    let raf = 0;
    const tick = () => {
      raf = requestAnimationFrame(tick);
      const root = rootRef.current, host = ref.current;
      if (!root || !host) return;
      const o = host.getBoundingClientRect();
      const find = (id: string | null) => id ? root.querySelector<HTMLElement>(`[data-node-id="${CSS.escape(id)}"]`) : null;
      const boxOf = (el: HTMLElement | null): Box | null => { if (!el) return null; const r = el.getBoundingClientRect(); return { x: r.left - o.left, y: r.top - o.top, w: r.width, h: r.height }; };
      const sEl = find(selId), hEl = hoverId && hoverId !== selId ? find(hoverId) : null;
      const sel = boxOf(sEl), hover = boxOf(hEl);
      let selMeta: Measured["selMeta"] = null;
      if (sEl) {
        const pid = sEl.dataset.parentId;
        const sibs = pid ? root.querySelectorAll(`[data-parent-id="${CSS.escape(pid)}"]`).length : 0;
        selMeta = { kind: sEl.dataset.nodeKind ?? "widget", parentId: pid, parentOrient: sEl.dataset.parentOrient, index: Number(sEl.dataset.index ?? 0), siblings: sibs };
      }
      setM(prev => same(prev.sel, sel) && same(prev.hover, hover) && prev.selMeta?.index === selMeta?.index && prev.selMeta?.siblings === selMeta?.siblings && prev.selMeta?.parentOrient === selMeta?.parentOrient && prev.selMeta?.kind === selMeta?.kind ? prev : { sel, hover, selMeta });
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [rootRef, selId, hoverId]);

  // ── resizing ──
  const nodeEl = () => (selId ? rootRef.current?.querySelector<HTMLElement>(`[data-node-id="${CSS.escape(selId)}"]`) ?? null : null);

  const startHeight = (e: React.PointerEvent) => {
    if (!selId) return;
    e.preventDefault(); e.stopPropagation();
    const el = nodeEl(); if (!el) return;
    const z = getZoom(), sy = e.clientY, start = el.offsetHeight;
    let h = start;
    const move = (ev: PointerEvent) => { h = Math.max(40, Math.round(start + (ev.clientY - sy) / z)); setLive(selId, { height: h }); setResizeInfo(`${el.offsetWidth} × ${h}px`); };
    const up = () => {
      window.removeEventListener("pointermove", move); window.removeEventListener("pointerup", up);
      updateModule(mod => mod.sections[selId]
        ? { ...mod, sections: { ...mod.sections, [selId]: { ...mod.sections[selId], height: `${h}px` } } }
        : { ...mod, widgets: { ...mod.widgets, [selId]: { ...mod.widgets[selId], height: h } } }, "resize height");
      clearLive([selId]); setResizeInfo(null);
    };
    window.addEventListener("pointermove", move); window.addEventListener("pointerup", up);
  };
  const resetHeight = () => { if (selId) updateModule(mod => mod.sections[selId] ? { ...mod, sections: { ...mod.sections, [selId]: { ...mod.sections[selId], height: undefined } } } : { ...mod, widgets: { ...mod.widgets, [selId]: { ...mod.widgets[selId], height: undefined } } }, "resize height"); };

  /** Drag the boundary between sibling `a` (left) and `b` (right). */
  const startSplit = (e: React.PointerEvent, side: "right" | "left") => {
    if (!selId || !m.selMeta?.parentId) return;
    e.preventDefault(); e.stopPropagation();
    const root = rootRef.current; if (!root) return;
    const sibs = Array.from(root.querySelectorAll<HTMLElement>(`[data-parent-id="${CSS.escape(m.selMeta.parentId)}"]`));
    const idx = sibs.findIndex(s => s.dataset.nodeId === selId);
    const ai = side === "right" ? idx : idx - 1, bi = ai + 1;
    const aEl = sibs[ai], bEl = sibs[bi]; if (!aEl || !bEl) return;
    const aId = aEl.dataset.nodeId!, bId = bEl.dataset.nodeId!;
    const z = getZoom(), sx = e.clientX;
    const wa = aEl.offsetWidth, wb = bEl.offsetWidth, pair = wa + wb;
    const readNode = (id: string) => { const mod = storeApi.getSnapshot().core.module; return { fixed: mod.sections[id]?.width !== undefined, flex: flexOf(mod, id) }; };
    const A = readNode(aId), B = readNode(bId);
    let result: { a?: number; b?: number; aw?: number; bw?: number } = {};
    const move = (ev: PointerEvent) => {
      const d = (ev.clientX - sx) / z;
      if (A.fixed) { const w = Math.max(80, Math.round(wa + d)); result = { aw: w }; setLive(aId, { width: w }); setResizeInfo(`${w}px`); }
      else if (B.fixed) { const w = Math.max(80, Math.round(wb - d)); result = { bw: w }; setLive(bId, { width: w }); setResizeInfo(`${w}px`); }
      else {
        const na = Math.min(pair - 80, Math.max(80, wa + d));
        const total = A.flex + B.flex, fa = (total * na) / pair, fb = total - fa;
        result = { a: fa, b: fb }; setLive(aId, { flex: fa }); setLive(bId, { flex: fb });
        setResizeInfo(`${Math.round((na / pair) * 100)}% / ${Math.round(100 - (na / pair) * 100)}%`);
      }
    };
    const up = () => {
      window.removeEventListener("pointermove", move); window.removeEventListener("pointerup", up);
      updateModule(mod => {
        let next = mod;
        if (result.aw) next = { ...next, sections: { ...next.sections, [aId]: { ...next.sections[aId], width: `${result.aw}px` } } };
        if (result.bw) next = { ...next, sections: { ...next.sections, [bId]: { ...next.sections[bId], width: `${result.bw}px` } } };
        if (result.a !== undefined && result.b !== undefined) next = setFlex(setFlex(next, aId, Math.round(result.a * 1000) / 1000), bId, Math.round(result.b * 1000) / 1000);
        return next;
      }, "resize");
      clearLive([aId, bId]); setResizeInfo(null);
    };
    window.addEventListener("pointermove", move); window.addEventListener("pointerup", up);
  };
  const equalizePair = (side: "right" | "left") => {
    if (!selId || !m.selMeta?.parentId) return;
    const root = rootRef.current; if (!root) return;
    const sibs = Array.from(root.querySelectorAll<HTMLElement>(`[data-parent-id="${CSS.escape(m.selMeta.parentId)}"]`));
    const idx = sibs.findIndex(s => s.dataset.nodeId === selId);
    const a = sibs[side === "right" ? idx : idx - 1]?.dataset.nodeId, b = sibs[side === "right" ? idx + 1 : idx]?.dataset.nodeId;
    if (a && b) updateModule(mod => setFlex(setFlex(mod, a, 1), b, 1), "resize");
  };

  const meta = m.selMeta;
  const horiz = meta?.parentOrient === "h";
  const canRight = !!meta?.parentId && horiz && meta.index < meta.siblings - 1;
  const canLeft = !!meta?.parentId && horiz && meta.index === meta.siblings - 1 && meta.siblings > 1;
  const chipTop = m.sel ? (m.sel.y < 30 ? m.sel.y + 4 : m.sel.y - 26) : 0;

  return (
    <div ref={ref} style={{ position: "absolute", inset: 0, pointerEvents: "none", overflow: "hidden", zIndex: 20 }}>
      {m.hover && !dragging && <div style={{ position: "absolute", left: m.hover.x, top: m.hover.y, width: m.hover.w, height: m.hover.h, outline: "1px solid rgba(43,108,176,.55)", outlineOffset: -1, background: "rgba(43,108,176,.04)" }}/>}
      {m.sel && (
        <>
          <div style={{ position: "absolute", left: m.sel.x, top: m.sel.y, width: m.sel.w, height: m.sel.h, outline: `2px solid ${ACCENT}`, outlineOffset: -1, opacity: dragging ? 0.45 : 1 }}/>
          {!dragging && (
            <>
              <div style={{ position: "absolute", left: Math.max(2, Math.min(m.sel.x, (ref.current?.clientWidth ?? 800) - 330)), top: chipTop, height: 22, display: "flex", alignItems: "center", gap: 2, background: ACCENT, color: "#fff", borderRadius: 3, padding: "0 3px", pointerEvents: "auto", fontSize: 11, boxShadow: "0 2px 6px rgba(0,0,0,.2)" }}>
                {selection.id && (
                  <span title="Drag to move" onPointerDown={e => beginDrag({ kind: "move", childKind: selection.kind === "section" ? "section" : "widget", id: selection.id!, name }, e.nativeEvent)}
                    style={{ cursor: "grab", padding: "0 4px", fontSize: 13, lineHeight: "22px", touchAction: "none", userSelect: "none" }}>⠿</span>
                )}
                <span style={{ fontWeight: 600, maxWidth: 140, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{name}</span>
                <span style={{ opacity: 0.75, fontSize: 10, marginRight: 2 }}>{typeLabel}</span>
                <ChipBtn title={horiz ? "Move left (Alt+←)" : "Move up (Alt+↑)"} disabled={!meta || meta.index === 0} onClick={() => ui.moveSiblingSel(-1)}>{horiz ? "◀" : "▲"}</ChipBtn>
                <ChipBtn title={horiz ? "Move right (Alt+→)" : "Move down (Alt+↓)"} disabled={!meta || meta.index >= meta.siblings - 1} onClick={() => ui.moveSiblingSel(1)}>{horiz ? "▶" : "▼"}</ChipBtn>
                <ChipBtn title="Group into a row (⌘G)" onClick={() => ui.groupSel("columns")}>▥</ChipBtn>
                <ChipBtn title="Duplicate (⌘D)" onClick={ui.duplicateSel}><Icon.Copy size={11}/></ChipBtn>
                <ChipBtn title="Delete (⌫)" onClick={ui.deleteSel}><Icon.Trash size={11}/></ChipBtn>
              </div>
              {(canRight || canLeft) && (
                <div role="separator" aria-orientation="vertical" aria-label="Resize" title="Drag to resize · double-click to equalise"
                  onPointerDown={e => startSplit(e, canRight ? "right" : "left")} onDoubleClick={() => equalizePair(canRight ? "right" : "left")}
                  style={{ position: "absolute", left: (canRight ? m.sel.x + m.sel.w : m.sel.x) - 5, top: m.sel.y, width: 10, height: m.sel.h, cursor: "col-resize", pointerEvents: "auto", display: "flex", alignItems: "center", justifyContent: "center", touchAction: "none" }}>
                  <div style={{ width: 4, height: Math.min(48, m.sel.h), borderRadius: 2, background: ACCENT, boxShadow: "0 0 0 2px #fff" }}/>
                </div>
              )}
              <div role="separator" aria-orientation="horizontal" aria-label="Resize height" title="Drag to set height · double-click for auto"
                onPointerDown={startHeight} onDoubleClick={resetHeight}
                style={{ position: "absolute", left: m.sel.x, top: m.sel.y + m.sel.h - 5, width: m.sel.w, height: 10, cursor: "row-resize", pointerEvents: "auto", display: "flex", justifyContent: "center", alignItems: "center", touchAction: "none" }}>
                <div style={{ height: 4, width: Math.min(48, m.sel.w), borderRadius: 2, background: ACCENT, boxShadow: "0 0 0 2px #fff" }}/>
              </div>
            </>
          )}
          {resizeInfo && <div style={{ position: "absolute", left: m.sel.x + m.sel.w / 2 - 40, top: m.sel.y + m.sel.h / 2 - 11, background: "var(--fnd-text)", color: "var(--fnd-panel)", borderRadius: 3, padding: "3px 8px", fontSize: 11, fontWeight: 600 }}>{resizeInfo}</div>}
        </>
      )}
    </div>
  );
}

function ChipBtn({ children, title, onClick, disabled }: { children: React.ReactNode; title: string; onClick: () => void; disabled?: boolean }) {
  return (
    <button title={title} aria-label={title} disabled={disabled} onClick={e => { e.stopPropagation(); onClick(); }}
      style={{ width: 20, height: 18, borderRadius: 2, color: "#fff", opacity: disabled ? 0.35 : 1, cursor: disabled ? "not-allowed" : "pointer", fontSize: 10, display: "flex", alignItems: "center", justifyContent: "center", background: "transparent", border: 0 }}
      onMouseEnter={e => { if (!disabled) e.currentTarget.style.background = "rgba(255,255,255,.22)"; }} onMouseLeave={e => { e.currentTarget.style.background = "transparent"; }}>
      {children}
    </button>
  );
}
