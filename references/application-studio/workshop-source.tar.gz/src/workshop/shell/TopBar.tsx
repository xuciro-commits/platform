"use client";
import React from "react";
import Link from "next/link";
import { useWorkshop } from "../WorkshopContext";
import { Icon } from "../widgets/icons";

export function TopBar() {
  const w = useWorkshop();
  const { module, undo, redo, canUndo, canRedo, undoLabel, redoLabel, saveState, retrySave, mode, setMode, publish, publishedVersion, isDirtySincePublish, toggleTheme, theme, openContextMenu, setCommandOpen, setLeftPanel, snapshot } = w;

  const moreMenu = (e: React.MouseEvent) => {
    const r = (e.currentTarget as HTMLElement).getBoundingClientRect();
    openContextMenu(r.right - 220, r.bottom + 2, [
      { label: "Take snapshot", onClick: () => snapshot(`v${Date.now().toString().slice(-4)}`) },
      { label: "Command palette", shortcut: "⌘K", onClick: () => setCommandOpen(true) },
      { separator: true, label: "" },
      { label: "Open changelog", onClick: () => setLeftPanel("changelog") },
      { label: "Open profiler", onClick: () => setLeftPanel("profiler") },
      { label: "Export / import module…", onClick: () => setLeftPanel("settings") },
      { separator: true, label: "" },
      { label: "Back to Foundry home", onClick: () => { window.location.href = "/"; } },
    ]);
  };

  return (
    <div className="flex items-center gap-2 px-2 border-b fnd-border" style={{ height: 44, background: "var(--fnd-panel)", flexShrink: 0 }}>
      <Link href="/" className="fnd-btn fnd-btn-minimal" style={{ fontWeight: 700 }} title="Foundry home">
        <span style={{ width: 20, height: 20, background: "var(--fnd-text)", color: "var(--fnd-panel)", display: "inline-flex", alignItems: "center", justifyContent: "center", borderRadius: 2, fontSize: 11, fontWeight: 800 }}>F</span>
        <span className="hidden md:inline">Foundry</span>
      </Link>
      <span className="fnd-text-dim hidden lg:inline">/</span>
      <span className="text-xs hidden lg:inline">Workshop</span>
      <span className="fnd-text-dim">/</span>
      <input aria-label="Module name" className="text-xs font-semibold bg-transparent truncate" style={{ border: "1px solid transparent", borderRadius: 3, padding: "2px 4px", width: "clamp(110px, 18vw, 240px)", color: "var(--fnd-text)" }}
        value={module.name} onChange={e => w.updateModule(m => ({ ...m, name: e.target.value }), "edit module")} onFocus={e => (e.currentTarget.style.borderColor = "var(--fnd-accent)")} onBlur={e => (e.currentTarget.style.borderColor = "transparent")}/>
      <span className="fnd-tag hidden md:inline-flex">main</span>
      <span className="fnd-tag hidden md:inline-flex" style={publishedVersion && !isDirtySincePublish ? { background: "#e4f1e5", color: "#296936", borderColor: "transparent" } : { background: "#fdf1dc", color: "#8a5a16", borderColor: "transparent" }}>
        {publishedVersion ? (isDirtySincePublish ? `v${publishedVersion} + draft` : `Published v${publishedVersion}`) : "Draft"}
      </span>
      <SaveChip state={saveState} onRetry={retrySave}/>
      <div className="flex-1"/>
      <button className="fnd-btn fnd-btn-minimal" title={canUndo ? `Undo ${undoLabel} (⌘Z)` : "Nothing to undo"} aria-label="Undo" disabled={!canUndo} onClick={undo}><Icon.Undo size={14}/></button>
      <button className="fnd-btn fnd-btn-minimal" title={canRedo ? `Redo ${redoLabel} (⌘⇧Z)` : "Nothing to redo"} aria-label="Redo" disabled={!canRedo} onClick={redo}><Icon.Redo size={14}/></button>
      <div style={{ width: 1, height: 18, background: "var(--fnd-border)" }}/>
      <div className="flex items-center" style={{ border: "1px solid var(--fnd-border-strong)", borderRadius: 3 }} role="group" aria-label="Mode">
        <button className={`fnd-btn fnd-btn-minimal ${mode === "builder" ? "fnd-selected" : ""}`} aria-pressed={mode === "builder"} style={{ borderRadius: 0, borderRight: "1px solid var(--fnd-border)" }} onClick={() => setMode("builder")}><Icon.Edit size={12}/> Edit</button>
        <button className={`fnd-btn fnd-btn-minimal ${mode === "runtime" ? "fnd-selected" : ""}`} aria-pressed={mode === "runtime"} style={{ borderRadius: 0 }} onClick={() => setMode("runtime")}><Icon.Eye size={12}/> View</button>
      </div>
      <button className="fnd-btn fnd-btn-minimal" title="Toggle theme" aria-label="Toggle theme" onClick={toggleTheme}>{theme === "light" ? "☾" : "☀"}</button>
      <button className="fnd-btn fnd-btn-primary" title="Publish the current draft as a new version" onClick={publish} disabled={!!publishedVersion && !isDirtySincePublish}><Icon.Play size={12}/> Publish</button>
      <button className="fnd-btn fnd-btn-minimal" title="More" aria-label="More actions" aria-haspopup="menu" onClick={moreMenu}><Icon.More size={14}/></button>
    </div>
  );
}

function SaveChip({ state, onRetry }: { state: string; onRetry: () => void }) {
  const map: Record<string, { label: string; color: string }> = {
    saved: { label: "Saved", color: "var(--fnd-success)" }, saving: { label: "Saving…", color: "var(--fnd-info)" },
    unsaved: { label: "Unsaved changes", color: "var(--fnd-warning)" }, failed: { label: "Save failed — retry", color: "var(--fnd-danger)" },
  };
  const s = map[state] ?? map.saved;
  return (
    <button className="ml-1 flex items-center gap-1 text-[11px] fnd-text-muted" disabled={state !== "failed"} onClick={onRetry} title={state === "failed" ? "Click to retry saving" : s.label} aria-live="polite" style={{ cursor: state === "failed" ? "pointer" : "default" }}>
      <span className={state === "saving" ? "fnd-pulse" : ""} style={{ width: 7, height: 7, background: s.color, borderRadius: "50%" }}/>
      <span className="hidden sm:inline">{s.label}</span>
    </button>
  );
}
