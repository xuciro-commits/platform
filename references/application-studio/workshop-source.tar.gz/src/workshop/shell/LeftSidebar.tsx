"use client";
import React from "react";
import { useWorkshop } from "../WorkshopContext";
import { Icon } from "../widgets/icons";
import { OverviewPanel, SettingsPanel, ProfilerPanel, ChangelogPanel } from "../panels/OtherPanels";
import { LayoutTree } from "../panels/LayoutTree";
import { VariablesPanel } from "../panels/VariablesPanel";
import { WidgetsPalette } from "../panels/WidgetsPalette";
import { OntologyNav } from "../panels/OntologyManager";
import { FlowNav } from "../panels/FlowNav";

const NAV = [
  { key: "overview", label: "Overview", icon: <Icon.Flow size={13}/> },
  { key: "layout", label: "Layout", icon: <Icon.Section size={13}/> },
  { key: "widgets", label: "Widgets", icon: <Icon.Plus size={13}/> },
  { key: "variables", label: "Variables", icon: <Icon.Variable size={13}/> },
  { key: "ontology", label: "Ontology", icon: <Icon.Diagram size={13}/> },
  { key: "flows", label: "Flows", icon: <Icon.Flow size={13}/> },
  { key: "settings", label: "Settings", icon: <Icon.Settings size={13}/> },
  { key: "profiler", label: "Profiler", icon: <Icon.Chart size={13}/> },
  { key: "changelog", label: "Changes", icon: <Icon.Timeline size={13}/> },
] as const;

export function LeftSidebar() {
  const { leftPanel, setLeftPanel } = useWorkshop();
  return (
    <div className="flex h-full">
      <div className="flex flex-col items-center border-r fnd-border" style={{ width: 48, background: "var(--fnd-panel)" }}>
        {NAV.map(n => (
          <button key={n.key} onClick={() => setLeftPanel(n.key)}
            title={n.label}
            className="w-full flex flex-col items-center justify-center"
            style={{
              height: 46, border: 0, cursor: "pointer",
              background: leftPanel === n.key ? "var(--fnd-selection)" : "transparent",
              color: leftPanel === n.key ? "var(--fnd-accent)" : "var(--fnd-text-muted)",
              borderLeft: leftPanel === n.key ? "2px solid var(--fnd-accent)" : "2px solid transparent",
            }}>
            {n.icon}
            <span style={{ fontSize: 9, marginTop: 3 }}>{n.label}</span>
          </button>
        ))}
      </div>
      <div className="flex-1 flex flex-col overflow-hidden min-w-0" style={{ background: "var(--fnd-panel)" }}>
        {leftPanel === "overview" && <OverviewPanel/>}
        {leftPanel === "layout" && <LayoutTree/>}
        {leftPanel === "widgets" && <WidgetsPalette/>}
        {leftPanel === "variables" && <VariablesPanel/>}
        {leftPanel === "ontology" && <OntologyNav/>}
        {leftPanel === "flows" && <FlowNav/>}
        {leftPanel === "settings" && <SettingsPanel/>}
        {leftPanel === "profiler" && <ProfilerPanel/>}
        {leftPanel === "changelog" && <ChangelogPanel/>}
      </div>
    </div>
  );
}
