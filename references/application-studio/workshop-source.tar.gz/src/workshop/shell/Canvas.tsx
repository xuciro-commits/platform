"use client";
import React, { useCallback, useContext, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { StoreCtx, useWS, useWSShallow } from "../WorkshopContext";
import { SectionView } from "../widgets/SectionRenderer";
import { Icon } from "../widgets/icons";
import { WidgetSelector } from "../panels/WidgetSelector";
import { RuntimeHeader } from "../runtime/RuntimeShell";
import { DragLayer, SelectionOverlay } from "./CanvasChrome";
import { DEVICES, MAX_ZOOM, MIN_ZOOM, clampZoom, hoverStore, useStore, viewStore } from "../runtimeStores";
import { leavesOf, pathTo, preferredSize, applyPackedRows, arrangeSection, type ArrangePreset } from "../layoutOps";
import { packRows } from "../elk";
import { dndStore } from "../dnd";
import type { WidgetType } from "../types";

const PAD = 32;
export const CONTENT_MAX = 1680;

export function Canvas() {
  const pages = useWS(s => s.core.module.pages);
  const pageId = useWS(s => s.core.currentPageId);
  const rootId = useWS(s => (s.core.module.pages.find(p => p.id === s.core.currentPageId) ?? s.core.module.pages[0])?.rootSectionId ?? "");
  const sectionCount = useWS(s => Object.keys(s.core.module.sections).length);
  const module = useWS(s => s.core.module);
  const selection = useWS(s => s.ui.selection);
  const ui = useWS(s => s.ui);
  const core = useWSShallow(s => ({ updateModule: s.core.updateModule, pushToast: s.core.pushToast, openContextMenu: s.core.openContextMenu, setCurrentPageId: s.core.setCurrentPageId }));
  const storeApi = useContext(StoreCtx)!;
  const view = useStore(viewStore, s => s);
  const device = DEVICES.find(d => d.id === view.deviceId) ?? DEVICES[0];

  const [showAdd, setShowAdd] = useState(false);
  const [renaming, setRenaming] = useState<string | null>(null);
  const [spaceDown, setSpaceDown] = useState(false);
  const [panning, setPanning] = useState(false);
  const [box, setBox] = useState({ w: 900, h: 600 });
  const [contentH, setContentH] = useState(600);
  const [arranging, setArranging] = useState(false);
  const scroller = useRef<HTMLDivElement>(null);
  const stage = useRef<HTMLDivElement>(null);
  const frame = useRef<HTMLDivElement>(null);

  // measure viewport + stage content
  useLayoutEffect(() => {
    const sc = scroller.current, st = stage.current; if (!sc || !st) return;
    const a = new ResizeObserver(() => setBox({ w: sc.clientWidth, h: sc.clientHeight }));
    const b = new ResizeObserver(() => setContentH(st.offsetHeight));
    a.observe(sc); b.observe(st);
    setBox({ w: sc.clientWidth, h: sc.clientHeight }); setContentH(st.offsetHeight);
    return () => { a.disconnect(); b.disconnect(); };
  }, []);

  const zoom = view.zoom;
  const stageW = device.width ?? Math.max(320, Math.floor((box.w - PAD * 2) / zoom));
  const wrapW = Math.max(box.w, stageW * zoom + PAD * 2);
  const wrapH = Math.max(box.h, contentH * zoom + PAD * 2);
  const left = Math.max(PAD, (wrapW - stageW * zoom) / 2);

  const setZoom = useCallback((z: number, focus?: { px: number; py: number }) => {
    const sc = scroller.current, st = stage.current;
    const next = clampZoom(z), prev = viewStore.get().zoom;
    if (next === prev) return;
    if (sc && st && focus) {
      const cx = (sc.scrollLeft + focus.px - st.offsetLeft) / prev, cy = (sc.scrollTop + focus.py - st.offsetTop) / prev;
      viewStore.set(v => ({ ...v, zoom: next }));
      requestAnimationFrame(() => { sc.scrollLeft = cx * next + st.offsetLeft - focus.px; sc.scrollTop = cy * next + st.offsetTop - focus.py; });
    } else viewStore.set(v => ({ ...v, zoom: next }));
  }, []);
  const fitWidth = useCallback(() => { const w = device.width ?? 1; setZoom(device.width ? (box.w - PAD * 2) / w : 1); }, [device.width, box.w, setZoom]);
  const fitAll = useCallback(() => { const w = device.width ?? stageW; setZoom(Math.min((box.w - PAD * 2) / w, (box.h - PAD * 2) / Math.max(400, contentH))); }, [device.width, stageW, box, contentH, setZoom]);
  const pickDevice = (id: string) => {
    const d = DEVICES.find(x => x.id === id)!;
    viewStore.set(v => ({ ...v, deviceId: id, zoom: d.width ? clampZoom(Math.min(1, (box.w - PAD * 2) / d.width)) : 1 }));
  };

  // ctrl/⌘ + wheel (and trackpad pinch) zooms around the cursor
  useEffect(() => {
    const sc = scroller.current; if (!sc) return;
    const onWheel = (e: WheelEvent) => {
      if (!(e.ctrlKey || e.metaKey)) return;
      e.preventDefault();
      const r = sc.getBoundingClientRect();
      setZoom(viewStore.get().zoom * Math.exp(-e.deltaY * 0.0022), { px: e.clientX - r.left, py: e.clientY - r.top });
    };
    sc.addEventListener("wheel", onWheel, { passive: false });
    return () => sc.removeEventListener("wheel", onWheel);
  }, [setZoom]);

  // keyboard: zoom shortcuts + space-to-pan
  useEffect(() => {
    const inField = (t: EventTarget | null) => { const el = t as HTMLElement | null; return !!el && (el.tagName === "INPUT" || el.tagName === "TEXTAREA" || el.tagName === "SELECT" || el.isContentEditable); };
    const down = (e: KeyboardEvent) => {
      if (inField(e.target)) return;
      const meta = e.metaKey || e.ctrlKey;
      if (e.code === "Space" && !e.repeat) { setSpaceDown(true); e.preventDefault(); }
      else if (meta && (e.key === "=" || e.key === "+")) { e.preventDefault(); setZoom(viewStore.get().zoom * 1.2); }
      else if (meta && e.key === "-") { e.preventDefault(); setZoom(viewStore.get().zoom / 1.2); }
      else if (meta && e.key === "0") { e.preventDefault(); setZoom(1); }
      else if (meta && e.key === "1") { e.preventDefault(); fitAll(); }
    };
    const up = (e: KeyboardEvent) => { if (e.code === "Space") setSpaceDown(false); };
    window.addEventListener("keydown", down); window.addEventListener("keyup", up);
    return () => { window.removeEventListener("keydown", down); window.removeEventListener("keyup", up); };
  }, [setZoom, fitAll]);

  const nodeAt = (t: EventTarget | null) => ((t as HTMLElement | null)?.closest?.("[data-node-id]") as HTMLElement | null);

  const onPointerDown = (e: React.PointerEvent) => {
    const sc = scroller.current; if (!sc) return;
    if (spaceDown || view.handTool || e.button === 1) {
      e.preventDefault();
      const sx = e.clientX, sy = e.clientY, ox = sc.scrollLeft, oy = sc.scrollTop;
      setPanning(true);
      const move = (ev: PointerEvent) => { sc.scrollLeft = ox - (ev.clientX - sx); sc.scrollTop = oy - (ev.clientY - sy); };
      const upH = () => { setPanning(false); window.removeEventListener("pointermove", move); window.removeEventListener("pointerup", upH); };
      window.addEventListener("pointermove", move); window.addEventListener("pointerup", upH);
      return;
    }
    if (e.button !== 0) return;
    const n = nodeAt(e.target);
    if (n) ui.select({ kind: n.dataset.nodeKind === "section" ? "section" : "widget", id: n.dataset.nodeId! });
    else ui.select({ kind: null, id: null });
  };
  const onPointerMove = (e: React.PointerEvent) => {
    if (dndStore.get().active || panning) return;
    const n = nodeAt(e.target);
    hoverStore.set({ id: n?.dataset.nodeId ?? null });
  };

  const targetSection = () => {
    const m = storeApi.getSnapshot().core.module;
    const s = storeApi.getSnapshot().ui.selection;
    if (s.kind === "section" && s.id) return s.id;
    if (s.kind === "widget" && s.id) { const p = pathTo(m, s.id); if (p.length > 1) return p[p.length - 2].id; }
    return rootId;
  };

  const arrangeElk = async () => {
    const sid = targetSection();
    const m = storeApi.getSnapshot().core.module;
    const sec = m.sections[sid];
    if (!sec || sec.layout === "tabs") { core.pushToast({ kind: "warning", message: "Auto-arrange isn't available for tab sections." }); return; }
    const units = leavesOf(m, sec.children);
    if (units.length < 2) { core.pushToast({ kind: "info", message: "Add at least two widgets to arrange." }); return; }
    setArranging(true);
    try {
      const rows = await packRows(units.map(u => ({ id: u.id, ...preferredSize(m, u) })), Math.min(stageW, CONTENT_MAX) - 40);
      core.updateModule(mm => applyPackedRows(mm, sid, rows), "arrange ELK");
      core.pushToast({ kind: "success", message: `Arranged ${units.length} items into ${rows.length} row(s) with ELK` });
    } catch (e) {
      core.updateModule(mm => arrangeSection(mm, sid, "smart"), "arrange smart");
      core.pushToast({ kind: "warning", message: `ELK unavailable (${(e as Error).message}) — used smart arrange` });
    } finally { setArranging(false); }
  };

  const arrangeMenu = (x: number, y: number) => {
    const items: Array<{ label: string; preset: ArrangePreset }> = [
      { label: "Smart (controls on top, widgets balanced)", preset: "smart" }, { label: "Stack vertically", preset: "stack" },
      { label: "2 columns", preset: "columns-2" }, { label: "3 columns", preset: "columns-3" },
      { label: "Master / detail (1 : 3 : 2)", preset: "master-detail" }, { label: "Equalise sizes", preset: "equalize" },
    ];
    core.openContextMenu(x, y, [
      { label: "Pack with ELK (rectpacking)", onClick: () => void arrangeElk() },
      { separator: true, label: "" },
      ...items.map(i => ({ label: i.label, onClick: () => ui.arrangeSel(i.preset) })),
      { separator: true, label: "" },
      { label: "Group selection into row  ⌘G", onClick: () => ui.groupSel("columns") },
      { label: "Group selection into column", onClick: () => ui.groupSel("rows") },
      { label: "Ungroup section  ⌘⇧G", onClick: ui.ungroupSel },
      { label: "Move out one level  Alt+⇧+←", onClick: ui.outdentSel },
      { label: "Move into previous section  Alt+⇧+→", onClick: ui.indentSel },
    ]);
  };

  const nodeMenu = (e: React.MouseEvent) => {
    const n = nodeAt(e.target);
    if (!n) return;
    e.preventDefault();
    const kind = n.dataset.nodeKind === "section" ? "section" : "widget";
    ui.select({ kind, id: n.dataset.nodeId! });
    core.openContextMenu(e.clientX, e.clientY, [
      { label: "Duplicate", shortcut: "⌘D", onClick: ui.duplicateSel },
      { label: "Copy", shortcut: "⌘C", onClick: ui.copySel },
      { label: "Paste into", shortcut: "⌘V", disabled: !ui.clipboard, onClick: () => ui.pasteSel(kind === "section" ? n.dataset.nodeId : undefined) },
      { separator: true, label: "" },
      { label: "Move earlier", shortcut: "Alt+←/↑", onClick: () => ui.moveSiblingSel(-1) },
      { label: "Move later", shortcut: "Alt+→/↓", onClick: () => ui.moveSiblingSel(1) },
      { label: "Group into row", shortcut: "⌘G", onClick: () => ui.groupSel("columns") },
      { label: "Group into column", onClick: () => ui.groupSel("rows") },
      ...(kind === "section" ? [{ label: "Ungroup", shortcut: "⌘⇧G", onClick: ui.ungroupSel }, { label: "Arrange…", onClick: () => arrangeMenu(e.clientX, e.clientY) }] : [{ label: "Make unused", onClick: ui.makeUnusedSel }]),
      { separator: true, label: "" },
      { label: "Delete", danger: true, shortcut: "⌫", onClick: ui.deleteSel },
    ]);
  };

  const zoomMenu = (e: React.MouseEvent) => {
    const r = (e.currentTarget as HTMLElement).getBoundingClientRect();
    core.openContextMenu(r.left, r.bottom + 2, [
      ...[0.25, 0.5, 0.75, 1, 1.25, 1.5, 2].map(z => ({ label: `${Math.abs(zoom - z) < 0.005 ? "✓ " : "   "}${Math.round(z * 100)}%`, onClick: () => setZoom(z) })),
      { separator: true, label: "" },
      { label: "Fit width", onClick: fitWidth },
      { label: "Fit page  ⌘1", onClick: fitAll },
      { label: "Reset  ⌘0", onClick: () => setZoom(1) },
    ]);
  };

  const path = useMemo(() => (selection.id && (selection.kind === "widget" || selection.kind === "section") ? pathTo(module, selection.id) : []), [module, selection]);
  const isNodeSel = selection.kind === "widget" || selection.kind === "section";

  const commitRename = (id: string, name: string) => {
    setRenaming(null);
    const n = name.trim();
    if (n) core.updateModule(m => ({ ...m, pages: m.pages.map(p => (p.id === id ? { ...p, name: n } : p)) }), "rename page");
  };

  return (
    <div className="h-full flex flex-col overflow-hidden" style={{ background: "var(--fnd-bg)" }}>
      {/* row 1 — pages · device · zoom */}
      <div className="flex items-center gap-2 border-b fnd-border px-2" style={{ height: 36, background: "var(--fnd-panel)", flexShrink: 0 }}>
        <div className="flex items-center gap-0.5 overflow-x-auto min-w-0" role="tablist" aria-label="Pages">
          {pages.map(p => (
            renaming === p.id ? (
              <input key={p.id} autoFocus className="fnd-input" style={{ width: 130, height: 24 }} defaultValue={p.name} aria-label="Page name"
                onBlur={e => commitRename(p.id, e.target.value)} onKeyDown={e => { if (e.key === "Enter") commitRename(p.id, (e.target as HTMLInputElement).value); if (e.key === "Escape") setRenaming(null); }}/>
            ) : (
              <button key={p.id} role="tab" aria-selected={p.id === pageId} title="Double-click to rename · right-click for more"
                onClick={() => { core.setCurrentPageId(p.id); ui.select({ kind: "page", id: p.id }); }} onDoubleClick={() => setRenaming(p.id)}
                onContextMenu={e => {
                  e.preventDefault();
                  core.openContextMenu(e.clientX, e.clientY, [
                    { label: "Rename", onClick: () => setRenaming(p.id) },
                    { label: "New page", onClick: () => ui.addNewPage() },
                    { separator: true, label: "" },
                    { label: "Delete page", danger: true, disabled: pages.length <= 1, onClick: () => { ui.select({ kind: "page", id: p.id }); ui.deleteSel(); } },
                  ]);
                }}
                className="px-2.5 py-1 text-xs font-medium rounded-sm whitespace-nowrap"
                style={{ background: p.id === pageId ? "var(--fnd-selection)" : "transparent", color: p.id === pageId ? "var(--fnd-accent)" : "var(--fnd-text-muted)" }}>{p.name}</button>
            )
          ))}
          <button className="fnd-btn fnd-btn-minimal" style={{ height: 24 }} title="Add page" aria-label="Add page" onClick={() => ui.addNewPage()}><Icon.Plus size={12}/></button>
        </div>
        <div className="flex-1"/>
        <select className="fnd-input fnd-select" style={{ width: 186, height: 24 }} value={device.id} onChange={e => pickDevice(e.target.value)} aria-label="Preview device / viewport">
          {(["Fluid", "Desktop", "Tablet", "Mobile"] as const).map(g => (
            <optgroup key={g} label={g}>{DEVICES.filter(d => d.group === g).map(d => <option key={d.id} value={d.id}>{d.label}</option>)}</optgroup>
          ))}
        </select>
        <div className="flex items-center" style={{ border: "1px solid var(--fnd-border-strong)", borderRadius: 3 }}>
          <button className="fnd-btn fnd-btn-minimal" style={{ height: 22, borderRadius: 0 }} title="Zoom out (⌘−)" aria-label="Zoom out" disabled={zoom <= MIN_ZOOM} onClick={() => setZoom(zoom / 1.2)}><Icon.Minus size={11}/></button>
          <button className="fnd-btn fnd-btn-minimal" style={{ height: 22, borderRadius: 0, width: 54, justifyContent: "center", fontVariantNumeric: "tabular-nums" }} title="Zoom presets" aria-haspopup="menu" onClick={zoomMenu}>{Math.round(zoom * 100)}%</button>
          <button className="fnd-btn fnd-btn-minimal" style={{ height: 22, borderRadius: 0 }} title="Zoom in (⌘+)" aria-label="Zoom in" disabled={zoom >= MAX_ZOOM} onClick={() => setZoom(zoom * 1.2)}><Icon.Plus size={11}/></button>
        </div>
        <button className="fnd-btn fnd-btn-minimal" title="Fit page (⌘1)" onClick={fitAll}>Fit</button>
        <button className={`fnd-btn fnd-btn-minimal ${view.handTool ? "fnd-selected" : ""}`} title="Hand tool — drag to pan (or hold Space)" aria-pressed={view.handTool} onClick={() => viewStore.set(v => ({ ...v, handTool: !v.handTool }))}>✋</button>
        <button className="fnd-btn fnd-btn-minimal" title="Command palette (⌘K)" onClick={() => ui.setCommandOpen(true)}>⌘K</button>
      </div>

      {/* row 2 — breadcrumb + structure tools */}
      <div className="flex items-center gap-1 px-2 border-b fnd-border" style={{ height: 32, background: isNodeSel ? "var(--fnd-selection)" : "var(--fnd-panel)", flexShrink: 0, overflowX: "auto" }}>
        {isNodeSel ? (
          <>
            <nav className="flex items-center gap-0.5 text-xs min-w-0" aria-label="Selection path">
              {path.map((p, i) => (
                <React.Fragment key={p.id}>
                  {i > 0 && <span className="fnd-text-dim">›</span>}
                  <button className="px-1 rounded-sm fnd-row-hover truncate" style={{ maxWidth: 130, fontWeight: i === path.length - 1 ? 700 : 500 }} title={`Select ${p.name}`} onClick={() => ui.select({ kind: p.kind, id: p.id })}>{p.name}</button>
                </React.Fragment>
              ))}
            </nav>
            <div style={{ width: 1, height: 16, background: "var(--fnd-border-strong)", margin: "0 4px" }}/>
            <button className="fnd-btn fnd-btn-minimal" onClick={() => setShowAdd(true)}><Icon.Plus size={11}/> Widget</button>
            <button className="fnd-btn fnd-btn-minimal" disabled={arranging} onClick={e => { const r = e.currentTarget.getBoundingClientRect(); arrangeMenu(r.left, r.bottom + 2); }}>{arranging ? "Arranging…" : "Arrange ▾"}</button>
            <button className="fnd-btn fnd-btn-minimal" title="Group into a row (⌘G)" onClick={() => ui.groupSel("columns")}>Group</button>
            {selection.kind === "section" && <button className="fnd-btn fnd-btn-minimal" title="Ungroup (⌘⇧G)" onClick={ui.ungroupSel}>Ungroup</button>}
            <button className="fnd-btn fnd-btn-minimal" title="Move out one level (Alt+⇧+←)" onClick={ui.outdentSel}>⇤ Out</button>
            <button className="fnd-btn fnd-btn-minimal" title="Move into previous section (Alt+⇧+→)" onClick={ui.indentSel}>In ⇥</button>
            {selection.kind === "section" && (
              <>
                <button className="fnd-btn fnd-btn-minimal" onClick={() => selection.id && ui.addSectionAt(selection.id, "left")}>+ Left</button>
                <button className="fnd-btn fnd-btn-minimal" onClick={() => selection.id && ui.addSectionAt(selection.id, "right")}>+ Right</button>
                <button className="fnd-btn fnd-btn-minimal" onClick={() => selection.id && ui.addSectionAt(selection.id, "above")}>+ Above</button>
                <button className="fnd-btn fnd-btn-minimal" onClick={() => selection.id && ui.addSectionAt(selection.id, "below")}>+ Below</button>
              </>
            )}
            <div className="flex-1"/>
            <button className="fnd-btn fnd-btn-minimal" title="Copy (⌘C)" aria-label="Copy" onClick={ui.copySel}><Icon.Copy size={11}/></button>
            <button className="fnd-btn fnd-btn-minimal" title="Duplicate (⌘D)" onClick={ui.duplicateSel}>Duplicate</button>
            <button className="fnd-btn fnd-btn-minimal fnd-btn-danger" title="Delete (⌫)" aria-label="Delete" onClick={ui.deleteSel}><Icon.Trash size={11}/></button>
          </>
        ) : (
          <>
            <span className="text-[11px] fnd-text-muted whitespace-nowrap">Click to select · drag ⠿ to move (drop on edges to place side-by-side, centre to swap) · ⌘/Ctrl+scroll zoom · Space+drag pan</span>
            <div className="flex-1"/>
            <button className="fnd-btn fnd-btn-minimal" onClick={() => setShowAdd(true)}><Icon.Plus size={11}/> Add widget</button>
            <button className="fnd-btn fnd-btn-minimal" disabled={arranging} onClick={e => { ui.select({ kind: "section", id: rootId }); const r = e.currentTarget.getBoundingClientRect(); arrangeMenu(r.left, r.bottom + 2); }}>Arrange page ▾</button>
          </>
        )}
      </div>

      {/* viewport */}
      <div className="flex-1 relative min-h-0">
        <div ref={scroller} data-canvas-scroller className="absolute inset-0 overflow-auto fnd-canvas-bg"
          style={{ cursor: panning ? "grabbing" : spaceDown || view.handTool ? "grab" : "default", overscrollBehavior: "contain" }}
          onPointerDown={onPointerDown} onPointerMove={onPointerMove} onPointerLeave={() => hoverStore.set({ id: null })} onContextMenu={nodeMenu}>
          <div style={{ width: wrapW, height: wrapH, position: "relative" }}>
            <div ref={stage} style={{ position: "absolute", left, top: PAD, width: stageW, transform: `scale(${zoom})`, transformOrigin: "0 0" }}>
              <div ref={frame} className="fnd-panel" style={{ minHeight: 520, borderRadius: 3, overflow: "hidden", boxShadow: "0 1px 3px rgba(16,22,26,.12), 0 8px 24px rgba(16,22,26,.08)", pointerEvents: spaceDown || view.handTool ? "none" : undefined }}>
                <RuntimeHeader/>
                <div style={{ padding: 16 }}>
                  <div style={{ maxWidth: CONTENT_MAX, margin: "0 auto", display: "flex", flexDirection: "column" }}>
                    {rootId ? <SectionView sectionId={rootId} isBuilder/> : null}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <SelectionOverlay rootRef={stage}/>
        <div className="absolute left-2 bottom-2 text-[10px] fnd-panel px-1.5 py-0.5 fnd-text-muted" style={{ zIndex: 21, pointerEvents: "none" }}>
          {device.label.split(" · ")[0]} · {stageW}px · {sectionCount} sections
        </div>
      </div>
      <DragLayer/>
      {showAdd && <WidgetSelector onPick={(type: WidgetType, name: string) => { ui.addWidgetOfType(type, name, selection.kind === "section" ? selection.id ?? undefined : undefined); setShowAdd(false); }} onClose={() => setShowAdd(false)}/>}
    </div>
  );
}
