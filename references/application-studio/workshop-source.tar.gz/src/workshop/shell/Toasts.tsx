"use client";
import React from "react";
import { useWorkshop } from "../WorkshopContext";
import { Icon } from "../widgets/icons";

export function Toasts() {
  const { toasts, dismissToast } = useWorkshop();
  return (
    <div style={{ position: "fixed", bottom: 20, right: 20, zIndex: 100, display: "flex", flexDirection: "column", gap: 6, pointerEvents: "none" }}>
      {toasts.map(t => (
        <div key={t.id} className="fnd-fade-in fnd-panel" style={{
          minWidth: 240, maxWidth: 360, pointerEvents: "auto",
          borderLeft: `3px solid ${t.kind === "success" ? "#15b371" : t.kind === "warning" ? "#d9822b" : t.kind === "error" ? "#c23030" : "#2b6cb0"}`,
          padding: "8px 10px", borderRadius: 3, display: "flex", alignItems: "center", gap: 6,
          boxShadow: "0 2px 8px rgba(0,0,0,0.12)",
        }}>
          <div className="text-xs flex-1">{t.message}</div>
          <button className="fnd-btn fnd-btn-minimal" style={{ height: 20, padding: 2 }} onClick={() => dismissToast(t.id)}><Icon.Close size={10}/></button>
        </div>
      ))}
    </div>
  );
}
