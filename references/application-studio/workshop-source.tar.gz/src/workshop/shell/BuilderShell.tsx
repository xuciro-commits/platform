"use client";
import React, { useEffect, useLayoutEffect, useRef, useState } from "react";
import { useWorkshop, useWS } from "../WorkshopContext";
import { TopBar } from "./TopBar";
import { LeftSidebar } from "./LeftSidebar";
import { Canvas } from "./Canvas";
import { Inspector } from "../panels/Inspector";
import { Toasts } from "./Toasts";
import { OverlayHost } from "../runtime/OverlayHost";
import { RuntimeShell } from "../runtime/RuntimeShell";
import { ConfirmDialog } from "../ui/ConfirmDialog";
import { ContextMenu } from "../ui/ContextMenu";
import { CommandPalette } from "../ui/CommandPalette";
import { OntologyManager } from "../panels/OntologyManager";
import { LineageView } from "../panels/GraphViews";
import { FlowBuilder } from "../panels/FlowBuilder";
import { lineageStore, useStore } from "../runtimeStores";

const LS = "foundry.workshop.layout.v1";
interface Dock { leftW: number; rightW: number; leftOpen: boolean; rightOpen: boolean }
const DEFAULT: Dock = { leftW: 300, rightW: 330, leftOpen: true, rightOpen: true };

function useDock() {
  const [dock, setDock] = useState<Dock>(DEFAULT);
  useEffect(() => { try { const raw = localStorage.getItem(LS); if (raw) setDock({ ...DEFAULT, ...JSON.parse(raw) }); } catch { /* ignore */ } }, []);
  const update = (p: Partial<Dock>) => setDock(d => { const n = { ...d, ...p }; try { localStorage.setItem(LS, JSON.stringify(n)); } catch { /* ignore */ } return n; });
  return [dock, update] as const;
}

function Resizer({ side, onDrag }: { side: "left" | "right"; onDrag: (dx: number) => void }) {
  return (
    <div role="separator" aria-orientation="vertical" aria-label={`Resize ${side} panel`} title="Drag to resize"
      onPointerDown={e => {
        e.preventDefault();
        let last = e.clientX;
        const move = (ev: PointerEvent) => { onDrag(ev.clientX - last); last = ev.clientX; };
        const up = () => { window.removeEventListener("pointermove", move); window.removeEventListener("pointerup", up); document.body.style.cursor = ""; };
        document.body.style.cursor = "col-resize";
        window.addEventListener("pointermove", move); window.addEventListener("pointerup", up);
      }}
      className="fnd-resizer" style={{ width: 5, cursor: "col-resize", flexShrink: 0, margin: "0 -2px", zIndex: 5, touchAction: "none" }}/>
  );
}

export function BuilderShell() {
  const { mode, leftPanel } = useWorkshop();
  const ontologyMode = mode === "builder" && leftPanel === "ontology";
  const lineageOn = useStore(lineageStore, v => v);
  const lineageMode = mode === "builder" && leftPanel === "variables" && lineageOn;
  const flowMode = mode === "builder" && leftPanel === "flows";
  const [dock, setDock] = useDock();
  const host = useRef<HTMLDivElement>(null);
  const [width, setWidth] = useState(1440);
  useLayoutEffect(() => {
    const el = host.current; if (!el) return;
    setWidth(el.clientWidth);
    const ro = new ResizeObserver(e => setWidth(e[0].contentRect.width));
    ro.observe(el);
    return () => ro.disconnect();
  }, [mode]);

  if (mode === "runtime") {
    return (
      <div className="h-screen flex flex-col overflow-hidden">
        <TopBar/>
        <div className="flex-1 overflow-hidden"><RuntimeShell/></div>
        <GlobalChrome/>
      </div>
    );
  }

  // never let the side panels squeeze the canvas below ~40% of the window
  const maxSide = Math.max(200, width * 0.3);
  const leftW = dock.leftOpen ? Math.min(dock.leftW, maxSide) : 0;
  const rightW = dock.rightOpen && !ontologyMode ? Math.min(dock.rightW, maxSide) : 0;

  return (
    <div className="h-screen flex flex-col overflow-hidden" style={{ background: "var(--fnd-bg)" }}>
      <TopBar/>
      <div ref={host} className="flex-1 flex overflow-hidden min-h-0">
        {dock.leftOpen && (
          <>
            <aside style={{ width: leftW, flexShrink: 0 }} className="border-r fnd-border overflow-hidden" aria-label="Builder panels"><LeftSidebar/></aside>
            <Resizer side="left" onDrag={dx => setDock({ leftW: Math.max(220, Math.min(560, dock.leftW + dx)) })}/>
          </>
        )}
        <main className="flex-1 overflow-hidden min-w-0">
          {ontologyMode ? <OntologyManager/> : lineageMode ? <LineageView/> : flowMode ? <FlowBuilder/> : <Canvas/>}
        </main>
        {!ontologyMode && dock.rightOpen && (
          <>
            <Resizer side="right" onDrag={dx => setDock({ rightW: Math.max(260, Math.min(560, dock.rightW - dx)) })}/>
            <aside style={{ width: rightW, flexShrink: 0, background: "var(--fnd-panel)" }} className="border-l fnd-border overflow-hidden" aria-label="Inspector">
              <div style={{ height: "100%", overflowY: "auto" }}><Inspector/></div>
            </aside>
          </>
        )}
      </div>
      <StatusBar dock={dock} setDock={setDock} ontologyMode={ontologyMode}/>
      <OverlayHost isBuilder/>
      <Toasts/>
      <GlobalChrome/>
    </div>
  );
}

function GlobalChrome() {
  const { confirm, cancelConfirm, contextMenu, closeContextMenu, commandOpen, setCommandOpen } = useWorkshop();
  return (
    <>
      {confirm && <ConfirmDialog title={confirm.title} message={confirm.message} impact={confirm.impact} onConfirm={() => { confirm.onConfirm(); cancelConfirm(); }} onCancel={cancelConfirm}/>}
      {contextMenu && <ContextMenu x={contextMenu.x} y={contextMenu.y} items={contextMenu.items} onClose={closeContextMenu}/>}
      <CommandPalette open={commandOpen} onClose={() => setCommandOpen(false)}/>
    </>
  );
}

function StatusBar({ dock, setDock, ontologyMode }: { dock: Dock; setDock: (p: Partial<Dock>) => void; ontologyMode: boolean }) {
  const sel = useWS(s => {
    const { kind, id } = s.ui.selection; const m = s.core.module;
    if (!kind || !id) return "no selection";
    const name = kind === "widget" ? m.widgets[id]?.name : kind === "section" ? m.sections[id]?.name : kind === "page" ? m.pages.find(p => p.id === id)?.name : kind === "variable" ? m.variables.find(v => v.id === id)?.name : kind === "flow" ? m.flows.find(f => f.id === id)?.name : kind === "flowNode" ? m.flows.flatMap(f => f.nodes).find(n => n.id === id)?.name : id;
    return `${kind}: ${name ?? id}`;
  });
  const counts = useWS(s => `${Object.keys(s.core.module.widgets).length} widgets · ${s.core.module.variables.length} variables · ${Object.keys(s.core.module.sections).length} sections`);
  const dirty = useWS(s => s.ui.saveState);
  return (
    <div className="flex items-center gap-3 px-3 border-t fnd-border text-[11px] fnd-text-muted" style={{ height: 24, background: "var(--fnd-panel)", flexShrink: 0 }}>
      <button className="fnd-btn fnd-btn-minimal" style={{ height: 18, padding: "0 4px" }} aria-pressed={dock.leftOpen} title={dock.leftOpen ? "Hide left panel" : "Show left panel"} onClick={() => setDock({ leftOpen: !dock.leftOpen })}>◧ Panels</button>
      <span className="truncate">{sel}</span>
      <span className="hidden md:inline">·</span><span className="hidden md:inline">{counts}</span>
      <div className="flex-1"/>
      <span>{dirty === "saving" ? "Saving…" : dirty === "failed" ? "Save failed" : "All changes saved"}</span>
      {!ontologyMode && <button className="fnd-btn fnd-btn-minimal" style={{ height: 18, padding: "0 4px" }} aria-pressed={dock.rightOpen} title={dock.rightOpen ? "Hide inspector" : "Show inspector"} onClick={() => setDock({ rightOpen: !dock.rightOpen })}>Inspector ◨</button>}
    </div>
  );
}
