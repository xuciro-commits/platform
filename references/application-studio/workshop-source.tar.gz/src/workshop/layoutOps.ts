import type { ModuleDef, SectionDef, WidgetDef, WidgetType } from "./types";
import { collectSectionSubtree, createWidget, emptySection, findParent, newId } from "./moduleOps";
import type { DragPayload, DropTarget } from "./dnd";

export type Ref = SectionDef["children"][number];
export type Orient = "h" | "v" | "tabs" | "loop";

export const orientOf = (layout: SectionDef["layout"]): Orient =>
  layout === "columns" || layout === "toolbar" ? "h" : layout === "tabs" ? "tabs" : layout === "loop" ? "loop" : "v";

const isSection = (m: ModuleDef, id: string) => !!m.sections[id];
export const refOf = (m: ModuleDef, id: string): Ref => ({ kind: isSection(m, id) ? "section" : "widget", id });

// ─── Primitive tree edits (all pure, structural sharing) ───────────────────
function withChildren(m: ModuleDef, sectionId: string, children: Ref[]): ModuleDef {
  const s = m.sections[sectionId];
  if (!s) return m;
  return { ...m, sections: { ...m.sections, [sectionId]: { ...s, children } } };
}

function detach(m: ModuleDef, ref: Ref): ModuleDef {
  const p = findParent(m, ref.id);
  let next = m;
  if (p) next = withChildren(m, p.sectionId, m.sections[p.sectionId].children.filter(c => c.id !== ref.id));
  if (next.unusedWidgetIds.includes(ref.id)) next = { ...next, unusedWidgetIds: next.unusedWidgetIds.filter(i => i !== ref.id) };
  return next;
}

function insertAt(m: ModuleDef, sectionId: string, index: number, ref: Ref): ModuleDef {
  const s = m.sections[sectionId];
  if (!s) return m;
  const children = [...s.children];
  children.splice(Math.max(0, Math.min(index, children.length)), 0, ref);
  return withChildren(m, sectionId, children);
}

export function setFlex(m: ModuleDef, id: string, flex: number | undefined): ModuleDef {
  if (m.sections[id]) return { ...m, sections: { ...m.sections, [id]: { ...m.sections[id], flex } } };
  if (m.widgets[id]) return { ...m, widgets: { ...m.widgets, [id]: { ...m.widgets[id], flex } } };
  return m;
}
export const flexOf = (m: ModuleDef, id: string) => m.sections[id]?.flex ?? m.widgets[id]?.flex ?? 1;

function subtreeIds(m: ModuleDef, ref: Ref): Set<string> {
  if (ref.kind === "widget") return new Set([ref.id]);
  const { sectionIds, widgetIds } = collectSectionSubtree(m, ref.id);
  return new Set([...sectionIds, ...widgetIds]);
}

// ─── Normalisation: keep the tree minimal after structural edits ───────────
export function normalize(m0: ModuleDef): ModuleDef {
  let m = m0;
  for (let pass = 0; pass < 8; pass++) {
    const roots = [...m.pages.map(p => p.rootSectionId), ...m.overlays.map(o => o.rootSectionId)];
    const reachable = new Set<string>();
    const walk = (id: string) => {
      if (reachable.has(id)) return;
      reachable.add(id);
      m.sections[id]?.children.forEach(c => { if (c.kind === "section") walk(c.id); });
    };
    roots.forEach(walk);

    const sections = { ...m.sections };
    const widgets = { ...m.widgets };
    let changed = false;
    const setW = (id: string, flex: number | undefined) => {
      if (sections[id]) sections[id] = { ...sections[id], flex };
      else if (widgets[id]) widgets[id] = { ...widgets[id], flex };
    };

    for (const id of reachable) {
      const s = sections[id];
      if (!s) continue;
      const next: Ref[] = [];
      let local = false;
      for (const c of s.children) {
        const cs = c.kind === "section" ? sections[c.id] : undefined;
        if (cs?.auto) {
          if (cs.children.length === 0) { local = true; continue; }
          if (cs.children.length === 1) {
            const only = cs.children[0];
            if (cs.flex !== undefined) setW(only.id, cs.flex);
            next.push(only); local = true; continue;
          }
          const co = orientOf(cs.layout), so = orientOf(s.layout);
          if (co === so && (co === "h" || co === "v") && !cs.width) {
            // flatten same-orientation auto wrapper, preserving the share it occupied
            const share = cs.flex ?? 1;
            const sum = cs.children.reduce((a, k) => a + (sections[k.id]?.flex ?? widgets[k.id]?.flex ?? 1), 0) || 1;
            if (co === "h") for (const k of cs.children) setW(k.id, ((sections[k.id]?.flex ?? widgets[k.id]?.flex ?? 1) / sum) * share);
            next.push(...cs.children); local = true; continue;
          }
        }
        next.push(c);
      }
      if (local) { sections[id] = { ...sections[id], children: next }; changed = true; }
    }
    // garbage-collect auto sections that are no longer referenced
    const stillReachable = new Set<string>();
    const walk2 = (id: string) => {
      if (stillReachable.has(id)) return;
      stillReachable.add(id);
      sections[id]?.children.forEach(c => { if (c.kind === "section") walk2(c.id); });
    };
    roots.forEach(walk2);
    for (const id of Object.keys(sections)) if (sections[id].auto && !stillReachable.has(id)) { delete sections[id]; changed = true; }
    m = { ...m, sections, widgets };
    if (!changed) break;
  }
  return m;
}

// ─── Drop application ──────────────────────────────────────────────────────
export function applyDrop(
  m0: ModuleDef, payload: DragPayload, target: DropTarget,
): { module: ModuleDef; select: { kind: "widget" | "section"; id: string } } | null {
  let m = m0;
  let ref: Ref;
  if (payload.kind === "new") {
    const w: WidgetDef = createWidget(payload.widgetType as WidgetType, payload.name);
    m = { ...m, widgets: { ...m.widgets, [w.id]: w } };
    ref = { kind: "widget", id: w.id };
  } else ref = { kind: payload.childKind, id: payload.id };
  const select = { kind: ref.kind, id: ref.id };
  const owned = subtreeIds(m, ref);

  if (target.kind === "swap") {
    if (owned.has(target.targetId)) return null;
    const tRef = refOf(m, target.targetId);
    if (subtreeIds(m, tRef).has(ref.id)) return null;
    const pa = findParent(m, ref.id), pb = findParent(m, tRef.id);
    if (!pa || !pb) return null;
    if (pa.sectionId === pb.sectionId) {
      const ch = [...m.sections[pa.sectionId].children];
      [ch[pa.index], ch[pb.index]] = [ch[pb.index], ch[pa.index]];
      m = withChildren(m, pa.sectionId, ch);
    } else {
      const ca = [...m.sections[pa.sectionId].children]; ca[pa.index] = tRef;
      const cb = [...m.sections[pb.sectionId].children]; cb[pb.index] = ref;
      m = withChildren(withChildren(m, pa.sectionId, ca), pb.sectionId, cb);
    }
    return { module: normalize(m), select };
  }

  if (target.kind === "insert" || target.kind === "into") {
    const sectionId = target.sectionId;
    if (owned.has(sectionId)) return null;
    let index = target.kind === "into" ? (m.sections[sectionId]?.children.length ?? 0) : target.index;
    const old = payload.kind === "move" ? findParent(m, ref.id) : null;
    m = detach(m, ref);
    if (old && old.sectionId === sectionId && old.index < index) index -= 1;
    m = insertAt(m, sectionId, index, ref);
    return { module: normalize(m), select };
  }

  // wrap: place dragged beside target inside a new auto container
  if (owned.has(target.targetId)) return null;
  m = detach(m, ref);
  const tp = findParent(m, target.targetId);
  if (!tp) return null;
  const horizontal = target.side === "left" || target.side === "right";
  const wid = newId("s");
  const tRef = refOf(m, target.targetId);
  const pair: Ref[] = target.side === "left" || target.side === "top" ? [ref, tRef] : [tRef, ref];
  const wrapper: SectionDef = { ...emptySection(wid, horizontal ? "Columns" : "Rows", horizontal ? "columns" : "rows"), auto: true, padding: 0, children: pair, flex: flexOf(m, target.targetId) };
  m = { ...m, sections: { ...m.sections, [wid]: wrapper } };
  m = setFlex(m, target.targetId, 1);
  m = setFlex(m, ref.id, 1);
  const ch = [...m.sections[tp.sectionId].children];
  ch[tp.index] = { kind: "section", id: wid };
  return { module: normalize(withChildren(m, tp.sectionId, ch)), select };
}

// ─── Structure commands ────────────────────────────────────────────────────
/** Wrap a node into a new (user-visible) Row / Column section at its current position. */
export function groupNode(m: ModuleDef, id: string, layout: "columns" | "rows"): { module: ModuleDef; id: string } | null {
  const p = findParent(m, id);
  if (!p) return null;
  const sid = newId("s");
  const g: SectionDef = { ...emptySection(sid, layout === "columns" ? "Row" : "Column", layout), padding: 0, children: [refOf(m, id)], flex: flexOf(m, id) };
  let next: ModuleDef = { ...m, sections: { ...m.sections, [sid]: g } };
  next = setFlex(next, id, 1);
  const ch = [...next.sections[p.sectionId].children];
  ch[p.index] = { kind: "section", id: sid };
  return { module: withChildren(next, p.sectionId, ch), id: sid };
}

/** Dissolve a section, promoting its children into the parent. */
export function ungroupSection(m: ModuleDef, sectionId: string): ModuleDef {
  const p = findParent(m, sectionId);
  const s = m.sections[sectionId];
  if (!p || !s) return m;
  const ch = [...m.sections[p.sectionId].children];
  ch.splice(p.index, 1, ...s.children);
  const sections = { ...m.sections };
  delete sections[sectionId];
  return normalize(withChildren({ ...m, sections }, p.sectionId, ch));
}

/** Move a node out of its parent, placing it after the parent in the grandparent. */
export function outdent(m: ModuleDef, id: string): ModuleDef {
  const p = findParent(m, id);
  const gp = p ? findParent(m, p.sectionId) : null;
  if (!p || !gp) return m;
  const ref = refOf(m, id);
  let next = detach(m, ref);
  next = insertAt(next, gp.sectionId, gp.index + 1, ref);
  return normalize(next);
}

/** Move a node into the previous sibling section (if there is one). */
export function indent(m: ModuleDef, id: string): ModuleDef {
  const p = findParent(m, id);
  if (!p || p.index === 0) return m;
  const prev = m.sections[p.sectionId].children[p.index - 1];
  if (prev.kind !== "section") return m;
  const ref = refOf(m, id);
  let next = detach(m, ref);
  next = insertAt(next, prev.id, next.sections[prev.id].children.length, ref);
  return normalize(next);
}

export function moveSibling(m: ModuleDef, id: string, delta: -1 | 1): ModuleDef {
  const p = findParent(m, id);
  if (!p) return m;
  const ch = [...m.sections[p.sectionId].children];
  const j = p.index + delta;
  if (j < 0 || j >= ch.length) return m;
  [ch[p.index], ch[j]] = [ch[j], ch[p.index]];
  return withChildren(m, p.sectionId, ch);
}

export function equalizeSection(m: ModuleDef, sectionId: string): ModuleDef {
  const s = m.sections[sectionId];
  if (!s) return m;
  let next = m;
  for (const c of s.children) next = setFlex(next, c.id, undefined);
  return next;
}

// ─── Auto arrange ──────────────────────────────────────────────────────────
export type ArrangePreset = "smart" | "stack" | "columns-2" | "columns-3" | "master-detail" | "equalize";

const SMALL: ReadonlySet<string> = new Set([
  "MetricCard", "TextInput", "NumericInput", "DateInput", "DateTimePicker", "StringSelector", "ObjectDropdown", "ObjectSelector", "Checkbox",
  "ToggleSwitch", "RadioGroup", "SegmentedControl", "UserSelect", "MultiSelector", "RangeSlider", "ButtonGroup", "SingleButton", "HeaderText",
  "Breadcrumbs", "AlertBanner", "Callout", "Divider", "Spacer", "Tabs", "ExplorationFilter", "ExplorationSearch", "Gauge", "SparklineKpi",
  "ProgressBar", "ObjectSetTitle", "TagList", "AvatarStack", "StatusTracker", "Stepper", "ObjectCard",
]);
const BIG_WEIGHT: Record<string, number> = { ObjectTable: 3, Map: 3, Gantt: 3, KanbanBoard: 3, ChartXY: 2, PivotTable: 2, Timeline: 2, ObjectView: 2, ObjectList: 2, FilterList: 1, PropertyList: 1, Links: 1 };

export function isSmallNode(m: ModuleDef, ref: Ref) { return ref.kind === "widget" && SMALL.has(m.widgets[ref.id]?.type ?? ""); }
export function weightOf(m: ModuleDef, ref: Ref) { return ref.kind === "widget" ? (BIG_WEIGHT[m.widgets[ref.id]?.type ?? ""] ?? 2) : 2; }

/** Expand nested auto wrappers so arrangement is computed on the real leaves. */
export function leavesOf(m: ModuleDef, children: Ref[]): Ref[] {
  const out: Ref[] = [];
  for (const c of children) {
    const s = c.kind === "section" ? m.sections[c.id] : undefined;
    if (s?.auto) out.push(...leavesOf(m, s.children)); else out.push(c);
  }
  return out;
}

function chunk<T>(arr: T[], size: number): T[][] {
  const out: T[][] = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}

function makeRow(m: ModuleDef, refs: Ref[], flexes: number[], layout: "columns" | "rows"): { m: ModuleDef; ref: Ref } {
  let next = m;
  refs.forEach((r, i) => { next = setFlex(next, r.id, flexes[i] ?? 1); });
  if (refs.length === 1) return { m: setFlex(next, refs[0].id, undefined), ref: refs[0] };
  const sid = newId("s");
  const sec: SectionDef = { ...emptySection(sid, layout === "columns" ? "Row" : "Column", layout), auto: true, padding: 0, children: refs };
  return { m: { ...next, sections: { ...next.sections, [sid]: sec } }, ref: { kind: "section", id: sid } };
}

export function arrangeSection(m0: ModuleDef, sectionId: string, preset: ArrangePreset): ModuleDef {
  const s0 = m0.sections[sectionId];
  if (!s0 || s0.layout === "tabs") return m0;
  if (preset === "equalize") return equalizeSection(m0, sectionId);
  let m = m0;
  const units = leavesOf(m, s0.children);
  if (units.length === 0) return m0;
  let layout: SectionDef["layout"] = "rows";
  let children: Ref[] = [];

  if (preset === "stack") {
    for (const u of units) m = setFlex(m, u.id, undefined);
    children = units;
  } else if (preset.startsWith("columns-")) {
    const n = Number(preset.split("-")[1]);
    if (units.length <= n) { layout = "columns"; children = units; for (const u of units) m = setFlex(m, u.id, 1); }
    else for (const row of chunk(units, n)) { const r = makeRow(m, row, row.map(() => 1), "columns"); m = r.m; children.push(r.ref); }
  } else if (preset === "master-detail") {
    if (units.length < 2) return m0;
    const head = units.slice(0, Math.min(3, units.length));
    const rest = units.slice(head.length);
    const flexes = head.length === 3 ? [1, 3, 2] : [1, 2];
    if (rest.length === 0) { layout = "columns"; children = head; head.forEach((u, i) => { m = setFlex(m, u.id, flexes[i]); }); }
    else {
      const r = makeRow(m, head, flexes, "columns"); m = r.m; children.push(r.ref);
      for (const row of chunk(rest, 3)) { const rr = makeRow(m, row, row.map(() => 1), "columns"); m = rr.m; children.push(rr.ref); }
    }
  } else {
    // smart: compact controls/KPIs into strips on top, pack big widgets into balanced rows weighted by importance
    const smalls = units.filter(u => isSmallNode(m, u));
    const bigs = units.filter(u => !isSmallNode(m, u));
    if (smalls.length > 0) {
      const perRow = smalls.length <= 4 ? smalls.length : Math.ceil(smalls.length / Math.ceil(smalls.length / 4));
      for (const row of chunk(smalls, perRow)) { const r = makeRow(m, row, row.map(() => 1), "columns"); m = r.m; children.push(r.ref); }
    }
    if (bigs.length > 0) {
      const rows = Math.ceil(bigs.length / 3);
      const per = Math.ceil(bigs.length / rows);
      for (const row of chunk(bigs, per)) { const r = makeRow(m, row, row.map(u => weightOf(m, u)), "columns"); m = r.m; children.push(r.ref); }
    }
  }
  m = { ...m, sections: { ...m.sections, [sectionId]: { ...m.sections[sectionId], layout, children, direction: layout === "columns" ? "horizontal" : "vertical" } } };
  return normalize(m);
}

/** Convert an ELK rectpacking result (rows of node ids with widths) into section structure. */
export function applyPackedRows(m0: ModuleDef, sectionId: string, rows: Array<Array<{ id: string; w: number }>>): ModuleDef {
  const s0 = m0.sections[sectionId];
  if (!s0) return m0;
  let m = m0;
  const children: Ref[] = [];
  for (const row of rows) {
    const refs = row.map(r => refOf(m, r.id));
    const r = makeRow(m, refs, row.map(x => Math.max(1, Math.round(x.w))), "columns");
    m = r.m; children.push(r.ref);
  }
  m = { ...m, sections: { ...m.sections, [sectionId]: { ...m.sections[sectionId], layout: "rows", children, direction: "vertical" } } };
  return normalize(m);
}

/** Preferred pixel footprint of a node used as input to ELK's packer. */
export function preferredSize(m: ModuleDef, ref: Ref): { w: number; h: number } {
  if (ref.kind === "section") return { w: 420, h: 280 };
  const t = m.widgets[ref.id]?.type ?? "";
  if (SMALL.has(t)) return t === "MetricCard" ? { w: 220, h: 90 } : { w: 240, h: 56 };
  const w = BIG_WEIGHT[t] ?? 2;
  return { w: 220 + w * 130, h: 180 + w * 70 };
}

/** Ancestor chain (root → node) for breadcrumbs. */
export function pathTo(m: ModuleDef, id: string): Array<{ id: string; name: string; kind: "section" | "widget" }> {
  const out: Array<{ id: string; name: string; kind: "section" | "widget" }> = [];
  let cur: string | undefined = id;
  for (let guard = 0; cur && guard < 24; guard++) {
    out.unshift({ id: cur, name: m.sections[cur]?.name ?? m.widgets[cur]?.name ?? cur, kind: m.sections[cur] ? "section" : "widget" });
    cur = findParent(m, cur)?.sectionId;
  }
  return out;
}
