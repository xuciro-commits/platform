"use client";
import { createStore } from "../runtimeStores";

export const TELEMETRY_CAPACITY = 100_000;
export const TELEMETRY_COLUMNS = 100;
export const TELEMETRY_DEVICES = 160;
export const SIGNALS = ["vibration", "temperature", "pressure", "flow", "current", "voltage", "rpm", "torque", "humidity", "acoustic"] as const;
export const STATUS_NAMES = ["Active", "Warning", "Offline", "Maintenance"] as const;

export interface TelemetryState {
  ready: boolean; loading: boolean; error: string | null;
  capacity: number; columns: number; devices: number; plants: string[]; columnNames: string[];
  version: number; written: number; rowsPerSecond: number; paused: boolean; wasm: boolean; initMs: number;
}
export interface TelemetryRow {
  row: number; key: number; plantId: number; plant: string; deviceId: number; device: string;
  assetIndex: number; assetId: string; statusId: number; status: string; time: number;
  /** Numeric values for [colFrom,colTo). Index with signalIndex-colFrom. */
  values: Float32Array;
}
export interface AssetSample {
  assetId: string; deviceId: number; plantId: number; plant: string; status: string; time: number;
  key: number; version: number; signals: Float32Array;
}
export interface TelemetryFilter {
  plants?: number[]; statuses?: number[]; deviceId?: number; assetId?: number;
  timeFrom?: number; timeTo?: number; search?: string;
  signalIndex?: number; min?: number; max?: number;
}
export interface TelemetrySort { property: "eventTime" | "plant" | "device" | "status" | "asset" | "signal"; direction: "asc" | "desc"; signal?: number }
export interface TelemetryQuery { indices: Uint32Array; total: number; elapsedMs: number; version: number }
export interface TelemetryStats { count: number; sum: number; mean: number; min: number; max: number; above: number; wasm: boolean; elapsedMs: number }

const initial: TelemetryState = {
  ready: false, loading: false, error: null, capacity: 0, columns: 0, devices: 0, plants: [], columnNames: [],
  version: 0, written: 0, rowsPerSecond: 0, paused: true, wasm: false, initMs: 0,
};
export const telemetryStore = createStore<TelemetryState>(initial);
const latestByAsset = new Map<string, AssetSample>();

let worker: Worker | null = null;
let initialising: Promise<TelemetryState> | null = null;
let sequence = 0;
const pending = new Map<number, { resolve: (v: unknown) => void; reject: (e: Error) => void; timeout: ReturnType<typeof setTimeout> }>();
const listeners = new Set<(sample: AssetSample) => void>();

function ensureWorker(): Worker {
  if (worker) return worker;
  if (typeof Worker === "undefined") throw new Error("Web Worker is unavailable in this browser");
  worker = new Worker("/telemetry-worker.js", { name: "workshop-telemetry" });
  worker.onmessage = (e: MessageEvent) => {
    const m = e.data as Record<string, unknown>;
    if (m.type === "ready") {
      telemetryStore.set(s => ({ ...s, ready: true, loading: false, error: null, capacity: Number(m.capacity), columns: Number(m.columns), devices: Number(m.devices), plants: m.plants as string[], columnNames: m.columnNames as string[], wasm: Boolean(m.wasm), initMs: Number(m.elapsedMs), paused: true }));
    } else if (m.type === "tick") {
      // Version is intentionally small, not the full 40MB dataset. Components decide their own refresh cadence.
      telemetryStore.set(s => ({ ...s, version: Number(m.version), written: Number(m.written), rowsPerSecond: Number(m.rowsPerSecond) }));
    }
    if (m.requestId !== undefined) {
      const id = Number(m.requestId), p = pending.get(id);
      if (!p) return;
      pending.delete(id); clearTimeout(p.timeout);
      if (m.type === "error") p.reject(new Error(String(m.message)));
      else p.resolve(m);
    }
  };
  worker.onerror = e => {
    const message = e.message || "Telemetry worker crashed";
    telemetryStore.set(s => ({ ...s, ready: false, loading: false, error: message, paused: true }));
    for (const [key, p] of pending) { clearTimeout(p.timeout); p.reject(new Error(message)); pending.delete(key); }
    worker?.terminate(); worker = null; initialising = null;
  };
  return worker;
}

function rpc<T>(command: Record<string, unknown>, transfer: Transferable[] = [], timeoutMs = 15000): Promise<T> {
  const target = ensureWorker(), requestId = ++sequence;
  return new Promise<T>((resolve, reject) => {
    const timeout = setTimeout(() => { pending.delete(requestId); reject(new Error(`${command.type} timed out after ${timeoutMs}ms`)); }, timeoutMs);
    pending.set(requestId, { resolve: resolve as (v: unknown) => void, reject, timeout });
    target.postMessage({ ...command, requestId }, transfer);
  });
}

export function ensureTelemetry(): Promise<TelemetryState> {
  if (telemetryStore.get().ready) return Promise.resolve(telemetryStore.get());
  if (initialising) return initialising;
  telemetryStore.set(s => ({ ...s, loading: true, error: null }));
  initialising = rpc<{ type: string }>( { type: "init", autoStart: false }, [], 60000)
    .then(() => telemetryStore.get())
    .catch(e => { telemetryStore.set(s => ({ ...s, loading: false, error: (e as Error).message })); initialising = null; throw e; });
  return initialising;
}

export async function startTelemetry(intervalMs = 100) {
  await ensureTelemetry();
  if (!telemetryStore.get().paused) return;
  ensureWorker().postMessage({ type: "start", intervalMs });
  telemetryStore.set(s => ({ ...s, paused: false }));
}
export async function pauseTelemetry(paused = true) {
  await ensureTelemetry();
  ensureWorker().postMessage({ type: "pause", paused });
  telemetryStore.set(s => ({ ...s, paused }));
}
export function stopTelemetry() {
  if (!worker) return;
  worker.postMessage({ type: "stop" });
  telemetryStore.set(s => ({ ...s, paused: true }));
}
export function resetTelemetryWorker() {
  worker?.terminate(); worker = null; initialising = null; sequence = 0;
  for (const [, p] of pending) { clearTimeout(p.timeout); p.reject(new Error("Worker reset")); }
  pending.clear(); latestByAsset.clear(); telemetryStore.set(initial);
}

export async function queryTelemetry(filter: TelemetryFilter = {}, sort?: TelemetrySort): Promise<TelemetryQuery> {
  await ensureTelemetry();
  const reply = await rpc<{ indices: Uint32Array; total: number; elapsedMs: number; version: number }>({ type: "query", filter, sort });
  return { indices: reply.indices, total: reply.total, elapsedMs: reply.elapsedMs, version: reply.version };
}

/** Read at most 300 rows and ONLY requested numeric columns; 100K-row data never crosses the Worker boundary. */
export async function readTelemetryRange(from: number, to: number, colFrom: number, colTo: number, indices?: Uint32Array): Promise<TelemetryRow[]> {
  await ensureTelemetry();
  const subset = indices?.slice(from, Math.min(to, from + 300));
  const response = await rpc<{
    values: Float32Array; plants: Uint8Array; devices: Uint16Array; assets: Uint16Array;
    statuses: Uint8Array; times: Float64Array; keys: Uint32Array; colFrom: number; colTo: number;
  }>({ type: "window", from, to: Math.min(to, from + 300), colFrom, colTo, indices: subset ? subset.buffer : undefined }, subset ? [subset.buffer] : []);
  const stride = response.colTo - response.colFrom, count = response.keys.length;
  const st = telemetryStore.get(), result: TelemetryRow[] = new Array(count);
  for (let i = 0; i < count; i++) {
    const dev = response.devices[i], ai = response.assets[i], pi = response.plants[i], status = response.statuses[i];
    result[i] = {
      row: from + i, key: response.keys[i], plantId: pi, plant: st.plants[pi] ?? `Plant ${pi}`,
      deviceId: dev, device: `DEV-${String(dev + 1).padStart(4, "0")}`,
      assetIndex: ai, assetId: `AST-${String(ai + 1000).padStart(4, "0")}`,
      statusId: status, status: STATUS_NAMES[status] ?? "Unknown", time: response.times[i],
      values: response.values.subarray(i * stride, (i + 1) * stride),
    };
  }
  return result;
}
export async function readLatestTelemetry(count: number, colFrom = 0, colTo = TELEMETRY_COLUMNS): Promise<TelemetryRow[]> {
  await ensureTelemetry();
  const response = await rpc<{
    values: Float32Array; plants: Uint8Array; devices: Uint16Array; assets: Uint16Array;
    statuses: Uint8Array; times: Float64Array; keys: Uint32Array; colFrom: number; colTo: number;
  }>({ type: "latest", count: Math.min(2048, count), colFrom, colTo });
  const stride = response.colTo - response.colFrom, st = telemetryStore.get();
  return Array.from({ length: response.keys.length }, (_, i) => {
    const ai = response.assets[i], dev = response.devices[i], pi = response.plants[i], si = response.statuses[i];
    return { row: i, key: response.keys[i], plantId: pi, plant: st.plants[pi] ?? "—", deviceId: dev, device: `DEV-${String(dev + 1).padStart(4, "0")}`, assetIndex: ai, assetId: `AST-${String(ai + 1000).padStart(4, "0")}`, statusId: si, status: STATUS_NAMES[si] ?? "Unknown", time: response.times[i], values: response.values.subarray(i * stride, (i + 1) * stride) };
  });
}
export interface DrainBatch { rows: TelemetryRow[]; nextCursor: number; backlog: number; dropped: number; version: number }
/** Durable sequence-based consumption. Reads in order and reports overwritten gaps instead of silently sampling the latest rows. */
export async function drainTelemetry(cursor: number | null, limit: number, colFrom = 0, colTo = TELEMETRY_COLUMNS): Promise<DrainBatch> {
  await ensureTelemetry();
  const response = await rpc<{
    nextCursor: number; backlog: number; dropped: number; version: number;
    colFrom: number; colTo: number; values: Float32Array; plants: Uint8Array; devices: Uint16Array;
    assets: Uint16Array; statuses: Uint8Array; times: Float64Array; keys: Uint32Array;
  }>({ type: "drain", cursor, limit: Math.min(4096, Math.max(1, limit)), colFrom, colTo });
  const stride = response.colTo - response.colFrom, st = telemetryStore.get();
  const rows: TelemetryRow[] = Array.from({ length: response.keys.length }, (_, i) => {
    const pi = response.plants[i], di = response.devices[i], ai = response.assets[i], si = response.statuses[i];
    return { row: i, key: response.keys[i], plantId: pi, plant: st.plants[pi] ?? "—", deviceId: di, device: `DEV-${String(di + 1).padStart(4, "0")}`,
      assetIndex: ai, assetId: `AST-${String(ai + 1000).padStart(4, "0")}`, statusId: si, status: STATUS_NAMES[si] ?? "Unknown", time: response.times[i], values: response.values.subarray(i * stride, (i + 1) * stride) };
  });
  return { rows, nextCursor: response.nextCursor, backlog: response.backlog, dropped: response.dropped, version: response.version };
}

export async function readAssetSample(assetId: string): Promise<AssetSample> {
  await ensureTelemetry();
  const m = await rpc<{ error?: string; deviceId: number; plantId: number; status: number; time: number; key: number; version: number; signals: Float32Array }>({ type: "sample", assetId });
  if (m.error) throw new Error(m.error);
  const sample: AssetSample = {
    assetId, deviceId: m.deviceId, plantId: m.plantId, plant: telemetryStore.get().plants[m.plantId] ?? "—",
    status: STATUS_NAMES[m.status] ?? "Unknown", time: m.time, key: m.key, version: m.version, signals: m.signals,
  };
  latestByAsset.set(assetId, sample); listeners.forEach(fn => fn(sample));
  return sample;
}
export function getCachedAssetSample(assetId: string): AssetSample | undefined { return latestByAsset.get(assetId); }
export function subscribeAssetSamples(listener: (sample: AssetSample) => void) { listeners.add(listener); return () => { listeners.delete(listener); }; }

export async function aggregateTelemetry(from: number, to: number, signal: number, threshold: number): Promise<TelemetryStats> {
  await ensureTelemetry();
  const response = await rpc<{ stats: TelemetryStats }>({ type: "aggregate", from, to, signal, threshold });
  return response.stats;
}
