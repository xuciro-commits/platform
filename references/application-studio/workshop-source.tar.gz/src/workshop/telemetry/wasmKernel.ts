"use client";
export interface Stats { sum: number; mean: number; min: number; max: number; above: number; count: number; wasm: boolean; elapsedMs: number }
interface Exports { memory: WebAssembly.Memory; stats: (ptr: number, len: number, threshold: number, out: number) => void }
let kernel: Promise<Exports | null> | null = null;
let warned = false;

async function load(): Promise<Exports | null> {
  if (!kernel) kernel = (async () => {
    try {
      const response = await fetch("/wasm/telemetry_stats.wasm");
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const bytes = await response.arrayBuffer();
      const result = await WebAssembly.instantiate(bytes, {});
      return result.instance.exports as unknown as Exports;
    } catch (e) {
      if (!warned) { console.warn("Telemetry WASM kernel unavailable; using typed-array fallback.", e); warned = true; }
      return null;
    }
  })();
  return kernel;
}

/** Aggregates a packed f32 window. The 100k-row hot path executes in WebAssembly, not JS. */
export async function wasmStats(values: Float32Array, threshold = Infinity): Promise<Stats> {
  const t0 = performance.now();
  const ex = await load();
  if (ex) {
    const inputBytes = values.byteLength;
    const outPtr = Math.ceil(inputBytes / 65536) * 65536 + 64;
    const neededPages = Math.ceil((outPtr + 32) / 65536);
    const currentPages = ex.memory.buffer.byteLength / 65536;
    if (neededPages > currentPages) ex.memory.grow(neededPages - currentPages);
    const f32 = new Float32Array(ex.memory.buffer);
    const srcPtr = 0;
    f32.set(values, srcPtr / 4);
    ex.stats(srcPtr, values.length, threshold, outPtr);
    const r = new Float32Array(ex.memory.buffer, outPtr, 5);
    return { sum: r[0], mean: r[1], min: r[2], max: r[3], above: r[4], count: values.length, wasm: true, elapsedMs: performance.now() - t0 };
  }
  let sum = 0, min = Infinity, max = -Infinity, above = 0;
  for (let i = 0; i < values.length; i++) { const v = values[i]; sum += v; if (v < min) min = v; if (v > max) max = v; if (v > threshold) above++; }
  return { sum, mean: values.length ? sum / values.length : 0, min: values.length ? min : 0, max: values.length ? max : 0, above, count: values.length, wasm: false, elapsedMs: performance.now() - t0 };
}
