import type { FlowDef, FlowEdgeDef, FlowNodeDef, FlowNodeStatus, FlowRun, FlowRunEvent, FlowValueType } from "./flowTypes";
import type { ModuleDef } from "./types";
import type { Ontology } from "./ontology";
import { getObjects, pivotTo, validateAction, type Obj, type OntologyMeta } from "./ontologyMeta";
import { ensureTelemetry, startTelemetry, drainTelemetry, telemetryStore, type TelemetryRow } from "./telemetry/telemetryStore";
import { wasmStats, type Stats } from "./telemetry/wasmKernel";
import { getSpec } from "./flowCatalog";

export interface FlowRecord extends Record<string, unknown> { assetId?: string; deviceId?: number; plantId?: number; time?: number }
export interface StatsRecord extends FlowRecord { count: number; mean: number; min: number; max: number; above: number; signal: string; wasm: boolean; elapsedMs: number }
export interface AlertRecord extends FlowRecord { assetId: string; title: string; severity: string; description: string; reading: number }
export type FlowValue =
  | { kind: "telemetry"; rows: TelemetryRow[]; version: number; backlog?: number; dropped?: number }
  | { kind: "objects"; rows: Obj[]; objectType: string }
  | { kind: "records"; rows: FlowRecord[] }
  | { kind: "stats"; rows: StatsRecord[] }
  | { kind: "alerts"; rows: AlertRecord[] }
  | { kind: "scalar"; value: unknown };

export interface FlowRuntimeContext {
  module: ModuleDef;
  ontology: Ontology;
  ontologyMeta: OntologyMeta;
  executeAction: (apiName: string, params: Record<string, unknown>) => { ok: boolean; errors: string[] };
  setVariable: (id: string, value: unknown) => void;
  getVariable?: (id: string) => unknown;
  /** Injectable for deterministic tests. Default reads the shared telemetry Worker. */
  readLatest?: (count: number) => Promise<TelemetryRow[]>;
  calculateStats?: (values: Float32Array, threshold: number) => Promise<Stats>;
  onRun?: (run: FlowRun) => void;
  signal?: AbortSignal;
  now?: () => number;
}

const MAX_EVENTS = 250, MAX_WINDOW = 50_000, MAX_DEAD_LETTER = 2_000;
const now = (ctx: FlowRuntimeContext) => ctx.now?.() ?? Date.now();
const count = (v?: FlowValue): number => v && "rows" in v ? v.rows.length : v ? 1 : 0;
const rows = (v?: FlowValue): FlowRecord[] => v && "rows" in v ? v.rows as unknown as FlowRecord[] : v?.kind === "scalar" && v.value && typeof v.value === "object" ? [v.value as FlowRecord] : [];
const emptyFor = (v?: FlowValue): FlowValue => v?.kind === "telemetry" ? { ...v, rows: [] } : v?.kind === "objects" ? { ...v, rows: [] } : v?.kind === "stats" ? { kind: "stats", rows: [] } : v?.kind === "alerts" ? { kind: "alerts", rows: [] } : { kind: "records", rows: [] };
const withRows = (v: FlowValue | undefined, items: FlowRecord[]): FlowValue => v?.kind === "telemetry" ? { ...v, rows: items as unknown as TelemetryRow[] } : v?.kind === "objects" ? { ...v, rows: items as Obj[] } : v?.kind === "stats" ? { kind: "stats", rows: items as StatsRecord[] } : v?.kind === "alerts" ? { kind: "alerts", rows: items as AlertRecord[] } : { kind: "records", rows: items };
const asNumber = (v: unknown, fallback = 0) => Number.isFinite(Number(v)) ? Number(v) : fallback;
const bounded = (v: unknown, min: number, max: number, fallback: number) => Math.max(min, Math.min(max, asNumber(v, fallback)));
const sleep = (ms: number, signal?: AbortSignal) => new Promise<void>((resolve, reject) => {
  if (signal?.aborted) return reject(new Error("Run cancelled"));
  const t = setTimeout(() => { signal?.removeEventListener("abort", cancel); resolve(); }, ms);
  const cancel = () => { clearTimeout(t); reject(new Error("Run cancelled")); };
  signal?.addEventListener("abort", cancel, { once: true });
});

/** Field access consistently interprets a telemetry signal name or numeric column index. */
function field(row: FlowRecord, key: string): unknown {
  if (key in row) return row[key];
  if ("values" in row && row.values instanceof Float32Array) {
    const index = /^\d+$/.test(key) ? Number(key) : signalIndex(key);
    return row.values[index];
  }
  const parts = key.split(".");
  let cur: unknown = row;
  for (const p of parts) { if (!cur || typeof cur !== "object") return undefined; cur = (cur as Record<string, unknown>)[p]; }
  return cur;
}
function signalIndex(signal: string): number {
  const sigs = ["vibration", "temperature", "pressure", "flow", "current", "voltage", "rpm", "torque", "humidity", "acoustic"];
  const s = sigs.findIndex(x => signal.toLowerCase().startsWith(x));
  if (s < 0) return Math.max(0, Math.min(99, asNumber(signal, 0)));
  const ordinal = Math.max(1, Math.min(10, asNumber(signal.match(/_(\d+)$/)?.[1], 1)));
  return s * 10 + ordinal - 1;
}
const typeCompatible = (out: FlowValueType, input: FlowValueType) => out === "Any" || input === "Any" || out === input || out === "Scalar" && input === "Alert";

function effectiveEdges(flow: FlowDef) { return flow.edges.filter(e => e.enabled !== false); }

/** Strong graph validation: ports, types, single-input cardinality and cycles. A Delay node breaks a feedback dependency across executions. */
export function validateFlow(flow: FlowDef, ctx?: Pick<FlowRuntimeContext, "ontologyMeta" | "module">): string[] {
  const errors: string[] = [], nodes = new Map(flow.nodes.map(n => [n.id, n]));
  if (nodes.size !== flow.nodes.length) errors.push("Duplicate node IDs detected.");
  const inputUse = new Map<string, number>();
  for (const edge of effectiveEdges(flow)) {
    const source = nodes.get(edge.source), target = nodes.get(edge.target);
    if (!source || !target) { errors.push(`Connection ${edge.id}: source or target node is missing.`); continue; }
    const a = getSpec(source.type)?.outputs.find(p => p.id === edge.sourcePort), b = getSpec(target.type)?.inputs.find(p => p.id === edge.targetPort);
    if (!a || !b) { errors.push(`Connection ${edge.id}: port not found (${edge.sourcePort} → ${edge.targetPort}).`); continue; }
    if (!typeCompatible(a.type, b.type)) errors.push(`${source.name}.${a.label} (${a.type}) cannot connect to ${target.name}.${b.label} (${b.type}).`);
    const key = `${edge.target}:${edge.targetPort}`; inputUse.set(key, (inputUse.get(key) ?? 0) + 1);
    if (!b.multiple && inputUse.get(key)! > 1) errors.push(`${target.name}.${b.label} allows one connection; remove a duplicate edge.`);
  }
  for (const node of flow.nodes) {
    const spec = getSpec(node.type);
    if (!spec) { errors.push(`Unknown processor type ${node.type}.`); continue; }
    if (node.disabled) continue;
    for (const port of spec.inputs) if (port.required && !effectiveEdges(flow).some(e => e.target === node.id && e.targetPort === port.id)) errors.push(`${node.name}: required input “${port.label}” is not connected.`);
    if (node.type === "variableOutput" && ctx && !ctx.module.variables.some(v => v.id === node.config.variableId)) errors.push(`${node.name}: variable @${node.config.variableId} does not exist.`);
    if ((node.type === "alertOutput" || node.type === "action") && ctx && !ctx.ontologyMeta.actionTypes.some(a => a.apiName === node.config.actionType)) errors.push(`${node.name}: Action Type ${node.config.actionType} does not exist.`);
  }
  const indegrees = new Map(flow.nodes.map(n => [n.id, 0]));
  const next = new Map<string, string[]>();
  for (const e of effectiveEdges(flow)) {
    if (!nodes.has(e.source) || !nodes.has(e.target) || nodes.get(e.source)?.type === "delay") continue;
    indegrees.set(e.target, (indegrees.get(e.target) ?? 0) + 1);
    next.set(e.source, [...(next.get(e.source) ?? []), e.target]);
  }
  const queue = flow.nodes.filter(n => indegrees.get(n.id) === 0).map(n => n.id);
  let visited = 0;
  for (let i = 0; i < queue.length; i++) {
    const id = queue[i]; visited++;
    for (const dest of next.get(id) ?? []) { const d = indegrees.get(dest)! - 1; indegrees.set(dest, d); if (d === 0) queue.push(dest); }
  }
  if (visited !== flow.nodes.length) errors.push("Cycle without a Delay node: add a bounded Delay/Buffer to break the feedback dependency.");
  return [...new Set(errors)];
}

export function topologicalNodes(flow: FlowDef): FlowNodeDef[] {
  const remaining = new Set(flow.nodes.map(n => n.id));
  const result: FlowNodeDef[] = [];
  while (remaining.size) {
    const ready = flow.nodes.filter(n => remaining.has(n.id) && !effectiveEdges(flow).some(e => e.target === n.id && remaining.has(e.source) && flow.nodes.find(src => src.id === e.source)?.type !== "delay"));
    if (!ready.length) throw new Error("Cycle without Delay node");
    for (const n of ready) { result.push(n); remaining.delete(n.id); }
  }
  return result;
}

export interface FlowPreview { nodeId: string; kind: string; count: number; example?: Record<string, unknown> }
export class FlowRuntime {
  readonly id: string;
  private windows = new Map<string, TelemetryRow[]>();
  private cursors = new Map<string, number>();
  private dedup = new Map<string, Map<string, number>>();
  private buckets = new Map<string, Map<string, { tokens: number; time: number }>>();
  private hysteresis = new Map<string, Map<string, { hot: boolean; since: number; fired: boolean }>>();
  private delays = new Map<string, FlowValue>();
  private deadLetters: Array<{ at: number; node: string; reason: string; records: FlowRecord[] }> = [];
  private runs = 0;
  previews: Record<string, FlowPreview> = {};
  constructor(flowId: string) { this.id = flowId; }
  getDeadLetters() { return this.deadLetters.map(d => ({ ...d, records: d.records.slice(0, 20) })); }
  clearDeadLetters() { this.deadLetters = []; }
  reset() { this.windows.clear(); this.cursors.clear(); this.dedup.clear(); this.buckets.clear(); this.hysteresis.clear(); this.delays.clear(); this.deadLetters = []; this.previews = {}; this.runs = 0; }

  async run(flow: FlowDef, ctx: FlowRuntimeContext): Promise<FlowRun> {
    const stamp = now(ctx);
    const run: FlowRun = { id: `run-${stamp}-${++this.runs}`, flowId: flow.id, startedAt: stamp, status: "running", processed: 0, nodeStatuses: {}, events: [] };
    const log = (nodeId: string, level: FlowRunEvent["level"], message: string, meta: Partial<FlowRunEvent> = {}) => {
      if (run.events.length >= MAX_EVENTS) run.events.shift();
      run.events.push({ id: `${run.id}-${run.events.length}-${Date.now()}`, runId: run.id, flowId: flow.id, nodeId, at: now(ctx), level, message, ...meta });
    };
    const publish = () => ctx.onRun?.({ ...run, events: [...run.events], nodeStatuses: { ...run.nodeStatuses } });
    const problems = validateFlow(flow, ctx);
    if (problems.length) {
      run.status = "failed"; run.error = problems.join(" "); run.finishedAt = now(ctx);
      problems.forEach(p => log("graph", "error", p)); publish(); return run;
    }
    if (ctx.signal?.aborted) { run.status = "cancelled"; run.finishedAt = now(ctx); publish(); return run; }
    const nodes = new Map(flow.nodes.map(n => [n.id, n]));
    const connections = effectiveEdges(flow);
    const pending = new Map(flow.nodes.map(n => [n.id, connections.filter(e => e.target === n.id && nodes.get(e.source)?.type !== "delay").length]));
    const outputs = new Map<string, Map<string, FlowValue>>();
    for (const [id, value] of this.delays) outputs.set(id, new Map([["out", value]]));
    const queue = flow.nodes.filter(n => pending.get(n.id) === 0).map(n => n.id);
    const concurrency = bounded(flow.execution.maxConcurrency, 1, 16, 4);
    let partial = false, fatal = false;
    const getInputs = (n: FlowNodeDef) => {
      const incoming = new Map<string, FlowValue>();
      for (const e of connections.filter(e => e.target === n.id)) {
        const v = outputs.get(e.source)?.get(e.sourcePort);
        if (v) incoming.set(e.targetPort, v);
      }
      return incoming;
    };
    while (queue.length && !fatal && !ctx.signal?.aborted) {
      const batch = queue.splice(0, concurrency);
      await Promise.all(batch.map(async id => {
        const node = nodes.get(id)!;
        const inputs = getInputs(node);
        const missing = getSpec(node.type).inputs.filter(p => p.required && !inputs.has(p.id));
        if (missing.length && node.type !== "delay") {
          run.nodeStatuses[id] = "warning";
          log(id, "warning", `Skipped: ${missing.map(p => p.label).join(", ")} received no data on this run.`);
          publish(); return;
        }
        run.nodeStatuses[id] = "running"; publish();
        const t0 = performance.now();
        let result: Map<string, FlowValue> | null = null;
        const retries = bounded(node.retry?.attempts, 0, 5, 0);
        for (let attempt = 0; attempt <= retries; attempt++) {
          try {
            result = node.disabled ? new Map([[getSpec(node.type).outputs[0]?.id ?? "out", inputs.values().next().value ?? { kind: "records", rows: [] }]]) : await this.executeNode(flow, node, inputs, ctx);
            break;
          } catch (error) {
            if (ctx.signal?.aborted) break;
            const message = (error as Error).message || String(error);
            if (attempt < retries) {
              log(id, "warning", `Attempt ${attempt + 1} failed: ${message}. Retrying in ${Math.min(1500, (node.retry?.backoffMs ?? 100) * 2 ** attempt)}ms.`);
              await sleep(Math.min(1500, (node.retry?.backoffMs ?? 100) * 2 ** attempt), ctx.signal).catch(() => {});
            } else {
              run.nodeStatuses[id] = "error"; partial = true;
              log(id, "error", message, { durationMs: performance.now() - t0 });
              if (flow.execution.errorPolicy === "deadLetter") this.deadLetters.push({ at: now(ctx), node: id, reason: message, records: [...inputs.values()].flatMap(rows).slice(0, 200) });
              this.deadLetters = this.deadLetters.slice(-MAX_DEAD_LETTER);
              if (flow.execution.errorPolicy === "stop") fatal = true;
            }
          }
        }
        if (result) {
          outputs.set(id, result);
          const sent = [...result.values()].reduce((a, v) => a + count(v), 0);
          const received = [...inputs.values()].reduce((a, v) => a + count(v), 0);
          run.processed += received;
          const elapsed = performance.now() - t0;
          const firstValue = result.values().next().value as FlowValue | undefined;
          const previewRow = rows(firstValue)[0];
          this.previews[id] = { nodeId: id, kind: firstValue?.kind ?? "empty", count: sent, example: previewRow ? Object.fromEntries(Object.entries(previewRow).filter(([k]) => k !== "values").slice(0, 8)) : undefined };
          let message = `${node.disabled ? "Disabled · " : ""}${received.toLocaleString()} in → ${sent.toLocaleString()} out`;
          let level: FlowRunEvent["level"] = node.disabled ? "warning" : "info";
          const metrics: Record<string, number | string> = { durationMs: elapsed };
          if (node.type === "telemetrySource") {
            const batch = result.get("batch");
            if (batch?.kind === "telemetry") {
              message = `${batch.rows.length.toLocaleString()} rows consumed · ${batch.backlog ?? 0} queued · ${batch.dropped ?? 0} overwritten`;
              metrics.backlog = batch.backlog ?? 0; metrics.dropped = batch.dropped ?? 0;
              if (batch.dropped) { partial = true; level = "warning"; }
            }
          } else if (node.type === "window") {
            const late = count(result.get("late"));
            message = `${count(result.get("window")).toLocaleString()} buffered · ${late} late/overflow → side output`;
            if (late) level = "warning";
          } else if (node.type === "aggregate") {
            const stats = result.get("stats");
            if (stats?.kind === "stats") {
              const accelerated = stats.rows.filter(s => s.wasm).length;
              const compute = stats.rows.reduce((sum, s) => sum + s.elapsedMs, 0);
              message = `${stats.rows.length} groups · ${accelerated} WASM · ${compute.toFixed(2)}ms kernel time · ${count(result.get("alerts"))} threshold candidates`;
              metrics.wasmGroups = accelerated; metrics.kernelMs = compute;
            }
          } else if (node.type === "threshold") message = `${count(result.get("triggered"))} emitted after debounce/hysteresis · ${count(result.get("normal"))} normal`;
          else if (node.type === "alertOutput" || node.type === "action") {
            const errors = count(result.get("errors"));
            message = `${count(result.get(node.type === "action" ? "result" : "done"))} submitted · ${errors} rejected`;
            if (errors) { partial = true; level = "warning"; }
          }
          run.nodeStatuses[id] = level === "warning" ? "warning" : "success";
          log(id, level, message, { rowsIn: received, rowsOut: sent, durationMs: elapsed, metrics });
        }
        publish();
      }));
      for (const id of batch) for (const edge of connections.filter(e => e.source === id && nodes.get(id)?.type !== "delay")) {
        const dep = (pending.get(edge.target) ?? 1) - 1; pending.set(edge.target, dep);
        if (dep === 0) queue.push(edge.target);
      }
    }
    run.status = ctx.signal?.aborted ? "cancelled" : fatal ? "failed" : partial ? "partial" : "success";
    run.finishedAt = now(ctx);
    if (this.runs % bounded(flow.execution.checkpointEvery, 1, 10000, 100) === 0) log("graph", "info", `Checkpoint: ${this.windows.size} windows, ${this.dedup.size} dedup stores, ${this.deadLetters.length} dead-letter batches.`);
    publish(); return run;
  }

  private async executeNode(flow: FlowDef, node: FlowNodeDef, input: Map<string, FlowValue>, ctx: FlowRuntimeContext): Promise<Map<string, FlowValue>> {
    const c = node.config, out = new Map<string, FlowValue>();
    const v = (port: string) => input.get(port);
    const r = (port: string) => rows(v(port));
    const t = now(ctx);
    switch (node.type) {
      case "objectSource": {
        const objectType = String(c.objectType ?? "Asset"), limit = bounded(c.limit, 1, 100000, 10000);
        out.set("objects", { kind: "objects", objectType, rows: getObjects(ctx.ontology, objectType).slice(0, limit) }); break;
      }
      case "telemetrySource": {
        const batchSize = bounded(c.batchSize, 16, 4096, 512);
        let source: TelemetryRow[] = [], backlog = 0, dropped = 0, sourceVersion = telemetryStore.get().version;
        if (ctx.readLatest) source = await ctx.readLatest(batchSize); // deterministic test / external connector
        else {
          await ensureTelemetry(); await startTelemetry(100);
          let cursor = this.cursors.get(node.id) ?? null;
          for (let i = 0; i < 16 && source.length < 4096; i++) {
            const part = await drainTelemetry(cursor, Math.min(batchSize, 4096 - source.length));
            source.push(...part.rows); cursor = part.nextCursor; backlog = part.backlog; dropped += part.dropped; sourceVersion = part.version;
            if (!backlog || !part.rows.length) break;
          }
          if (cursor !== null) this.cursors.set(node.id, cursor);
        }
        const wanted = new Set(Array.isArray(c.plants) ? c.plants.map(String) : []);
        out.set("batch", { kind: "telemetry", rows: wanted.size ? source.filter(item => wanted.has(item.plant)) : source, version: sourceVersion, backlog, dropped }); break;
      }
      case "filter": {
        const x = v("in"), predicates = Array.isArray(c.predicates) ? c.predicates as Array<{ field: string; operator: string; value: unknown }> : [];
        const matched = r("in").filter(record => c.join === "any" ? predicates.some(p => matches(record, p)) : predicates.every(p => matches(record, p)));
        const accepted = new Set(matched);
        out.set("out", withRows(x, matched)); out.set("rejected", withRows(x, r("in").filter(rec => !accepted.has(rec)))); break;
      }
      case "window": {
        const prev = this.windows.get(node.id) ?? [];
        const incoming = r("in") as unknown as TelemetryRow[];
        const maxEvent = Math.max(t, ...incoming.map(row => row.time));
        const length = bounded(c.windowMs, 100, 3600000, 30000), lateness = bounded(c.watermarkMs, 0, 600000, 2000);
        const oldest = maxEvent - length, seen = new Set(prev.map(item => item.key));
        const unique = incoming.filter(item => !seen.has(item.key));
        const late = unique.filter(item => item.time < oldest - lateness);
        const admitted = unique.filter(item => item.time >= oldest - lateness && (c.lateEvents === "accept" || item.time >= oldest));
        const merged = [...prev.filter(item => item.time >= oldest), ...admitted];
        const overflow = merged.length > MAX_WINDOW ? merged.slice(0, merged.length - MAX_WINDOW) : [];
        const window = merged.slice(-MAX_WINDOW);
        this.windows.set(node.id, window);
        out.set("window", { kind: "telemetry", rows: window, version: telemetryStore.get().version });
        out.set("late", { kind: "telemetry", rows: [...(c.lateEvents === "sideOutput" ? late : []), ...overflow], version: telemetryStore.get().version }); break;
      }
      case "aggregate": {
        const grouped = new Map<string, TelemetryRow[]>(), groupBy = Array.isArray(c.groupBy) ? c.groupBy as string[] : [];
        for (const row of r("in") as unknown as TelemetryRow[]) {
          const key = groupBy.length ? groupBy.map(k => String(field(row as unknown as FlowRecord, k))).join("/") : "all";
          grouped.set(key, [...(grouped.get(key) ?? []), row]);
        }
        const signal = String(c.signal ?? "vibration"), index = signalIndex(signal), threshold = asNumber(c.threshold, Infinity);
        const result: StatsRecord[] = [], alerts: AlertRecord[] = [];
        for (const [key, group] of grouped) {
          const data = new Float32Array(group.length);
          for (let i = 0; i < group.length; i++) data[i] = group[i].values[index] ?? 0;
          const s = await (ctx.calculateStats ?? wasmStats)(data, threshold), last = group[group.length - 1];
          const stats: StatsRecord = { ...s, signal, key, assetId: last.assetId, deviceId: last.deviceId, plantId: last.plantId, plant: last.plant, time: last.time };
          result.push(stats);
          if (s.above) alerts.push({ assetId: last.assetId, title: `${signal} threshold on ${last.assetId}`, severity: "High", description: `${s.above}/${s.count} readings exceed ${threshold}; window mean ${s.mean.toFixed(2)}.`, reading: s.mean, time: last.time, deviceId: last.deviceId, plantId: last.plantId });
        }
        out.set("stats", { kind: "stats", rows: result }); out.set("alerts", { kind: "alerts", rows: alerts }); break;
      }
      case "threshold": {
        const keyField = String(c.key ?? "assetId"), high = asNumber(c.high, 12), low = asNumber(c.low, high - 2), debounce = bounded(c.debounceMs, 0, 60000, 0);
        if (low > high) throw new Error("Hysteresis low threshold must not exceed high threshold.");
        const state = this.hysteresis.get(node.id) ?? new Map<string, { hot: boolean; since: number; fired: boolean }>();
        const triggered: AlertRecord[] = [], normal: FlowRecord[] = [];
        for (const item of r("in")) {
          const key = String(field(item, keyField) ?? "global"), number = asNumber(field(item, String(c.field ?? "mean")), NaN);
          if (!Number.isFinite(number)) { normal.push(item); continue; }
          const s = state.get(key) ?? { hot: false, since: t, fired: false };
          if (number <= low) { s.hot = false; s.fired = false; s.since = t; normal.push(item); }
          else if (number >= high) {
            if (!s.hot) { s.hot = true; s.since = t; s.fired = false; }
            if (!s.fired && t - s.since >= debounce) {
              s.fired = true;
              const assetId = String(item.assetId ?? "");
              triggered.push({ ...item, assetId, title: `${c.field ?? "Signal"} high on ${assetId}`, description: `${c.field ?? "Signal"} ${number.toFixed(2)} crossed ${high} (clear below ${low})`, severity: String(c.severity ?? "High"), reading: number });
            }
          }
          state.set(key, s);
        }
        this.hysteresis.set(node.id, state);
        out.set("triggered", { kind: "alerts", rows: triggered }); out.set("normal", { kind: "records", rows: normal }); break;
      }
      case "branch": {
        const predicate = (c.predicate && typeof c.predicate === "object") ? c.predicate as { field: string; operator: string; value: unknown } : { field: String(c.field ?? "status"), operator: String(c.operator ?? "eq"), value: c.value };
        const all = r("in"), yes = all.filter(item => matches(item, predicate)), found = new Set(yes);
        out.set("match", withRows(v("in"), yes)); out.set("else", withRows(v("in"), all.filter(item => !found.has(item)))); break;
      }
      case "join": case "enrich": {
        const source = v(node.type === "join" ? "stream" : "in"), ref = v("objects"), reference = new Map(r("objects").map(item => [String(field(item, String(c.rightKey ?? "id"))), item]));
        const joined: FlowRecord[] = [], unmatched: FlowRecord[] = [], leftKey = String(c.leftKey ?? c.joinKey ?? "assetId");
        for (const item of rows(source)) {
          const object = reference.get(String(field(item, leftKey)));
          if (object) joined.push({ ...item, ontology: object });
          else { unmatched.push(item); if (c.mode !== "inner" && node.type === "join") joined.push({ ...item, ontology: null }); }
        }
        out.set(node.type === "join" ? "joined" : "enriched", { kind: "records", rows: joined });
        out.set(node.type === "join" ? "unmatched" : "unresolved", { kind: "records", rows: unmatched });
        void ref; break;
      }
      case "formula": {
        const expression = String(c.expression ?? "0"), name = String(c.outputName ?? "derivedValue");
        out.set("out", { kind: "records", rows: r("in").map(item => ({ ...item, [name]: safeFormula(expression, item) })) }); break;
      }
      case "rateLimit": {
        const rate = bounded(c.maxPerSecond, .01, 10000, 20), burst = bounded(c.burst, 1, 50000, 100), keyName = String(c.key ?? "deviceId");
        const buckets = this.buckets.get(node.id) ?? new Map<string, { tokens: number; time: number }>();
        const allowed: FlowRecord[] = [], rejected: FlowRecord[] = [];
        for (const item of r("in")) {
          const key = String(field(item, keyName) ?? "all"), b = buckets.get(key) ?? { tokens: burst, time: t };
          b.tokens = Math.min(burst, b.tokens + Math.max(0, (t - b.time) / 1000 * rate)); b.time = t;
          if (b.tokens >= 1) { allowed.push(item); b.tokens--; } else rejected.push(item);
          buckets.set(key, b);
        }
        this.buckets.set(node.id, buckets);
        out.set("allowed", withRows(v("in"), allowed)); out.set("limited", withRows(v("in"), rejected)); break;
      }
      case "delay": {
        const incoming = v("in"), previous = this.delays.get(node.id) ?? emptyFor(incoming);
        out.set("out", previous);
        const max = bounded(c.maxBuffer, 1, 100000, 10000);
        const items = rows(incoming);
        const accepted = items.length > max ? c.backpressure === "dropNewest" ? items.slice(0, max) : items.slice(-max) : items;
        this.delays.set(node.id, incoming ? withRows(incoming, accepted) : emptyFor(incoming));
        out.set("overflow", withRows(incoming, items.length > max ? items.slice(0, items.length - max) : [])); break;
      }
      case "deduplicate": {
        const keys = Array.isArray(c.keys) ? c.keys.map(String) : String(c.keys ?? "deviceId,key").split(",").map(x => x.trim());
        const ttl = bounded(c.ttlMs, 100, 86400000, 300000), seen = this.dedup.get(node.id) ?? new Map<string, number>();
        for (const [key, ts] of seen) if (ts + ttl < t) seen.delete(key);
        const unique: FlowRecord[] = [], duplicates: FlowRecord[] = [];
        for (const item of r("in")) {
          const key = keys.map(k => String(field(item, k) ?? "")).join("|");
          if (seen.has(key)) duplicates.push(item); else { unique.push(item); seen.set(key, t); }
        }
        if (seen.size > 50000) { const evict = seen.size - 50000; for (const key of seen.keys()) { seen.delete(key); if (seen.size <= 50000) break; } void evict; }
        this.dedup.set(node.id, seen);
        out.set("unique", withRows(v("in"), unique)); out.set("duplicates", withRows(v("in"), duplicates)); break;
      }
      case "sample": {
        const items = r("in"), limit = bounded(c.maxPoints, 10, 5000, 2000), method = String(c.method ?? "minMax");
        let result: FlowRecord[];
        if (items.length <= limit) result = items;
        else if (method === "last") result = items.slice(-limit);
        else if (method === "minMax") {
          const binSize = Math.ceil(items.length / (limit / 2)), samples: FlowRecord[] = [];
          const key = String(c.field ?? "vibration");
          for (let i = 0; i < items.length; i += binSize) {
            const segment = items.slice(i, i + binSize);
            let low = segment[0], high = segment[0];
            for (const item of segment) { if (asNumber(field(item, key)) < asNumber(field(low, key))) low = item; if (asNumber(field(item, key)) > asNumber(field(high, key))) high = item; }
            samples.push(low); if (low !== high) samples.push(high);
          }
          result = samples.slice(0, limit);
        } else { const step = items.length / limit; result = Array.from({ length: limit }, (_, i) => items[Math.floor(i * step)]); }
        out.set("sampled", withRows(v("in"), result)); break;
      }
      case "union": {
        const a = v("a"), b = v("b"), merged = new Map<string, FlowRecord>();
        for (const item of [...rows(a), ...rows(b)]) merged.set(String(item.key ?? item.id ?? JSON.stringify(item).slice(0, 60)), item);
        out.set("out", withRows(a ?? b, [...merged.values()])); break;
      }
      case "pivotTo": {
        const source = r("objects") as Obj[], linked = pivotTo(ctx.ontology, ctx.ontologyMeta, String(c.linkType ?? ""), source);
        out.set("linked", { kind: "objects", rows: linked, objectType: String(linked[0]?.__type ?? "") }); break;
      }
      case "action": {
        const actionId = String(c.actionType ?? ""), def = ctx.ontologyMeta.actionTypes.find(a => a.apiName === actionId);
        if (!def) throw new Error(`Action Type ${actionId} is missing from the Ontology.`);
        const results: FlowRecord[] = [], errors: FlowRecord[] = [];
        for (const item of r("in").slice(0, 100)) {
          const params = { ...item, ...(c.params && typeof c.params === "object" ? c.params as Record<string, unknown> : {}) };
          for (const param of def.parameters.filter(p => p.type === "ObjectReference")) {
            if (!params[param.apiName]) params[param.apiName] = item.assetId ?? item.id;
          }
          const validation = validateAction(def, ctx.ontology, ctx.ontologyMeta, params);
          if (Object.keys(validation.fieldErrors).length || validation.criteriaErrors.length) { errors.push({ ...item, errors: [...Object.values(validation.fieldErrors), ...validation.criteriaErrors] }); continue; }
          const res = c.dryRun === false ? ctx.executeAction(actionId, params) : { ok: true, errors: [] as string[] };
          if (res.ok) results.push({ ...item, action: actionId, dryRun: c.dryRun !== false });
          else errors.push({ ...item, errors: res.errors });
        }
        out.set("result", { kind: "records", rows: results }); out.set("errors", { kind: "records", rows: errors }); break;
      }
      case "variableOutput": {
        const id = String(c.variableId ?? "");
        if (!ctx.module.variables.some(x => x.id === id)) throw new Error(`Workshop variable @${id} does not exist.`);
        const source = v("in"), value = source?.kind === "scalar" ? source.value : source?.kind === "stats" && source.rows.length === 1 ? source.rows[0] : source && "rows" in source ? source.rows : null;
        if (c.mode === "append" && Array.isArray(value)) ctx.setVariable(id, [...(Array.isArray(ctx.getVariable?.(id)) ? ctx.getVariable!(id) as unknown[] : []), ...value].slice(-5000));
        else ctx.setVariable(id, value);
        out.set("done", { kind: "scalar", value: { variableId: id, count: count(source), publishedAt: t } }); break;
      }
      case "alertOutput": {
        const actionId = String(c.actionType ?? "createOperationalAlert"), accepted: FlowRecord[] = [], errors: FlowRecord[] = [];
        for (const item of r("in").slice(0, 40) as AlertRecord[]) {
          if (!item.assetId || item.__suppressed) continue;
          const params = { asset: item.assetId, title: item.title, severity: String(item.severity ?? c.severity ?? "High"), description: item.description ?? `Signal ${item.reading}`, reading: item.reading };
          const res = c.dryRun === true ? { ok: true, errors: [] as string[] } : ctx.executeAction(actionId, params);
          if (res.ok) accepted.push({ ...item, submitted: c.dryRun !== true }); else errors.push({ ...item, errors: res.errors });
        }
        if (errors.length) this.deadLetters.push({ at: t, node: node.id, reason: "Alert Action validation failed", records: errors });
        out.set("done", { kind: "records", rows: accepted }); out.set("errors", { kind: "records", rows: errors }); break;
      }
      case "deadLetter": {
        const items = r("in");
        if (items.length) this.deadLetters.push({ at: t, node: node.id, reason: "Explicit DLQ routing", records: items.slice(0, 200) });
        this.deadLetters = this.deadLetters.slice(-MAX_DEAD_LETTER);
        out.set("queue", { kind: "records", rows: items.slice(0, bounded(c.maxRecords, 1, 200, 200)) }); break;
      }
      case "debug": {
        const source = v("in");
        if (source) out.set("out", source);
        break;
      }
      default: throw new Error(`Processor “${node.type}” has no implementation.`);
    }
    return out;
  }
}

const runtimes = new Map<string, FlowRuntime>();
export function getFlowRuntime(id: string) { let r = runtimes.get(id); if (!r) { r = new FlowRuntime(id); runtimes.set(id, r); } return r; }
export async function executeFlow(flow: FlowDef, ctx: FlowRuntimeContext) { return getFlowRuntime(flow.id).run(flow, ctx); }

function matches(item: FlowRecord, predicate: { field: string; operator: string; value: unknown }): boolean {
  const current = field(item, String(predicate.field ?? "")), wanted = predicate.value;
  switch (predicate.operator) {
    case "eq": return String(current) === String(wanted);
    case "neq": return String(current) !== String(wanted);
    case "gt": return Number(current) > Number(wanted);
    case "gte": return Number(current) >= Number(wanted);
    case "lt": return Number(current) < Number(wanted);
    case "lte": return Number(current) <= Number(wanted);
    case "contains": return String(current ?? "").toLowerCase().includes(String(wanted).toLowerCase());
    case "in": return Array.isArray(wanted) && wanted.some(v => String(v) === String(current));
    default: throw new Error(`Unknown predicate operator “${predicate.operator}”.`);
  }
}

/** No eval()/Function() or arbitrary code execution. Shunting-yard evaluator for bounded numeric expressions. */
export function safeFormula(expression: string, record: FlowRecord): number {
  if (expression.length > 250) throw new Error("Formula exceeds 250 characters.");
  const tokens = expression.match(/(?:\d+\.?\d*|\.\d+)|[A-Za-z_][A-Za-z0-9_.]*|[()+\-*/]/g) ?? [];
  if (tokens.join("").replace(/\s/g, "") !== expression.replace(/\s/g, "")) throw new Error("Invalid formula token.");
  const precedence: Record<string, number> = { "+": 1, "-": 1, "*": 2, "/": 2 };
  const output: string[] = [], operators: string[] = [];
  for (const token of tokens) {
    if (/^(\d|\.)/.test(token) || /^[A-Za-z_]/.test(token)) output.push(token);
    else if (token === "(") operators.push(token);
    else if (token === ")") {
      while (operators.length && operators[operators.length - 1] !== "(") output.push(operators.pop()!);
      if (operators.pop() !== "(") throw new Error("Unbalanced formula parentheses.");
    } else if (token in precedence) {
      while (operators.length && (precedence[operators[operators.length - 1]] ?? 0) >= precedence[token]) output.push(operators.pop()!);
      operators.push(token);
    }
  }
  while (operators.length) { const op = operators.pop()!; if (op === "(") throw new Error("Unbalanced formula parentheses."); output.push(op); }
  const stack: number[] = [];
  for (const token of output) {
    if (token in precedence) {
      if (stack.length < 2) throw new Error("Formula requires two operands.");
      const b = stack.pop()!, a = stack.pop()!;
      if (token === "/" && b === 0) throw new Error("Division by zero.");
      stack.push(token === "+" ? a + b : token === "-" ? a - b : token === "*" ? a * b : a / b);
    } else {
      const v = Number(/^[A-Za-z_]/.test(token) ? field(record, token) : token);
      if (!Number.isFinite(v)) throw new Error(`Formula input “${token}” is not numeric.`);
      stack.push(v);
    }
  }
  if (stack.length !== 1) throw new Error("Invalid formula expression.");
  return stack[0];
}
