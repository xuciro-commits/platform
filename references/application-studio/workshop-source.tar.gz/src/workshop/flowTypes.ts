export type FlowValueType = "ObjectSet" | "TelemetryBatch" | "Scalar" | "Boolean" | "Alert" | "Any";
export type FlowPortDirection = "input" | "output";

export interface FlowPortDef {
  id: string;
  label: string;
  direction: FlowPortDirection;
  type: FlowValueType;
  required?: boolean;
  multiple?: boolean;
}

export type FlowNodeType =
  | "objectSource" | "telemetrySource" | "filter" | "window" | "aggregate" | "join" | "formula" | "branch"
  | "enrich" | "threshold" | "rateLimit" | "delay" | "deduplicate" | "sample" | "union" | "pivotTo"
  | "action" | "variableOutput" | "alertOutput" | "deadLetter" | "debug";

export type FlowNodeStatus = "idle" | "queued" | "running" | "success" | "warning" | "error";

export interface FlowNodeDef {
  id: string;
  type: FlowNodeType;
  name: string;
  x: number;
  y: number;
  /** Parameters read by the node executor. */
  config: Record<string, unknown>;
  disabled?: boolean;
  retry?: { attempts: number; backoffMs: number };
  /** cached UI-only result metadata (never used as node input). */
  lastStatus?: FlowNodeStatus;
}

export interface FlowEdgeDef {
  id: string;
  source: string;
  sourcePort: string;
  target: string;
  targetPort: string;
  label?: string;
  enabled?: boolean;
}

export interface FlowDef {
  id: string;
  name: string;
  description: string;
  enabled: boolean;
  version: number;
  nodes: FlowNodeDef[];
  edges: FlowEdgeDef[];
  /** Execution settings are part of the definition, not a visual-only canvas. */
  execution: {
    mode: "onDemand" | "stream" | "scheduled";
    maxConcurrency: number;
    checkpointEvery: number;
    errorPolicy: "stop" | "continue" | "deadLetter";
    scheduleMs?: number;
  };
}

export interface FlowRunEvent {
  id: string;
  runId: string;
  flowId: string;
  nodeId: string;
  at: number;
  level: "info" | "warning" | "error";
  message: string;
  rowsIn?: number;
  rowsOut?: number;
  durationMs?: number;
  metrics?: Record<string, number | string>;
}

export interface FlowRun {
  id: string;
  flowId: string;
  startedAt: number;
  finishedAt?: number;
  status: "queued" | "running" | "success" | "partial" | "failed" | "cancelled";
  processed: number;
  nodeStatuses: Record<string, FlowNodeStatus>;
  events: FlowRunEvent[];
  error?: string;
}
