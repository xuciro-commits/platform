"use client";
import { useSyncExternalStore } from "react";

// ─── Minimal external store ────────────────────────────────────────────────
export interface Store<T> {
  get: () => T;
  set: (next: T | ((prev: T) => T)) => void;
  subscribe: (fn: () => void) => () => void;
}

export function createStore<T>(initial: T): Store<T> {
  let state = initial;
  const listeners = new Set<() => void>();
  return {
    get: () => state,
    set: next => {
      const value = typeof next === "function" ? (next as (p: T) => T)(state) : next;
      if (Object.is(value, state)) return;
      state = value;
      listeners.forEach(l => l());
    },
    subscribe: fn => { listeners.add(fn); return () => { listeners.delete(fn); }; },
  };
}

export function useStore<T, U>(store: Store<T>, selector: (s: T) => U): U {
  return useSyncExternalStore(store.subscribe, () => selector(store.get()), () => selector(store.get()));
}

// ─── Real performance metrics (no fabricated numbers) ──────────────────────
export interface VarMetric { ms: number; total: number; runs: number; lastAt: number }
export interface WidgetMetric { last: number; max: number; total: number; renders: number }

export const metrics = {
  startedAt: typeof performance !== "undefined" ? performance.now() : 0,
  firstInteractiveMs: 0,
  variables: new Map<string, VarMetric>(),
  widgets: new Map<string, WidgetMetric>(),
  evalPasses: 0,
  lastEvalMs: 0,
  recordVariable(id: string, ms: number) {
    const m = this.variables.get(id) ?? { ms: 0, total: 0, runs: 0, lastAt: 0 };
    m.ms = ms; m.total += ms; m.runs += 1; m.lastAt = performance.now();
    this.variables.set(id, m);
  },
  recordWidget(id: string, ms: number) {
    const m = this.widgets.get(id) ?? { last: 0, max: 0, total: 0, renders: 0 };
    m.last = ms; m.max = Math.max(m.max, ms); m.total += ms; m.renders += 1;
    this.widgets.set(id, m);
  },
  clear() {
    this.variables.clear(); this.widgets.clear(); this.evalPasses = 0; this.lastEvalMs = 0;
    this.startedAt = performance.now();
  },
};

// ─── Canvas view (zoom / device) ───────────────────────────────────────────
export interface Device { id: string; label: string; width: number | null; group: "Fluid" | "Desktop" | "Tablet" | "Mobile" }
export const DEVICES: Device[] = [
  { id: "fluid", label: "Responsive (fill)", width: null, group: "Fluid" },
  { id: "laptop", label: "Laptop · 1280", width: 1280, group: "Desktop" },
  { id: "desktop", label: "Desktop · 1440", width: 1440, group: "Desktop" },
  { id: "fhd", label: "Full HD · 1920", width: 1920, group: "Desktop" },
  { id: "qhd", label: "Ultra-wide · 2560", width: 2560, group: "Desktop" },
  { id: "tablet-l", label: "Tablet landscape · 1024", width: 1024, group: "Tablet" },
  { id: "tablet-p", label: "Tablet portrait · 768", width: 768, group: "Tablet" },
  { id: "mobile", label: "Mobile · 390", width: 390, group: "Mobile" },
];

export interface ViewState { zoom: number; deviceId: string; autoFit: boolean; handTool: boolean }
export const viewStore = createStore<ViewState>({ zoom: 1, deviceId: "fluid", autoFit: false, handTool: false });
export const MIN_ZOOM = 0.2, MAX_ZOOM = 3;
export const clampZoom = (z: number) => Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, Math.round(z * 100) / 100));
export const getZoom = () => viewStore.get().zoom;

// ─── Transient sizes while resizing (avoid committing history per pixel) ───
export interface LiveSize { flex?: number; width?: number; height?: number }
export const liveStore = createStore<Record<string, LiveSize>>({});
export function setLive(id: string, v: LiveSize) { liveStore.set(s => ({ ...s, [id]: v })); }
export function clearLive(ids: string[]) {
  liveStore.set(s => { const n = { ...s }; for (const i of ids) delete n[i]; return n; });
}
export function useLive(id: string): LiveSize | undefined {
  return useSyncExternalStore(liveStore.subscribe, () => liveStore.get()[id], () => undefined);
}

// ─── Hover (single listener at canvas level, not per node) ─────────────────
export const hoverStore = createStore<{ id: string | null }>({ id: null });

/** Whether the variable lineage graph is shown in the main workspace. */
export const lineageStore = createStore<boolean>(false);
