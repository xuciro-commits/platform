"use client";

import React, {
  createContext, useCallback, useContext, useEffect, useLayoutEffect, useMemo, useRef, useState, useSyncExternalStore,
} from "react";
import type { ModuleDef, VariableDef, WidgetDef, SectionDef, EventAction, WidgetType } from "./types";
import { buildDefaultModule } from "./seedModule";
import { buildOntology, type Ontology, type AnyObj } from "./ontology";
import { applyEventAction, computeVariables, EvalCache, type EventContext, type VarValues } from "./engine";
import {
  addPage, addOverlay, addSectionRelative, addWidgetToSection, copySelection, createWidget,
  deletePage, deleteSection, deleteVariable, deleteWidget, describeImpact, duplicateSection,
  duplicateWidget, makeUnused, pasteClipboard, restoreUnused, findParent, type ClipboardPayload,
} from "./moduleOps";
import { applyDrop, arrangeSection, groupNode, indent, moveSibling, outdent, ungroupSection, type ArrangePreset } from "./layoutOps";
import type { MenuItem } from "./ui/ContextMenu";
import { applyAction, defaultOntologyMeta, type ActionEdit, type OntologyMeta } from "./ontologyMeta";
import { configureDnd, type DragPayload, type DropTarget } from "./dnd";
import { metrics } from "./runtimeStores";
import { migrateModule, WORKSHOP_SCHEMA_VERSION } from "./moduleMigration";

export type Mode = "builder" | "runtime";
export type TextScale = "compact" | "default" | "large" | "xl";
export const TEXT_SCALES: Record<TextScale, number> = { compact: 0.92, default: 1, large: 1.12, xl: 1.25 };

export interface Selection {
  kind: "widget" | "section" | "page" | "overlay" | "header" | "variable" | "flow" | "flowNode" | "flowEdge" | null;
  id: string | null;
}
export interface Toast { id: string; kind: "info" | "success" | "warning" | "error"; message: string }
export interface ActionLogEntry { id: string; ts: number; actionType: string; displayName: string; user: string; params: Record<string, unknown>; edits: ActionEdit[] }
interface HistoryEntry { label: string; module: ModuleDef }
interface ConfirmState { title: string; message: string; impact: string[]; onConfirm: () => void }
type LeftPanel = "overview" | "layout" | "widgets" | "variables" | "ontology" | "flows" | "settings" | "profiler" | "changelog";

/** State widgets are allowed to depend on. Everything here is either data or a *stable* function. */
export interface CoreState {
  mode: Mode; setMode: (m: Mode) => void;
  module: ModuleDef; ontology: Ontology; ontologyMeta: OntologyMeta; dataVersion: number;
  theme: "light" | "dark"; toggleTheme: () => void;
  values: VarValues; setValues: (updater: (prev: VarValues) => VarValues) => void;
  currentPageId: string; setCurrentPageId: (id: string) => void;
  actionLog: ActionLogEntry[];
  openOverlay: (id: string) => void; closeOverlay: (id: string) => void;
  setSectionCollapsed: (id: string, c: boolean | "toggle") => void;
  setTabIndex: (sectionId: string, idx: number) => void;
  updateModule: (updater: (m: ModuleDef) => ModuleDef, label?: string) => void;
  fireEvents: (actions: EventAction[], triggerValue?: unknown) => void;
  mutateAsset: (id: string, patch: Partial<AnyObj>) => void;
  executeAction: (apiName: string, params: Record<string, unknown>) => { ok: boolean; errors: string[] };
  pushToast: (t: Omit<Toast, "id">) => void;
  openContextMenu: (x: number, y: number, items: MenuItem[]) => void;
  closeContextMenu: () => void;
  requestConfirm: (c: ConfirmState) => void;
}

/** Builder chrome state. Volatile — widgets never subscribe to this. */
export interface UiState {
  selection: Selection; select: (sel: Selection) => void;
  openOverlayIds: string[]; collapsedSections: Record<string, boolean>; tabSelection: Record<string, number>;
  undo: () => void; redo: () => void; canUndo: boolean; canRedo: boolean; undoLabel: string | null; redoLabel: string | null;
  toasts: Toast[]; dismissToast: (id: string) => void;
  leftPanel: LeftPanel; setLeftPanel: (p: LeftPanel) => void;
  savedSnapshots: Array<{ ts: number; label: string; module: ModuleDef }>; snapshot: (label: string) => void;
  publish: () => void; publishedVersion: number; isDirtySincePublish: boolean;
  saveState: "saved" | "saving" | "unsaved" | "failed"; retrySave: () => void;
  clipboard: ClipboardPayload | null;
  copySel: () => void; cutSel: () => void; pasteSel: (targetSectionId?: string) => void; duplicateSel: () => void;
  deleteSel: () => void; makeUnusedSel: () => void; restoreWidget: (widgetId: string) => void;
  addSectionAt: (sectionId: string, where: "above" | "below" | "left" | "right") => void;
  moveSel: (dir: "up" | "down") => void; moveSiblingSel: (delta: -1 | 1) => void;
  groupSel: (layout: "columns" | "rows") => void; ungroupSel: () => void; outdentSel: () => void; indentSel: () => void;
  arrangeSel: (preset: ArrangePreset) => void;
  addWidgetOfType: (type: WidgetType, name: string, sectionId?: string) => string;
  addNewPage: () => string; addNewOverlay: (kind: "drawer" | "modal") => string;
  commitDrop: (payload: DragPayload, target: DropTarget) => void;
  confirm: ConfirmState | null; cancelConfirm: () => void;
  contextMenu: { x: number; y: number; items: MenuItem[] } | null;
  commandOpen: boolean; setCommandOpen: (v: boolean) => void;
  headerCollapsed: boolean; setHeaderCollapsed: (v: boolean) => void;
  updateOntologyMeta: (updater: (m: OntologyMeta) => OntologyMeta) => void; resetOntologyMeta: () => void;
  textScale: TextScale; setTextScale: (s: TextScale) => void;
  activeFlowId: string; setActiveFlowId: (id: string) => void;
}
export type WorkshopState = CoreState & UiState;
export interface StoreSnapshot { core: CoreState; ui: UiState }

// ─── Contexts + selector store ─────────────────────────────────────────────
export const CoreCtx = createContext<CoreState | null>(null);
const UiCtx = createContext<UiState | null>(null);
interface SnapStore { getSnapshot: () => StoreSnapshot; subscribe: (fn: () => void) => () => void }
export const StoreCtx = createContext<SnapStore | null>(null);

export function useCore(): CoreState {
  const v = useContext(CoreCtx);
  if (!v) throw new Error("useCore must be used inside WorkshopProvider");
  return v;
}
/** Convenience for builder chrome: merged core + ui (re-renders on either). Prefer `useWS` in hot paths. */
export function useWorkshop(): WorkshopState {
  const core = useContext(CoreCtx), ui = useContext(UiCtx);
  if (!core || !ui) throw new Error("useWorkshop must be used inside WorkshopProvider");
  return useMemo(() => ({ ...core, ...ui }) as WorkshopState, [core, ui]);
}

/** Subscribe to a slice of state; re-renders only when the selected value changes (Object.is by default). */
export function useWS<T>(selector: (s: StoreSnapshot) => T, equal: (a: T, b: T) => boolean = Object.is): T {
  const store = useContext(StoreCtx);
  if (!store) throw new Error("useWS must be used inside WorkshopProvider");
  const cache = useRef<{ snap: StoreSnapshot | null; sel: typeof selector | null; val: T | undefined; has: boolean }>({ snap: null, sel: null, val: undefined, has: false });
  const get = () => {
    const snap = store.getSnapshot();
    const c = cache.current;
    if (c.has && c.snap === snap && c.sel === selector) return c.val as T;
    const next = selector(snap);
    if (c.has && equal(c.val as T, next)) { c.snap = snap; c.sel = selector; return c.val as T; }
    cache.current = { snap, sel: selector, val: next, has: true };
    return next;
  };
  return useSyncExternalStore(store.subscribe, get, get);
}
export function shallowEqual<T extends Record<string, unknown>>(a: T, b: T): boolean {
  if (a === b) return true;
  const ka = Object.keys(a), kb = Object.keys(b);
  if (ka.length !== kb.length) return false;
  for (const k of ka) if (!Object.is(a[k], b[k])) return false;
  return true;
}
export function useWSShallow<T extends Record<string, unknown>>(selector: (s: StoreSnapshot) => T): T { return useWS(selector, shallowEqual); }

function useStable<A extends unknown[], R>(fn: (...a: A) => R): (...a: A) => R {
  const ref = useRef(fn);
  ref.current = fn;
  return useCallback((...a: A) => ref.current(...a), []);
}

// ─── Persistence ───────────────────────────────────────────────────────────
const SCHEMA = WORKSHOP_SCHEMA_VERSION;
const LS_KEY = "foundry.workshop.module.v6";
const LS_VALUES = "foundry.workshop.values.v5";
const LS_META = "foundry.workshop.ontologyMeta.v3";
const LS_PREFS = "foundry.workshop.prefs.v1";

function validModule(m: unknown): m is ModuleDef {
  const x = m as Partial<ModuleDef> | null;
  return !!x && Array.isArray(x.pages) && x.pages.length > 0 && !!x.sections && !!x.widgets && Array.isArray(x.variables) && Array.isArray(x.overlays);
}
function readLS<T>(key: string): T | null {
  try { const raw = localStorage.getItem(key); return raw ? (JSON.parse(raw) as T) : null; } catch { return null; }
}
const STRUCTURAL = /^(add|delete|move|drop|duplicate|paste|cut|make|restore|group|ungroup|arrange|indent|outdent|resize|swap)/;

function ModuleLoading() {
  return (
    <div className="h-screen flex flex-col" style={{ background: "var(--fnd-bg)" }} aria-busy="true" aria-label="Loading module">
      <div className="fnd-skeleton" style={{ height: 44 }}/>
      <div className="flex-1 flex">
        <div className="fnd-skeleton" style={{ width: 300, margin: 8 }}/>
        <div className="flex-1 p-4 space-y-3"><div className="fnd-skeleton" style={{ height: 36 }}/><div className="fnd-skeleton" style={{ height: 120 }}/><div className="fnd-skeleton" style={{ height: 320 }}/></div>
        <div className="fnd-skeleton" style={{ width: 320, margin: 8 }}/>
      </div>
    </div>
  );
}

export function WorkshopProvider({ children, initialMode = "builder" as Mode }: { children: React.ReactNode; initialMode?: Mode }) {
  const [hydrated, setHydrated] = useState(false);
  const [mode, setMode] = useState<Mode>(initialMode);
  const [theme, setTheme] = useState<"light" | "dark">("light");
  const [textScale, setTextScaleState] = useState<TextScale>("default");
  const [module, setModule] = useState<ModuleDef>(() => buildDefaultModule());
  const [ontology, setOntology] = useState<Ontology>(() => buildOntology());
  const [ontologyMeta, setOntologyMeta] = useState<OntologyMeta>(() => defaultOntologyMeta());
  const [dataVersion, setDataVersion] = useState(0);
  const [selection, setSelection] = useState<Selection>({ kind: null, id: null });
  const [currentPageId, setCurrentPageIdRaw] = useState<string>(() => module.pages[0]?.id ?? "");
  const [openOverlayIds, setOpenOverlayIds] = useState<string[]>([]);
  const [collapsedSections, setCollapsedSections] = useState<Record<string, boolean>>({});
  const [tabSelection, setTabSelection] = useState<Record<string, number>>({});
  const [leftPanel, setLeftPanel] = useState<LeftPanel>("layout");
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [future, setFuture] = useState<HistoryEntry[]>([]);
  const [savedSnapshots, setSavedSnapshots] = useState<UiState["savedSnapshots"]>([]);
  const [saveState, setSaveState] = useState<UiState["saveState"]>("saved");
  const [clipboard, setClipboard] = useState<ClipboardPayload | null>(null);
  const [confirm, setConfirm] = useState<ConfirmState | null>(null);
  const [contextMenu, setContextMenu] = useState<UiState["contextMenu"]>(null);
  const [commandOpen, setCommandOpen] = useState(false);
  const [headerCollapsed, setHeaderCollapsed] = useState(false);
  const [actionLog, setActionLog] = useState<ActionLogEntry[]>([]);
  const [activeFlowId, setActiveFlowId] = useState("flow-telemetry");
  const [publishedModule, setPublishedModule] = useState<ModuleDef | null>(null);
  const [publishedVersion, setPublishedVersion] = useState(0);
  const [values, setValuesState] = useState<VarValues>(() => {
    const init: VarValues = {};
    for (const v of module.variables) if (v.definitionKind === "static") init[v.id] = v.staticValue;
    return init;
  });

  // Latest-value mirror so stable callbacks never close over stale state.
  const L = useRef({} as {
    module: ModuleDef; ontology: Ontology; meta: OntologyMeta; values: VarValues; selection: Selection; pageId: string;
    history: HistoryEntry[]; future: HistoryEntry[]; clipboard: ClipboardPayload | null; openOverlayIds: string[]; confirm: ConfirmState | null;
    published: ModuleDef | null; publishedVersion: number; lastEdit: { label: string; t: number } | null; lastVarPage: string;
  });

  // ── Hydration (localStorage first, then server) ──
  useEffect(() => {
    let cancelled = false;
    const m = readLS<ModuleDef>(LS_KEY) ?? readLS<ModuleDef>("foundry.workshop.module.v5");
    const v = readLS<VarValues>(LS_VALUES);
    const meta = readLS<OntologyMeta>(LS_META);
    const prefs = readLS<{ theme?: "light" | "dark"; textScale?: TextScale }>(LS_PREFS);
    if (prefs?.theme) setTheme(prefs.theme);
    if (prefs?.textScale && TEXT_SCALES[prefs.textScale]) setTextScaleState(prefs.textScale);
    if (meta && Array.isArray(meta.objectTypes) && meta.apiNamespace) setOntologyMeta(meta);
    if (v) setValuesState(v);
    if (validModule(m)) { setModule(m); setCurrentPageIdRaw(m.pages[0].id); L.current.lastVarPage = m.pages[0].id; setHydrated(true); }
    else {
      fetch("/api/workshop/module").then(r => r.json()).then((j: { module?: (ModuleDef & { __schema?: number }) | null }) => {
        if (cancelled) return;
        if (j.module && j.module.__schema === SCHEMA && validModule(j.module)) { setModule(j.module); setCurrentPageIdRaw(j.module.pages[0].id); L.current.lastVarPage = j.module.pages[0].id; }
      }).catch(() => { /* offline: keep default */ }).finally(() => { if (!cancelled) setHydrated(true); });
    }
    return () => { cancelled = true; };
  }, []);
  useEffect(() => { if (hydrated && !metrics.firstInteractiveMs) metrics.firstInteractiveMs = performance.now() - metrics.startedAt; }, [hydrated]);

  // ── Derived variable values (incremental, memoised per variable) ──
  const evalCache = useRef(new EvalCache());
  const computedValues = useMemo(
    () => computeVariables(module, ontology, values, dataVersion, ontologyMeta, evalCache.current),
    // only the variable definitions matter — layout edits must not invalidate evaluation
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [module.variables, ontology, values, dataVersion, ontologyMeta],
  );

  L.current.module = module; L.current.ontology = ontology; L.current.meta = ontologyMeta; L.current.values = computedValues;
  L.current.selection = selection; L.current.pageId = currentPageId; L.current.history = history; L.current.future = future;
  L.current.clipboard = clipboard; L.current.openOverlayIds = openOverlayIds; L.current.confirm = confirm;
  L.current.published = publishedModule; L.current.publishedVersion = publishedVersion;
  if (L.current.lastVarPage === undefined) L.current.lastVarPage = module.pages[0]?.id ?? "";

  // ── Persistence (debounced, honest status) ──
  const persistNow = useStable(() => {
    const m = L.current.module;
    setSaveState("saving");
    try { localStorage.setItem(LS_KEY, JSON.stringify(m)); } catch { setSaveState("failed"); return; }
    fetch("/api/workshop/module", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: m.id, name: m.name, definition: { ...m, __schema: SCHEMA } }) })
      .then(r => setSaveState(r.ok ? "saved" : "failed"))
      .catch(() => setSaveState("failed"));
  });
  useEffect(() => {
    if (!hydrated) return;
    setSaveState("saving");
    const t = setTimeout(persistNow, 600);
    return () => clearTimeout(t);
  }, [module, hydrated, persistNow]);
  useEffect(() => {
    if (!hydrated) return;
    const t = setTimeout(() => { try { localStorage.setItem(LS_VALUES, JSON.stringify(values)); } catch { /* quota */ } }, 400);
    return () => clearTimeout(t);
  }, [values, hydrated]);
  useEffect(() => {
    if (!hydrated) return;
    try { localStorage.setItem(LS_META, JSON.stringify(ontologyMeta)); } catch { /* quota */ }
  }, [ontologyMeta, hydrated]);
  useEffect(() => {
    if (!hydrated) return;
    try { localStorage.setItem(LS_PREFS, JSON.stringify({ theme, textScale })); } catch { /* quota */ }
    document.documentElement.classList.toggle("dark", theme === "dark");
    document.documentElement.style.setProperty("--fnd-text-scale", String(TEXT_SCALES[textScale]));
  }, [theme, textScale, hydrated]);

  // ── Basic UI actions (all stable) ──
  const pushToast = useCallback((t: Omit<Toast, "id">) => {
    const id = `t${Date.now()}${Math.random().toString(36).slice(2, 6)}`;
    setToasts(ts => [...ts.slice(-4), { id, ...t }]);
    setTimeout(() => setToasts(ts => ts.filter(x => x.id !== id)), 3500);
  }, []);
  const dismissToast = useCallback((id: string) => setToasts(ts => ts.filter(x => x.id !== id)), []);
  const setValues = useCallback((updater: (prev: VarValues) => VarValues) => setValuesState(prev => updater(prev)), []);
  const setTabIndex = useCallback((sectionId: string, idx: number) => setTabSelection(prev => (prev[sectionId] === idx ? prev : { ...prev, [sectionId]: idx })), []);
  const setSectionCollapsed = useCallback((id: string, c: boolean | "toggle") => setCollapsedSections(prev => ({ ...prev, [id]: c === "toggle" ? !prev[id] : c })), []);
  const toggleTheme = useCallback(() => setTheme(t => (t === "light" ? "dark" : "light")), []);
  const refreshData = useCallback(() => { setDataVersion(v => v + 1); pushToast({ kind: "info", message: "Data refreshed" }); }, [pushToast]);
  const mutateAsset = useCallback((id: string, patch: Partial<AnyObj>) => {
    setOntology(prev => ({ ...prev, assets: prev.assets.map(a => (a.id === id ? ({ ...a, ...patch } as typeof a) : a)) }));
  }, []);
  const setCurrentPageId = useStable((id: string) => {
    setCurrentPageIdRaw(id);
    L.current.lastVarPage = id;
    setValuesState(p => (p.currentPage === id ? p : { ...p, currentPage: id }));
  });
  const setTextScale = useCallback((s: TextScale) => setTextScaleState(s), []);

  // Variable ⇄ page selection (a `currentPage` variable can drive navigation)
  useEffect(() => {
    const v = computedValues.currentPage;
    if (typeof v === "string" && v !== L.current.lastVarPage) {
      L.current.lastVarPage = v;
      if (module.pages.some(p => p.id === v)) setCurrentPageIdRaw(v);
    }
  }, [computedValues.currentPage, module.pages]);

  // ── Overlays: open state is variable-backed in both directions ──
  const fireRef = useRef<(a: EventAction[], t?: unknown) => void>(() => {});
  const openOverlay = useStable((id: string) => {
    setOpenOverlayIds(prev => (prev.includes(id) ? prev : [...prev, id]));
    const o = L.current.module.overlays.find(x => x.id === id);
    if (o?.openVariableId) setValuesState(p => (p[o.openVariableId!] === true ? p : { ...p, [o.openVariableId!]: true }));
  });
  const closeOverlay = useStable((id: string) => {
    const wasOpen = L.current.openOverlayIds.includes(id);
    setOpenOverlayIds(prev => prev.filter(x => x !== id));
    const o = L.current.module.overlays.find(x => x.id === id);
    if (o?.openVariableId) setValuesState(p => (p[o.openVariableId!] === false ? p : { ...p, [o.openVariableId!]: false }));
    if (wasOpen && o?.onCloseActions?.length) fireRef.current(o.onCloseActions);
  });
  useEffect(() => {
    for (const o of module.overlays) {
      if (!o.openVariableId) continue;
      const want = computedValues[o.openVariableId] === true;
      const open = openOverlayIds.includes(o.id);
      if (want && !open) setOpenOverlayIds(p => (p.includes(o.id) ? p : [...p, o.id]));
      else if (!want && open && o.openVariableId in computedValues) setOpenOverlayIds(p => p.filter(x => x !== o.id));
    }
  }, [computedValues, module.overlays, openOverlayIds]);

  // ── Actions (ontology writeback) ──
  const executeAction = useStable((apiName: string, params: Record<string, unknown>) => {
    const res = applyAction(L.current.ontology, L.current.meta, apiName, params);
    if (!res.ok || !res.ontology) {
      pushToast({ kind: "error", message: res.errors[0] ?? "Action failed" });
      return { ok: false, errors: res.errors };
    }
    L.current.ontology = res.ontology; // consecutive Actions in one flow see prior writes before React commits
    setOntology(res.ontology);
    // keep object-valued variables (selectedAsset etc.) pointing at the edited objects
    setValuesState(prev => {
      let next = prev, changed = false;
      for (const e of res.edits) {
        for (const [k, v] of Object.entries(prev)) {
          if (v && typeof v === "object" && !Array.isArray(v) && (v as Record<string, unknown>).id === e.objectId) {
            if (!changed) { next = { ...prev }; changed = true; }
            next[k] = e.kind === "delete" ? null : e.after;
          } else if (Array.isArray(v) && v.some(x => x && typeof x === "object" && (x as Record<string, unknown>).id === e.objectId)) {
            if (!changed) { next = { ...prev }; changed = true; }
            next[k] = e.kind === "delete" ? v.filter(x => (x as Record<string, unknown>).id !== e.objectId) : v.map(x => ((x as Record<string, unknown>).id === e.objectId ? e.after : x));
          }
        }
      }
      return next;
    });
    const at = L.current.meta.actionTypes.find(a => a.apiName === apiName);
    setActionLog(l => [{ id: `log${Date.now()}${Math.random().toString(36).slice(2, 5)}`, ts: Date.now(), actionType: apiName, displayName: at?.displayName ?? apiName, user: "Jane Smith", params, edits: res.edits }, ...l].slice(0, 300));
    pushToast({ kind: "success", message: `${at?.displayName ?? apiName}: ${res.edits.length} object edit(s) applied` });
    return { ok: true, errors: [] };
  });

  const runAction = useStable((actionId: string) => {
    const at = L.current.meta.actionTypes.find(a => a.apiName === actionId);
    if (!at) { pushToast({ kind: "error", message: `Unknown action ${actionId}` }); return; }
    const vals = L.current.values;
    const params: Record<string, unknown> = {};
    for (const p of at.parameters) {
      if (p.type === "ObjectReference") {
        const hit = Object.values(vals).find(v => v && typeof v === "object" && !Array.isArray(v) && (v as Record<string, unknown>).__type === p.validation.objectTypeApiName) as Record<string, unknown> | undefined;
        if (hit) params[p.apiName] = hit.id;
      }
    }
    const first = at.parameters[0]?.apiName;
    const obj = Object.values(vals).find(v => v && typeof v === "object" && !Array.isArray(v) && (v as Record<string, unknown>).id === params[first]) as Record<string, unknown> | undefined;
    for (const p of at.parameters) if (params[p.apiName] === undefined && p.defaultFrom?.startsWith("object.") && obj) params[p.apiName] = obj[p.defaultFrom.slice(7)];
    executeAction(actionId, params);
  });

  const fireEvents = useStable((actions: EventAction[], triggerValue?: unknown) => {
    const ctx: EventContext = {
      values: L.current.values, setValues, module: L.current.module,
      switchPage: setCurrentPageId, openOverlay, closeOverlay, toggleTheme, refreshData, runAction, setSectionCollapsed, setTabIndex,
    };
    for (const a of actions) {
      try { applyEventAction(a, ctx, triggerValue); }
      catch (e) { pushToast({ kind: "error", message: `Event failed: ${(e as Error).message}` }); }
    }
  });
  fireRef.current = fireEvents;

  // Auto-refresh is a real timer that re-evaluates every variable
  const autoRefresh = computedValues.autoRefresh === true;
  useEffect(() => {
    if (!autoRefresh) return;
    const t = setInterval(() => setDataVersion(v => v + 1), 30000);
    return () => clearInterval(t);
  }, [autoRefresh]);

  // ── History (coalesces continuous edits such as typing) ──
  const updateModule = useStable((updater: (m: ModuleDef) => ModuleDef, label: string = "edit"): void => {
    const prev = L.current.module;
    const next = updater(prev);
    if (next === prev) return;
    const now = performance.now();
    const last = L.current.lastEdit;
    const coalesce = !!last && last.label === label && now - last.t < 700 && !STRUCTURAL.test(label);
    if (!coalesce) setHistory(h => [...h, { label, module: prev }].slice(-100));
    L.current.lastEdit = { label, t: now };
    setFuture([]);
    L.current.module = next;
    setModule(next);
  });
  const undo = useStable(() => {
    const h = L.current.history;
    if (!h.length) return;
    const last = h[h.length - 1];
    setFuture(f => [...f, { label: last.label, module: L.current.module }]);
    setHistory(h.slice(0, -1));
    L.current.lastEdit = null; L.current.module = last.module;
    setModule(last.module);
  });
  const redo = useStable(() => {
    const f = L.current.future;
    if (!f.length) return;
    const next: HistoryEntry = f[f.length - 1];
    setHistory(h => [...h, { label: next.label, module: L.current.module }]);
    setFuture(f.slice(0, -1));
    L.current.lastEdit = null; L.current.module = next.module;
    setModule(next.module);
  });

  const snapshot = useStable((label: string) => {
    setSavedSnapshots(s => [...s, { ts: Date.now(), label, module: L.current.module }].slice(-30));
    pushToast({ kind: "success", message: `Snapshot "${label}" saved` });
  });
  const publish = useStable(() => {
    const v = L.current.publishedVersion + 1;
    setSavedSnapshots(s => [...s, { ts: Date.now(), label: `v${v} · published`, module: L.current.module }].slice(-30));
    setPublishedModule(L.current.module); setPublishedVersion(v);
    pushToast({ kind: "success", message: `Published version ${v}` });
  });

  const requestConfirm = useCallback((c: ConfirmState) => setConfirm(c), []);
  const cancelConfirm = useCallback(() => setConfirm(null), []);
  const openContextMenu = useCallback((x: number, y: number, items: MenuItem[]) => setContextMenu({ x, y, items }), []);
  const closeContextMenu = useCallback(() => setContextMenu(null), []);
  const select = useCallback((s: Selection) => setSelection(s), []);

  // ── Structural editing commands (operate on current selection) ──
  const targetSectionId = useStable((): string => {
    const { selection: sel, module: mod, pageId } = L.current;
    if (sel.kind === "section" && sel.id) return sel.id;
    if (sel.kind === "widget" && sel.id) { const p = findParent(mod, sel.id); if (p) return p.sectionId; }
    const page = mod.pages.find(p => p.id === pageId) ?? mod.pages[0];
    return page?.rootSectionId ?? Object.keys(mod.sections)[0];
  });
  const selNode = () => { const s = L.current.selection; return (s.kind === "widget" || s.kind === "section") && s.id ? { kind: s.kind, id: s.id } : null; };

  const copySel = useStable(() => {
    const n = selNode(); if (!n) return;
    const c = copySelection(L.current.module, n.kind, n.id);
    if (c) { setClipboard(c); pushToast({ kind: "info", message: `${n.kind === "widget" ? "Widget" : "Section"} copied` }); }
  });
  const cutSel = useStable(() => {
    const n = selNode(); if (!n) return;
    copySel();
    if (n.kind === "widget") { updateModule(m => makeUnused(m, n.id), "cut widget"); setSelection({ kind: null, id: null }); }
  });
  const pasteSel = useStable((sid?: string) => {
    const clip = L.current.clipboard; if (!clip) return;
    const res = pasteClipboard(L.current.module, clip, sid ?? targetSectionId());
    if (res) { updateModule(() => res.module, "paste"); setSelection(res.select); }
  });
  const duplicateSel = useStable(() => {
    const n = selNode(); if (!n) return;
    const res = n.kind === "widget" ? duplicateWidget(L.current.module, n.id) : duplicateSection(L.current.module, n.id);
    if (res) { updateModule(() => res.module, `duplicate ${n.kind}`); setSelection({ kind: n.kind, id: res.newId }); }
  });
  const deleteSel = useStable(() => {
    const { selection: sel, module: mod } = L.current;
    if (!sel.kind || !sel.id) return;
    const kind = sel.kind, id = sel.id;
    if (kind !== "widget" && kind !== "section" && kind !== "page" && kind !== "overlay" && kind !== "variable") return;
    if (kind === "section" && mod.pages.some(p => p.rootSectionId === id)) { pushToast({ kind: "warning", message: "A page's root section can't be deleted — delete the page instead." }); return; }
    requestConfirm({
      title: `Delete ${kind}`, message: `This will permanently remove the selected ${kind} from the module.`, impact: describeImpact(mod, kind, id),
      onConfirm: () => {
        if (kind === "widget") updateModule(m => deleteWidget(m, id), "delete widget");
        else if (kind === "section") updateModule(m => deleteSection(m, id), "delete section");
        else if (kind === "page") updateModule(m => deletePage(m, id), "delete page");
        else if (kind === "overlay") updateModule(m => ({ ...m, overlays: m.overlays.filter(o => o.id !== id) }), "delete overlay");
        else updateModule(m => deleteVariable(m, id), "delete variable");
        setSelection({ kind: null, id: null }); setConfirm(null);
      },
    });
  });
  const makeUnusedSel = useStable(() => {
    const s = L.current.selection;
    if (s.kind === "widget" && s.id) { const id = s.id; updateModule(m => makeUnused(m, id), "make unused"); setSelection({ kind: null, id: null }); }
  });
  const restoreWidget = useStable((widgetId: string) => updateModule(m => restoreUnused(m, widgetId, targetSectionId()), "restore unused"));
  const addSectionAt = useStable((sectionId: string, where: "above" | "below" | "left" | "right") => updateModule(m => addSectionRelative(m, sectionId, where), `add section ${where}`));
  const moveSiblingSel = useStable((delta: -1 | 1) => { const n = selNode(); if (n) updateModule(m => moveSibling(m, n.id, delta), `move ${delta < 0 ? "up" : "down"}`); });
  const moveSel = useStable((dir: "up" | "down") => moveSiblingSel(dir === "up" ? -1 : 1));
  const groupSel = useStable((layout: "columns" | "rows") => {
    const n = selNode(); if (!n) return;
    const res = groupNode(L.current.module, n.id, layout);
    if (res) { updateModule(() => res.module, "group"); setSelection({ kind: "section", id: res.id }); }
  });
  const ungroupSel = useStable(() => { const s = L.current.selection; if (s.kind === "section" && s.id) { const id = s.id; updateModule(m => ungroupSection(m, id), "ungroup"); setSelection({ kind: null, id: null }); } });
  const outdentSel = useStable(() => { const n = selNode(); if (n) updateModule(m => outdent(m, n.id), "outdent"); });
  const indentSel = useStable(() => { const n = selNode(); if (n) updateModule(m => indent(m, n.id), "indent"); });
  const arrangeSel = useStable((preset: ArrangePreset) => {
    const id = targetSectionId();
    updateModule(m => arrangeSection(m, id, preset), `arrange ${preset}`);
  });
  const addWidgetOfType = useStable((type: WidgetType, name: string, sectionId?: string) => {
    const w: WidgetDef = createWidget(type, name);
    updateModule(m => addWidgetToSection(m, sectionId ?? targetSectionId(), w), "add widget");
    setSelection({ kind: "widget", id: w.id });
    return w.id;
  });
  const addNewPage = useStable(() => {
    const res = addPage(L.current.module);
    updateModule(() => res.module, "add page");
    setCurrentPageId(res.pageId); setSelection({ kind: "page", id: res.pageId });
    return res.pageId;
  });
  const addNewOverlay = useStable((kind: "drawer" | "modal") => {
    const res = addOverlay(L.current.module, kind);
    updateModule(() => res.module, "add overlay");
    setSelection({ kind: "overlay", id: res.overlayId });
    return res.overlayId;
  });
  const commitDrop = useStable((payload: DragPayload, target: DropTarget) => {
    const res = applyDrop(L.current.module, payload, target);
    if (!res) { pushToast({ kind: "warning", message: "That drop isn't allowed here." }); return; }
    updateModule(() => res.module, payload.kind === "new" ? "drop new widget" : target.kind === "swap" ? "swap" : "move");
    setSelection(res.select);
  });
  useEffect(() => {
    configureDnd({ getModule: () => L.current.module, commit: commitDrop, getScroller: () => document.querySelector<HTMLElement>("[data-canvas-scroller]") });
  }, [commitDrop]);

  const updateOntologyMeta = useCallback((updater: (m: OntologyMeta) => OntologyMeta) => setOntologyMeta(prev => updater(prev)), []);
  const resetOntologyMeta = useCallback(() => setOntologyMeta(defaultOntologyMeta()), []);

  // ── Keyboard ──
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      const inField = tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || (e.target as HTMLElement)?.isContentEditable;
      const meta = e.metaKey || e.ctrlKey;
      const k = e.key.toLowerCase();
      if (meta && k === "k") { e.preventDefault(); setCommandOpen(true); return; }
      if (e.key === "Escape") {
        setCommandOpen(false); setContextMenu(null);
        if (L.current.confirm) { setConfirm(null); return; }
        const ids = L.current.openOverlayIds;
        if (ids.length) { const last = ids[ids.length - 1]; const o = L.current.module.overlays.find(x => x.id === last); if (!o || o.closeOnEsc !== false) closeOverlay(last); }
        else if (!inField) setSelection({ kind: null, id: null });
        return;
      }
      if (inField) return;
      if (meta && k === "z") { e.preventDefault(); if (e.shiftKey) redo(); else undo(); }
      else if (meta && k === "y") { e.preventDefault(); redo(); }
      else if (meta && k === "c") { e.preventDefault(); copySel(); }
      else if (meta && k === "x") { e.preventDefault(); cutSel(); }
      else if (meta && k === "v") { e.preventDefault(); pasteSel(); }
      else if (meta && k === "d") { e.preventDefault(); duplicateSel(); }
      else if (meta && k === "g") { e.preventDefault(); if (e.shiftKey) ungroupSel(); else groupSel("columns"); }
      else if (e.altKey && e.key === "ArrowUp") { e.preventDefault(); moveSiblingSel(-1); }
      else if (e.altKey && e.key === "ArrowDown") { e.preventDefault(); moveSiblingSel(1); }
      else if (e.altKey && e.key === "ArrowLeft") { e.preventDefault(); if (e.shiftKey) outdentSel(); else moveSiblingSel(-1); }
      else if (e.altKey && e.key === "ArrowRight") { e.preventDefault(); if (e.shiftKey) indentSel(); else moveSiblingSel(1); }
      else if (e.key === "Delete" || e.key === "Backspace") { e.preventDefault(); deleteSel(); }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [undo, redo, copySel, cutSel, pasteSel, duplicateSel, deleteSel, groupSel, ungroupSel, moveSiblingSel, outdentSel, indentSel, closeOverlay]);

  // ── Assemble contexts. Function identities above are stable, so these change only when data changes. ──
  const core = useMemo<CoreState>(() => ({
    mode, setMode, module, ontology, ontologyMeta, dataVersion, theme, toggleTheme, values: computedValues, setValues,
    currentPageId, setCurrentPageId, actionLog, openOverlay, closeOverlay, setSectionCollapsed, setTabIndex, updateModule, fireEvents,
    mutateAsset, executeAction, pushToast, openContextMenu, closeContextMenu, requestConfirm,
  }), [mode, module, ontology, ontologyMeta, dataVersion, theme, computedValues, currentPageId, actionLog,
    toggleTheme, setValues, setCurrentPageId, openOverlay, closeOverlay, setSectionCollapsed, setTabIndex, updateModule, fireEvents,
    mutateAsset, executeAction, pushToast, openContextMenu, closeContextMenu, requestConfirm]);

  const ui = useMemo<UiState>(() => ({
    selection, select, openOverlayIds, collapsedSections, tabSelection,
    undo, redo, canUndo: history.length > 0, canRedo: future.length > 0,
    undoLabel: history.length ? history[history.length - 1].label : null, redoLabel: future.length ? future[future.length - 1].label : null,
    toasts, dismissToast, leftPanel, setLeftPanel, savedSnapshots, snapshot, publish, publishedVersion,
    isDirtySincePublish: publishedModule !== module, saveState, retrySave: persistNow, clipboard, activeFlowId, setActiveFlowId,
    copySel, cutSel, pasteSel, duplicateSel, deleteSel, makeUnusedSel, restoreWidget, addSectionAt, moveSel, moveSiblingSel,
    groupSel, ungroupSel, outdentSel, indentSel, arrangeSel, addWidgetOfType, addNewPage, addNewOverlay, commitDrop,
    confirm, cancelConfirm, contextMenu, commandOpen, setCommandOpen, headerCollapsed, setHeaderCollapsed,
    updateOntologyMeta, resetOntologyMeta, textScale, setTextScale,
  } as UiState), [selection, select, openOverlayIds, collapsedSections, tabSelection, undo, redo, history, future, toasts, dismissToast,
    leftPanel, savedSnapshots, snapshot, publish, publishedVersion, publishedModule, module, saveState, persistNow, clipboard,
    copySel, cutSel, pasteSel, duplicateSel, deleteSel, makeUnusedSel, restoreWidget, addSectionAt, moveSel, moveSiblingSel,
    groupSel, ungroupSel, outdentSel, indentSel, arrangeSel, addWidgetOfType, addNewPage, addNewOverlay, commitDrop,
    confirm, cancelConfirm, contextMenu, commandOpen, headerCollapsed, updateOntologyMeta, resetOntologyMeta, textScale, setTextScale]);

  const storeRef = useRef<{ snap: StoreSnapshot; listeners: Set<() => void>; api: SnapStore } | null>(null);
  if (!storeRef.current) {
    const listeners = new Set<() => void>();
    const holder = { snap: null as unknown as StoreSnapshot, listeners, api: null as unknown as SnapStore };
    holder.api = { getSnapshot: () => holder.snap, subscribe: fn => { listeners.add(fn); return () => { listeners.delete(fn); }; } };
    storeRef.current = holder;
  }
  const snap = useMemo<StoreSnapshot>(() => ({ core, ui }), [core, ui]);
  storeRef.current.snap = snap;
  useLayoutEffect(() => { storeRef.current?.listeners.forEach(l => l()); }, [snap]);

  return (
    <StoreCtx.Provider value={storeRef.current.api}>
      <CoreCtx.Provider value={core}>
        <UiCtx.Provider value={ui}>{hydrated ? children : <ModuleLoading/>}</UiCtx.Provider>
      </CoreCtx.Provider>
    </StoreCtx.Provider>
  );
}

// Helpers
export function findWidget(module: ModuleDef, id: string): WidgetDef | undefined { return module.widgets[id]; }
export function findSection(module: ModuleDef, id: string): SectionDef | undefined { return module.sections[id]; }
export function findVariable(module: ModuleDef, id: string): VariableDef | undefined { return module.variables.find(v => v.id === id); }
