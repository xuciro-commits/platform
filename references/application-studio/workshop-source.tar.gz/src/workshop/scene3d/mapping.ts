import type { AssetSample } from "../telemetry/telemetryStore";

export type MappingSource = "telemetry" | "ontology";
export type MappingMode = "rotation" | "position" | "scale" | "color" | "visibility";
export type Axis = "x" | "y" | "z";

/** Persisted on Scene3D Widget config. Each mapping controls one named glTF node. */
export interface SceneMapping {
  id: string;
  node: string;
  source: MappingSource;
  signalIndex?: number;
  property?: string;
  mode: MappingMode;
  axis: Axis;
  inputMin: number;
  inputMax: number;
  outputMin: number;
  outputMax: number;
  threshold?: number;
  colorLow?: string;
  colorHigh?: string;
  smooth?: number;
  enabled: boolean;
}
export interface SceneLayer {
  id: string;
  name: string;
  nodes: string[];
  visible: boolean;
  opacity: number;
  wireframe: boolean;
  color?: string;
}
export interface SceneConfig {
  modelUrl: string;
  assetVarId: string;
  selectedPartVarId?: string;
  mappings: SceneMapping[];
  layers: SceneLayer[];
  background: "light" | "dark";
  showGrid: boolean;
  quality: "performance" | "balanced" | "high";
  live: boolean;
}
export interface MappedValue { raw: number; normalised: number; value: number; isAbove: boolean }

export function resolveMapping(mapping: SceneMapping, sample: AssetSample | null | undefined, asset: Record<string, unknown> | null | undefined): MappedValue | null {
  const rawValue = mapping.source === "ontology" ? asset?.[mapping.property ?? ""] : sample?.signals[mapping.signalIndex ?? 0];
  if (rawValue === null || rawValue === undefined || rawValue === "") return null;
  const raw = Number(rawValue);
  if (!Number.isFinite(raw)) return null;
  const span = mapping.inputMax - mapping.inputMin;
  const normalised = span === 0 ? 0 : Math.max(0, Math.min(1, (raw - mapping.inputMin) / span));
  const value = mapping.outputMin + normalised * (mapping.outputMax - mapping.outputMin);
  return { raw, normalised, value, isAbove: mapping.threshold !== undefined && raw > mapping.threshold };
}

export function defaultSceneConfig(): SceneConfig {
  return {
    modelUrl: "/models/industrial-robot-cell.glb",
    assetVarId: "selectedAsset",
    selectedPartVarId: "selectedScenePart",
    background: "dark", showGrid: true, quality: "balanced", live: true,
    layers: [
      { id: "base", name: "01 / Foundation", nodes: ["Foundation", "BasePedestal", "YawMotor", "Turret"], visible: true, opacity: 1, wireframe: false },
      { id: "arm", name: "02 / Kinematics", nodes: ["ShoulderHousing", "UpperArm", "ElbowHousing", "Forearm", "WristHousing", "GripperBody", "LeftJaw", "RightJaw"], visible: true, opacity: 1, wireframe: false },
      { id: "sensors", name: "03 / Sensors", nodes: ["VibrationProbe", "TemperatureProbe", "PressureProbe", "ConveyorSensor", "SafetyBeacon"], visible: true, opacity: 1, wireframe: false },
      { id: "conveyor", name: "04 / Conveyor", nodes: ["ConveyorBed", "ConveyorBelt", "ConveyorMotor"], visible: true, opacity: 1, wireframe: false },
    ],
    mappings: [
      { id: "m-yaw", node: "BaseYaw", source: "telemetry", signalIndex: 60, mode: "rotation", axis: "y", inputMin: 400, inputMax: 1200, outputMin: -1.4, outputMax: 1.4, smooth: .12, enabled: true },
      { id: "m-shoulder", node: "ShoulderPitch", source: "telemetry", signalIndex: 0, mode: "rotation", axis: "z", inputMin: 0, inputMax: 20, outputMin: -.65, outputMax: .75, smooth: .10, enabled: true },
      { id: "m-elbow", node: "ElbowPitch", source: "telemetry", signalIndex: 10, mode: "rotation", axis: "z", inputMin: 40, inputMax: 90, outputMin: -.95, outputMax: .45, smooth: .12, enabled: true },
      { id: "m-wrist", node: "WristRoll", source: "telemetry", signalIndex: 70, mode: "rotation", axis: "y", inputMin: 5, inputMax: 42, outputMin: -1.2, outputMax: 1.2, smooth: .2, enabled: true },
      { id: "m-jaw-left", node: "FingerLeft", source: "telemetry", signalIndex: 20, mode: "position", axis: "x", inputMin: 12, inputMax: 38, outputMin: -.14, outputMax: .05, smooth: .15, enabled: true },
      { id: "m-jaw-right", node: "FingerRight", source: "telemetry", signalIndex: 20, mode: "position", axis: "x", inputMin: 12, inputMax: 38, outputMin: .14, outputMax: -.05, smooth: .15, enabled: true },
      { id: "m-probe", node: "VibrationProbe", source: "telemetry", signalIndex: 0, mode: "color", axis: "y", inputMin: 5, inputMax: 19, outputMin: 0, outputMax: 1, threshold: 11.5, colorLow: "#1abb7f", colorHigh: "#e65b43", smooth: .2, enabled: true },
      { id: "m-temp", node: "TemperatureProbe", source: "telemetry", signalIndex: 10, mode: "color", axis: "y", inputMin: 40, inputMax: 90, outputMin: 0, outputMax: 1, threshold: 77, colorLow: "#238acf", colorHigh: "#e38c32", smooth: .2, enabled: true },
      { id: "m-status", node: "SafetyBeacon", source: "ontology", property: "openAlerts", mode: "color", axis: "y", inputMin: 0, inputMax: 4, outputMin: 0, outputMax: 1, threshold: 0, colorLow: "#19ad6e", colorHigh: "#d43d35", smooth: .1, enabled: true },
    ],
  };
}

export function sceneConfigFrom(value: Record<string, unknown>): SceneConfig {
  const defaults = defaultSceneConfig();
  return {
    ...defaults,
    ...value,
    modelUrl: typeof value.modelUrl === "string" ? value.modelUrl : defaults.modelUrl,
    layers: Array.isArray(value.layers) ? value.layers as SceneLayer[] : defaults.layers,
    mappings: Array.isArray(value.mappings) ? value.mappings as SceneMapping[] : defaults.mappings,
    background: value.background === "light" ? "light" : "dark",
    quality: value.quality === "high" || value.quality === "performance" ? value.quality : "balanced",
  };
}
