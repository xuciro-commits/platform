import fs from "node:fs";
import path from "node:path";
import wabtFactory from "wabt";

const wabt = await wabtFactory();
const watPath = path.resolve("src/workshop/telemetry/telemetry_stats.wat");
const outPath = path.resolve("public/wasm/telemetry_stats.wasm");
const text = fs.readFileSync(watPath, "utf8");
const mod = wabt.parseWat(watPath, text, { bulk_memory: true });
mod.resolveNames();
mod.validate();
const { buffer } = mod.toBinary({ canonicalize_lebs: true, write_debug_names: true });
fs.mkdirSync(path.dirname(outPath), { recursive: true });
fs.writeFileSync(outPath, Buffer.from(buffer));
console.log(`Wrote ${outPath} (${buffer.length} bytes)`);
