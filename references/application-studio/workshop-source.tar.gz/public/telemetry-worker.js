/* Synthetic industrial telemetry engine. 100,000 logical rows × 100 numeric signals.
 * Numeric data is genuinely column-major (signal * CAPACITY + row); metadata is in typed columns.
 * No row objects and no per-tick full table transfer. Queries, sorting and WASM aggregation remain off the UI thread.
 */
const CAPACITY = 100000, SIGNALS = 100, DEVICES = 160;
const PLANTS = ['Houston', 'Rotterdam', 'Singapore', 'Calgary', 'Perth', 'Ulsan', 'Aberdeen', 'Jubail'];
const NAMES = ['vibration', 'temperature', 'pressure', 'flow', 'current', 'voltage', 'rpm', 'torque', 'humidity', 'acoustic'];
const COLUMNS = Array.from({ length: SIGNALS }, (_, c) => `${NAMES[Math.floor(c / 10)]}_${String(c % 10 + 1).padStart(2, '0')}`);
let values, plants, devices, assets, statuses, priorities, timestamps, sequence, latestAsset;
let wasm = null, initialised = false, timer = null, paused = true, written = 0, version = 0, lastTickAt = 0;

function random(n) {
  let x = Math.imul(n ^ 0x9e3779b9, 0x85ebca6b);
  x ^= x >>> 13; x = Math.imul(x, 0xc2b2ae35);
  return ((x ^ x >>> 16) >>> 0) / 4294967296;
}
const at = (c, row) => c * CAPACITY + row;
function initData() {
  values = new Float32Array(CAPACITY * SIGNALS); // 40 MB, never transferred wholesale
  plants = new Uint8Array(CAPACITY);
  devices = new Uint16Array(CAPACITY);
  assets = new Uint16Array(CAPACITY);
  statuses = new Uint8Array(CAPACITY);
  priorities = new Uint8Array(CAPACITY);
  timestamps = new Float64Array(CAPACITY);
  sequence = new Uint32Array(CAPACITY);
  latestAsset = new Int32Array(120);
  const start = Date.now() - CAPACITY * 50;
  for (let row = 0; row < CAPACITY; row++) {
    const device = row % DEVICES, asset = device % 120;
    plants[row] = device % PLANTS.length;
    devices[row] = device; assets[row] = asset;
    statuses[row] = row % 79 < 61 ? 0 : row % 79 < 72 ? 1 : row % 79 < 76 ? 2 : 3;
    priorities[row] = row % 17 < 2 ? 0 : row % 17 < 11 ? 1 : 2;
    timestamps[row] = start + row * 50; sequence[row] = row;
    latestAsset[asset] = row;
  }
  // Contiguous writes per signal; row reads are copied into a small window-sized payload on demand.
  for (let c = 0; c < SIGNALS; c++) {
    const type = Math.floor(c / 10);
    const base = [3, 45, 14, 180, 18, 220, 560, 12, 34, 10][type];
    const span = [14, 39, 22, 120, 18, 10, 580, 27, 45, 24][type];
    const wave = new Float32Array(128);
    for (let i = 0; i < 128; i++) wave[i] = Math.sin(i / 17 + c) * (type === 0 ? 1.8 : span * .045);
    const offset = c * CAPACITY;
    for (let r = 0; r < CAPACITY; r++) values[offset + r] = base + random(r * 131 + c * 17) * span + wave[r & 127];
  }
  initialised = true;
}

function pushLiveBatch() {
  if (paused || !initialised) return;
  const begun = performance.now(), now = Date.now(), batch = 256;
  for (let j = 0; j < batch; j++) {
    const row = (written + j) % CAPACITY, device = devices[row], asset = assets[row];
    const step = Math.sin((written + j) / 23 + device) * .17;
    for (let c = 0; c < SIGNALS; c++) {
      const type = Math.floor(c / 10), scale = type === 0 ? 1.9 : type === 1 ? 4 : type === 2 ? 1.2 : .7;
      values[at(c, row)] = Math.max(0, values[at(c, row)] + step * scale + (random((written + j) * 19 + c) - .5) * scale);
    }
    const vib = values[at(0, row)];
    statuses[row] = vib > 16 ? 2 : vib > 11.5 ? 1 : 0;
    timestamps[row] = now; sequence[row] = CAPACITY + written + j;
    latestAsset[asset] = row;
  }
  written += batch; version++;
  const elapsedMs = performance.now() - begun;
  const dt = lastTickAt ? now - lastTickAt : 100;
  lastTickAt = now;
  self.postMessage({ type: 'tick', version, written, batch, rowsPerSecond: Math.round(batch * 1000 / Math.max(1, dt)), elapsedMs });
}

function query(request) {
  const f = request.filter || {}, sort = request.sort;
  const plantSet = new Set(f.plants || []), statusSet = new Set(f.statuses || []);
  const text = String(f.search || '').trim().toLowerCase();
  const signal = Number.isInteger(f.signalIndex) ? Math.max(0, Math.min(SIGNALS - 1, f.signalIndex)) : -1;
  const min = Number(f.min), max = Number(f.max);
  const result = new Uint32Array(CAPACITY);
  const started = performance.now();
  let n = 0;
  for (let row = 0; row < CAPACITY; row++) {
    if (plantSet.size && !plantSet.has(plants[row])) continue;
    if (statusSet.size && !statusSet.has(statuses[row])) continue;
    if (f.deviceId != null && devices[row] !== f.deviceId) continue;
    if (f.assetId != null && assets[row] !== f.assetId) continue;
    if (f.timeFrom != null && timestamps[row] < f.timeFrom) continue;
    if (f.timeTo != null && timestamps[row] > f.timeTo) continue;
    if (signal >= 0) {
      const v = values[at(signal, row)];
      if (Number.isFinite(min) && v < min || Number.isFinite(max) && v > max) continue;
    }
    if (text && !PLANTS[plants[row]].toLowerCase().includes(text) && !`dev-${String(devices[row] + 1).padStart(4, '0')}`.includes(text) && !`ast-${String(1000 + assets[row]).padStart(4, '0')}`.includes(text) && !String(sequence[row]).includes(text)) continue;
    result[n++] = row;
  }
  const indices = result.slice(0, n);
  if (sort) {
    const desc = sort.direction === 'desc' ? -1 : 1, field = sort.property, c = Math.max(0, Math.min(SIGNALS - 1, Number(sort.signal) || 0));
    const col = field === 'time' || field === 'eventTime' ? timestamps : field === 'plant' ? plants : field === 'device' ? devices : field === 'status' ? statuses : field === 'asset' ? assets : null;
    indices.sort((a, b) => {
      const av = col ? col[a] : values[at(c, a)], bv = col ? col[b] : values[at(c, b)];
      return (av - bv) * desc || a - b;
    });
  }
  self.postMessage({ type: 'query', requestId: request.requestId, indices, total: n, elapsedMs: performance.now() - started, version }, [indices.buffer]);
}

function windowRows(request) {
  const indices = request.indices ? new Uint32Array(request.indices) : null;
  const from = Math.max(0, request.from | 0), requested = Math.min(300, Math.max(0, (request.to | 0) - from));
  const startColumn = Math.max(0, Math.min(SIGNALS, request.colFrom | 0));
  const endColumn = Math.max(startColumn, Math.min(SIGNALS, request.colTo | 0));
  const count = indices ? Math.min(indices.length, requested) : Math.max(0, Math.min(requested, CAPACITY - from));
  const stride = endColumn - startColumn;
  const out = new Float32Array(count * stride), p = new Uint8Array(count), d = new Uint16Array(count), a = new Uint16Array(count), s = new Uint8Array(count), t = new Float64Array(count), seq = new Uint32Array(count);
  for (let i = 0; i < count; i++) {
    const row = indices ? indices[i] : from + i;
    p[i] = plants[row]; d[i] = devices[row]; a[i] = assets[row]; s[i] = statuses[row]; t[i] = timestamps[row]; seq[i] = sequence[row];
    for (let c = 0; c < stride; c++) out[i * stride + c] = values[at(startColumn + c, row)];
  }
  self.postMessage({ type: 'window', requestId: request.requestId, from, colFrom: startColumn, colTo: endColumn, values: out, plants: p, devices: d, assets: a, statuses: s, times: t, keys: seq, version }, [out.buffer, p.buffer, d.buffer, a.buffer, s.buffer, t.buffer, seq.buffer]);
}

function latestRows(request) {
  const n = Math.max(0, Math.min(2048, request.count | 0));
  const order = new Uint32Array(n);
  // When streaming hasn't started, the newest historical rows sit at the end of the ring.
  const end = written > 0 ? written % CAPACITY : CAPACITY;
  for (let i = 0; i < n; i++) order[i] = (end - n + i + CAPACITY * 2) % CAPACITY;
  windowRows({ ...request, from: 0, to: n, indices: order.buffer });
}

function drain(request) {
  const requested = Math.max(1, Math.min(4096, request.limit | 0));
  const latest = CAPACITY + written - 1;
  const earliest = Math.max(0, latest - CAPACITY + 1);
  const initial = request.cursor == null || !Number.isFinite(Number(request.cursor));
  const wanted = initial ? Math.max(earliest, latest - requested + 1) : Math.max(0, Number(request.cursor));
  const dropped = Math.max(0, earliest - wanted);
  const start = Math.max(earliest, wanted);
  const n = Math.max(0, Math.min(requested, latest - start + 1));
  const colFrom = Math.max(0, Math.min(SIGNALS, request.colFrom | 0));
  const colTo = Math.max(colFrom, Math.min(SIGNALS, request.colTo == null ? SIGNALS : request.colTo | 0));
  const stride = colTo - colFrom;
  const out = new Float32Array(n * stride), p = new Uint8Array(n), d = new Uint16Array(n), a = new Uint16Array(n), s = new Uint8Array(n), t = new Float64Array(n), seq = new Uint32Array(n);
  for (let i = 0; i < n; i++) {
    const key = start + i;
    const row = key < CAPACITY ? key : (key - CAPACITY) % CAPACITY;
    p[i] = plants[row]; d[i] = devices[row]; a[i] = assets[row]; s[i] = statuses[row]; t[i] = timestamps[row]; seq[i] = sequence[row];
    for (let c = 0; c < stride; c++) out[i * stride + c] = values[at(colFrom + c, row)];
  }
  self.postMessage({ type: 'drain', requestId: request.requestId, nextCursor: start + n, backlog: Math.max(0, latest - (start + n) + 1), dropped, values: out, plants: p, devices: d, assets: a, statuses: s, times: t, keys: seq, colFrom, colTo, version }, [out.buffer, p.buffer, d.buffer, a.buffer, s.buffer, t.buffer, seq.buffer]);
}

function assetSample(request) {
  const i = Number(String(request.assetId || '').match(/\d+/)?.[0]) - 1000;
  if (!Number.isInteger(i) || i < 0 || i >= 120) { self.postMessage({ type: 'sample', requestId: request.requestId, error: 'Unknown Asset ID' }); return; }
  const row = latestAsset[i], signals = new Float32Array(SIGNALS);
  for (let c = 0; c < SIGNALS; c++) signals[c] = values[at(c, row)];
  self.postMessage({ type: 'sample', requestId: request.requestId, assetId: `AST-${String(i + 1000).padStart(4, '0')}`, deviceId: devices[row], plantId: plants[row], time: timestamps[row], key: sequence[row], status: statuses[row], version, signals }, [signals.buffer]);
}

function aggregate(request) {
  const start = Math.max(0, Math.min(CAPACITY, request.from | 0)), end = Math.max(start, Math.min(CAPACITY, request.to | 0));
  const signal = Math.max(0, Math.min(SIGNALS - 1, request.signal | 0)), n = end - start;
  const threshold = Number(request.threshold ?? Infinity);
  const t0 = performance.now();
  let sum = 0, mean = 0, min = 0, max = 0, above = 0, accelerated = false;
  if (wasm) {
    const mem = wasm.memory, input = values.subarray(at(signal, start), at(signal, end));
    const outputPtr = Math.ceil(n * 4 / 65536) * 65536 + 64;
    const requiredPages = Math.ceil((outputPtr + 32) / 65536);
    if (requiredPages > mem.buffer.byteLength / 65536) mem.grow(requiredPages - mem.buffer.byteLength / 65536);
    new Float32Array(mem.buffer, 0, n).set(input);
    wasm.stats(0, n, threshold, outputPtr);
    const result = new Float32Array(mem.buffer, outputPtr, 5);
    [sum, mean, min, max, above] = result;
    accelerated = true;
  } else if (n) {
    min = Infinity; max = -Infinity;
    for (let r = start; r < end; r++) {
      const v = values[at(signal, r)]; sum += v; min = Math.min(min, v); max = Math.max(max, v); if (v > threshold) above++;
    }
    mean = sum / n;
  }
  self.postMessage({ type: 'aggregate', requestId: request.requestId, stats: { count: n, sum, mean, min, max, above, wasm: accelerated, elapsedMs: performance.now() - t0 }, signal, from: start, to: end });
}

self.onmessage = async event => {
  const request = event.data || {};
  if (request.type === 'init') {
    if (!initialised) {
      const t0 = performance.now();
      initData();
      try {
        const response = await fetch('/wasm/telemetry_stats.wasm');
        if (!response.ok) throw new Error(`WASM HTTP ${response.status}`);
        const { instance } = await WebAssembly.instantiate(await response.arrayBuffer());
        wasm = instance.exports;
      } catch { wasm = null; }
      self.postMessage({ type: 'ready', capacity: CAPACITY, columns: SIGNALS, devices: DEVICES, plants: PLANTS, signalNames: NAMES, columnNames: COLUMNS, elapsedMs: performance.now() - t0, wasm: !!wasm });
    }
    if (request.autoStart) { paused = false; timer = setInterval(pushLiveBatch, Math.max(50, request.intervalMs || 100)); }
    return;
  }
  if (!initialised) { self.postMessage({ type: 'error', requestId: request.requestId, message: 'Telemetry engine is not initialised' }); return; }
  try {
    if (request.type === 'start') { paused = false; if (timer) clearInterval(timer); timer = setInterval(pushLiveBatch, Math.max(50, request.intervalMs || 100)); }
    else if (request.type === 'pause') paused = !!request.paused;
    else if (request.type === 'stop') { paused = true; if (timer) { clearInterval(timer); timer = null; } }
    else if (request.type === 'query') query(request);
    else if (request.type === 'window') windowRows(request);
    else if (request.type === 'latest') latestRows(request);
    else if (request.type === 'drain') drain(request);
    else if (request.type === 'sample') assetSample(request);
    else if (request.type === 'aggregate') aggregate(request);
    else if (request.type === 'health') self.postMessage({ type: 'health', requestId: request.requestId, capacity: CAPACITY, columns: SIGNALS, wasm: !!wasm, version });
    else self.postMessage({ type: 'error', requestId: request.requestId, message: `Unsupported worker command: ${request.type}` });
  } catch (error) {
    self.postMessage({ type: 'error', requestId: request.requestId, message: String(error && error.message || error) });
  }
};
